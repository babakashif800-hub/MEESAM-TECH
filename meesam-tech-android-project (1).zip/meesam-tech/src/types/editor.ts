export interface VideoAsset {
  id: string;
  name: string;
  size: number;
  duration: number;
  width: number;
  height: number;
  mimeType: string;
  url: string;
  file?: File;
  isSample?: boolean;
  mediaKind?: 'video' | 'image';
}

export type KeyframeEasing = 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';

export interface TransformKeyframe {
  id: string;
  time: number; // source timeline seconds
  x: number; // -50..50 (% of stage width)
  y: number; // -50..50 (% of stage height)
  scale: number; // 0.25..3.0
  rotation: number; // -180..180 degrees
  opacity: number; // 0..1
  easing: KeyframeEasing;
}

export interface SpeedCurvePoint {
  id: string;
  position: number; // 0..1 normalized position within segment
  speed: number; // 0.25..4.0
}

export type TransitionType =
  | 'none'
  | 'fade'
  | 'dissolve'
  | 'wipe-left'
  | 'wipe-right'
  | 'slide-up'
  | 'zoom';

export interface ClipTransition {
  type: TransitionType;
  duration: number; // seconds, e.g. 0.2 to 2.0
}

export interface TimelineSegment {
  id: string;
  start: number;
  end: number;
  deleted: boolean;
  meta?: {
    speed?: number; // 0.1 to 4.0, default 1.0
    speedCurve?: SpeedCurvePoint[];
    smoothSlowMo?: boolean; // Optional frame-blended slow motion on export
    muted?: boolean;
    volume?: number; // 0 to 1, default 1.0
    fadeInSec?: number; // 0 to 3.0s audio fade in
    fadeOutSec?: number; // 0 to 3.0s audio fade out
    transition?: ClipTransition; // entry transition for this segment
  };
}

export interface MotionTrackPoint {
  time: number; // source timeline seconds
  x: number; // -50..50 (% of stage width relative to center)
  y: number; // -50..50 (% of stage height relative to center)
  confidence?: number; // 0..1
}

export interface MotionTrack {
  id: string;
  label: string;
  anchorX: number; // -50..50 initial target (% relative to center)
  anchorY: number; // -50..50 initial target (% relative to center)
  startTime: number;
  endTime: number;
  points: MotionTrackPoint[];
}

export interface OverlayLayer {
  id: string;
  name: string;
  kind: 'video' | 'image';
  url: string;
  duration: number; // for images, project span; for videos, intrinsic duration
  width: number;
  height: number;
  startTime: number;
  endTime: number;
  x: number; // -50..50 (%)
  y: number; // -50..50 (%)
  scale: number; // 0.15..2.0 (relative to stage)
  rotation: number; // -180..180 degrees
  opacity: number; // 0..1
  muted: boolean;
  volume: number; // 0..1
  trackId?: string;
  keyframes: TransformKeyframe[];
}

export interface AudioLayer {
  id: string;
  name: string;
  url: string;
  duration: number;
  startTime: number;
  endTime: number;
  sourceOffsetSec?: number; // Start offset inside the audio file (trim song intro)
  volume: number; // 0..1.5
  muted: boolean;
  fadeInSec?: number; // 0..3.0s
  fadeOutSec?: number; // 0..3.0s
}

export type BgRemovalMode = 'off' | 'transparent' | 'blur' | 'color' | 'image';

export interface BgRemovalSettings {
  mode: BgRemovalMode;
  threshold: number; // 0.2..0.85
  edgeSoftness: number; // 0..10 px
  blurAmount: number; // 6..28 px
  bgColor: string;
  bgImageUrl?: string;
  bgImageName?: string;
}

export type ChromaKeyBgMode = 'transparent' | 'color' | 'image' | 'video';

export interface ChromaKeySettings {
  enabled: boolean;
  keyColor: string; // hex e.g. #00b140
  similarity: number; // 0.05..0.65
  smoothness: number; // 0.01..0.35
  spillSuppression: number; // 0..1
  bgMode: ChromaKeyBgMode;
  bgColor: string;
  bgImageUrl?: string;
  bgImageName?: string;
  bgVideoUrl?: string;
  bgVideoName?: string;
}

export interface StabilizationOffset {
  time: number;
  x: number; // % of stage width (-15..15)
  y: number; // % of stage height (-15..15)
}

export interface StabilizationSettings {
  enabled: boolean;
  strength: number; // 0..100
  autoScale: number; // 1.0..1.3
  analyzed: boolean;
  offsets: StabilizationOffset[];
}

export type MaskShape = 'none' | 'rect' | 'circle' | 'linear' | 'split';

export interface MaskSettings {
  shape: MaskShape;
  x: number; // -50..50 (% from stage center)
  y: number; // -50..50 (% from stage center)
  width: number; // 10..100 (% of stage width)
  height: number; // 10..100 (% of stage height)
  rotation: number; // -180..180 degrees
  feather: number; // 0..40 px
  invert: boolean;
}

export interface BeatAnalysis {
  bpm: number;
  beats: number[]; // source timeline seconds
  sensitivity: number; // 0.2..0.9
  sourceId: string; // 'main' or audio layer id
  sourceName: string;
}

export type FilterPresetId = string;

export type FilterCategory =
  | 'all'
  | 'cinematic'
  | 'nature'
  | 'portrait'
  | 'vintage'
  | 'dark'
  | 'food'
  | 'bw'
  | 'social';

export interface VideoAdjustments {
  filterPreset: FilterPresetId;
  filterIntensity: number; // 0..100 (100 = full preset strength)
  brightness: number; // 50..150 (100 = normal)
  contrast: number; // 50..150 (100 = normal)
  saturation: number; // 0..200 (100 = normal)
}

export type EffectCategory =
  | 'all'
  | 'cinematic'
  | 'blur'
  | '3d'
  | 'glitch'
  | 'vintage'
  | 'color'
  | 'light'
  | 'beauty'
  | 'ai'
  | 'magic'
  | 'transition';

export type VideoEffectId = string;

export interface VideoEffectLayer {
  id: string;
  effectId: VideoEffectId;
  enabled: boolean;
  intensity: number; // 0..100
  speed: number; // 0..100 (animation speed, spread, or secondary depth)
  startTime: number; // source timeline seconds
  endTime: number; // source timeline seconds
}

export type AspectRatioPreset = 'original' | '9:16' | '16:9' | '1:1' | '4:5';

export type FrameFitMode = 'contain' | 'cover';

export type TextStylePreset = 'clean' | 'outline' | 'boxed' | 'subtitle-bar' | 'pop';

export type TextPosition = 'top' | 'center' | 'bottom';

export type TextSizePreset = 'sm' | 'md' | 'lg';

export type AppLanguage = 'sd' | 'ur' | 'hi' | 'en' | 'zh';

export type ChineseVariant = 'zh-Hans' | 'zh-Hant';

export type TargetLanguageCode = 'sd' | 'ur' | 'hi' | 'en' | 'zh-Hans' | 'zh-Hant';

export type CaptionLanguage = 'auto' | TargetLanguageCode;

export type TtsVoiceName = 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';

export type TtsGenerationMode = 'tts' | 'voice_design';

export interface TextOverlay {
  id: string;
  text: string;
  startTime: number; // source timeline seconds
  endTime: number; // source timeline seconds
  color: string;
  style: TextStylePreset;
  position: TextPosition;
  size: TextSizePreset;
  scale?: number; // 0.5..2.5 direct on-video resize multiplier (default 1)
  opacity?: number; // 0.15..1.0 (handy for watermarks, default 1)
  kind?: 'text' | 'title' | 'subtitle' | 'watermark';
  isCaption?: boolean;
  isSticker?: boolean;
  x?: number; // -50..50 (% relative to stage center when positioned freely or motion tracked)
  y?: number; // -50..50 (% relative to stage center)
  trackId?: string;
  lang?: TargetLanguageCode;
  dir?: 'auto' | 'rtl' | 'ltr';
  keyframes?: TransformKeyframe[];
}

export type EditorPanelMode =
  | 'default'
  | 'ai'
  | 'layers'
  | 'keyframes'
  | 'motion'
  | 'bgremove'
  | 'chroma'
  | 'stabilize'
  | 'mask'
  | 'beats'
  | 'captions'
  | 'voice'
  | 'trim'
  | 'speed'
  | 'filters'
  | 'effects'
  | 'transitions'
  | 'text'
  | 'audio'
  | 'ratio';

export type PreviewScope = 'edited' | 'source';

export type ExportResolution = '4k' | '1080p' | '720p' | '480p' | 'original';

export interface SavedProjectSummary {
  id: string;
  name: string;
  updatedAt: number;
  createdAt: number;
  duration: number;
  width: number;
  height: number;
  mediaKind: 'video' | 'image';
  mimeType: string;
  aspectRatio: AspectRatioPreset;
  thumbnailDataUrl?: string;
}

export interface SavedProjectRecord extends SavedProjectSummary {
  assetBlobKey: string;
  assetSize: number;
  isSample?: boolean;
  edits: EditorProjectEdits;
}

export interface ExportState {
  status: 'idle' | 'rendering' | 'complete' | 'error';
  progress: number;
  detail?: string;
  blobUrl?: string;
  filename?: string;
  outputSize?: number;
  outputMime?: string;
}

export interface EditorProjectEdits {
  segments: TimelineSegment[];
  mainKeyframes: TransformKeyframe[];
  motionTracks: MotionTrack[];
  overlayLayers: OverlayLayer[];
  audioLayers: AudioLayer[];
  bgRemoval: BgRemovalSettings;
  chromaKey: ChromaKeySettings;
  stabilization: StabilizationSettings;
  mask: MaskSettings;
  beatAnalysis: BeatAnalysis | null;
  adjustments: VideoAdjustments;
  videoEffects?: VideoEffectLayer[];
  textOverlays: TextOverlay[];
  aspectRatio: AspectRatioPreset;
  frameFit: FrameFitMode;
}

export type AiEditMode =
  | 'auto_edit'
  | 'auto_cut'
  | 'auto_captions'
  | 'smart_filters'
  | 'custom_prompt';

export interface AiAutoCutRange {
  startTime: number;
  endTime: number;
  reason?: string;
  score?: number;
}

export interface AiSlowMoRange {
  startTime: number;
  endTime: number;
  speed: number;
  smoothSlowMo?: boolean;
  reason?: string;
}

export interface AiCaptionSuggestion {
  text: string;
  startTime: number;
  endTime: number;
  position?: TextPosition;
  style?: TextStylePreset;
  color?: string;
  size?: TextSizePreset;
  lang?: TargetLanguageCode;
}

export interface AiFilterRecommendation {
  filterId: string;
  reason: string;
}

export interface AiEditResult {
  summary: string;
  transcript?: string;
  detectedLanguage?: TargetLanguageCode;
  recommendedFilterId?: string;
  filterIntensity?: number;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  aspectRatio?: AspectRatioPreset;
  frameFit?: FrameFitMode;
  slowMoRanges?: AiSlowMoRange[];
  keepRanges?: AiAutoCutRange[];
  captions?: AiCaptionSuggestion[];
  filterRecommendations?: AiFilterRecommendation[];
}
