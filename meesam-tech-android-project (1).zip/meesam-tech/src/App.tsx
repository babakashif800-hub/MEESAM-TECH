import React, { useCallback, useEffect, useRef, useState } from 'react';
import { EditorToolbar } from './components/EditorToolbar';
import { ExportModal } from './components/ExportModal';
import { LanguageModal } from './components/LanguageModal';
import { ProjectsModal } from './components/ProjectsModal';
import { TimelineEditor } from './components/TimelineEditor';
import { ToolPanel } from './components/ToolPanel';
import { TopBar } from './components/TopBar';
import { UploadDropzone } from './components/UploadDropzone';
import { VideoPreview } from './components/VideoPreview';
import { getUiStrings } from './i18n/translations';
import {
  AiEditMode,
  AiEditResult,
  AppLanguage,
  AspectRatioPreset,
  AudioLayer,
  BeatAnalysis,
  BgRemovalSettings,
  CaptionLanguage,
  ChromaKeySettings,
  ChineseVariant,
  ClipTransition,
  EditorPanelMode,
  EditorProjectEdits,
  FrameFitMode,
  MaskSettings,
  MotionTrack,
  OverlayLayer,
  PreviewScope,
  SavedProjectSummary,
  SpeedCurvePoint,
  StabilizationSettings,
  TargetLanguageCode,
  TextOverlay,
  TextStylePreset,
  TimelineSegment,
  TransformKeyframe,
  TtsGenerationMode,
  TtsVoiceName,
  VideoAdjustments,
  VideoAsset,
  VideoEffectLayer,
} from './types/editor';
import {
  buildSrtContent,
  requestAiStudioEdit,
  requestAiTtsVoice,
  requestSpeechToText,
  requestTranslation,
} from './utils/aiClient';
import { downloadMediaFile } from './utils/androidBridge';
import {
  analyzeClipActivityWindows,
  buildSegmentsFromKeepRanges,
  selectKeepRangesFromWindows,
} from './utils/autoCut';
import { analyzeAudioBeats, splitSegmentsOnBeats } from './utils/beatDetector';
import { DEFAULT_CHROMA_KEY } from './utils/chromaKey';
import { findEffectDefinition } from './utils/effectsCatalog';
import {
  DEFAULT_ADJUSTMENTS,
  findFilterPreset,
  hasCustomAdjustments,
} from './utils/filters';
import {
  createMotionPresetKeyframes,
  DEFAULT_TRANSFORM,
  evaluateKeyframes,
} from './utils/keyframes';
import {
  detectScriptLanguage,
  FIVE_SUPPORTED_LANGUAGES,
  getHtmlLangAndDir,
  resolveTargetLanguageCode,
} from './utils/languages';
import { DEFAULT_MASK_SETTINGS } from './utils/maskRenderer';
import { trackObjectInVideo } from './utils/motionTracker';
import {
  deleteSavedProject,
  listSavedProjects,
  loadProjectFromIdb,
  saveProjectToIdb,
} from './utils/projectStorage';
import {
  createCurveFromPreset,
  hasCustomSpeedCurve,
  SpeedCurvePresetId,
} from './utils/speedCurve';
import {
  analyzeVideoStabilization,
  DEFAULT_STABILIZATION,
} from './utils/stabilizer';
import {
  clamp,
  findSegmentAtTime,
  getActiveSegments,
  getEditedDuration,
} from './utils/time';
import { createSampleVideoFile, generateThumbnails } from './utils/videoEngine';

const MIN_CLIP_DURATION = 0.25;

const DEFAULT_BG_REMOVAL: BgRemovalSettings = {
  mode: 'off',
  threshold: 0.55,
  edgeSoftness: 3,
  blurAmount: 14,
  bgColor: '#00b140',
};

function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export default function App() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const overlayInputRef = useRef<HTMLInputElement | null>(null);
  const audioInputRef = useRef<HTMLInputElement | null>(null);
  const bgImageInputRef = useRef<HTMLInputElement | null>(null);
  const chromaBgImageInputRef = useRef<HTMLInputElement | null>(null);
  const chromaBgVideoInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const lastDragHistoryRef = useRef<number>(0);

  const [asset, setAsset] = useState<VideoAsset | null>(null);
  const [segments, setSegments] = useState<TimelineSegment[]>([]);
  const [mainKeyframes, setMainKeyframes] = useState<TransformKeyframe[]>([]);
  const [motionTracks, setMotionTracks] = useState<MotionTrack[]>([]);
  const [pendingTrackTarget, setPendingTrackTarget] = useState<{ x: number; y: number } | null>({
    x: 0,
    y: 0,
  });
  const [motionTrackingProgress, setMotionTrackingProgress] = useState<number | null>(null);
  const [motionTrackError, setMotionTrackError] = useState<string | null>(null);
  const [overlayLayers, setOverlayLayers] = useState<OverlayLayer[]>([]);
  const [selectedOverlayId, setSelectedOverlayId] = useState<string>('');
  const [audioLayers, setAudioLayers] = useState<AudioLayer[]>([]);
  const [selectedAudioId, setSelectedAudioId] = useState<string>('');
  const [bgRemoval, setBgRemoval] = useState<BgRemovalSettings>(DEFAULT_BG_REMOVAL);
  const [bgModelError, setBgModelError] = useState<string | null>(null);
  const [chromaKey, setChromaKey] = useState<ChromaKeySettings>(DEFAULT_CHROMA_KEY);
  const [stabilization, setStabilization] = useState<StabilizationSettings>(DEFAULT_STABILIZATION);
  const [stabProgress, setStabProgress] = useState<number | null>(null);
  const [stabError, setStabError] = useState<string | null>(null);
  const [mask, setMask] = useState<MaskSettings>(DEFAULT_MASK_SETTINGS);
  const [beatAnalysis, setBeatAnalysis] = useState<BeatAnalysis | null>(null);
  const [beatsBusy, setBeatsBusy] = useState<boolean>(false);
  const [beatsError, setBeatsError] = useState<string | null>(null);
  const [autoCutBusy, setAutoCutBusy] = useState<boolean>(false);

  const [adjustments, setAdjustments] = useState<VideoAdjustments>(DEFAULT_ADJUSTMENTS);
  const [videoEffects, setVideoEffects] = useState<VideoEffectLayer[]>([]);
  const [selectedEffectId, setSelectedEffectId] = useState<string>('');
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);
  const [selectedTextId, setSelectedTextId] = useState<string>('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioPreset>('original');
  const [frameFit, setFrameFit] = useState<FrameFitMode>('contain');

  const [captionLanguage, setCaptionLanguage] = useState<CaptionLanguage>('auto');
  const [captionStyle, setCaptionStyle] = useState<TextStylePreset>('subtitle-bar');
  const [captionColor, setCaptionColor] = useState<string>('#ffffff');
  const [captionsSaved, setCaptionsSaved] = useState<boolean>(false);
  const captionsSavedTimerRef = useRef<number | null>(null);

  const [history, setHistory] = useState<EditorProjectEdits[]>([]);
  const [redoHistory, setRedoHistory] = useState<EditorProjectEdits[]>([]);
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>('');
  const [thumbnails, setThumbnails] = useState<string[]>([]);

  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [previewScope, setPreviewScope] = useState<PreviewScope>('edited');
  const [panelMode, setPanelMode] = useState<EditorPanelMode>('default');

  const [isLoadingSample, setIsLoadingSample] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);

  // Saved Projects (IndexedDB)
  const [savedProjects, setSavedProjects] = useState<SavedProjectSummary[]>([]);
  const [currentSavedProjectId, setCurrentSavedProjectId] = useState<string | null>(null);
  const [isProjectsModalOpen, setIsProjectsModalOpen] = useState<boolean>(false);
  const [isSavingProject, setIsSavingProject] = useState<boolean>(false);
  const [loadingProjectId, setLoadingProjectId] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState<boolean>(false);
  const [projectsError, setProjectsError] = useState<string | null>(null);
  const savedTimerRef = useRef<number | null>(null);

  // Strictly 5-language App UI & Script Settings
  const [uiLanguage, setUiLanguage] = useState<AppLanguage>(() => {
    try {
      const saved = localStorage.getItem('meesam_ui_lang');
      if (saved === 'sd' || saved === 'ur' || saved === 'hi' || saved === 'en' || saved === 'zh') {
        return saved;
      }
    } catch {
      // Ignore storage failures
    }
    return 'en';
  });
  const [chineseVariant, setChineseVariant] = useState<ChineseVariant>(() => {
    try {
      const saved = localStorage.getItem('meesam_zh_variant');
      if (saved === 'zh-Hans' || saved === 'zh-Hant') return saved;
    } catch {
      // Ignore storage failures
    }
    return 'zh-Hans';
  });
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState<boolean>(false);

  const [aiBusy, setAiBusy] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiResult, setAiResult] = useState<AiEditResult | null>(null);

  // Speech-to-Text & Subtitle Translation state
  const [speechTranscript, setSpeechTranscript] = useState<string>('');
  const [speechBusy, setSpeechBusy] = useState<boolean>(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [isRecordingMic, setIsRecordingMic] = useState<boolean>(false);
  const micRecorderRef = useRef<MediaRecorder | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);

  const [translateTargetLang, setTranslateTargetLang] = useState<TargetLanguageCode>('ur');
  const [translateBusy, setTranslateBusy] = useState<boolean>(false);

  // Text-to-Speech & AI Voice Generation state
  const [ttsText, setTtsText] = useState<string>('');
  const [ttsLang, setTtsLang] = useState<TargetLanguageCode>(() =>
    resolveTargetLanguageCode(uiLanguage, chineseVariant)
  );
  const [ttsLangAutoDetected, setTtsLangAutoDetected] = useState<boolean>(false);
  const [ttsLangManual, setTtsLangManual] = useState<boolean>(false);
  const [ttsVoice, setTtsVoice] = useState<TtsVoiceName>('Kore');
  const [ttsMode, setTtsMode] = useState<TtsGenerationMode>('tts');
  const [ttsStylePrompt, setTtsStylePrompt] = useState<string>('');
  const [ttsBusy, setTtsBusy] = useState<boolean>(false);
  const [ttsError, setTtsError] = useState<string | null>(null);
  const [ttsResultUrl, setTtsResultUrl] = useState<string | null>(null);
  const [ttsResultDuration, setTtsResultDuration] = useState<number>(0);
  const [ttsResultModel, setTtsResultModel] = useState<string | null>(null);

  // Video Text Overlay Translation target
  const [textTranslateTargetLang, setTextTranslateTargetLang] = useState<TargetLanguageCode>('sd');
  const [textTranslateBusy, setTextTranslateBusy] = useState<boolean>(false);

  const createdUrlsRef = useRef<Set<string>>(new Set());
  const urlToBlobMapRef = useRef<Map<string, Blob>>(new Map());

  const strings = getUiStrings(uiLanguage, chineseVariant);

  useEffect(() => {
    listSavedProjects().then(setSavedProjects).catch(() => {});
  }, []);

  useEffect(() => {
    const { htmlLang, dir } = getHtmlLangAndDir(uiLanguage, chineseVariant);
    document.documentElement.lang = htmlLang;
    document.documentElement.dir = dir;
    try {
      localStorage.setItem('meesam_ui_lang', uiLanguage);
      localStorage.setItem('meesam_zh_variant', chineseVariant);
    } catch {
      // Ignore storage errors
    }
  }, [uiLanguage, chineseVariant]);

  const trackObjectUrl = useCallback((url: string, blob?: Blob) => {
    createdUrlsRef.current.add(url);
    if (blob) {
      urlToBlobMapRef.current.set(url, blob);
    }
    return url;
  }, []);

  useEffect(() => {
    const urls = createdUrlsRef.current;
    const blobMap = urlToBlobMapRef.current;
    return () => {
      urls.forEach((url) => URL.revokeObjectURL(url));
      urls.clear();
      blobMap.clear();
      if (savedTimerRef.current !== null) {
        window.clearTimeout(savedTimerRef.current);
      }
      if (captionsSavedTimerRef.current !== null) {
        window.clearTimeout(captionsSavedTimerRef.current);
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  useEffect(() => {
    return () => {
      if (asset?.url) {
        URL.revokeObjectURL(asset.url);
      }
    };
  }, [asset]);

  const loadVideoFile = useCallback(async (file: File, isSample = false) => {
    setUploadError(null);
    const isVideo =
      file.type.startsWith('video/') ||
      Boolean(file.name.match(/\.(mp4|webm|mov|m4v|mkv)$/i));
    const isImage =
      !isVideo &&
      (file.type.startsWith('image/') ||
        Boolean(file.name.match(/\.(png|jpe?g|webp|gif|bmp|heic|avif)$/i)));

    if (!isVideo && !isImage) {
      setUploadError(
        'Please select a valid video (MP4, WebM, MOV) or photo (JPG, PNG, WebP) file.'
      );
      return;
    }

    const objectUrl = URL.createObjectURL(file);

    try {
      const meta = isImage
        ? await new Promise<{
            duration: number;
            width: number;
            height: number;
            smallThumb: string;
          }>((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
              const w = img.naturalWidth || 1280;
              const h = img.naturalHeight || 720;
              let smallThumb = objectUrl;
              try {
                const c = document.createElement('canvas');
                const targetH = 96;
                const targetW = Math.max(64, Math.round((w / Math.max(1, h)) * targetH));
                c.width = targetW;
                c.height = targetH;
                const ctx = c.getContext('2d');
                if (ctx) {
                  ctx.drawImage(img, 0, 0, targetW, targetH);
                  smallThumb = c.toDataURL('image/jpeg', 0.72);
                }
              } catch {
                smallThumb = objectUrl;
              }
              resolve({ duration: 5.0, width: w, height: h, smallThumb });
            };
            img.onerror = () => {
              reject(new Error('This photo could not be decoded by your browser.'));
            };
            img.src = objectUrl;
          })
        : await new Promise<{
            duration: number;
            width: number;
            height: number;
            smallThumb?: string;
          }>((resolve, reject) => {
            const probe = document.createElement('video');
            probe.preload = 'metadata';
            probe.playsInline = true;
            probe.muted = true;
            probe.src = objectUrl;

            const timeout = window.setTimeout(() => {
              reject(new Error('Timed out reading video metadata.'));
            }, 8000);

            probe.onloadedmetadata = () => {
              window.clearTimeout(timeout);
              const dur =
                Number.isFinite(probe.duration) && probe.duration > 0 ? probe.duration : 0;
              if (dur <= 0.1) {
                reject(new Error('This video file appears empty or unsupported.'));
                return;
              }
              resolve({
                duration: dur,
                width: probe.videoWidth || 1280,
                height: probe.videoHeight || 720,
              });
            };

            probe.onerror = () => {
              window.clearTimeout(timeout);
              reject(new Error('This video format could not be decoded by your browser.'));
            };
          });

      const initialSegId = makeId('seg');
      const nextAsset: VideoAsset = {
        id: `asset-${Date.now()}`,
        name: file.name,
        size: file.size,
        duration: meta.duration,
        width: meta.width,
        height: meta.height,
        mimeType: file.type || (isImage ? 'image/jpeg' : 'video/mp4'),
        url: objectUrl,
        file,
        isSample,
        mediaKind: isImage ? 'image' : 'video',
      };

      setIsPlaying(false);
      setAsset(nextAsset);
      setSegments([
        {
          id: initialSegId,
          start: 0,
          end: meta.duration,
          deleted: false,
        },
      ]);
      setMainKeyframes([]);
      setMotionTracks([]);
      setPendingTrackTarget({ x: 0, y: 0 });
      setMotionTrackError(null);
      setOverlayLayers([]);
      setSelectedOverlayId('');
      setAudioLayers([]);
      setSelectedAudioId('');
      setBgRemoval(DEFAULT_BG_REMOVAL);
      setBgModelError(null);
      setChromaKey(DEFAULT_CHROMA_KEY);
      setStabilization(DEFAULT_STABILIZATION);
      setStabError(null);
      setMask(DEFAULT_MASK_SETTINGS);
      setBeatAnalysis(null);
      setBeatsError(null);
      setAdjustments(DEFAULT_ADJUSTMENTS);
      setVideoEffects([]);
      setSelectedEffectId('');
      setTextOverlays([]);
      setSelectedTextId('');
      setAspectRatio('original');
      setFrameFit('contain');
      setSelectedSegmentId(initialSegId);
      setHistory([]);
      setRedoHistory([]);
      setCurrentSavedProjectId(null);
      setThumbnails([]);
      setCurrentTime(0);
      setPanelMode('default');
      setPreviewScope('edited');
      setAiError(null);
      setAiResult(null);
      setSpeechTranscript('');
      setSpeechError(null);
      setCaptionsSaved(false);

      if (isImage && meta.smallThumb) {
        setThumbnails(Array.from({ length: 10 }, () => meta.smallThumb!));
      } else {
        generateThumbnails(objectUrl, meta.duration, 12).then((frames) => {
          setThumbnails(frames);
        });
      }
    } catch (err) {
      URL.revokeObjectURL(objectUrl);
      setUploadError(
        err instanceof Error ? err.message : 'Unable to open this media file.'
      );
    }
  }, []);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (file) {
      loadVideoFile(file, false);
    }
  };

  const handleTriggerUpload = () => {
    fileInputRef.current?.click();
  };

  const handleLoadSample = async () => {
    setIsLoadingSample(true);
    setUploadError(null);
    try {
      const sampleFile = await createSampleVideoFile();
      await loadVideoFile(sampleFile, true);
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Could not prepare sample clip.'
      );
    } finally {
      setIsLoadingSample(false);
    }
  };

  const seekTo = useCallback(
    (time: number) => {
      if (!asset) return;
      const clamped = clamp(time, 0, asset.duration);
      setCurrentTime(clamped);
      if (videoRef.current) {
        videoRef.current.currentTime = clamped;
      }
    },
    [asset]
  );

  const handleTogglePlay = useCallback(() => {
    if (!asset) return;

    if (asset.mediaKind === 'image') {
      if (isPlaying) {
        setIsPlaying(false);
        return;
      }
      const active = getActiveSegments(segments);
      if (previewScope === 'edited' && active.length > 0) {
        const inside = active.find(
          (s) => currentTime >= s.start - 0.04 && currentTime < s.end - 0.05
        );
        if (!inside) {
          const next = active.find((s) => s.start >= currentTime) ?? active[0];
          setCurrentTime(next.start);
        }
      }
      setIsPlaying(true);
      return;
    }

    const vid = videoRef.current;
    if (!vid) return;

    if (!vid.paused) {
      vid.pause();
      setIsPlaying(false);
      return;
    }

    const active = getActiveSegments(segments);
    if (previewScope === 'edited' && active.length > 0) {
      const inside = active.find(
        (s) => vid.currentTime >= s.start - 0.04 && vid.currentTime < s.end - 0.05
      );
      if (!inside) {
        const next = active.find((s) => s.start >= vid.currentTime) ?? active[0];
        vid.currentTime = next.start;
        setCurrentTime(next.start);
      }
    }

    vid.play().catch(() => {
      setIsPlaying(false);
    });
  }, [asset, currentTime, isPlaying, previewScope, segments]);

  const handleStepTime = useCallback(
    (delta: number) => {
      if (!asset) return;
      seekTo(currentTime + delta);
    },
    [asset, currentTime, seekTo]
  );

  const buildCurrentSnapshot = useCallback((): EditorProjectEdits => {
    return {
      segments: segments.map((s) => ({
        ...s,
        meta: s.meta
          ? {
              ...s.meta,
              speedCurve: s.meta.speedCurve
                ? s.meta.speedCurve.map((pt) => ({ ...pt }))
                : undefined,
              transition: s.meta.transition ? { ...s.meta.transition } : undefined,
            }
          : undefined,
      })),
      mainKeyframes: mainKeyframes.map((k) => ({ ...k })),
      motionTracks: motionTracks.map((tr) => ({
        ...tr,
        points: tr.points.map((pt) => ({ ...pt })),
      })),
      overlayLayers: overlayLayers.map((o) => ({
        ...o,
        keyframes: o.keyframes.map((k) => ({ ...k })),
      })),
      audioLayers: audioLayers.map((a) => ({ ...a })),
      bgRemoval: { ...bgRemoval },
      chromaKey: { ...chromaKey },
      stabilization: {
        ...stabilization,
        offsets: stabilization.offsets.map((off) => ({ ...off })),
      },
      mask: { ...mask },
      beatAnalysis: beatAnalysis
        ? { ...beatAnalysis, beats: [...beatAnalysis.beats] }
        : null,
      adjustments: { ...adjustments },
      videoEffects: videoEffects.map((fx) => ({ ...fx })),
      textOverlays: textOverlays.map((t) => ({ ...t })),
      aspectRatio,
      frameFit,
    };
  }, [
    adjustments,
    aspectRatio,
    audioLayers,
    beatAnalysis,
    bgRemoval,
    chromaKey,
    frameFit,
    mainKeyframes,
    mask,
    motionTracks,
    overlayLayers,
    segments,
    stabilization,
    textOverlays,
    videoEffects,
  ]);

  const applySnapshot = useCallback(
    (snapshot: EditorProjectEdits) => {
      const nextEffects = (snapshot.videoEffects ?? []).map((fx) => ({ ...fx }));
      setSegments(snapshot.segments);
      setMainKeyframes(snapshot.mainKeyframes);
      setMotionTracks(snapshot.motionTracks);
      setOverlayLayers(snapshot.overlayLayers);
      setAudioLayers(snapshot.audioLayers);
      setBgRemoval(snapshot.bgRemoval);
      setChromaKey(snapshot.chromaKey);
      setStabilization(snapshot.stabilization);
      setMask(snapshot.mask);
      setBeatAnalysis(snapshot.beatAnalysis);
      setAdjustments(snapshot.adjustments);
      setVideoEffects(nextEffects);
      setTextOverlays(snapshot.textOverlays);
      setAspectRatio(snapshot.aspectRatio);
      setFrameFit(snapshot.frameFit);

      if (
        !snapshot.segments.some((s) => s.id === selectedSegmentId) &&
        snapshot.segments[0]
      ) {
        setSelectedSegmentId(snapshot.segments[0].id);
      }
      if (!nextEffects.some((fx) => fx.id === selectedEffectId)) {
        setSelectedEffectId(nextEffects[0]?.id ?? '');
      }
      if (!snapshot.textOverlays.some((t) => t.id === selectedTextId)) {
        setSelectedTextId(snapshot.textOverlays[0]?.id ?? '');
      }
      if (!snapshot.overlayLayers.some((o) => o.id === selectedOverlayId)) {
        setSelectedOverlayId(snapshot.overlayLayers[0]?.id ?? '');
      }
      if (!snapshot.audioLayers.some((a) => a.id === selectedAudioId)) {
        setSelectedAudioId(snapshot.audioLayers[0]?.id ?? '');
      }
    },
    [selectedAudioId, selectedEffectId, selectedOverlayId, selectedSegmentId, selectedTextId]
  );

  const pushHistory = useCallback(() => {
    const snapshot = buildCurrentSnapshot();
    setHistory((prev) => [...prev.slice(-29), snapshot]);
    setRedoHistory([]);
  }, [buildCurrentSnapshot]);

  const recordHistoryDebounced = useCallback(() => {
    const now = Date.now();
    if (now - lastDragHistoryRef.current > 450) {
      pushHistory();
    }
    lastDragHistoryRef.current = now;
  }, [pushHistory]);

  // Overlay Layer upload handler (Image or Video PiP)
  const handleOverlayFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !asset) return;

    const isVideo =
      file.type.startsWith('video/') || Boolean(file.name.match(/\.(mp4|webm|mov|m4v)$/i));
    const isImage =
      file.type.startsWith('image/') ||
      Boolean(file.name.match(/\.(png|jpe?g|webp|gif|bmp)$/i));
    if (!isVideo && !isImage) {
      setUploadError('Overlay must be a video or image file.');
      return;
    }

    const url = trackObjectUrl(URL.createObjectURL(file), file);

    try {
      const meta = isVideo
        ? await new Promise<{ duration: number; width: number; height: number }>(
            (resolve, reject) => {
              const probe = document.createElement('video');
              probe.preload = 'metadata';
              probe.muted = true;
              probe.playsInline = true;
              probe.src = url;
              probe.onloadedmetadata = () => {
                resolve({
                  duration: Math.max(0.5, probe.duration || 4),
                  width: probe.videoWidth || 640,
                  height: probe.videoHeight || 360,
                });
              };
              probe.onerror = () => reject(new Error('Could not read overlay video.'));
            }
          )
        : await new Promise<{ duration: number; width: number; height: number }>(
            (resolve, reject) => {
              const img = new Image();
              img.onload = () => {
                resolve({
                  duration: Math.min(5, asset.duration),
                  width: img.naturalWidth || 512,
                  height: img.naturalHeight || 512,
                });
              };
              img.onerror = () => reject(new Error('Could not read overlay image.'));
              img.src = url;
            }
          );

      pushHistory();
      const id = makeId('ov');
      const startTime = clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
      const endTime = clamp(startTime + meta.duration, startTime + 0.5, asset.duration);

      const newLayer: OverlayLayer = {
        id,
        name: file.name,
        kind: isVideo ? 'video' : 'image',
        url,
        duration: meta.duration,
        width: meta.width,
        height: meta.height,
        startTime,
        endTime,
        x: 20,
        y: -20,
        scale: 0.38,
        rotation: 0,
        opacity: 1,
        muted: false,
        volume: 0.9,
        keyframes: [],
      };
      setOverlayLayers((prev) => [...prev, newLayer]);
      setSelectedOverlayId(id);
      setPanelMode('layers');
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to load overlay.');
    }
  };

  // Extra Audio Layer upload handler (A1 track)
  const handleAudioFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !asset) return;

    const isAudio =
      file.type.startsWith('audio/') ||
      Boolean(file.name.match(/\.(mp3|wav|m4a|aac|ogg|flac|webm)$/i));
    if (!isAudio) {
      setUploadError('Please select a valid audio file (MP3, WAV, M4A, AAC).');
      return;
    }

    const url = trackObjectUrl(URL.createObjectURL(file), file);

    try {
      const audioDuration = await new Promise<number>((resolve) => {
        const aud = new Audio();
        aud.preload = 'metadata';
        aud.src = url;
        aud.onloadedmetadata = () => {
          resolve(
            Number.isFinite(aud.duration) && aud.duration > 0.2
              ? aud.duration
              : asset.duration
          );
        };
        aud.onerror = () => resolve(asset.duration);
      });

      pushHistory();
      const id = makeId('aud');
      const startTime = clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
      const endTime = clamp(startTime + audioDuration, startTime + 0.5, asset.duration);

      const layer: AudioLayer = {
        id,
        name: file.name,
        url,
        duration: audioDuration,
        startTime,
        endTime,
        sourceOffsetSec: 0,
        volume: 0.85,
        muted: false,
      };
      setAudioLayers((prev) => [...prev, layer]);
      setSelectedAudioId(id);
      setPanelMode('audio');
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Could not open audio file.');
    }
  };

  const handleAddAudioLayerDirect = (params: {
    name: string;
    url: string;
    duration: number;
    blob?: Blob;
  }) => {
    if (!asset) return;
    pushHistory();
    const id = makeId('aud');
    const trackedUrl = trackObjectUrl(params.url, params.blob);
    const startTime =
      currentTime < 0.5 ? 0 : clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
    const endTime = asset.duration;
    const layer: AudioLayer = {
      id,
      name: params.name,
      url: trackedUrl,
      duration: Math.max(0.5, params.duration),
      startTime,
      endTime: Math.max(startTime + 0.5, endTime),
      sourceOffsetSec: 0,
      volume: 0.75,
      muted: false,
      fadeInSec: 0.4,
      fadeOutSec: 0.6,
    };
    setAudioLayers((prev) => [...prev, layer]);
    setSelectedAudioId(id);
    setPanelMode('audio');
  };

  // Custom BG Remover backdrop image
  const handleBgImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setUploadError('Backdrop must be an image file.');
      return;
    }
    const url = trackObjectUrl(URL.createObjectURL(file), file);
    pushHistory();
    setBgRemoval((prev) => ({
      ...prev,
      mode: 'image',
      bgImageUrl: url,
      bgImageName: file.name,
    }));
  };

  // Chroma Key backdrop photo & video handlers
  const handleChromaBgImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setUploadError('Chroma backdrop must be an image file.');
      return;
    }
    const url = trackObjectUrl(URL.createObjectURL(file), file);
    pushHistory();
    setChromaKey((prev) => ({
      ...prev,
      enabled: true,
      bgMode: 'image',
      bgImageUrl: url,
      bgImageName: file.name,
    }));
  };

  const handleChromaBgVideoSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (
      !file.type.startsWith('video/') &&
      !file.name.match(/\.(mp4|webm|mov|m4v|mkv)$/i)
    ) {
      setUploadError('Chroma backdrop must be a video file.');
      return;
    }
    const url = trackObjectUrl(URL.createObjectURL(file), file);
    pushHistory();
    setChromaKey((prev) => ({
      ...prev,
      enabled: true,
      bgMode: 'video',
      bgVideoUrl: url,
      bgVideoName: file.name,
    }));
  };

  const handleTrimSegment = useCallback(
    (segmentId: string, newStart: number, newEnd: number, previewTime?: number) => {
      recordHistoryDebounced();
      setSegments((prev) =>
        prev.map((seg) =>
          seg.id === segmentId ? { ...seg, start: newStart, end: newEnd } : seg
        )
      );
      if (typeof previewTime === 'number') {
        seekTo(previewTime);
      }
    },
    [recordHistoryDebounced, seekTo]
  );

  const selectedSegment =
    segments.find((s) => s.id === selectedSegmentId) ?? segments[0];

  const getBoundsForSegment = (segId: string) => {
    if (!asset) return { minStart: 0, maxEnd: 0 };
    const idx = segments.findIndex((s) => s.id === segId);
    if (idx === -1) return { minStart: 0, maxEnd: asset.duration };
    const prev = idx > 0 ? segments[idx - 1] : null;
    const next = idx < segments.length - 1 ? segments[idx + 1] : null;
    return {
      minStart: prev ? prev.end : 0,
      maxEnd: next ? next.start : asset.duration,
    };
  };

  const handleNudgeTrim = (edge: 'start' | 'end', delta: number) => {
    if (!selectedSegment) return;
    const { minStart, maxEnd } = getBoundsForSegment(selectedSegment.id);
    if (edge === 'start') {
      const nextStart = clamp(
        Number((selectedSegment.start + delta).toFixed(2)),
        minStart,
        selectedSegment.end - MIN_CLIP_DURATION
      );
      handleTrimSegment(selectedSegment.id, nextStart, selectedSegment.end, nextStart);
    } else {
      const nextEnd = clamp(
        Number((selectedSegment.end + delta).toFixed(2)),
        selectedSegment.start + MIN_CLIP_DURATION,
        maxEnd
      );
      handleTrimSegment(
        selectedSegment.id,
        selectedSegment.start,
        nextEnd,
        Math.max(selectedSegment.start, nextEnd - 0.05)
      );
    }
  };

  const handleSnapTrimToPlayhead = (edge: 'start' | 'end') => {
    if (!selectedSegment) return;
    const { minStart, maxEnd } = getBoundsForSegment(selectedSegment.id);
    if (edge === 'start') {
      const nextStart = clamp(
        currentTime,
        minStart,
        selectedSegment.end - MIN_CLIP_DURATION
      );
      handleTrimSegment(selectedSegment.id, nextStart, selectedSegment.end, nextStart);
    } else {
      const nextEnd = clamp(
        currentTime,
        selectedSegment.start + MIN_CLIP_DURATION,
        maxEnd
      );
      handleTrimSegment(selectedSegment.id, selectedSegment.start, nextEnd, nextEnd);
    }
  };

  const segmentUnderPlayhead = findSegmentAtTime(currentTime, segments);
  const canSplitAtPlayhead = Boolean(
    segmentUnderPlayhead &&
      currentTime - segmentUnderPlayhead.start >= MIN_CLIP_DURATION &&
      segmentUnderPlayhead.end - currentTime >= MIN_CLIP_DURATION
  );

  const handleSplit = useCallback(() => {
    if (!segmentUnderPlayhead || !canSplitAtPlayhead) return;

    pushHistory();

    const firstId = segmentUnderPlayhead.id;
    const secondId = makeId('seg');
    const splitTime = Number(currentTime.toFixed(3));

    const nextSegments: TimelineSegment[] = [];
    for (const seg of segments) {
      if (seg.id === firstId) {
        nextSegments.push({
          ...seg,
          end: splitTime,
        });
        nextSegments.push({
          id: secondId,
          start: splitTime,
          end: seg.end,
          deleted: seg.deleted,
          meta: seg.meta
            ? {
                ...seg.meta,
                speedCurve: seg.meta.speedCurve
                  ? seg.meta.speedCurve.map((pt) => ({ ...pt }))
                  : undefined,
                transition: seg.meta.transition ? { ...seg.meta.transition } : undefined,
              }
            : undefined,
        });
      } else {
        nextSegments.push(seg);
      }
    }

    setSegments(nextSegments);
    setSelectedSegmentId(secondId);
  }, [canSplitAtPlayhead, currentTime, pushHistory, segmentUnderPlayhead, segments]);

  const activeSegments = getActiveSegments(segments);
  const canDeleteSelected = Boolean(
    selectedSegment && !selectedSegment.deleted && activeSegments.length > 1
  );
  const canDeleteSegmentPermanently = Boolean(
    selectedSegment &&
      segments.length > 1 &&
      segments.some((s) => s.id !== selectedSegment.id && !s.deleted)
  );

  const handleToggleDeleteSelected = useCallback(() => {
    if (!selectedSegment) return;
    if (!selectedSegment.deleted && activeSegments.length <= 1) return;

    pushHistory();
    const nextDeleted = !selectedSegment.deleted;

    const nextSegments = segments.map((seg) =>
      seg.id === selectedSegment.id ? { ...seg, deleted: nextDeleted } : seg
    );
    setSegments(nextSegments);

    if (nextDeleted) {
      const remaining = getActiveSegments(nextSegments);
      if (remaining[0]) {
        seekTo(remaining[0].start);
      }
    }
  }, [activeSegments.length, pushHistory, seekTo, segments, selectedSegment]);

  const handleDeleteSegmentPermanently = useCallback(
    (segmentId: string) => {
      const remainingActive = segments.filter((s) => s.id !== segmentId && !s.deleted);
      if (segments.length <= 1 || remainingActive.length === 0) return;

      pushHistory();
      const nextSegments = segments.filter((s) => s.id !== segmentId);
      setSegments(nextSegments);
      const nextFocus = remainingActive[0] ?? nextSegments[0];
      if (nextFocus) {
        setSelectedSegmentId(nextFocus.id);
        seekTo(nextFocus.start);
      }
    },
    [pushHistory, seekTo, segments]
  );

  const handleChangeClipTransition = useCallback(
    (segmentId: string, transition: ClipTransition, applyAll = false) => {
      pushHistory();
      setSegments((prev) =>
        prev.map((seg) =>
          applyAll || seg.id === segmentId
            ? {
                ...seg,
                meta: {
                  ...seg.meta,
                  transition: { ...transition },
                },
              }
            : seg
        )
      );
    },
    [pushHistory]
  );

  const handleChangeClipSpeed = (segmentId: string, speed: number, applyAll = false) => {
    pushHistory();
    setSegments((prev) =>
      prev.map((seg) =>
        applyAll || seg.id === segmentId
          ? {
              ...seg,
              meta: {
                ...seg.meta,
                speed,
                speedCurve: undefined,
                smoothSlowMo: speed < 1 ? seg.meta?.smoothSlowMo ?? true : false,
              },
            }
          : seg
      )
    );
  };

  const handleUpdateSpeedCurve = (
    segmentId: string,
    curve: SpeedCurvePoint[] | undefined
  ) => {
    recordHistoryDebounced();
    setSegments((prev) =>
      prev.map((seg) =>
        seg.id === segmentId
          ? {
              ...seg,
              meta: {
                ...seg.meta,
                speedCurve: curve,
                smoothSlowMo: curve?.some((p) => p.speed < 0.95)
                  ? seg.meta?.smoothSlowMo ?? true
                  : seg.meta?.smoothSlowMo,
              },
            }
          : seg
      )
    );
  };

  const handleApplySpeedCurvePreset = (
    segmentId: string,
    presetId: SpeedCurvePresetId
  ) => {
    pushHistory();
    const curve =
      presetId === 'normal'
        ? undefined
        : createCurveFromPreset(presetId, () => makeId('sc'));
    setSegments((prev) =>
      prev.map((seg) =>
        seg.id === segmentId
          ? {
              ...seg,
              meta: {
                ...seg.meta,
                speed: presetId === 'normal' ? 1.0 : seg.meta?.speed,
                speedCurve: curve,
                smoothSlowMo: curve?.some((p) => p.speed < 0.95) ? true : false,
              },
            }
          : seg
      )
    );
  };

  const handleToggleSmoothSlowMo = (segmentId: string) => {
    pushHistory();
    setSegments((prev) =>
      prev.map((seg) =>
        seg.id === segmentId
          ? {
              ...seg,
              meta: {
                ...seg.meta,
                smoothSlowMo: !seg.meta?.smoothSlowMo,
              },
            }
          : seg
      )
    );
  };

  const splitSegmentsWithSlowMo = (
    baseSegments: TimelineSegment[],
    ranges: Array<{ startTime: number; endTime: number; speed: number; smoothSlowMo?: boolean }>
  ): { nextSegments: TimelineSegment[]; focusId?: string } => {
    let working: TimelineSegment[] = baseSegments.map((s) => ({
      ...s,
      meta: s.meta ? { ...s.meta } : undefined,
    }));
    let focusId: string | undefined;

    for (const range of ranges) {
      const rStart = Number(range.startTime.toFixed(3));
      const rEnd = Number(range.endTime.toFixed(3));
      if (rEnd - rStart < MIN_CLIP_DURATION) continue;

      const updated: TimelineSegment[] = [];
      for (const seg of working) {
        if (seg.deleted || seg.end <= rStart + 0.05 || seg.start >= rEnd - 0.05) {
          updated.push(seg);
          continue;
        }
        const cutStart = Math.max(seg.start, rStart);
        const cutEnd = Math.min(seg.end, rEnd);
        if (cutEnd - cutStart < MIN_CLIP_DURATION) {
          updated.push(seg);
          continue;
        }

        if (cutStart - seg.start >= MIN_CLIP_DURATION) {
          updated.push({
            id: makeId('seg'),
            start: seg.start,
            end: cutStart,
            deleted: false,
            meta: seg.meta ? { ...seg.meta } : undefined,
          });
        }

        const midId = makeId('seg');
        focusId = focusId ?? midId;
        updated.push({
          id: midId,
          start: cutStart,
          end: cutEnd,
          deleted: false,
          meta: {
            ...seg.meta,
            speed: range.speed,
            smoothSlowMo: range.smoothSlowMo ?? range.speed < 1,
          },
        });

        if (seg.end - cutEnd >= MIN_CLIP_DURATION) {
          updated.push({
            id: makeId('seg'),
            start: cutEnd,
            end: seg.end,
            deleted: false,
            meta: seg.meta ? { ...seg.meta } : undefined,
          });
        }
      }
      working = updated;
    }

    return { nextSegments: working, focusId };
  };

  const handleApplySlowMoHighlight = (speed: number) => {
    if (!asset) return;
    const targetSeg = findSegmentAtTime(currentTime, segments) ?? selectedSegment;
    if (!targetSeg || targetSeg.deleted) return;

    const segLen = targetSeg.end - targetSeg.start;
    pushHistory();

    if (segLen <= 2.8) {
      setSegments((prev) =>
        prev.map((seg) =>
          seg.id === targetSeg.id
            ? { ...seg, meta: { ...seg.meta, speed, smoothSlowMo: true } }
            : seg
        )
      );
      setSelectedSegmentId(targetSeg.id);
      return;
    }

    const winStart = clamp(
      currentTime - 1.25,
      targetSeg.start,
      targetSeg.end - 2.5
    );
    const winEnd = clamp(winStart + 2.5, winStart + 0.5, targetSeg.end);
    const { nextSegments, focusId } = splitSegmentsWithSlowMo(segments, [
      { startTime: winStart, endTime: winEnd, speed, smoothSlowMo: true },
    ]);
    setSegments(nextSegments);
    if (focusId) {
      setSelectedSegmentId(focusId);
      seekTo(winStart);
    }
  };

  const handleChangeClipAudio = (
    segmentId: string,
    patch: { volume?: number; muted?: boolean; fadeInSec?: number; fadeOutSec?: number },
    applyAll = false
  ) => {
    recordHistoryDebounced();
    setSegments((prev) =>
      prev.map((seg) =>
        applyAll || seg.id === segmentId
          ? { ...seg, meta: { ...seg.meta, ...patch } }
          : seg
      )
    );
  };

  const handleChangeAdjustments = (next: VideoAdjustments) => {
    recordHistoryDebounced();
    setAdjustments(next);
  };

  const handleApplyVideoEffect = (effectId: VideoEffectLayer['effectId'], stack = false) => {
    if (!asset) return;
    const def = findEffectDefinition(effectId);

    if (!stack) {
      const existingSame = videoEffects.find((f) => f.effectId === effectId && f.enabled);
      if (existingSame) {
        pushHistory();
        const next = videoEffects.filter((f) => f.id !== existingSame.id);
        setVideoEffects(next);
        if (selectedEffectId === existingSame.id) {
          setSelectedEffectId(next[0]?.id ?? '');
        }
        return;
      }

      const currentSelected = videoEffects.find((f) => f.id === selectedEffectId) ?? videoEffects[0];
      if (currentSelected) {
        pushHistory();
        setVideoEffects((prev) =>
          prev.map((f) =>
            f.id === currentSelected.id
              ? {
                  ...f,
                  effectId,
                  enabled: true,
                  intensity: def.defaultIntensity,
                  speed: def.defaultSpeed,
                }
              : f
          )
        );
        setSelectedEffectId(currentSelected.id);
        return;
      }
    }

    pushHistory();
    const id = makeId('fx');
    const created: VideoEffectLayer = {
      id,
      effectId,
      enabled: true,
      intensity: def.defaultIntensity,
      speed: def.defaultSpeed,
      startTime: 0,
      endTime: asset.duration,
    };
    setVideoEffects((prev) => [...prev, created]);
    setSelectedEffectId(id);
  };

  const handleUpdateVideoEffect = (
    id: string,
    patch: Partial<VideoEffectLayer>
  ) => {
    recordHistoryDebounced();
    setVideoEffects((prev) =>
      prev.map((fx) => (fx.id === id ? { ...fx, ...patch } : fx))
    );
  };

  const handleDeleteVideoEffect = (id: string) => {
    pushHistory();
    const next = videoEffects.filter((fx) => fx.id !== id);
    setVideoEffects(next);
    if (selectedEffectId === id) {
      setSelectedEffectId(next[0]?.id ?? '');
    }
  };

  const handleClearAllVideoEffects = () => {
    if (videoEffects.length === 0) return;
    pushHistory();
    setVideoEffects([]);
    setSelectedEffectId('');
  };

  const handleMoveVideoEffect = (id: string, delta: -1 | 1) => {
    setVideoEffects((prev) => {
      const idx = prev.findIndex((fx) => fx.id === id);
      if (idx === -1) return prev;
      const targetIdx = idx + delta;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      pushHistory();
      const next = [...prev];
      const [moved] = next.splice(idx, 1);
      next.splice(targetIdx, 0, moved);
      return next;
    });
  };

  // Keyframes CRUD
  const handleUpsertMainKeyframe = (
    patch?: Partial<Omit<TransformKeyframe, 'id'>>
  ) => {
    recordHistoryDebounced();
    const targetTime = Number(currentTime.toFixed(2));
    setMainKeyframes((prev) => {
      const existingIdx = prev.findIndex((k) => Math.abs(k.time - targetTime) <= 0.15);
      if (existingIdx !== -1) {
        const next = [...prev];
        next[existingIdx] = { ...next[existingIdx], ...patch };
        return next;
      }
      const base = evaluateKeyframes(prev, targetTime, DEFAULT_TRANSFORM);
      const created: TransformKeyframe = {
        id: makeId('kf'),
        time: targetTime,
        x: patch?.x ?? base.x,
        y: patch?.y ?? base.y,
        scale: patch?.scale ?? base.scale,
        rotation: patch?.rotation ?? base.rotation,
        opacity: patch?.opacity ?? base.opacity,
        easing: patch?.easing ?? 'ease-in-out',
      };
      return [...prev, created].sort((a, b) => a.time - b.time);
    });
  };

  const handleDeleteMainKeyframe = (id: string) => {
    pushHistory();
    setMainKeyframes((prev) => prev.filter((k) => k.id !== id));
  };

  const handleApplyMotionPreset = (
    preset: 'zoom_in' | 'zoom_out' | 'pan_lr' | 'fade_pop'
  ) => {
    if (!asset) return;
    pushHistory();
    const start = selectedSegment ? selectedSegment.start : 0;
    const end = selectedSegment ? selectedSegment.end : asset.duration;
    setMainKeyframes(createMotionPresetKeyframes(preset, start, end, () => makeId('kf')));
  };

  // Motion Tracking handler
  const handleRunMotionTrack = async (label: string) => {
    if (!asset || asset.mediaKind === 'image' || motionTrackingProgress !== null) return;
    setMotionTrackError(null);
    setMotionTrackingProgress(0);
    const target = pendingTrackTarget ?? { x: 0, y: 0 };
    const trackStart = selectedSegment ? selectedSegment.start : 0;
    const trackEnd = selectedSegment ? selectedSegment.end : asset.duration;
    try {
      const track = await trackObjectInVideo({
        videoUrl: asset.url,
        anchorX: target.x,
        anchorY: target.y,
        startTime: trackStart,
        endTime: trackEnd,
        label,
        trackId: makeId('trk'),
        onProgress: (pct) => setMotionTrackingProgress(pct),
      });
      pushHistory();
      setMotionTracks((prev) => [...prev, track]);
    } catch (err) {
      setMotionTrackError(
        err instanceof Error ? err.message : 'Motion tracking failed on this video.'
      );
    } finally {
      setMotionTrackingProgress(null);
    }
  };

  const handleAddTrackedItem = (trackId: string, content: string, isSticker: boolean) => {
    if (!asset) return;
    const track = motionTracks.find((t) => t.id === trackId);
    if (!track) return;
    pushHistory();
    const id = makeId(isSticker ? 'stk' : 'txt');
    const nextItem: TextOverlay = {
      id,
      text: content,
      startTime: track.startTime,
      endTime: track.endTime,
      color: '#ffffff',
      style: isSticker ? 'clean' : 'boxed',
      position: 'center',
      size: isSticker ? 'lg' : 'md',
      isSticker,
      x: track.anchorX,
      y: track.anchorY,
      trackId: track.id,
      lang: resolveTargetLanguageCode(uiLanguage, chineseVariant),
      dir: 'auto',
    };
    setTextOverlays((prev) => [...prev, nextItem]);
    setSelectedTextId(id);
  };

  // Video Stabilization handler
  const handleRunStabilization = async () => {
    if (!asset || asset.mediaKind === 'image' || stabProgress !== null) return;
    setStabError(null);
    setStabProgress(0);
    try {
      const result = await analyzeVideoStabilization({
        videoUrl: asset.url,
        duration: asset.duration,
        strength: stabilization.strength,
        onProgress: (pct) => setStabProgress(pct),
      });
      pushHistory();
      setStabilization(result);
    } catch (err) {
      setStabError(
        err instanceof Error ? err.message : 'Could not analyze camera shake.'
      );
    } finally {
      setStabProgress(null);
    }
  };

  // Music Beat Sync handlers
  const handleDetectBeats = async (sourceId: string, sensitivity: number) => {
    if (!asset || beatsBusy) return;
    setBeatsBusy(true);
    setBeatsError(null);
    try {
      const audLayer =
        sourceId !== 'main' ? audioLayers.find((a) => a.id === sourceId) : undefined;
      const mediaUrl = audLayer ? audLayer.url : asset.url;
      const sourceName = audLayer ? audLayer.name : asset.name;
      const startOffsetSec = audLayer ? audLayer.startTime : 0;

      const analysis = await analyzeAudioBeats({
        mediaUrl,
        sensitivity,
        sourceId,
        sourceName,
        startOffsetSec,
        projectDuration: asset.duration,
      });
      pushHistory();
      setBeatAnalysis(analysis);
      if (analysis.beats.length === 0) {
        setBeatsError('No strong rhythm peaks detected. Try raising sensitivity.');
      }
    } catch (err) {
      setBeatsError(
        err instanceof Error ? err.message : 'Beat detection failed on this audio.'
      );
    } finally {
      setBeatsBusy(false);
    }
  };

  const handleSyncClipsToBeats = (beatStep: 1 | 2 | 4) => {
    if (!beatAnalysis || beatAnalysis.beats.length === 0) return;
    pushHistory();
    const next = splitSegmentsOnBeats(
      segments,
      beatAnalysis.beats,
      beatStep,
      () => makeId('seg'),
      MIN_CLIP_DURATION
    );
    setSegments(next);
    if (next[0]) {
      setSelectedSegmentId(next[0].id);
    }
  };

  // Instant Local Activity AI Auto Cut handler
  const handleInstantLocalAutoCut = async () => {
    if (!asset || asset.mediaKind === 'image' || autoCutBusy) return;
    setAutoCutBusy(true);
    setAiError(null);
    try {
      const windows = await analyzeClipActivityWindows(asset.url, asset.duration);
      const keepRanges = selectKeepRangesFromWindows(windows, asset.duration, 0.55);
      pushHistory();
      const nextSegs = buildSegmentsFromKeepRanges(
        asset.duration,
        keepRanges,
        () => makeId('seg')
      );
      setSegments(nextSegs);
      const firstActive = nextSegs.find((s) => !s.deleted) ?? nextSegs[0];
      if (firstActive) {
        setSelectedSegmentId(firstActive.id);
        seekTo(firstActive.start);
      }
      setAiResult({
        summary: `Auto Cut selected ${keepRanges.length} high-activity highlight clip${
          keepRanges.length === 1 ? '' : 's'
        } and trimmed quiet gaps.`,
        keepRanges,
      });
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Smart highlight detection failed.'
      );
    } finally {
      setAutoCutBusy(false);
    }
  };

  // AI Studio + Dedicated Auto Captions
  const handleRunAiEdit = async (mode: AiEditMode, customPrompt?: string) => {
    if (mode === 'auto_captions') {
      await handleGenerateAutoCaptions();
      return;
    }
    if (!asset || aiBusy) return;
    setAiBusy(true);
    setAiError(null);
    try {
      const result = await requestAiStudioEdit({
        asset,
        mode,
        prompt: customPrompt,
        language: captionLanguage,
        captionStyle,
        captionColor,
      });
      setAiResult(result);
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Unable to complete AI analysis.'
      );
    } finally {
      setAiBusy(false);
    }
  };

  const handleGenerateAutoCaptions = async () => {
    if (!asset || aiBusy) return;
    setAiBusy(true);
    setAiError(null);
    setCaptionsSaved(false);
    try {
      const result = await requestAiStudioEdit({
        asset,
        mode: 'auto_captions',
        language: captionLanguage,
        captionStyle,
        captionColor,
      });
      setAiResult(result);

      if (result.transcript) {
        setSpeechTranscript(result.transcript);
      }

      if (result.captions && result.captions.length > 0) {
        pushHistory();
        const fallbackLang: TargetLanguageCode =
          captionLanguage === 'auto'
            ? result.detectedLanguage ?? resolveTargetLanguageCode(uiLanguage, chineseVariant)
            : captionLanguage;
        const generated: TextOverlay[] = result.captions.map((c) => {
          const capLang: TargetLanguageCode =
            captionLanguage !== 'auto' ? captionLanguage : c.lang ?? fallbackLang;
          const startTime = clamp(c.startTime, 0, Math.max(0, asset.duration - 0.3));
          const endTime = clamp(
            Math.max(startTime + 0.3, c.endTime),
            Math.min(asset.duration, startTime + 0.25),
            asset.duration
          );
          return {
            id: makeId('cap'),
            text: c.text,
            startTime,
            endTime,
            color: captionColor,
            style: c.style ?? captionStyle,
            position: c.position ?? 'bottom',
            size: c.size ?? 'md',
            isCaption: true,
            lang: capLang,
            dir: capLang === 'sd' || capLang === 'ur' ? 'rtl' : 'ltr',
          };
        });
        setTextOverlays((prev) => [
          ...prev.filter((item) => !item.isCaption),
          ...generated,
        ]);
        setSelectedTextId(generated[0].id);

        const playheadVisible = generated.some(
          (g) => currentTime >= g.startTime - 0.02 && currentTime <= g.endTime + 0.02
        );
        if (!playheadVisible && generated[0]) {
          const previewTarget = Math.min(
            generated[0].endTime,
            generated[0].startTime + Math.min(0.15, (generated[0].endTime - generated[0].startTime) * 0.25)
          );
          seekTo(previewTarget);
        }
      } else {
        setAiError('No spoken voice or dialogue was detected in this video.');
      }
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Unable to generate AI captions.'
      );
    } finally {
      setAiBusy(false);
    }
  };

  // Speech-to-Text from uploaded video's audio track
  const handleTranscribeVideoSpeech = async () => {
    if (!asset || speechBusy || isRecordingMic) return;
    setSpeechBusy(true);
    setSpeechError(null);
    try {
      const res = await requestSpeechToText({
        mediaUrl: asset.url,
        language: captionLanguage,
      });
      setSpeechTranscript(res.text);
    } catch (err) {
      setSpeechError(
        err instanceof Error ? err.message : 'Video Speech-to-Text failed.'
      );
    } finally {
      setSpeechBusy(false);
    }
  };

  // Speech-to-Text from Browser Microphone
  const handleToggleMicRecord = async () => {
    if (isRecordingMic) {
      try {
        micRecorderRef.current?.stop();
      } catch {
        // Ignore stop errors
      }
      setIsRecordingMic(false);
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setSpeechError('Microphone recording is not supported in this browser.');
      return;
    }

    setSpeechError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(stream);
      micRecorderRef.current = recorder;

      recorder.ondataavailable = (evt) => {
        if (evt.data && evt.data.size > 0) {
          chunks.push(evt.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        micStreamRef.current = null;
        micRecorderRef.current = null;

        const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size < 256) {
          setSpeechError('No audio recorded. Please speak closer to the microphone.');
          return;
        }
        const micUrl = URL.createObjectURL(blob);
        setSpeechBusy(true);
        try {
          const res = await requestSpeechToText({
            mediaUrl: micUrl,
            language: captionLanguage,
          });
          setSpeechTranscript(res.text);
        } catch (err) {
          setSpeechError(
            err instanceof Error ? err.message : 'Microphone transcription failed.'
          );
        } finally {
          URL.revokeObjectURL(micUrl);
          setSpeechBusy(false);
        }
      };

      recorder.start();
      setIsRecordingMic(true);
    } catch (err) {
      setSpeechError(
        err instanceof Error
          ? err.message
          : 'Microphone access was denied. Enable mic permissions to record speech.'
      );
    }
  };

  // Real Subtitle Translation (across all 5 supported languages)
  const handleTranslateCaptions = async (targetOverride?: TargetLanguageCode) => {
    const targetLang = targetOverride ?? translateTargetLang;
    const captionItems = textOverlays.filter((t) => t.isCaption && t.text.trim().length > 0);
    if (captionItems.length === 0 || translateBusy) return;
    setTranslateBusy(true);
    setAiError(null);
    setCaptionsSaved(false);
    try {
      const translated = await requestTranslation({
        texts: captionItems.map((c) => c.text),
        targetLanguage: targetLang,
      });

      pushHistory();
      const map = new Map<string, string>();
      captionItems.forEach((cap, idx) => {
        const nextText = translated[idx];
        if (nextText && nextText.trim()) {
          map.set(cap.id, nextText.trim());
        }
      });

      const nextDir: 'rtl' | 'ltr' =
        targetLang === 'sd' || targetLang === 'ur' ? 'rtl' : 'ltr';

      setTextOverlays((prev) =>
        prev.map((item) =>
          map.has(item.id)
            ? {
                ...item,
                text: map.get(item.id)!,
                lang: targetLang,
                dir: nextDir,
              }
            : item
        )
      );
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Subtitle translation failed.'
      );
    } finally {
      setTranslateBusy(false);
    }
  };

  const handleTtsTextChange = (nextText: string) => {
    setTtsText(nextText);
    if (ttsError) setTtsError(null);
    if (!nextText.trim()) {
      setTtsLangManual(false);
      setTtsLangAutoDetected(false);
      return;
    }
    const detected = detectScriptLanguage(nextText, chineseVariant, ttsLang);
    if (detected && (!ttsLangManual || detected !== 'en')) {
      if (detected !== ttsLang) {
        setTtsLang(detected);
        setTtsLangAutoDetected(true);
      } else if (!ttsLangManual) {
        setTtsLangAutoDetected(true);
      }
    }
  };

  const handleTtsLangManualSelect = (lang: TargetLanguageCode) => {
    setTtsLang(lang);
    setTtsLangManual(true);
    setTtsLangAutoDetected(false);
  };

  // Real Text-to-Speech & AI Voice Generation (across all 5 languages)
  const handleGenerateVoice = async () => {
    if (ttsBusy) return;
    if (!ttsText.trim()) {
      setTtsError(strings.voiceEmptyError);
      return;
    }
    setTtsBusy(true);
    setTtsError(null);
    try {
      const voiceGender: 'female' | 'male' =
        ttsVoice === 'Fenrir' || ttsVoice === 'Charon' || ttsVoice === 'Puck'
          ? 'male'
          : 'female';
      const res = await requestAiTtsVoice({
        text: ttsText.trim(),
        language: ttsLang,
        voiceName: ttsVoice,
        voiceGender,
        voiceMode: ttsMode,
        stylePrompt: ttsMode === 'voice_design' ? ttsStylePrompt.trim() || undefined : undefined,
      });
      const tracked = trackObjectUrl(res.blobUrl);
      setTtsResultUrl(tracked);
      setTtsResultDuration(res.duration);
      setTtsResultModel(res.model);
    } catch (err) {
      setTtsError(
        err instanceof Error ? err.message : 'AI Voice generation failed.'
      );
    } finally {
      setTtsBusy(false);
    }
  };

  const handleAddGeneratedVoiceToTimeline = () => {
    if (!asset || !ttsResultUrl) return;
    pushHistory();
    const id = makeId('voice');
    const startTime = clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
    const clipSpan = Math.max(0.5, ttsResultDuration || 3);
    const endTime = clamp(startTime + clipSpan, startTime + 0.5, asset.duration);

    const voiceLayer: AudioLayer = {
      id,
      name: `AI Voice (${ttsLang} · ${ttsVoice})`,
      url: ttsResultUrl,
      duration: clipSpan,
      startTime,
      endTime,
      sourceOffsetSec: 0,
      volume: 1.0,
      muted: false,
    };
    setAudioLayers((prev) => [...prev, voiceLayer]);
    setSelectedAudioId(id);
    setPanelMode('audio');
  };

  // Real Video Text Translation
  const handleTranslateSelectedText = async () => {
    const selectedText = textOverlays.find((t) => t.id === selectedTextId) ?? textOverlays[0];
    if (!selectedText || !selectedText.text.trim() || textTranslateBusy) return;
    setTextTranslateBusy(true);
    setAiError(null);
    try {
      const [translated] = await requestTranslation({
        texts: [selectedText.text],
        targetLanguage: textTranslateTargetLang,
      });
      if (translated && translated.trim()) {
        pushHistory();
        const nextDir: 'rtl' | 'ltr' =
          textTranslateTargetLang === 'sd' || textTranslateTargetLang === 'ur'
            ? 'rtl'
            : 'ltr';
        setTextOverlays((prev) =>
          prev.map((item) =>
            item.id === selectedText.id
              ? {
                  ...item,
                  text: translated.trim(),
                  lang: textTranslateTargetLang,
                  dir: nextDir,
                }
              : item
          )
        );
      }
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : 'Text translation failed.'
      );
    } finally {
      setTextTranslateBusy(false);
    }
  };

  const handleExportSrt = () => {
    if (!asset || textOverlays.length === 0) return;
    const srt = buildSrtContent(textOverlays);
    const blob = new Blob([srt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const baseName = asset.name.replace(/\.[^/.]+$/, '') || 'meesam-captions';
    void downloadMediaFile({
      blob,
      url,
      filename: `${baseName}.srt`,
      mimeType: 'text/plain;charset=utf-8',
    }).finally(() => {
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  };

  const handleApplyAiEdit = (result: AiEditResult) => {
    if (!asset) return;
    pushHistory();

    if (
      result.recommendedFilterId ||
      result.brightness !== undefined ||
      result.contrast !== undefined ||
      result.saturation !== undefined ||
      result.filterIntensity !== undefined
    ) {
      const preset = result.recommendedFilterId
        ? findFilterPreset(result.recommendedFilterId)
        : null;
      setAdjustments((prev) => ({
        filterPreset: preset ? preset.id : prev.filterPreset,
        filterIntensity: result.filterIntensity ?? prev.filterIntensity ?? 100,
        brightness: result.brightness ?? prev.brightness,
        contrast: result.contrast ?? prev.contrast,
        saturation: result.saturation ?? prev.saturation,
      }));
    }

    if (result.aspectRatio) {
      setAspectRatio(result.aspectRatio);
    }
    if (result.frameFit) {
      setFrameFit(result.frameFit);
    }

    if (result.keepRanges && result.keepRanges.length > 0) {
      const autoCutSegments = buildSegmentsFromKeepRanges(
        asset.duration,
        result.keepRanges,
        () => makeId('seg')
      );
      setSegments(autoCutSegments);
      const firstActive = autoCutSegments.find((s) => !s.deleted) ?? autoCutSegments[0];
      if (firstActive) {
        setSelectedSegmentId(firstActive.id);
        seekTo(firstActive.start);
      }
    } else if (result.slowMoRanges && result.slowMoRanges.length > 0) {
      const { nextSegments, focusId } = splitSegmentsWithSlowMo(
        segments,
        result.slowMoRanges
      );
      setSegments(nextSegments);
      if (focusId) {
        setSelectedSegmentId(focusId);
      }
    }

    if (result.captions && result.captions.length > 0) {
      const fallbackLang: TargetLanguageCode =
        captionLanguage === 'auto'
          ? result.detectedLanguage ?? resolveTargetLanguageCode(uiLanguage, chineseVariant)
          : captionLanguage;
      const newOverlays: TextOverlay[] = result.captions.map((c) => {
        const capLang = c.lang ?? fallbackLang;
        return {
          id: makeId('txt'),
          text: c.text,
          startTime: clamp(c.startTime, 0, Math.max(0, asset.duration - 0.3)),
          endTime: clamp(c.endTime, 0.3, asset.duration),
          color: c.color ?? '#ffffff',
          style: c.style ?? 'boxed',
          position: c.position ?? 'bottom',
          size: c.size ?? 'md',
          isCaption: true,
          lang: capLang,
          dir: capLang === 'sd' || capLang === 'ur' ? 'rtl' : 'ltr',
        };
      });
      setTextOverlays((prev) => [...prev, ...newOverlays]);
      setSelectedTextId(newOverlays[0].id);
    }
  };

  const handleAddStickerOverlay = (emoji: string) => {
    if (!asset) return;
    pushHistory();
    const id = makeId('stk');
    const startTime = clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
    const endTime = clamp(startTime + 3.5, startTime + 0.5, asset.duration);
    const item: TextOverlay = {
      id,
      text: emoji,
      startTime,
      endTime,
      color: '#ffffff',
      style: 'clean',
      position: 'center',
      size: 'lg',
      isSticker: true,
      x: 0,
      y: 0,
      lang: resolveTargetLanguageCode(uiLanguage, chineseVariant),
      dir: 'auto',
    };
    setTextOverlays((prev) => [...prev, item]);
    setSelectedTextId(id);
  };

  const handleAddTextOverlay = (
    initialText?: string,
    initialLang?: TargetLanguageCode,
    preset: 'text' | 'title' | 'subtitle' | 'watermark' = 'text',
    styleOverride?: { style: TextStylePreset; color: string }
  ) => {
    if (!asset) return;
    pushHistory();
    const id = makeId(preset === 'watermark' ? 'wm' : 'txt');
    const isWatermark = preset === 'watermark';
    const startTime = isWatermark
      ? 0
      : clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
    const endTime = isWatermark
      ? asset.duration
      : clamp(startTime + 3.5, startTime + 0.5, asset.duration);
    const activeTarget =
      initialLang ?? resolveTargetLanguageCode(uiLanguage, chineseVariant);
    const meta = FIVE_SUPPORTED_LANGUAGES.find((l) => l.id === uiLanguage);
    const defaultSample =
      uiLanguage === 'zh' && chineseVariant === 'zh-Hant'
        ? meta?.traditionalSampleText
        : meta?.defaultSampleText;

    const baseItem: TextOverlay =
      preset === 'title'
        ? {
            id,
            text: initialText?.trim() || defaultSample || 'Your Video Title',
            startTime,
            endTime,
            color: '#ffffff',
            style: 'outline',
            position: 'center',
            size: 'lg',
            scale: 1.15,
            opacity: 1,
            kind: 'title',
            lang: activeTarget,
            dir: activeTarget === 'sd' || activeTarget === 'ur' ? 'rtl' : 'ltr',
          }
        : preset === 'subtitle'
        ? {
            id,
            text: initialText?.trim() || defaultSample || 'Subtitle text here',
            startTime,
            endTime,
            color: '#ffffff',
            style: 'subtitle-bar',
            position: 'bottom',
            size: 'md',
            scale: 1,
            opacity: 1,
            kind: 'subtitle',
            lang: activeTarget,
            dir: activeTarget === 'sd' || activeTarget === 'ur' ? 'rtl' : 'ltr',
          }
        : preset === 'watermark'
        ? {
            id,
            text: initialText?.trim() || '@MEESAMTECH',
            startTime,
            endTime,
            color: '#ffffff',
            style: 'clean',
            position: 'bottom',
            size: 'sm',
            scale: 0.9,
            opacity: 0.65,
            x: 26,
            y: 38,
            kind: 'watermark',
            lang: 'en',
            dir: 'ltr',
          }
        : {
            id,
            text: initialText?.trim() || defaultSample || 'MEESAM TECH',
            startTime,
            endTime,
            color: '#ffffff',
            style: 'boxed',
            position: 'center',
            size: 'md',
            scale: 1,
            opacity: 1,
            kind: 'text',
            lang: activeTarget,
            dir: activeTarget === 'sd' || activeTarget === 'ur' ? 'rtl' : 'ltr',
          };

    const nextItem: TextOverlay = styleOverride
      ? { ...baseItem, style: styleOverride.style, color: styleOverride.color }
      : baseItem;

    setTextOverlays((prev) => [...prev, nextItem]);
    setSelectedTextId(id);
  };

  const handleUpdateTextOverlay = (id: string, patch: Partial<TextOverlay>) => {
    recordHistoryDebounced();
    setCaptionsSaved(false);
    setTextOverlays((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...patch } : item))
    );
  };

  const handleDeleteTextOverlay = (id: string) => {
    pushHistory();
    setCaptionsSaved(false);
    setTextOverlays((prev) => {
      const next = prev.filter((item) => item.id !== id);
      if (selectedTextId === id) {
        setSelectedTextId(next[0]?.id ?? '');
      }
      return next;
    });
  };

  const handleUndo = useCallback(() => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    const currentSnap = buildCurrentSnapshot();
    setHistory((prev) => prev.slice(0, -1));
    setRedoHistory((prev) => [...prev.slice(-29), currentSnap]);
    applySnapshot(previous);
  }, [applySnapshot, buildCurrentSnapshot, history]);

  const handleRedo = useCallback(() => {
    if (redoHistory.length === 0) return;
    const nextSnap = redoHistory[redoHistory.length - 1];
    const currentSnap = buildCurrentSnapshot();
    setRedoHistory((prev) => prev.slice(0, -1));
    setHistory((prev) => [...prev.slice(-29), currentSnap]);
    applySnapshot(nextSnap);
  }, [applySnapshot, buildCurrentSnapshot, redoHistory]);

  const handleShiftAllCaptions = useCallback(
    (deltaSec: number) => {
      if (!asset) return;
      pushHistory();
      setTextOverlays((prev) =>
        prev.map((item) => {
          if (!item.isCaption) return item;
          const span = Math.max(0.25, item.endTime - item.startTime);
          const nextStart = clamp(item.startTime + deltaSec, 0, Math.max(0, asset.duration - span));
          return {
            ...item,
            startTime: Number(nextStart.toFixed(2)),
            endTime: Number(Math.min(asset.duration, nextStart + span).toFixed(2)),
          };
        })
      );
    },
    [asset, pushHistory]
  );

  const handleAddManualCaption = useCallback(() => {
    if (!asset) return;
    pushHistory();
    setCaptionsSaved(false);
    const id = makeId('cap');
    const startTime = clamp(currentTime, 0, Math.max(0, asset.duration - 0.5));
    const endTime = clamp(startTime + 2.5, startTime + 0.5, asset.duration);
    const activeTarget: TargetLanguageCode =
      captionLanguage === 'auto'
        ? resolveTargetLanguageCode(uiLanguage, chineseVariant)
        : captionLanguage;
    const item: TextOverlay = {
      id,
      text: 'Subtitle line',
      startTime,
      endTime,
      color: captionColor,
      style: captionStyle,
      position: 'bottom',
      size: 'md',
      isCaption: true,
      lang: activeTarget,
      dir: activeTarget === 'sd' || activeTarget === 'ur' ? 'rtl' : 'ltr',
    };
    setTextOverlays((prev) => [...prev, item]);
    setSelectedTextId(id);
  }, [asset, captionColor, captionLanguage, captionStyle, chineseVariant, currentTime, pushHistory, uiLanguage]);

  const handleChangeCaptionColor = useCallback(
    (color: string) => {
      setCaptionColor(color);
      setCaptionsSaved(false);
      if (textOverlays.some((t) => t.isCaption)) {
        pushHistory();
        setTextOverlays((prev) =>
          prev.map((t) => (t.isCaption ? { ...t, color } : t))
        );
      }
    },
    [pushHistory, textOverlays]
  );

  const handleSaveProject = useCallback(
    async (saveAsNew = false): Promise<boolean> => {
      if (!asset || isSavingProject) return false;
      setIsSavingProject(true);
      setProjectsError(null);
      try {
        const edits = buildCurrentSnapshot();
        const summary = await saveProjectToIdb({
          existingId: saveAsNew ? null : currentSavedProjectId,
          projectName: saveAsNew ? `${asset.name} (Copy)` : asset.name,
          asset,
          edits,
          thumbnailDataUrl: thumbnails[0],
          urlToBlobMap: urlToBlobMapRef.current,
        });
        setCurrentSavedProjectId(summary.id);
        const list = await listSavedProjects();
        setSavedProjects(list);
        setJustSaved(true);
        if (savedTimerRef.current !== null) {
          window.clearTimeout(savedTimerRef.current);
        }
        savedTimerRef.current = window.setTimeout(() => setJustSaved(false), 2400);
        return true;
      } catch (err) {
        setProjectsError(
          err instanceof Error ? err.message : 'Unable to save project locally.'
        );
        return false;
      } finally {
        setIsSavingProject(false);
      }
    },
    [asset, buildCurrentSnapshot, currentSavedProjectId, isSavingProject, thumbnails]
  );

  const handleSaveCaptions = useCallback(async () => {
    const ok = await handleSaveProject(false);
    if (!ok) return;
    setCaptionsSaved(true);
    if (captionsSavedTimerRef.current !== null) {
      window.clearTimeout(captionsSavedTimerRef.current);
    }
    captionsSavedTimerRef.current = window.setTimeout(() => setCaptionsSaved(false), 2600);
  }, [handleSaveProject]);

  const handleOpenProject = useCallback(
    async (projectId: string) => {
      if (loadingProjectId) return;
      setLoadingProjectId(projectId);
      setProjectsError(null);
      setUploadError(null);
      try {
        const loaded = await loadProjectFromIdb(projectId, trackObjectUrl);
        setIsPlaying(false);
        setAsset(loaded.asset);
        applySnapshot(loaded.edits);
        const firstCaption = loaded.edits.textOverlays.find((t) => t.isCaption);
        if (firstCaption) {
          setCaptionStyle(firstCaption.style);
          setCaptionColor(firstCaption.color || '#ffffff');
        }
        setCaptionsSaved(false);
        setSelectedSegmentId(loaded.edits.segments[0]?.id ?? '');
        setSelectedEffectId(loaded.edits.videoEffects?.[0]?.id ?? '');
        setSelectedTextId(loaded.edits.textOverlays[0]?.id ?? '');
        setSelectedOverlayId(loaded.edits.overlayLayers[0]?.id ?? '');
        setSelectedAudioId(loaded.edits.audioLayers[0]?.id ?? '');
        setHistory([]);
        setRedoHistory([]);
        setCurrentSavedProjectId(loaded.summary.id);
        setCurrentTime(0);
        setPanelMode('default');
        setPreviewScope('edited');
        setIsProjectsModalOpen(false);
        if (loaded.asset.mediaKind === 'image') {
          const thumb = loaded.summary.thumbnailDataUrl || loaded.asset.url;
          setThumbnails(Array.from({ length: 10 }, () => thumb));
        } else {
          setThumbnails(
            loaded.summary.thumbnailDataUrl ? [loaded.summary.thumbnailDataUrl] : []
          );
          generateThumbnails(loaded.asset.url, loaded.asset.duration, 12).then((frames) => {
            if (frames.length > 0) setThumbnails(frames);
          });
        }
      } catch (err) {
        const msg =
          err instanceof Error ? err.message : 'Unable to reopen saved project.';
        setProjectsError(msg);
        setUploadError(msg);
      } finally {
        setLoadingProjectId(null);
      }
    },
    [applySnapshot, loadingProjectId, trackObjectUrl]
  );

  const handleDeleteProject = useCallback(
    async (projectId: string) => {
      setProjectsError(null);
      try {
        await deleteSavedProject(projectId);
        if (currentSavedProjectId === projectId) {
          setCurrentSavedProjectId(null);
        }
        const list = await listSavedProjects();
        setSavedProjects(list);
      } catch (err) {
        setProjectsError(
          err instanceof Error ? err.message : 'Unable to delete saved project.'
        );
      }
    },
    [currentSavedProjectId]
  );

  const handleReset = useCallback(() => {
    if (!asset) return;
    pushHistory();
    const freshId = makeId('seg');
    setSegments([
      {
        id: freshId,
        start: 0,
        end: asset.duration,
        deleted: false,
      },
    ]);
    setMainKeyframes([]);
    setMotionTracks([]);
    setPendingTrackTarget({ x: 0, y: 0 });
    setOverlayLayers([]);
    setSelectedOverlayId('');
    setAudioLayers([]);
    setSelectedAudioId('');
    setBgRemoval(DEFAULT_BG_REMOVAL);
    setBgModelError(null);
    setChromaKey(DEFAULT_CHROMA_KEY);
    setStabilization(DEFAULT_STABILIZATION);
    setMask(DEFAULT_MASK_SETTINGS);
    setBeatAnalysis(null);
    setAdjustments(DEFAULT_ADJUSTMENTS);
    setVideoEffects([]);
    setSelectedEffectId('');
    setTextOverlays([]);
    setSelectedTextId('');
    setAspectRatio('original');
    setFrameFit('contain');
    setSelectedSegmentId(freshId);
    setPanelMode('default');
    seekTo(0);
  }, [asset, pushHistory, seekTo]);

  const editedDuration = getEditedDuration(segments);
  const hasEdits = Boolean(
    asset &&
      (segments.length > 1 ||
        segments.some(
          (seg) =>
            seg.deleted ||
            (seg.meta?.speed ?? 1) !== 1 ||
            hasCustomSpeedCurve(seg) ||
            Boolean(seg.meta?.muted) ||
            (seg.meta?.volume ?? 1) !== 1 ||
            (seg.meta?.fadeInSec ?? 0) > 0 ||
            (seg.meta?.fadeOutSec ?? 0) > 0 ||
            Boolean(seg.meta?.transition && seg.meta.transition.type !== 'none')
        ) ||
        segments[0]?.start > 0.05 ||
        Math.abs((segments[0]?.end ?? 0) - asset.duration) > 0.05 ||
        mainKeyframes.length > 0 ||
        motionTracks.length > 0 ||
        overlayLayers.length > 0 ||
        audioLayers.length > 0 ||
        bgRemoval.mode !== 'off' ||
        chromaKey.enabled ||
        stabilization.enabled ||
        mask.shape !== 'none' ||
        hasCustomAdjustments(adjustments) ||
        videoEffects.length > 0 ||
        textOverlays.length > 0 ||
        aspectRatio !== 'original')
  );

  // Desktop keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (!asset || isExportOpen || isProjectsModalOpen) return;
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT')
      ) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSaveProject(false);
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleStepTime(-0.5);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleStepTime(0.5);
      } else if (e.key.toLowerCase() === 's' && !e.metaKey && !e.ctrlKey) {
        handleSplit();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    asset,
    handleRedo,
    handleSaveProject,
    handleSplit,
    handleStepTime,
    handleTogglePlay,
    handleUndo,
    isExportOpen,
    isProjectsModalOpen,
  ]);

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-[#07080B] text-[#F5F2EA] overflow-hidden">
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,image/*"
        onChange={handleFileInputChange}
        className="hidden"
      />
      <input
        ref={overlayInputRef}
        type="file"
        accept="video/*,image/*"
        onChange={handleOverlayFileSelected}
        className="hidden"
      />
      <input
        ref={audioInputRef}
        type="file"
        accept="audio/*"
        onChange={handleAudioFileSelected}
        className="hidden"
      />
      <input
        ref={bgImageInputRef}
        type="file"
        accept="image/*"
        onChange={handleBgImageSelected}
        className="hidden"
      />
      <input
        ref={chromaBgImageInputRef}
        type="file"
        accept="image/*"
        onChange={handleChromaBgImageSelected}
        className="hidden"
      />
      <input
        ref={chromaBgVideoInputRef}
        type="file"
        accept="video/*"
        onChange={handleChromaBgVideoSelected}
        className="hidden"
      />

      <TopBar
        asset={asset}
        editedDuration={editedDuration}
        uiLanguage={uiLanguage}
        chineseVariant={chineseVariant}
        strings={strings}
        savedProjectsCount={savedProjects.length}
        isSavingProject={isSavingProject}
        justSaved={justSaved}
        onOpenLanguageSettings={() => setIsLanguageModalOpen(true)}
        onOpenProjects={() => setIsProjectsModalOpen(true)}
        onSaveProject={() => handleSaveProject(false)}
        onTriggerUpload={handleTriggerUpload}
        onOpenExport={() => {
          if (videoRef.current && !videoRef.current.paused) {
            videoRef.current.pause();
          }
          setIsPlaying(false);
          setIsExportOpen(true);
        }}
        canExport={Boolean(asset && activeSegments.length > 0)}
      />

      {!asset ? (
        <UploadDropzone
          strings={strings}
          savedProjects={savedProjects}
          loadingProjectId={loadingProjectId}
          onFileSelected={(file) => loadVideoFile(file, false)}
          onTriggerUpload={handleTriggerUpload}
          onLoadSample={handleLoadSample}
          onOpenProject={handleOpenProject}
          onDeleteProject={handleDeleteProject}
          isLoadingSample={isLoadingSample}
          errorMessage={uploadError}
        />
      ) : (
        <>
          <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
            <div className="flex-1 min-w-0 min-h-0 flex flex-col overflow-hidden">
              <VideoPreview
                asset={asset}
                videoRef={videoRef}
                segments={segments}
                mainKeyframes={mainKeyframes}
                motionTracks={motionTracks}
                overlayLayers={overlayLayers}
                audioLayers={audioLayers}
                bgRemoval={bgRemoval}
                chromaKey={chromaKey}
                stabilization={stabilization}
                mask={mask}
                adjustments={adjustments}
                videoEffects={videoEffects}
                textOverlays={textOverlays}
                selectedTextId={selectedTextId}
                aspectRatio={aspectRatio}
                frameFit={frameFit}
                currentTime={currentTime}
                isPlaying={isPlaying}
                isMuted={isMuted}
                canUndo={history.length > 0}
                canRedo={redoHistory.length > 0}
                previewScope={previewScope}
                panelMode={panelMode}
                pendingTrackTarget={pendingTrackTarget}
                strings={strings}
                onTimeUpdate={setCurrentTime}
                onPlayingChange={setIsPlaying}
                onTogglePlay={handleTogglePlay}
                onStepTime={handleStepTime}
                onToggleMute={() => setIsMuted((m) => !m)}
                onUndo={handleUndo}
                onRedo={handleRedo}
                onChangePreviewScope={setPreviewScope}
                onPickTrackTarget={(x, y) => setPendingTrackTarget({ x, y })}
                onBgModelError={setBgModelError}
                onSelectTextOverlay={(id, isCaption) => {
                  setSelectedTextId(id);
                  setPanelMode(isCaption ? 'captions' : 'text');
                }}
                onUpdateTextOverlay={handleUpdateTextOverlay}
              />

              <TimelineEditor
                duration={asset.duration}
                currentTime={currentTime}
                segments={segments}
                selectedSegmentId={selectedSegmentId}
                thumbnails={thumbnails}
                mainKeyframes={mainKeyframes}
                overlayLayers={overlayLayers}
                selectedOverlayId={selectedOverlayId}
                audioLayers={audioLayers}
                selectedAudioId={selectedAudioId}
                textOverlays={textOverlays}
                selectedTextId={selectedTextId}
                beatAnalysis={beatAnalysis}
                isMuted={isMuted}
                strings={strings}
                onSelectSegment={setSelectedSegmentId}
                onSelectOverlay={(id) => {
                  setSelectedOverlayId(id);
                  setPanelMode('layers');
                }}
                onSelectAudio={(id) => {
                  setSelectedAudioId(id);
                  setPanelMode('audio');
                }}
                onSelectText={(id, isCaption) => {
                  setSelectedTextId(id);
                  setPanelMode(isCaption ? 'captions' : 'text');
                }}
                onSelectKeyframe={(time) => {
                  seekTo(time);
                  setPanelMode('keyframes');
                }}
                onRequestAddOverlay={() => overlayInputRef.current?.click()}
                onRequestAddAudio={() => setPanelMode('audio')}
                onToggleMute={() => setIsMuted((m) => !m)}
                onSeek={seekTo}
                onTrimSegment={handleTrimSegment}
                onUpdateTextOverlay={handleUpdateTextOverlay}
              />
            </div>

            <ToolPanel
            panelMode={panelMode}
            mediaKind={asset.mediaKind}
            duration={asset.duration}
            currentTime={currentTime}
            selectedSegment={selectedSegment}
            adjustments={adjustments}
            videoEffects={videoEffects}
            selectedEffectId={selectedEffectId}
            previewThumbnail={
              thumbnails[0] || (asset.mediaKind === 'image' ? asset.url : undefined)
            }
            mainKeyframes={mainKeyframes}
            motionTracks={motionTracks}
            pendingTrackTarget={pendingTrackTarget}
            motionTrackingProgress={motionTrackingProgress}
            motionTrackError={motionTrackError}
            overlayLayers={overlayLayers}
            selectedOverlayId={selectedOverlayId}
            audioLayers={audioLayers}
            selectedAudioId={selectedAudioId}
            bgRemoval={bgRemoval}
            bgModelError={bgModelError}
            chromaKey={chromaKey}
            stabilization={stabilization}
            stabProgress={stabProgress}
            stabError={stabError}
            mask={mask}
            beatAnalysis={beatAnalysis}
            beatsBusy={beatsBusy}
            beatsError={beatsError}
            autoCutBusy={autoCutBusy}
            textOverlays={textOverlays}
            selectedTextId={selectedTextId}
            aspectRatio={aspectRatio}
            frameFit={frameFit}
            captionLanguage={captionLanguage}
            captionStyle={captionStyle}
            captionColor={captionColor}
            chineseVariant={chineseVariant}
            captionsSaved={captionsSaved}
            isSavingCaptions={isSavingProject}
            strings={strings}
            aiBusy={aiBusy}
            aiError={aiError}
            aiResult={aiResult}
            speechTranscript={speechTranscript}
            speechBusy={speechBusy}
            speechError={speechError}
            isRecordingMic={isRecordingMic}
            translateTargetLang={translateTargetLang}
            translateBusy={translateBusy}
            ttsText={ttsText}
            ttsLang={ttsLang}
            ttsLangAutoDetected={ttsLangAutoDetected}
            ttsVoice={ttsVoice}
            ttsMode={ttsMode}
            ttsStylePrompt={ttsStylePrompt}
            ttsBusy={ttsBusy}
            ttsError={ttsError}
            ttsResultUrl={ttsResultUrl}
            ttsResultDuration={ttsResultDuration}
            ttsResultModel={ttsResultModel}
            textTranslateTargetLang={textTranslateTargetLang}
            textTranslateBusy={textTranslateBusy}
            canDeleteSegmentPermanently={canDeleteSegmentPermanently}
            onClose={() => setPanelMode('default')}
            onSeek={seekTo}
            onNudgeTrim={handleNudgeTrim}
            onSnapTrimToPlayhead={handleSnapTrimToPlayhead}
            onDeleteSegmentPermanently={handleDeleteSegmentPermanently}
            onChangeClipTransition={handleChangeClipTransition}
            onChangeClipSpeed={handleChangeClipSpeed}
            onUpdateSpeedCurve={handleUpdateSpeedCurve}
            onApplySpeedCurvePreset={handleApplySpeedCurvePreset}
            onToggleSmoothSlowMo={handleToggleSmoothSlowMo}
            onApplySlowMoHighlight={handleApplySlowMoHighlight}
            onChangeClipAudio={handleChangeClipAudio}
            onChangeAdjustments={handleChangeAdjustments}
            onApplyVideoEffect={(fxId, stack) =>
              handleApplyVideoEffect(fxId as VideoEffectLayer['effectId'], stack)
            }
            onSelectVideoEffect={setSelectedEffectId}
            onUpdateVideoEffect={handleUpdateVideoEffect}
            onDeleteVideoEffect={handleDeleteVideoEffect}
            onClearAllVideoEffects={handleClearAllVideoEffects}
            onMoveVideoEffect={handleMoveVideoEffect}
            onAddTextOverlay={(preset, styleOverride) =>
              handleAddTextOverlay(undefined, undefined, preset, styleOverride)
            }
            onAddStickerOverlay={handleAddStickerOverlay}
            onSelectTextOverlay={setSelectedTextId}
            onUpdateTextOverlay={handleUpdateTextOverlay}
            onDeleteTextOverlay={handleDeleteTextOverlay}
            onClearAllCaptions={() => {
              pushHistory();
              setCaptionsSaved(false);
              setTextOverlays((prev) => prev.filter((t) => !t.isCaption));
            }}
            onShiftAllCaptions={handleShiftAllCaptions}
            onAddManualCaption={handleAddManualCaption}
            onChangeAspectRatio={(r) => {
              pushHistory();
              setAspectRatio(r);
            }}
            onChangeFrameFit={(f) => {
              pushHistory();
              setFrameFit(f);
            }}
            onRequestAddOverlay={() => overlayInputRef.current?.click()}
            onSelectOverlay={setSelectedOverlayId}
            onUpdateOverlay={(id, patch) => {
              recordHistoryDebounced();
              setOverlayLayers((prev) =>
                prev.map((o) => (o.id === id ? { ...o, ...patch } : o))
              );
            }}
            onDeleteOverlay={(id) => {
              pushHistory();
              setOverlayLayers((prev) => {
                const next = prev.filter((o) => o.id !== id);
                if (selectedOverlayId === id) {
                  setSelectedOverlayId(next[0]?.id ?? '');
                }
                return next;
              });
            }}
            onRequestAddAudio={() => audioInputRef.current?.click()}
            onAddAudioLayer={handleAddAudioLayerDirect}
            onSelectAudio={setSelectedAudioId}
            onUpdateAudio={(id, patch) => {
              recordHistoryDebounced();
              setAudioLayers((prev) =>
                prev.map((a) => (a.id === id ? { ...a, ...patch } : a))
              );
            }}
            onDeleteAudio={(id) => {
              pushHistory();
              setAudioLayers((prev) => {
                const next = prev.filter((a) => a.id !== id);
                if (selectedAudioId === id) {
                  setSelectedAudioId(next[0]?.id ?? '');
                }
                return next;
              });
            }}
            onUpsertMainKeyframe={handleUpsertMainKeyframe}
            onDeleteMainKeyframe={handleDeleteMainKeyframe}
            onClearMainKeyframes={() => {
              pushHistory();
              setMainKeyframes([]);
            }}
            onApplyMotionPreset={handleApplyMotionPreset}
            onRunMotionTrack={handleRunMotionTrack}
            onDeleteMotionTrack={(trackId) => {
              pushHistory();
              setMotionTracks((prev) => prev.filter((t) => t.id !== trackId));
              setTextOverlays((prev) =>
                prev.map((t) => (t.trackId === trackId ? { ...t, trackId: undefined } : t))
              );
              setOverlayLayers((prev) =>
                prev.map((o) => (o.trackId === trackId ? { ...o, trackId: undefined } : o))
              );
            }}
            onAddTrackedItem={handleAddTrackedItem}
            onChangeBgRemoval={(patch) => {
              recordHistoryDebounced();
              setBgModelError(null);
              setBgRemoval((prev) => ({ ...prev, ...patch }));
            }}
            onRequestBgImage={() => bgImageInputRef.current?.click()}
            onChangeChromaKey={(patch) => {
              recordHistoryDebounced();
              setChromaKey((prev) => ({ ...prev, ...patch }));
            }}
            onRequestChromaBgImage={() => chromaBgImageInputRef.current?.click()}
            onRequestChromaBgVideo={() => chromaBgVideoInputRef.current?.click()}
            onRunStabilization={handleRunStabilization}
            onChangeStabilization={(patch) => {
              recordHistoryDebounced();
              setStabError(null);
              setStabilization((prev) => ({ ...prev, ...patch }));
            }}
            onChangeMask={(patch) => {
              recordHistoryDebounced();
              setMask((prev) => ({ ...prev, ...patch }));
            }}
            onResetMask={() => {
              pushHistory();
              setMask(DEFAULT_MASK_SETTINGS);
            }}
            onDetectBeats={handleDetectBeats}
            onSyncClipsToBeats={handleSyncClipsToBeats}
            onChangeCaptionLanguage={setCaptionLanguage}
            onChangeCaptionStyle={(style) => {
              setCaptionStyle(style);
              setCaptionsSaved(false);
              if (textOverlays.some((t) => t.isCaption)) {
                pushHistory();
                setTextOverlays((prev) =>
                  prev.map((t) => (t.isCaption ? { ...t, style } : t))
                );
              }
            }}
            onChangeCaptionColor={handleChangeCaptionColor}
            onGenerateAutoCaptions={handleGenerateAutoCaptions}
            onSaveCaptions={handleSaveCaptions}
            onExportSrt={handleExportSrt}
            onChangeSpeechTranscript={setSpeechTranscript}
            onTranscribeVideoSpeech={handleTranscribeVideoSpeech}
            onToggleMicRecord={handleToggleMicRecord}
            onUseTranscriptForVoice={() => {
              setTtsText(speechTranscript);
              if (captionLanguage !== 'auto') {
                setTtsLang(captionLanguage);
              }
              setPanelMode('voice');
            }}
            onAddTranscriptAsText={() => {
              handleAddTextOverlay(
                speechTranscript.slice(0, 140),
                captionLanguage === 'auto'
                  ? resolveTargetLanguageCode(uiLanguage, chineseVariant)
                  : captionLanguage
              );
              setPanelMode('text');
            }}
            onChangeTranslateTargetLang={setTranslateTargetLang}
            onTranslateCaptions={handleTranslateCaptions}
            onChangeTtsText={handleTtsTextChange}
            onChangeTtsLang={handleTtsLangManualSelect}
            onChangeTtsVoice={setTtsVoice}
            onChangeTtsMode={setTtsMode}
            onChangeTtsStylePrompt={setTtsStylePrompt}
            onUseCaptionsForVoice={() => {
              const joined = textOverlays
                .filter((t) => t.isCaption && t.text.trim())
                .map((t) => t.text.trim())
                .join(' ');
              if (joined) {
                handleTtsTextChange(joined.slice(0, 1200));
              }
            }}
            onGenerateVoice={handleGenerateVoice}
            onAddGeneratedVoiceToTimeline={handleAddGeneratedVoiceToTimeline}
            onChangeTextTranslateTargetLang={setTextTranslateTargetLang}
            onTranslateSelectedText={handleTranslateSelectedText}
            onRunAiEdit={handleRunAiEdit}
            onApplyAiEdit={handleApplyAiEdit}
            onInstantLocalAutoCut={handleInstantLocalAutoCut}
          />
          </div>

          <EditorToolbar
            panelMode={panelMode}
            strings={strings}
            selectedSegment={selectedSegment}
            canSplitAtPlayhead={canSplitAtPlayhead}
            canDeleteSelected={canDeleteSelected}
            canUndo={history.length > 0}
            canRedo={redoHistory.length > 0}
            hasEdits={hasEdits}
            activeEffectsCount={videoEffects.filter((fx) => fx.enabled).length}
            activeAudioCount={audioLayers.length}
            onSplit={handleSplit}
            onSelectPanelMode={setPanelMode}
            onToggleDeleteSelected={handleToggleDeleteSelected}
            onUndo={handleUndo}
            onRedo={handleRedo}
            onReset={handleReset}
            onReplaceVideo={handleTriggerUpload}
          />
        </>
      )}

      {isExportOpen && asset && (
        <ExportModal
          asset={asset}
          segments={segments}
          mainKeyframes={mainKeyframes}
          motionTracks={motionTracks}
          overlayLayers={overlayLayers}
          audioLayers={audioLayers}
          bgRemoval={bgRemoval}
          chromaKey={chromaKey}
          stabilization={stabilization}
          mask={mask}
          adjustments={adjustments}
          videoEffects={videoEffects}
          textOverlays={textOverlays}
          aspectRatio={aspectRatio}
          frameFit={frameFit}
          strings={strings}
          onClose={() => setIsExportOpen(false)}
        />
      )}

      {isProjectsModalOpen && (
        <ProjectsModal
          projects={savedProjects}
          currentProjectId={currentSavedProjectId}
          hasActiveAsset={Boolean(asset)}
          isSaving={isSavingProject}
          isLoadingProjectId={loadingProjectId}
          errorMessage={projectsError}
          strings={strings}
          onSaveCurrent={(saveAsNew) => handleSaveProject(Boolean(saveAsNew))}
          onOpenProject={handleOpenProject}
          onDeleteProject={handleDeleteProject}
          onClose={() => setIsProjectsModalOpen(false)}
        />
      )}

      {isLanguageModalOpen && (
        <LanguageModal
          uiLanguage={uiLanguage}
          chineseVariant={chineseVariant}
          strings={strings}
          onSelectLanguage={(nextLang) => {
            setUiLanguage(nextLang);
            const target = resolveTargetLanguageCode(nextLang, chineseVariant);
            if (!ttsText.trim()) {
              setTtsLang(target);
            }
            setTranslateTargetLang(target);
            setTextTranslateTargetLang(target);
          }}
          onSelectChineseVariant={(variant) => {
            setChineseVariant(variant);
            if (uiLanguage === 'zh') {
              if (!ttsText.trim()) {
                setTtsLang(variant);
              }
              setTranslateTargetLang(variant);
              setTextTranslateTargetLang(variant);
            }
          }}
          onClose={() => setIsLanguageModalOpen(false)}
        />
      )}
    </div>
  );
}
