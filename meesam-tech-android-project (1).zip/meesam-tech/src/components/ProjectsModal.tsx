import React from 'react';
import { FolderOpen, Loader2, Save, Trash2, X } from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import { SavedProjectSummary } from '../types/editor';
import { formatDurationShort } from '../utils/time';
import { ProjectZipDownloadControl } from './ProjectZipDownloadControl';

interface ProjectsModalProps {
  projects: SavedProjectSummary[];
  currentProjectId: string | null;
  hasActiveAsset: boolean;
  isSaving: boolean;
  isLoadingProjectId: string | null;
  errorMessage: string | null;
  strings: UiStrings;
  onSaveCurrent: (saveAsNew?: boolean) => void;
  onOpenProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onClose: () => void;
}

export const ProjectsModal: React.FC<ProjectsModalProps> = ({
  projects,
  currentProjectId,
  hasActiveAsset,
  isSaving,
  isLoadingProjectId,
  errorMessage,
  strings,
  onSaveCurrent,
  onOpenProject,
  onDeleteProject,
  onClose,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="projects-modal-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
    >
      <div className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl bg-[#0D0F16] border-t sm:border border-[#8B5CF6]/35 p-5 sm:p-6 pb-safe shadow-2xl max-h-[85vh] flex flex-col">
        <div className="w-10 h-1 rounded-full bg-[#A855F7]/40 mx-auto mb-4 sm:hidden" />

        <div className="flex items-center justify-between gap-4 mb-4">
          <h2 id="projects-modal-title" className="text-lg font-bold text-[#F5F2EA] flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-[#E5C158]" aria-hidden="true" />
            <span>{strings.savedProjectsTitle}</span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close projects dialog"
            className="min-w-[40px] min-h-[40px] rounded-lg flex items-center justify-center text-[#9E978B] hover:text-[#F5F2EA] hover:bg-white/8 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {hasActiveAsset && (
          <div className="flex flex-wrap items-center gap-2 pb-4 mb-4 border-b border-white/8">
            <button
              type="button"
              disabled={isSaving}
              onClick={() => onSaveCurrent(false)}
              className="flex-1 min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 disabled:opacity-50 text-white border border-[#A855F7]/60 text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-2 cursor-pointer shadow-[0_2px_16px_rgba(124,58,237,0.3)]"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin text-[#F3D778]" aria-hidden="true" />
              ) : (
                <Save className="w-4 h-4 text-[#F3D778]" aria-hidden="true" />
              )}
              <span>{currentProjectId ? 'Update Saved Project' : strings.saveProject}</span>
            </button>

            {currentProjectId && (
              <button
                type="button"
                disabled={isSaving}
                onClick={() => onSaveCurrent(true)}
                className="min-h-[42px] px-3.5 rounded-xl bg-[#141722] hover:bg-[#1C202E] border border-[#D4AF37]/30 text-[#EAE4D7] text-xs font-medium cursor-pointer"
              >
                Save Copy
              </button>
            )}
          </div>
        )}

        {errorMessage && (
          <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200 mb-3">
            {errorMessage}
          </div>
        )}

        <div className="flex-1 overflow-y-auto studio-scroll space-y-2 pr-0.5">
          {projects.length === 0 ? (
            <p className="text-xs sm:text-sm text-[#9E978B] py-8 text-center">
              {strings.noSavedProjects}
            </p>
          ) : (
            projects.map((proj) => {
              const isCurrent = proj.id === currentProjectId;
              const isBusy = isLoadingProjectId === proj.id;
              return (
                <div
                  key={proj.id}
                  className={`rounded-xl p-2.5 border flex items-center gap-3 ${
                    isCurrent
                      ? 'bg-[#7C3AED]/15 border-[#A855F7]/70'
                      : 'bg-[#141722] border-white/8'
                  }`}
                >
                  <div className="w-16 h-11 rounded-lg bg-black/70 overflow-hidden shrink-0 flex items-center justify-center border border-[#D4AF37]/25">
                    {proj.thumbnailDataUrl ? (
                      <img
                        src={proj.thumbnailDataUrl}
                        alt={proj.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <FolderOpen className="w-4 h-4 text-[#8D8578]" aria-hidden="true" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs sm:text-sm font-semibold text-[#F5F2EA] truncate">
                        {proj.name}
                      </span>
                      {isCurrent && (
                        <span className="text-[10px] font-semibold text-[#E5C158] shrink-0">
                          · Active
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-[#9E978B] font-mono-tabular mt-0.5">
                      {proj.width}×{proj.height} · {formatDurationShort(proj.duration)} ·{' '}
                      {new Date(proj.updatedAt).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      disabled={Boolean(isLoadingProjectId)}
                      onClick={() => onOpenProject(proj.id)}
                      className="min-h-[36px] px-3 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#6D28D9] hover:brightness-110 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                    >
                      {isBusy ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                      ) : (
                        <span>{strings.openProject}</span>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteProject(proj.id)}
                      aria-label={strings.deleteProject}
                      className="min-w-[36px] min-h-[36px] rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="pt-3 mt-3 border-t border-white/8">
          <ProjectZipDownloadControl compact />
        </div>
      </div>
    </div>
  );
};
