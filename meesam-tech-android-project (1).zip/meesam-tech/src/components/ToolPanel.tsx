import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertCircle,
  ArrowLeftRight,
  Ban,
  Blend,
  Captions,
  Check,
  ChevronLeft,
  ChevronRight,
  Crosshair,
  Diamond,
  Download,
  Eraser,
  Eye,
  EyeOff,
  Film,
  ImagePlus,
  Languages,
  Layers,
  LayoutGrid,
  Loader2,
  Mic,
  Music,
  Music2,
  Palette,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Rows3,
  Save,
  Scan,
  Scissors,
  Search,
  Sparkles,
  Square,
  Trash2,
  Type,
  Video,
  Volume2,
  VolumeX,
  Wand2,
  X,
  Zap,
} from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import {
  AiEditMode,
  AiEditResult,
  AspectRatioPreset,
  AudioLayer,
  BeatAnalysis,
  BgRemovalMode,
  BgRemovalSettings,
  CaptionLanguage,
  ChineseVariant,
  ChromaKeyBgMode,
  ChromaKeySettings,
  ClipTransition,
  EditorPanelMode,
  EffectCategory,
  FilterCategory,
  FrameFitMode,
  KeyframeEasing,
  MaskSettings,
  MaskShape,
  MotionTrack,
  OverlayLayer,
  SpeedCurvePoint,
  StabilizationSettings,
  TargetLanguageCode,
  TextOverlay,
  TextPosition,
  TextSizePreset,
  TextStylePreset,
  TimelineSegment,
  TransformKeyframe,
  TtsGenerationMode,
  TtsVoiceName,
  VideoAdjustments,
  VideoEffectLayer,
} from '../types/editor';
import {
  EFFECT_CATEGORIES,
  findEffectDefinition,
  getEffectCategoryCount,
  TOTAL_EFFECT_COUNT,
  VIDEO_EFFECTS,
} from '../utils/effectsCatalog';
import {
  EffectsRenderPool,
  renderEffectThumbnailDataUrl,
} from '../utils/effectsEngine';
import {
  ASPECT_RATIO_OPTIONS,
  DEFAULT_ADJUSTMENTS,
  FILTER_CATEGORIES,
  FILTER_PRESETS,
  findFilterPreset,
  getFilterCategoryCount,
  SPEED_OPTIONS,
  TOTAL_FILTER_COUNT,
} from '../utils/filters';
import { DEFAULT_TRANSFORM, evaluateKeyframes } from '../utils/keyframes';
import {
  detectScriptLanguage,
  resolveScriptRenderConfig,
  TARGET_LANGUAGE_OPTIONS,
} from '../utils/languages';
import {
  evaluateCurveAtProgress,
  hasCustomSpeedCurve,
  sortAndClampCurve,
  SPEED_CURVE_PRESETS,
  SpeedCurvePresetId,
} from '../utils/speedCurve';
import { formatTimecode, getSegmentDisplaySpeed } from '../utils/time';
import { DEFAULT_TRANSITION, TRANSITION_PRESETS } from '../utils/transitions';
import {
  BUILTIN_MUSIC_TRACKS,
  getOrCreatePresetAudio,
  MUSIC_LIBRARY_CATEGORIES,
  MusicLibraryCategory,
} from '../utils/audioLibrary';
import { downloadMediaFile } from '../utils/androidBridge';

interface ToolPanelProps {
  panelMode: EditorPanelMode;
  mediaKind?: 'video' | 'image';
  duration: number;
  currentTime: number;
  selectedSegment: TimelineSegment | undefined;
  adjustments: VideoAdjustments;
  videoEffects: VideoEffectLayer[];
  selectedEffectId: string;
  previewThumbnail?: string;
  mainKeyframes: TransformKeyframe[];
  motionTracks: MotionTrack[];
  pendingTrackTarget: { x: number; y: number } | null;
  motionTrackingProgress: number | null;
  motionTrackError?: string | null;
  overlayLayers: OverlayLayer[];
  selectedOverlayId: string;
  audioLayers: AudioLayer[];
  selectedAudioId: string;
  bgRemoval: BgRemovalSettings;
  bgModelError: string | null;
  chromaKey: ChromaKeySettings;
  stabilization: StabilizationSettings;
  stabProgress: number | null;
  stabError?: string | null;
  mask: MaskSettings;
  beatAnalysis: BeatAnalysis | null;
  beatsBusy: boolean;
  beatsError?: string | null;
  autoCutBusy?: boolean;
  textOverlays: TextOverlay[];
  selectedTextId: string;
  aspectRatio: AspectRatioPreset;
  frameFit: FrameFitMode;
  captionLanguage: CaptionLanguage;
  captionStyle: TextStylePreset;
  captionColor: string;
  chineseVariant: ChineseVariant;
  captionsSaved: boolean;
  isSavingCaptions: boolean;
  strings: UiStrings;
  aiBusy: boolean;
  aiError: string | null;
  aiResult: AiEditResult | null;
  speechTranscript: string;
  speechBusy: boolean;
  speechError: string | null;
  isRecordingMic: boolean;
  translateTargetLang: TargetLanguageCode;
  translateBusy: boolean;
  ttsText: string;
  ttsLang: TargetLanguageCode;
  ttsLangAutoDetected?: boolean;
  ttsVoice: TtsVoiceName;
  ttsMode: TtsGenerationMode;
  ttsStylePrompt: string;
  ttsBusy: boolean;
  ttsError: string | null;
  ttsResultUrl: string | null;
  ttsResultDuration: number;
  ttsResultModel: string | null;
  textTranslateTargetLang: TargetLanguageCode;
  textTranslateBusy: boolean;
  canDeleteSegmentPermanently?: boolean;
  onClose: () => void;
  onSeek: (time: number) => void;
  onNudgeTrim: (edge: 'start' | 'end', delta: number) => void;
  onSnapTrimToPlayhead: (edge: 'start' | 'end') => void;
  onDeleteSegmentPermanently?: (segmentId: string) => void;
  onChangeClipTransition?: (
    segmentId: string,
    transition: ClipTransition,
    applyAll?: boolean
  ) => void;
  onChangeClipSpeed: (segmentId: string, speed: number, applyAll?: boolean) => void;
  onUpdateSpeedCurve: (segmentId: string, curve: SpeedCurvePoint[] | undefined) => void;
  onApplySpeedCurvePreset: (segmentId: string, presetId: SpeedCurvePresetId) => void;
  onToggleSmoothSlowMo: (segmentId: string) => void;
  onApplySlowMoHighlight: (speed: number) => void;
  onChangeClipAudio: (
    segmentId: string,
    patch: { volume?: number; muted?: boolean; fadeInSec?: number; fadeOutSec?: number },
    applyAll?: boolean
  ) => void;
  onChangeAdjustments: (next: VideoAdjustments) => void;
  onApplyVideoEffect: (effectId: string, stack?: boolean) => void;
  onSelectVideoEffect: (id: string) => void;
  onUpdateVideoEffect: (id: string, patch: Partial<VideoEffectLayer>) => void;
  onDeleteVideoEffect: (id: string) => void;
  onClearAllVideoEffects: () => void;
  onMoveVideoEffect?: (id: string, delta: -1 | 1) => void;
  onAddTextOverlay: (
    preset?: 'text' | 'title' | 'subtitle' | 'watermark',
    styleOverride?: { style: TextStylePreset; color: string }
  ) => void;
  onAddStickerOverlay: (emoji: string) => void;
  onSelectTextOverlay: (id: string) => void;
  onUpdateTextOverlay: (id: string, patch: Partial<TextOverlay>) => void;
  onDeleteTextOverlay: (id: string) => void;
  onClearAllCaptions: () => void;
  onShiftAllCaptions?: (deltaSec: number) => void;
  onAddManualCaption?: () => void;
  onChangeAspectRatio: (ratio: AspectRatioPreset) => void;
  onChangeFrameFit: (fit: FrameFitMode) => void;
  onRequestAddOverlay: () => void;
  onSelectOverlay: (id: string) => void;
  onUpdateOverlay: (id: string, patch: Partial<OverlayLayer>) => void;
  onDeleteOverlay: (id: string) => void;
  onRequestAddAudio: () => void;
  onAddAudioLayer?: (params: {
    name: string;
    url: string;
    duration: number;
    blob?: Blob;
  }) => void;
  onSelectAudio: (id: string) => void;
  onUpdateAudio: (id: string, patch: Partial<AudioLayer>) => void;
  onDeleteAudio: (id: string) => void;
  onUpsertMainKeyframe: (patch?: Partial<Omit<TransformKeyframe, 'id'>>) => void;
  onDeleteMainKeyframe: (id: string) => void;
  onClearMainKeyframes: () => void;
  onApplyMotionPreset: (preset: 'zoom_in' | 'zoom_out' | 'pan_lr' | 'fade_pop') => void;
  onRunMotionTrack: (label: string) => void;
  onDeleteMotionTrack: (trackId: string) => void;
  onAddTrackedItem: (trackId: string, content: string, isSticker: boolean) => void;
  onChangeBgRemoval: (patch: Partial<BgRemovalSettings>) => void;
  onRequestBgImage: () => void;
  onChangeChromaKey: (patch: Partial<ChromaKeySettings>) => void;
  onRequestChromaBgImage: () => void;
  onRequestChromaBgVideo: () => void;
  onRunStabilization: () => void;
  onChangeStabilization: (patch: Partial<StabilizationSettings>) => void;
  onChangeMask: (patch: Partial<MaskSettings>) => void;
  onResetMask: () => void;
  onDetectBeats: (sourceId: string, sensitivity: number) => void;
  onSyncClipsToBeats: (beatStep: 1 | 2 | 4) => void;
  onChangeCaptionLanguage: (lang: CaptionLanguage) => void;
  onChangeCaptionStyle: (style: TextStylePreset) => void;
  onChangeCaptionColor: (color: string) => void;
  onGenerateAutoCaptions: () => void;
  onSaveCaptions: () => void;
  onExportSrt: () => void;
  onChangeSpeechTranscript: (text: string) => void;
  onTranscribeVideoSpeech: () => void;
  onToggleMicRecord: () => void;
  onUseTranscriptForVoice: () => void;
  onAddTranscriptAsText: () => void;
  onChangeTranslateTargetLang: (lang: TargetLanguageCode) => void;
  onTranslateCaptions: (targetOverride?: TargetLanguageCode) => void;
  onChangeTtsText: (text: string) => void;
  onChangeTtsLang: (lang: TargetLanguageCode) => void;
  onChangeTtsVoice: (voice: TtsVoiceName) => void;
  onChangeTtsMode: (mode: TtsGenerationMode) => void;
  onChangeTtsStylePrompt: (prompt: string) => void;
  onUseCaptionsForVoice: () => void;
  onGenerateVoice: () => void;
  onAddGeneratedVoiceToTimeline: () => void;
  onChangeTextTranslateTargetLang: (lang: TargetLanguageCode) => void;
  onTranslateSelectedText: () => void;
  onRunAiEdit: (mode: AiEditMode, customPrompt?: string) => void;
  onApplyAiEdit: (result: AiEditResult) => void;
  onInstantLocalAutoCut: () => void;
}

const STICKER_PRESETS = ['🔥', '✨', '🎯', '🎬', '👍', '❤️', '😂', '⭐', '💯', '🎵'];
const CHROMA_KEY_PRESETS = [
  { hex: '#00b140', label: 'Green' },
  { hex: '#0047bb', label: 'Blue' },
  { hex: '#00d2ff', label: 'Cyan' },
];

const TEXT_COLORS = ['#ffffff', '#E5C158', '#38bdf8', '#A855F7', '#f87171', '#34d399', '#000000'];
const BG_COLORS = ['#00b140', '#0f172a', '#ffffff', '#2563eb', '#ec4899'];

const TEXT_AA_PRESETS: Array<{
  id: string;
  label: string;
  style: TextStylePreset;
  color: string;
  previewClass: string;
  cardClass: string;
}> = [
  {
    id: 'clean',
    label: 'Clean',
    style: 'clean',
    color: '#ffffff',
    previewClass: 'text-white font-bold',
    cardClass: 'bg-[#12141E] border-white/12',
  },
  {
    id: 'gold',
    label: 'Gold',
    style: 'pop',
    color: '#E5C158',
    previewClass: 'text-[#E5C158] font-extrabold drop-shadow-[0_2px_6px_rgba(229,193,88,0.45)]',
    cardClass: 'bg-[#12141E] border-[#D4AF37]/30',
  },
  {
    id: 'cyan',
    label: 'Cyan',
    style: 'outline',
    color: '#38bdf8',
    previewClass:
      'text-[#38bdf8] font-extrabold [text-shadow:_-1px_-1px_0_#062336,_1px_-1px_0_#062336,_-1px_1px_0_#062336,_1px_1px_0_#062336]',
    cardClass: 'bg-[#12141E] border-[#38bdf8]/30',
  },
  {
    id: 'neon',
    label: 'Neon',
    style: 'boxed',
    color: '#F5E1FF',
    previewClass:
      'text-white font-extrabold drop-shadow-[0_0_10px_rgba(168,85,247,0.95)]',
    cardClass:
      'bg-gradient-to-br from-[#2B124C]/80 to-[#141024] border-[#A855F7]/75 shadow-[0_0_14px_rgba(168,85,247,0.28)]',
  },
];

const CAPTION_STYLE_ITEMS: Array<{ id: TextStylePreset; label: string }> = [
  { id: 'subtitle-bar', label: 'Bar' },
  { id: 'boxed', label: 'Box' },
  { id: 'outline', label: 'Outline' },
  { id: 'pop', label: 'Pop' },
  { id: 'clean', label: 'Clean' },
];

const CAPTION_COLORS: Array<{ hex: string; label: string }> = [
  { hex: '#ffffff', label: 'White' },
  { hex: '#facc15', label: 'Yellow' },
  { hex: '#38bdf8', label: 'Cyan' },
  { hex: '#4ade80', label: 'Green' },
  { hex: '#fb7185', label: 'Pink' },
  { hex: '#fb923c', label: 'Orange' },
];

const TTS_VOICE_PROFILES: Array<{
  id: TtsVoiceName;
  urTitle: string;
  urSubtitle: string;
  title: string;
  subtitle: string;
}> = [
  {
    id: 'Kore',
    urTitle: 'Pakistani Female',
    urSubtitle: 'Clear & Natural',
    title: 'Female · Clear',
    subtitle: 'Balanced',
  },
  {
    id: 'Fenrir',
    urTitle: 'Pakistani Male',
    urSubtitle: 'Warm & Natural',
    title: 'Male · Warm',
    subtitle: 'Storyteller',
  },
  {
    id: 'Charon',
    urTitle: 'Deep Male',
    urSubtitle: 'News / Doc',
    title: 'Male · Deep',
    subtitle: 'Documentary',
  },
  {
    id: 'Zephyr',
    urTitle: 'Soft Female',
    urSubtitle: 'Calm & Gentle',
    title: 'Female · Soft',
    subtitle: 'Calm',
  },
  {
    id: 'Puck',
    urTitle: 'Young Male',
    urSubtitle: 'Energetic Reels',
    title: 'Male · Bright',
    subtitle: 'Energetic',
  },
];

const TTS_STYLE_CHIPS = [
  'Warm storyteller',
  'News anchor',
  'Energetic Reels host',
  'Calm explainer',
];

export const ToolPanel: React.FC<ToolPanelProps> = ({
  panelMode,
  mediaKind,
  duration,
  currentTime,
  selectedSegment,
  adjustments,
  videoEffects,
  selectedEffectId,
  previewThumbnail,
  mainKeyframes,
  motionTracks,
  pendingTrackTarget,
  motionTrackingProgress,
  motionTrackError,
  overlayLayers,
  selectedOverlayId,
  audioLayers,
  selectedAudioId,
  bgRemoval,
  bgModelError,
  chromaKey,
  stabilization,
  stabProgress,
  stabError,
  mask,
  beatAnalysis,
  beatsBusy,
  beatsError,
  autoCutBusy,
  textOverlays,
  selectedTextId,
  aspectRatio,
  frameFit,
  captionLanguage,
  captionStyle,
  captionColor,
  chineseVariant,
  captionsSaved,
  isSavingCaptions,
  strings,
  aiBusy,
  aiError,
  aiResult,
  speechTranscript: _speechTranscript,
  speechBusy: _speechBusy,
  speechError: _speechError,
  isRecordingMic: _isRecordingMic,
  translateTargetLang: _translateTargetLang,
  translateBusy,
  ttsText,
  ttsLang,
  ttsLangAutoDetected,
  ttsVoice,
  ttsMode,
  ttsStylePrompt,
  ttsBusy,
  ttsError,
  ttsResultUrl,
  ttsResultDuration,
  ttsResultModel,
  textTranslateTargetLang,
  textTranslateBusy,
  canDeleteSegmentPermanently,
  onClose,
  onSeek,
  onNudgeTrim,
  onSnapTrimToPlayhead,
  onDeleteSegmentPermanently,
  onChangeClipTransition,
  onChangeClipSpeed,
  onUpdateSpeedCurve,
  onApplySpeedCurvePreset,
  onToggleSmoothSlowMo,
  onApplySlowMoHighlight,
  onChangeClipAudio,
  onChangeAdjustments,
  onApplyVideoEffect,
  onSelectVideoEffect,
  onUpdateVideoEffect,
  onDeleteVideoEffect,
  onClearAllVideoEffects,
  onMoveVideoEffect,
  onAddTextOverlay,
  onAddStickerOverlay,
  onSelectTextOverlay,
  onUpdateTextOverlay,
  onDeleteTextOverlay,
  onClearAllCaptions,
  onShiftAllCaptions,
  onAddManualCaption,
  onChangeAspectRatio,
  onChangeFrameFit,
  onRequestAddOverlay,
  onSelectOverlay,
  onUpdateOverlay,
  onDeleteOverlay,
  onRequestAddAudio,
  onAddAudioLayer,
  onSelectAudio,
  onUpdateAudio,
  onDeleteAudio,
  onUpsertMainKeyframe,
  onDeleteMainKeyframe,
  onClearMainKeyframes,
  onApplyMotionPreset,
  onRunMotionTrack,
  onDeleteMotionTrack,
  onAddTrackedItem,
  onChangeBgRemoval,
  onRequestBgImage,
  onChangeChromaKey,
  onRequestChromaBgImage,
  onRequestChromaBgVideo,
  onRunStabilization,
  onChangeStabilization,
  onChangeMask,
  onResetMask,
  onDetectBeats,
  onSyncClipsToBeats,
  onChangeCaptionLanguage,
  onChangeCaptionStyle,
  onChangeCaptionColor,
  onGenerateAutoCaptions,
  onSaveCaptions,
  onExportSrt,
  onChangeSpeechTranscript: _onChangeSpeechTranscript,
  onTranscribeVideoSpeech: _onTranscribeVideoSpeech,
  onToggleMicRecord: _onToggleMicRecord,
  onUseTranscriptForVoice: _onUseTranscriptForVoice,
  onAddTranscriptAsText: _onAddTranscriptAsText,
  onChangeTranslateTargetLang,
  onTranslateCaptions,
  onChangeTtsText,
  onChangeTtsLang,
  onChangeTtsVoice,
  onChangeTtsMode,
  onChangeTtsStylePrompt,
  onUseCaptionsForVoice,
  onGenerateVoice,
  onAddGeneratedVoiceToTimeline,
  onChangeTextTranslateTargetLang,
  onTranslateSelectedText,
  onRunAiEdit,
  onApplyAiEdit,
  onInstantLocalAutoCut,
}) => {
  const [filterCategory, setFilterCategory] = useState<FilterCategory>('all');
  const [filterQuery, setFilterQuery] = useState('');
  const [filterLayout, setFilterLayout] = useState<'strip' | 'grid'>('strip');
  const [aiPrompt, setAiPrompt] = useState('');
  const [trackLabel, setTrackLabel] = useState('Subject 1');
  const [selectedTrackId, setSelectedTrackId] = useState<string>('');
  const [beatSourceId, setBeatSourceId] = useState<string>('main');
  const [beatSensitivity, setBeatSensitivity] = useState<number>(0.55);
  const [selectedCurvePointIdx, setSelectedCurvePointIdx] = useState<number>(0);

  const [effectCategory, setEffectCategory] = useState<EffectCategory>('all');
  const [effectQuery, setEffectQuery] = useState('');
  const [effectLayout, setEffectLayout] = useState<'grid' | 'strip'>('grid');
  const [effectStackMode, setEffectStackMode] = useState(false);
  const [showEffectTiming, setShowEffectTiming] = useState(false);
  const [textSubTab, setTextSubTab] = useState<'add' | 'styles' | 'timing'>('add');
  const [effectThumbMap, setEffectThumbMap] = useState<Record<string, string>>({});
  const [thumbImgVersion, setThumbImgVersion] = useState(0);
  const effectThumbPoolRef = useRef<EffectsRenderPool | null>(null);
  const effectThumbImgRef = useRef<HTMLImageElement | null>(null);
  const effectThumbCacheRef = useRef<Record<string, string>>({});
  const effectThumbCacheVersionRef = useRef<number>(-1);

  const filteredPresets = useMemo(() => {
    const q = filterQuery.trim().toLowerCase();
    return FILTER_PRESETS.filter((preset) => {
      const catOk =
        filterCategory === 'all' || preset.id === 'none' || preset.category === filterCategory;
      const queryOk =
        !q ||
        preset.label.toLowerCase().includes(q) ||
        preset.category.toLowerCase().includes(q);
      return catOk && queryOk;
    });
  }, [filterCategory, filterQuery]);

  const filteredVideoEffects = useMemo(() => {
    const q = effectQuery.trim().toLowerCase();
    return VIDEO_EFFECTS.filter((fx) => {
      const catOk = effectCategory === 'all' || fx.category === effectCategory;
      const queryOk =
        !q ||
        fx.label.toLowerCase().includes(q) ||
        fx.category.toLowerCase().includes(q);
      return catOk && queryOk;
    });
  }, [effectCategory, effectQuery]);

  useEffect(() => {
    effectThumbCacheRef.current = {};
    effectThumbCacheVersionRef.current = -1;
    setEffectThumbMap({});
    if (!previewThumbnail) {
      effectThumbImgRef.current = null;
      setThumbImgVersion((v) => v + 1);
      return;
    }
    let cancelled = false;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (cancelled) return;
      effectThumbImgRef.current = img;
      setThumbImgVersion((v) => v + 1);
    };
    img.onerror = () => {
      if (cancelled) return;
      effectThumbImgRef.current = null;
      setThumbImgVersion((v) => v + 1);
    };
    img.src = previewThumbnail;
    return () => {
      cancelled = true;
    };
  }, [previewThumbnail]);

  useEffect(() => {
    if (panelMode !== 'effects') return;
    if (effectThumbCacheVersionRef.current !== thumbImgVersion) {
      effectThumbCacheRef.current = {};
      effectThumbCacheVersionRef.current = thumbImgVersion;
    }
    const missing = filteredVideoEffects.filter(
      (fx) => !effectThumbCacheRef.current[fx.id]
    );
    if (missing.length === 0) return;

    if (!effectThumbPoolRef.current) {
      effectThumbPoolRef.current = new EffectsRenderPool();
    }
    const pool = effectThumbPoolRef.current;
    let cancelled = false;
    let cursor = 0;
    let rafId = 0;

    const renderBatch = () => {
      if (cancelled) return;
      let updated = false;
      const limit = Math.min(cursor + 6, missing.length);
      for (; cursor < limit; cursor++) {
        const fx = missing[cursor];
        if (effectThumbCacheRef.current[fx.id]) continue;
        const url = renderEffectThumbnailDataUrl(
          effectThumbImgRef.current,
          fx.id,
          fx.swatch,
          pool,
          112,
          64
        );
        if (url) {
          effectThumbCacheRef.current[fx.id] = url;
          updated = true;
        }
      }
      if (updated) {
        setEffectThumbMap({ ...effectThumbCacheRef.current });
      }
      if (cursor < missing.length) {
        rafId = requestAnimationFrame(renderBatch);
      }
    };

    rafId = requestAnimationFrame(renderBatch);
    return () => {
      cancelled = true;
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [filteredVideoEffects, panelMode, thumbImgVersion]);

  const voiceAudioRef = useRef<HTMLAudioElement | null>(null);
  const [isVoicePlaying, setIsVoicePlaying] = useState<boolean>(false);
  const [voicePlayTime, setVoicePlayTime] = useState<number>(0);

  const musicPreviewAudioRef = useRef<HTMLAudioElement | null>(null);
  const [audioSubTab, setAudioSubTab] = useState<'library' | 'tracks' | 'video'>('library');
  const [musicCategory, setMusicCategory] = useState<MusicLibraryCategory>('all');
  const [previewAudioKey, setPreviewAudioKey] = useState<string | null>(null);

  useEffect(() => {
    setIsVoicePlaying(false);
    setVoicePlayTime(0);
    if (voiceAudioRef.current) {
      voiceAudioRef.current.pause();
      voiceAudioRef.current.currentTime = 0;
    }
  }, [ttsResultUrl]);

  useEffect(() => {
    if (panelMode !== 'audio') {
      setPreviewAudioKey(null);
      if (musicPreviewAudioRef.current) {
        musicPreviewAudioRef.current.pause();
        musicPreviewAudioRef.current.currentTime = 0;
      }
    }
  }, [panelMode]);

  useEffect(() => {
    if (panelMode === 'audio' && audioLayers.length > 0 && selectedAudioId) {
      setAudioSubTab((prev) => (prev === 'video' ? prev : 'tracks'));
    }
  }, [audioLayers.length, panelMode, selectedAudioId]);

  useEffect(() => {
    return () => {
      if (musicPreviewAudioRef.current) {
        musicPreviewAudioRef.current.pause();
      }
    };
  }, []);

  if (panelMode === 'default') return null;

  const selectedSpeed = selectedSegment ? getSegmentDisplaySpeed(selectedSegment) : 1;
  const selectedSmooth = Boolean(selectedSegment?.meta?.smoothSlowMo);
  const selectedMuted = Boolean(selectedSegment?.meta?.muted);
  const selectedVolume = Math.round((selectedSegment?.meta?.volume ?? 1) * 100);
  const selectedText =
    textOverlays.find((t) => t.id === selectedTextId) ?? textOverlays[0];
  const selectedOverlay =
    overlayLayers.find((o) => o.id === selectedOverlayId) ?? overlayLayers[0];
  const selectedAudio =
    audioLayers.find((a) => a.id === selectedAudioId) ?? audioLayers[0];
  const activeMotionTrack =
    motionTracks.find((t) => t.id === selectedTrackId) ?? motionTracks[0];

  const sortedKeyframes = [...mainKeyframes].sort((a, b) => a.time - b.time);
  const nearestKeyframe = sortedKeyframes.find(
    (k) => Math.abs(k.time - currentTime) <= 0.15
  );
  const activeTransform = evaluateKeyframes(mainKeyframes, currentTime, DEFAULT_TRANSFORM);
  const captionOverlays = textOverlays.filter((t) => t.isCaption);

  const selectedFadeIn = selectedSegment?.meta?.fadeInSec ?? 0;
  const selectedFadeOut = selectedSegment?.meta?.fadeOutSec ?? 0;
  const selectedTransition: ClipTransition =
    selectedSegment?.meta?.transition ?? DEFAULT_TRANSITION;

  const titles: Record<Exclude<EditorPanelMode, 'default'>, string> = {
    ai: strings.panelAiTitle,
    layers: strings.panelLayersTitle,
    keyframes: strings.panelKeyframesTitle,
    motion: strings.panelMotionTrackTitle,
    bgremove: strings.panelBgRemoveTitle,
    chroma: strings.panelChromaKeyTitle,
    stabilize: strings.panelStabilizeTitle,
    mask: strings.panelMaskTitle,
    beats: strings.panelBeatSyncTitle,
    captions: strings.panelCaptionsTitle,
    voice: strings.panelVoiceTitle,
    trim: strings.panelTrimTitle,
    speed: strings.panelSpeedTitle,
    filters: `${strings.panelFiltersTitle} (${TOTAL_FILTER_COUNT})`,
    effects: `${strings.panelEffectsTitle} (${TOTAL_EFFECT_COUNT})`,
    transitions: strings.panelTransitionsTitle,
    text: strings.panelTextTitle,
    audio: strings.panelAudioTitle,
    ratio: strings.panelRatioTitle,
  };

  const ttsScriptCfg = resolveScriptRenderConfig(ttsText, ttsLang);

  const toggleVoicePreview = () => {
    const audio = voiceAudioRef.current;
    if (!audio || !ttsResultUrl) return;
    if (audio.paused) {
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
  };

  const selectedTextScriptCfg = selectedText
    ? resolveScriptRenderConfig(
        selectedText.text,
        selectedText.lang,
        selectedText.dir ?? 'auto'
      )
    : resolveScriptRenderConfig('', 'en');

  const rawCurve = selectedSegment?.meta?.speedCurve;
  const activeCurve =
    rawCurve && rawCurve.length >= 2
      ? sortAndClampCurve(rawCurve)
      : [
          { id: 'pt-0', position: 0, speed: selectedSpeed },
          { id: 'pt-1', position: 0.5, speed: selectedSpeed },
          { id: 'pt-2', position: 1, speed: selectedSpeed },
        ];
  const safeCurvePointIdx = Math.min(selectedCurvePointIdx, activeCurve.length - 1);

  return (
    <div className="bg-[#0B0D14] border-t border-[#8B5CF6]/30 lg:border-t-0 lg:border-l lg:border-[#8B5CF6]/30 lg:w-[395px] xl:w-[430px] lg:h-full lg:shrink-0 px-3 sm:px-4 py-2.5 lg:py-3 max-h-[46vh] lg:max-h-none overflow-y-auto studio-scroll shrink-0">
      <div className="max-w-5xl lg:max-w-none mx-auto flex flex-col gap-2.5">
        {/* Compact panel header */}
        <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-white/8">
          <span className="text-xs sm:text-sm font-semibold text-[#F5F2EA] tracking-wide flex items-center gap-2">
            {panelMode === 'ai' && (
              <Sparkles className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'layers' && (
              <Layers className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'keyframes' && (
              <Diamond className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'motion' && (
              <Crosshair className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'bgremove' && (
              <Eraser className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'chroma' && (
              <Blend className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'stabilize' && (
              <Activity className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'mask' && (
              <Scan className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'beats' && (
              <Music2 className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'captions' && (
              <Captions className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'voice' && (
              <Mic className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'effects' && (
              <Wand2 className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'filters' && (
              <Palette className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'text' && (
              <Type className="w-4 h-4 text-[#F5F2EA]" aria-hidden="true" />
            )}
            {panelMode === 'audio' && (
              <Music className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'trim' && (
              <Scissors className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'speed' && (
              <Zap className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            {panelMode === 'transitions' && (
              <ArrowLeftRight className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
            )}
            {panelMode === 'ratio' && (
              <LayoutGrid className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
            <span>{titles[panelMode]}</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close tool panel"
            className="min-w-[32px] min-h-[32px] px-2.5 rounded-lg text-xs font-medium text-[#D4C7A8] hover:text-white bg-[#141722] hover:bg-[#1E2233] border border-white/10 inline-flex items-center gap-1 cursor-pointer transition-colors"
          >
            <X className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{strings.done}</span>
          </button>
        </div>

        {/* MULTI-LAYER TIMELINE PANEL (V2 Overlays & A1 Audio Tracks) */}
        {panelMode === 'layers' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={onRequestAddOverlay}
                className="min-h-[40px] px-3.5 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Add Video / Image Overlay (V2)</span>
              </button>

              <button
                type="button"
                onClick={onRequestAddAudio}
                className="min-h-[40px] px-3.5 rounded-xl bg-[#141720] hover:bg-[#1C202B] border border-[#D4AF37]/35 text-[#F5E1A4] text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Music className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                <span>Add Music / Audio Track (A1)</span>
              </button>
            </div>

            {overlayLayers.length > 0 && (
              <div className="bg-[#141720] border border-white/8 rounded-xl p-2.5 flex flex-col gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                  <span className="text-[11px] font-semibold text-[#E5C158] shrink-0 mr-1">
                    V2 Overlays:
                  </span>
                  {overlayLayers.map((ov) => (
                    <button
                      key={ov.id}
                      type="button"
                      onClick={() => onSelectOverlay(ov.id)}
                      className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1 shrink-0 max-w-[150px] truncate cursor-pointer ${
                        ov.id === selectedOverlay?.id
                          ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                          : 'bg-[#090A0E] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                      }`}
                    >
                      <Film className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span className="truncate">{ov.name}</span>
                    </button>
                  ))}
                </div>

                {selectedOverlay && (
                  <>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      <label className="flex items-center gap-1.5 text-[11px] text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Size</span>
                        <input
                          type="range"
                          min={15}
                          max={150}
                          value={Math.round(selectedOverlay.scale * 100)}
                          onChange={(e) =>
                            onUpdateOverlay(selectedOverlay.id, {
                              scale: Number(e.target.value) / 100,
                            })
                          }
                          className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-9 text-right text-[#D4C7A8]">
                          {Math.round(selectedOverlay.scale * 100)}%
                        </span>
                      </label>

                      <label className="flex items-center gap-1.5 text-[11px] text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Pos X</span>
                        <input
                          type="range"
                          min={-45}
                          max={45}
                          value={Math.round(selectedOverlay.x)}
                          onChange={(e) =>
                            onUpdateOverlay(selectedOverlay.id, { x: Number(e.target.value) })
                          }
                          className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-8 text-right text-[#D4C7A8]">
                          {Math.round(selectedOverlay.x)}%
                        </span>
                      </label>

                      <label className="flex items-center gap-1.5 text-[11px] text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Pos Y</span>
                        <input
                          type="range"
                          min={-45}
                          max={45}
                          value={Math.round(selectedOverlay.y)}
                          onChange={(e) =>
                            onUpdateOverlay(selectedOverlay.id, { y: Number(e.target.value) })
                          }
                          className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-8 text-right text-[#D4C7A8]">
                          {Math.round(selectedOverlay.y)}%
                        </span>
                      </label>

                      <label className="flex items-center gap-1.5 text-[11px] text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Fade</span>
                        <input
                          type="range"
                          min={10}
                          max={100}
                          value={Math.round(selectedOverlay.opacity * 100)}
                          onChange={(e) =>
                            onUpdateOverlay(selectedOverlay.id, {
                              opacity: Number(e.target.value) / 100,
                            })
                          }
                          className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-9 text-right text-[#D4C7A8]">
                          {Math.round(selectedOverlay.opacity * 100)}%
                        </span>
                      </label>

                      <label className="flex items-center gap-1.5 text-[11px] text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Rot</span>
                        <input
                          type="range"
                          min={-180}
                          max={180}
                          value={Math.round(selectedOverlay.rotation)}
                          onChange={(e) =>
                            onUpdateOverlay(selectedOverlay.id, {
                              rotation: Number(e.target.value),
                            })
                          }
                          className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-9 text-right text-[#D4C7A8]">
                          {Math.round(selectedOverlay.rotation)}°
                        </span>
                      </label>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] pt-1.5 border-t border-white/8">
                      <div className="flex flex-wrap items-center gap-2 text-[#D4C7A8] font-mono-tabular">
                        <span>
                          Range: {formatTimecode(selectedOverlay.startTime)} –{' '}
                          {formatTimecode(selectedOverlay.endTime)}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateOverlay(selectedOverlay.id, {
                              startTime: Math.min(currentTime, Math.max(0, duration - 0.5)),
                              endTime: Math.max(
                                Math.min(duration, currentTime + 0.5),
                                selectedOverlay.endTime
                              ),
                            })
                          }
                          className="px-2.5 py-1 rounded-md bg-white/6 hover:bg-[#D4AF37]/15 text-[#F5F2EA] cursor-pointer"
                        >
                          Start @ Playhead
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateOverlay(selectedOverlay.id, {
                              endTime: Math.max(selectedOverlay.startTime + 0.4, currentTime),
                            })
                          }
                          className="px-2.5 py-1 rounded-md bg-white/6 hover:bg-[#D4AF37]/15 text-[#F5F2EA] cursor-pointer"
                        >
                          End @ Playhead
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {motionTracks.length > 0 && (
                          <label className="flex items-center gap-1.5 bg-[#090A0E] border border-white/12 rounded-md px-2 py-1 text-[11px] text-[#D4C7A8]">
                            <Crosshair className="w-3 h-3 text-[#E5C158]" aria-hidden="true" />
                            <span>Track:</span>
                            <select
                              value={selectedOverlay.trackId ?? ''}
                              onChange={(e) =>
                                onUpdateOverlay(selectedOverlay.id, {
                                  trackId: e.target.value || undefined,
                                })
                              }
                              className="bg-transparent text-[#F5F2EA] font-medium focus:outline-none cursor-pointer"
                            >
                              <option value="" className="bg-[#0D0F14]">
                                None
                              </option>
                              {motionTracks.map((tr) => (
                                <option key={tr.id} value={tr.id} className="bg-[#0D0F14]">
                                  {tr.label}
                                </option>
                              ))}
                            </select>
                          </label>
                        )}
                        {selectedOverlay.kind === 'video' && (
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateOverlay(selectedOverlay.id, {
                                muted: !selectedOverlay.muted,
                              })
                            }
                            className={`px-2.5 py-1 rounded-md inline-flex items-center gap-1 cursor-pointer ${
                              selectedOverlay.muted
                                ? 'bg-red-500/20 text-red-200 border border-red-500/35'
                                : 'bg-white/6 text-[#F5F2EA]'
                            }`}
                          >
                            {selectedOverlay.muted ? (
                              <VolumeX className="w-3 h-3" />
                            ) : (
                              <Volume2 className="w-3 h-3 text-[#E5C158]" />
                            )}
                            <span>{selectedOverlay.muted ? 'Muted' : 'Audio On'}</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onDeleteOverlay(selectedOverlay.id)}
                          className="px-2.5 py-1 rounded-md bg-red-500/15 hover:bg-red-500/25 text-red-300 inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" aria-hidden="true" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {audioLayers.length > 0 && (
              <div className="bg-[#141720] border border-white/8 rounded-xl p-2.5 flex flex-col gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                  <span className="text-[11px] font-semibold text-[#E5C158] shrink-0 mr-1">
                    A1 Audio:
                  </span>
                  {audioLayers.map((aud) => (
                    <button
                      key={aud.id}
                      type="button"
                      onClick={() => onSelectAudio(aud.id)}
                      className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1 shrink-0 max-w-[160px] truncate cursor-pointer ${
                        aud.id === selectedAudio?.id
                          ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                          : 'bg-[#090A0E] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                      }`}
                    >
                      <Music className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span className="truncate">{aud.name}</span>
                    </button>
                  ))}
                </div>

                {selectedAudio && (
                  <div className="flex flex-col gap-2 text-xs">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateAudio(selectedAudio.id, { muted: !selectedAudio.muted })
                        }
                        className={`min-h-[34px] px-2.5 rounded-lg inline-flex items-center gap-1 cursor-pointer ${
                          selectedAudio.muted
                            ? 'bg-red-500/20 text-red-200 border border-red-500/40'
                            : 'bg-[#090A0E] border border-[#D4AF37]/30 text-[#F5E1A4]'
                        }`}
                      >
                        {selectedAudio.muted ? (
                          <VolumeX className="w-3.5 h-3.5" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5 text-[#E5C158]" />
                        )}
                        <span>{selectedAudio.muted ? 'Muted' : 'Active'}</span>
                      </button>

                      <label className="flex-1 min-w-[160px] flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                        <span className="text-[#9E978B]">Volume</span>
                        <input
                          type="range"
                          min={0}
                          max={150}
                          value={selectedAudio.muted ? 0 : Math.round(selectedAudio.volume * 100)}
                          onChange={(e) => {
                            const v = Number(e.target.value);
                            onUpdateAudio(selectedAudio.id, {
                              volume: v / 100,
                              muted: v === 0,
                            });
                          }}
                          className="flex-1 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-10 text-right text-[#D4C7A8]">
                          {selectedAudio.muted ? '0%' : `${Math.round(selectedAudio.volume * 100)}%`}
                        </span>
                      </label>

                      <span className="text-[11px] font-mono-tabular text-[#9E978B]">
                        {formatTimecode(selectedAudio.startTime)} –{' '}
                        {formatTimecode(selectedAudio.endTime)}
                      </span>

                      <button
                        type="button"
                        onClick={() => onDeleteAudio(selectedAudio.id)}
                        className="min-h-[34px] px-2.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Remove</span>
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateAudio(selectedAudio.id, {
                            startTime: Math.min(currentTime, selectedAudio.endTime - 0.25),
                          })
                        }
                        className="min-h-[28px] px-2 rounded bg-white/6 hover:bg-[#D4AF37]/15 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                      >
                        Start @ Playhead
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateAudio(selectedAudio.id, {
                            endTime: Math.max(selectedAudio.startTime + 0.25, currentTime),
                          })
                        }
                        className="min-h-[28px] px-2 rounded bg-white/6 hover:bg-[#D4AF37]/15 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                      >
                        End @ Playhead
                      </button>
                      <label className="flex items-center gap-1.5 text-[11px] text-[#D4C7A8] ml-auto">
                        <span>Fade In</span>
                        <input
                          type="range"
                          min={0}
                          max={3}
                          step={0.1}
                          value={selectedAudio.fadeInSec ?? 0}
                          onChange={(e) =>
                            onUpdateAudio(selectedAudio.id, { fadeInSec: Number(e.target.value) })
                          }
                          className="w-20 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-8 text-right">
                          {(selectedAudio.fadeInSec ?? 0).toFixed(1)}s
                        </span>
                      </label>
                      <label className="flex items-center gap-1.5 text-[11px] text-[#D4C7A8]">
                        <span>Fade Out</span>
                        <input
                          type="range"
                          min={0}
                          max={3}
                          step={0.1}
                          value={selectedAudio.fadeOutSec ?? 0}
                          onChange={(e) =>
                            onUpdateAudio(selectedAudio.id, { fadeOutSec: Number(e.target.value) })
                          }
                          className="w-20 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular w-8 text-right">
                          {(selectedAudio.fadeOutSec ?? 0).toFixed(1)}s
                        </span>
                      </label>
                    </div>
                  </div>
                )}
              </div>
            )}

            {overlayLayers.length === 0 && audioLayers.length === 0 && (
              <p className="text-xs text-[#9E978B]">
                Stack a picture-in-picture video/image on V2 or add background music on A1. Everything composites directly into your final MP4 export.
              </p>
            )}
          </div>
        )}

        {/* ADVANCED KEYFRAME ANIMATION PANEL */}
        {panelMode === 'keyframes' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onUpsertMainKeyframe()}
                  className="min-h-[38px] px-3.5 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Diamond className="w-3.5 h-3.5 fill-current" aria-hidden="true" />
                  <span>
                    {nearestKeyframe
                      ? `Update Keyframe @ ${formatTimecode(nearestKeyframe.time)}`
                      : `Add Keyframe @ ${formatTimecode(currentTime)}`}
                  </span>
                </button>

                {nearestKeyframe && (
                  <button
                    type="button"
                    onClick={() => onDeleteMainKeyframe(nearestKeyframe.id)}
                    className="min-h-[38px] px-2.5 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Delete</span>
                  </button>
                )}

                {mainKeyframes.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearMainKeyframes}
                    className="min-h-[38px] px-2.5 rounded-xl bg-[#141720] hover:bg-[#1C202B] border border-white/10 text-[#D4C7A8] text-xs font-medium cursor-pointer"
                  >
                    Clear All ({mainKeyframes.length})
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1 overflow-x-auto studio-scroll">
                <span className="text-[11px] text-[#9E978B] mr-1 shrink-0">Presets:</span>
                {(
                  [
                    { id: 'zoom_in', label: 'Zoom In' },
                    { id: 'zoom_out', label: 'Zoom Out' },
                    { id: 'pan_lr', label: 'Pan L→R' },
                    { id: 'fade_pop', label: 'Fade Pop' },
                  ] as const
                ).map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => onApplyMotionPreset(preset.id)}
                    className="min-h-[32px] px-2.5 rounded-lg bg-[#141720] hover:bg-[#D4AF37]/18 border border-white/10 hover:border-[#E5C158]/60 text-[11px] font-medium text-[#F5F2EA] whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                <span className="text-[#9E978B] shrink-0">Scale</span>
                <input
                  type="range"
                  min={25}
                  max={300}
                  value={Math.round(activeTransform.scale * 100)}
                  onChange={(e) =>
                    onUpsertMainKeyframe({ scale: Number(e.target.value) / 100 })
                  }
                  className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                  {Math.round(activeTransform.scale * 100)}%
                </span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                <span className="text-[#9E978B] shrink-0">Pos X</span>
                <input
                  type="range"
                  min={-50}
                  max={50}
                  value={Math.round(activeTransform.x)}
                  onChange={(e) => onUpsertMainKeyframe({ x: Number(e.target.value) })}
                  className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                  {Math.round(activeTransform.x)}%
                </span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                <span className="text-[#9E978B] shrink-0">Pos Y</span>
                <input
                  type="range"
                  min={-50}
                  max={50}
                  value={Math.round(activeTransform.y)}
                  onChange={(e) => onUpsertMainKeyframe({ y: Number(e.target.value) })}
                  className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                  {Math.round(activeTransform.y)}%
                </span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                <span className="text-[#9E978B] shrink-0">Rotate</span>
                <input
                  type="range"
                  min={-180}
                  max={180}
                  value={Math.round(activeTransform.rotation)}
                  onChange={(e) =>
                    onUpsertMainKeyframe({ rotation: Number(e.target.value) })
                  }
                  className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                  {Math.round(activeTransform.rotation)}°
                </span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                <span className="text-[#9E978B] shrink-0">Opacity</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(activeTransform.opacity * 100)}
                  onChange={(e) =>
                    onUpsertMainKeyframe({ opacity: Number(e.target.value) / 100 })
                  }
                  className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                  {Math.round(activeTransform.opacity * 100)}%
                </span>
              </label>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div className="flex items-center gap-1">
                <span className="text-[#9E978B] mr-1">Easing:</span>
                {(['linear', 'ease-in', 'ease-out', 'ease-in-out'] as KeyframeEasing[]).map(
                  (eas) => (
                    <button
                      key={eas}
                      type="button"
                      onClick={() => onUpsertMainKeyframe({ easing: eas })}
                      className={`px-2.5 py-1 rounded-md capitalize cursor-pointer ${
                        (nearestKeyframe?.easing ?? 'ease-in-out') === eas
                          ? 'bg-[#D4AF37] text-[#08090C] font-semibold'
                          : 'bg-[#141720] text-[#D4C7A8] hover:text-[#F5F2EA]'
                      }`}
                    >
                      {eas}
                    </button>
                  )
                )}
              </div>

              {sortedKeyframes.length > 0 && (
                <div className="flex items-center gap-1 overflow-x-auto studio-scroll">
                  {sortedKeyframes.map((kf) => (
                    <button
                      key={kf.id}
                      type="button"
                      onClick={() => onSeek(kf.time)}
                      className={`px-2 py-1 rounded-md font-mono-tabular inline-flex items-center gap-1 cursor-pointer ${
                        Math.abs(kf.time - currentTime) <= 0.15
                          ? 'bg-[#D4AF37]/20 border border-[#E5C158] text-[#F5E1A4]'
                          : 'bg-[#141720] text-[#D4C7A8] hover:text-[#F5F2EA]'
                      }`}
                    >
                      <Diamond className="w-2.5 h-2.5 fill-current text-[#E5C158]" />
                      <span>{formatTimecode(kf.time)}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* AI BACKGROUND REMOVER PANEL */}
        {panelMode === 'bgremove' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                {(
                  [
                    { id: 'off', label: 'Off' },
                    { id: 'transparent', label: 'Transparent Cutout' },
                    { id: 'blur', label: 'Portrait Blur' },
                    { id: 'color', label: 'Solid Color' },
                    { id: 'image', label: 'Custom Image' },
                  ] as Array<{ id: BgRemovalMode; label: string }>
                ).map((modeOpt) => (
                  <button
                    key={modeOpt.id}
                    type="button"
                    onClick={() => onChangeBgRemoval({ mode: modeOpt.id })}
                    className={`min-h-[38px] px-3 rounded-xl text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                      bgRemoval.mode === modeOpt.id
                        ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4] font-semibold'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                    }`}
                  >
                    {modeOpt.label}
                  </button>
                ))}
              </div>

              <span className="text-[11px] text-[#9E978B]">
                On-device MediaPipe Subject Cutout
              </span>
            </div>

            {bgModelError && (
              <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                {bgModelError}
              </div>
            )}

            {bgRemoval.mode !== 'off' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <span className="w-20 shrink-0 text-[#9E978B]">Threshold</span>
                  <input
                    type="range"
                    min={20}
                    max={85}
                    value={Math.round(bgRemoval.threshold * 100)}
                    onChange={(e) =>
                      onChangeBgRemoval({ threshold: Number(e.target.value) / 100 })
                    }
                    className="flex-1 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                    {Math.round(bgRemoval.threshold * 100)}%
                  </span>
                </label>

                <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <span className="w-20 shrink-0 text-[#9E978B]">Edge Soft</span>
                  <input
                    type="range"
                    min={0}
                    max={10}
                    value={bgRemoval.edgeSoftness}
                    onChange={(e) =>
                      onChangeBgRemoval({ edgeSoftness: Number(e.target.value) })
                    }
                    className="flex-1 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                    {bgRemoval.edgeSoftness}px
                  </span>
                </label>

                {bgRemoval.mode === 'blur' && (
                  <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                    <span className="w-20 shrink-0 text-[#9E978B]">Blur Power</span>
                    <input
                      type="range"
                      min={6}
                      max={28}
                      value={bgRemoval.blurAmount}
                      onChange={(e) =>
                        onChangeBgRemoval({ blurAmount: Number(e.target.value) })
                      }
                      className="flex-1 accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                      {bgRemoval.blurAmount}px
                    </span>
                  </label>
                )}

                {bgRemoval.mode === 'color' && (
                  <div className="flex items-center justify-between gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                    <div className="flex items-center gap-1.5">
                      {BG_COLORS.map((hex) => (
                        <button
                          key={hex}
                          type="button"
                          aria-label={`Background color ${hex}`}
                          onClick={() => onChangeBgRemoval({ bgColor: hex })}
                          style={{ backgroundColor: hex }}
                          className={`w-6 h-6 rounded-full border cursor-pointer ${
                            bgRemoval.bgColor === hex
                              ? 'ring-2 ring-[#E5C158] ring-offset-2 ring-offset-[#141720] border-white'
                              : 'border-white/30'
                          }`}
                        />
                      ))}
                    </div>
                    <input
                      type="color"
                      value={bgRemoval.bgColor}
                      onChange={(e) => onChangeBgRemoval({ bgColor: e.target.value })}
                      aria-label="Custom background color"
                      className="w-7 h-7 rounded bg-transparent border-0 cursor-pointer"
                    />
                  </div>
                )}

                {bgRemoval.mode === 'image' && (
                  <div className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-1.5">
                    <button
                      type="button"
                      onClick={onRequestBgImage}
                      className="min-h-[32px] px-2.5 rounded-lg bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
                    >
                      <ImagePlus className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{bgRemoval.bgImageUrl ? 'Change Photo' : 'Choose Photo'}</span>
                    </button>
                    <span className="text-[11px] text-[#D4C7A8] truncate">
                      {bgRemoval.bgImageName || 'No backdrop selected'}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* MOTION TRACKING PANEL */}
        {panelMode === 'motion' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-[#090A0E] border border-[#D4AF37]/30 rounded-xl px-2.5 min-h-[38px] text-xs">
                <Crosshair className="w-3.5 h-3.5 text-[#E5C158] shrink-0" aria-hidden="true" />
                <span className="text-[#D4C7A8]">Tap preview target:</span>
                <span className="font-mono-tabular font-semibold text-[#F3D778]">
                  X {(pendingTrackTarget?.x ?? 0).toFixed(0)}% · Y {(pendingTrackTarget?.y ?? 0).toFixed(0)}%
                </span>
              </div>

              <input
                type="text"
                value={trackLabel}
                onChange={(e) => setTrackLabel(e.target.value)}
                placeholder="Track name..."
                maxLength={28}
                className="w-32 sm:w-40 min-h-[38px] rounded-xl bg-[#090A0E] border border-white/12 px-2.5 text-xs text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#E5C158]"
              />

              <button
                type="button"
                disabled={motionTrackingProgress !== null || mediaKind === 'image'}
                onClick={() => onRunMotionTrack(trackLabel.trim() || `Subject ${motionTracks.length + 1}`)}
                className="min-h-[38px] px-3.5 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 disabled:opacity-45 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                {motionTrackingProgress !== null ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                    <span>Tracking {motionTrackingProgress}%</span>
                  </>
                ) : (
                  <>
                    <Crosshair className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Start Motion Track</span>
                  </>
                )}
              </button>
            </div>

            {mediaKind === 'image' && (
              <p className="text-[11px] text-[#E5C158]">
                Motion tracking requires a video clip with moving frames.
              </p>
            )}

            {motionTrackError && (
              <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                {motionTrackError}
              </div>
            )}

            {motionTracks.length > 0 ? (
              <div className="bg-[#141720] border border-white/8 rounded-xl p-2.5 flex flex-col gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                  {motionTracks.map((tr) => (
                    <button
                      key={tr.id}
                      type="button"
                      onClick={() => setSelectedTrackId(tr.id)}
                      className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1.5 shrink-0 cursor-pointer ${
                        tr.id === activeMotionTrack?.id
                          ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                          : 'bg-[#090A0E] border-white/10 text-[#D4C7A8]'
                      }`}
                    >
                      <Crosshair className="w-3 h-3 text-[#E5C158]" aria-hidden="true" />
                      <span>{tr.label}</span>
                      <span className="font-mono-tabular text-[10px] opacity-75">
                        ({tr.points.length}pts)
                      </span>
                    </button>
                  ))}
                </div>

                {activeMotionTrack && (
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1.5 border-t border-white/8">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onAddTrackedItem(activeMotionTrack.id, 'Tracked Label', false)}
                        className="min-h-[32px] px-2.5 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/50 text-[#F5E1A4] text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" aria-hidden="true" />
                        <span>Attach Text</span>
                      </button>

                      {STICKER_PRESETS.slice(0, 6).map((emoji) => (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => onAddTrackedItem(activeMotionTrack.id, emoji, true)}
                          title={`Attach ${emoji} sticker to ${activeMotionTrack.label}`}
                          className="min-w-[32px] min-h-[32px] rounded-lg bg-[#090A0E] hover:bg-[#D4AF37]/18 border border-white/10 text-sm flex items-center justify-center cursor-pointer"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteMotionTrack(activeMotionTrack.id)}
                      className="min-h-[32px] px-2.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" aria-hidden="true" />
                      <span>Delete Track</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-[#9E978B]">
                Tap any moving person or object on the video preview above, then tap Start Motion Track to attach text, stickers, or graphics that follow them automatically.
              </p>
            )}
          </div>
        )}

        {/* CHROMA KEY / GREEN SCREEN PANEL */}
        {panelMode === 'chroma' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onChangeChromaKey({ enabled: !chromaKey.enabled })}
                  className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold border cursor-pointer transition-colors ${
                    chromaKey.enabled
                      ? 'bg-[#D4AF37] border-[#E5C158] text-[#08090C] font-bold'
                      : 'bg-[#141720] border-white/12 text-[#F5F2EA] hover:border-[#D4AF37]/40'
                  }`}
                >
                  Chroma Key: {chromaKey.enabled ? 'On' : 'Off'}
                </button>

                <div className="flex items-center gap-1.5 bg-[#141720] rounded-xl px-2.5 py-1.5 border border-white/8">
                  <span className="text-[11px] text-[#9E978B] mr-1">Key:</span>
                  {CHROMA_KEY_PRESETS.map((preset) => (
                    <button
                      key={preset.hex}
                      type="button"
                      onClick={() =>
                        onChangeChromaKey({ keyColor: preset.hex, enabled: true })
                      }
                      style={{ backgroundColor: preset.hex }}
                      title={preset.label}
                      aria-label={`Key color ${preset.label}`}
                      className={`w-6 h-6 rounded-full border cursor-pointer ${
                        chromaKey.keyColor.toLowerCase() === preset.hex
                          ? 'ring-2 ring-[#E5C158] ring-offset-2 ring-offset-[#141720] border-white'
                          : 'border-white/30'
                      }`}
                    />
                  ))}
                  <input
                    type="color"
                    value={chromaKey.keyColor}
                    onChange={(e) =>
                      onChangeChromaKey({ keyColor: e.target.value, enabled: true })
                    }
                    aria-label="Custom chroma key color"
                    className="w-7 h-7 rounded bg-transparent border-0 cursor-pointer ml-1"
                  />
                </div>
              </div>

              <div className="flex items-center gap-1 overflow-x-auto studio-scroll">
                {(
                  [
                    { id: 'transparent', label: 'Transparent' },
                    { id: 'color', label: 'Color' },
                    { id: 'image', label: 'Photo BG' },
                    { id: 'video', label: 'Video BG' },
                  ] as Array<{ id: ChromaKeyBgMode; label: string }>
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onChangeChromaKey({ bgMode: m.id, enabled: true })}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer ${
                      chromaKey.bgMode === m.id
                        ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8]'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {chromaKey.enabled && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <span className="w-20 shrink-0 text-[#9E978B]">Tolerance</span>
                  <input
                    type="range"
                    min={5}
                    max={65}
                    value={Math.round(chromaKey.similarity * 100)}
                    onChange={(e) =>
                      onChangeChromaKey({ similarity: Number(e.target.value) / 100 })
                    }
                    className="flex-1 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                    {Math.round(chromaKey.similarity * 100)}%
                  </span>
                </label>

                <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <span className="w-20 shrink-0 text-[#9E978B]">Smoothness</span>
                  <input
                    type="range"
                    min={1}
                    max={35}
                    value={Math.round(chromaKey.smoothness * 100)}
                    onChange={(e) =>
                      onChangeChromaKey({ smoothness: Number(e.target.value) / 100 })
                    }
                    className="flex-1 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                    {Math.round(chromaKey.smoothness * 100)}%
                  </span>
                </label>

                <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <span className="w-20 shrink-0 text-[#9E978B]">Spill Fix</span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={Math.round(chromaKey.spillSuppression * 100)}
                    onChange={(e) =>
                      onChangeChromaKey({ spillSuppression: Number(e.target.value) / 100 })
                    }
                    className="flex-1 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                    {Math.round(chromaKey.spillSuppression * 100)}%
                  </span>
                </label>
              </div>
            )}

            {chromaKey.enabled && chromaKey.bgMode === 'color' && (
              <div className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                <span className="text-xs text-[#9E978B]">Backdrop Color:</span>
                {BG_COLORS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    onClick={() => onChangeChromaKey({ bgColor: hex })}
                    style={{ backgroundColor: hex }}
                    className={`w-6 h-6 rounded-full border cursor-pointer ${
                      chromaKey.bgColor === hex
                        ? 'ring-2 ring-[#E5C158] ring-offset-2 ring-offset-[#141720] border-white'
                        : 'border-white/30'
                    }`}
                  />
                ))}
                <input
                  type="color"
                  value={chromaKey.bgColor}
                  onChange={(e) => onChangeChromaKey({ bgColor: e.target.value })}
                  aria-label="Custom chroma backdrop color"
                  className="w-7 h-7 rounded bg-transparent border-0 cursor-pointer"
                />
              </div>
            )}

            {chromaKey.enabled && chromaKey.bgMode === 'image' && (
              <div className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                <button
                  type="button"
                  onClick={onRequestChromaBgImage}
                  className="min-h-[34px] px-3 rounded-lg bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <ImagePlus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{chromaKey.bgImageUrl ? 'Change Backdrop Photo' : 'Select Backdrop Photo'}</span>
                </button>
                <span className="text-xs text-[#D4C7A8] truncate">
                  {chromaKey.bgImageName || 'No image selected'}
                </span>
              </div>
            )}

            {chromaKey.enabled && chromaKey.bgMode === 'video' && (
              <div className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                <button
                  type="button"
                  onClick={onRequestChromaBgVideo}
                  className="min-h-[34px] px-3 rounded-lg bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Video className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{chromaKey.bgVideoUrl ? 'Change Backdrop Video' : 'Select Backdrop Video'}</span>
                </button>
                <span className="text-xs text-[#D4C7A8] truncate">
                  {chromaKey.bgVideoName || 'No replacement video selected'}
                </span>
              </div>
            )}
          </div>
        )}

        {/* VIDEO STABILIZATION PANEL */}
        {panelMode === 'stabilize' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={stabProgress !== null || mediaKind === 'image'}
                  onClick={onRunStabilization}
                  className="min-h-[38px] px-3.5 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 disabled:opacity-45 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  {stabProgress !== null ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                      <span>Analyzing Shake {stabProgress}%</span>
                    </>
                  ) : (
                    <>
                      <Activity className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{stabilization.analyzed ? 'Re-Analyze Shake' : 'Analyze & Stabilize'}</span>
                    </>
                  )}
                </button>

                {stabilization.analyzed && (
                  <button
                    type="button"
                    onClick={() =>
                      onChangeStabilization({ enabled: !stabilization.enabled })
                    }
                    className={`min-h-[38px] px-3 rounded-xl text-xs font-semibold border cursor-pointer ${
                      stabilization.enabled
                        ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/12 text-[#D4C7A8]'
                    }`}
                  >
                    Stabilize: {stabilization.enabled ? 'On' : 'Off'}
                  </button>
                )}
              </div>

              {stabilization.analyzed && (
                <span className="text-[11px] font-mono-tabular text-[#F3D778] bg-[#D4AF37]/12 border border-[#D4AF37]/30 rounded-lg px-2.5 py-1">
                  Auto Crop Zoom: {stabilization.autoScale.toFixed(2)}x
                </span>
              )}
            </div>

            {mediaKind === 'image' && (
              <p className="text-[11px] text-[#E5C158]">
                Stabilization applies to video clips with camera shake.
              </p>
            )}

            {stabError && (
              <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                {stabError}
              </div>
            )}

            <label className="flex items-center gap-3 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 py-2.5">
              <span className="w-28 shrink-0 text-[#9E978B]">Smooth Strength</span>
              <input
                type="range"
                min={0}
                max={100}
                value={stabilization.strength}
                onChange={(e) =>
                  onChangeStabilization({ strength: Number(e.target.value) })
                }
                className="flex-1 accent-[#8B5CF6] cursor-pointer"
              />
              <span className="w-10 text-right font-mono-tabular font-semibold text-[#F5F2EA]">
                {stabilization.strength}%
              </span>
            </label>
          </div>
        )}

        {/* MASKING TOOLS PANEL */}
        {panelMode === 'mask' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                {(
                  [
                    { id: 'none', label: 'None' },
                    { id: 'rect', label: 'Rectangle' },
                    { id: 'circle', label: 'Circle' },
                    { id: 'linear', label: 'Linear Strip' },
                    { id: 'split', label: 'Split Half' },
                  ] as Array<{ id: MaskShape; label: string }>
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => onChangeMask({ shape: opt.id })}
                    className={`min-h-[38px] px-3 rounded-xl text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer ${
                      mask.shape === opt.id
                        ? 'bg-[#D4AF37] border-[#E5C158] text-[#08090C] font-semibold'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {mask.shape !== 'none' && (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onChangeMask({ invert: !mask.invert })}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border cursor-pointer ${
                      mask.invert
                        ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8]'
                    }`}
                  >
                    Invert: {mask.invert ? 'On' : 'Off'}
                  </button>
                  <button
                    type="button"
                    onClick={onResetMask}
                    className="min-h-[34px] px-2.5 rounded-lg bg-[#141720] hover:bg-[#1C202B] border border-white/10 text-[#D4C7A8] text-xs inline-flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" aria-hidden="true" />
                    <span>Reset</span>
                  </button>
                </div>
              )}
            </div>

            {mask.shape !== 'none' && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Pos X</span>
                  <input
                    type="range"
                    min={-50}
                    max={50}
                    value={Math.round(mask.x)}
                    onChange={(e) => onChangeMask({ x: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                    {Math.round(mask.x)}%
                  </span>
                </label>

                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Pos Y</span>
                  <input
                    type="range"
                    min={-50}
                    max={50}
                    value={Math.round(mask.y)}
                    onChange={(e) => onChangeMask({ y: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                    {Math.round(mask.y)}%
                  </span>
                </label>

                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Width</span>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={Math.round(mask.width)}
                    onChange={(e) => onChangeMask({ width: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                    {Math.round(mask.width)}%
                  </span>
                </label>

                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Height</span>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={Math.round(mask.height)}
                    onChange={(e) => onChangeMask({ height: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-8 text-right text-[#D4C7A8]">
                    {Math.round(mask.height)}%
                  </span>
                </label>

                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Rotate</span>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    value={Math.round(mask.rotation)}
                    onChange={(e) => onChangeMask({ rotation: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                    {Math.round(mask.rotation)}°
                  </span>
                </label>

                <label className="flex items-center gap-1.5 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-2.5 py-2">
                  <span className="text-[#9E978B] shrink-0">Feather</span>
                  <input
                    type="range"
                    min={0}
                    max={40}
                    value={Math.round(mask.feather)}
                    onChange={(e) => onChangeMask({ feather: Number(e.target.value) })}
                    className="flex-1 min-w-0 accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                    {Math.round(mask.feather)}px
                  </span>
                </label>
              </div>
            )}
          </div>
        )}

        {/* MUSIC BEAT SYNC PANEL */}
        {panelMode === 'beats' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <label className="flex items-center gap-1.5 text-xs bg-[#141720] border border-white/10 rounded-xl px-2.5 min-h-[38px]">
                <Music className="w-3.5 h-3.5 text-[#E5C158] shrink-0" aria-hidden="true" />
                <span className="text-[#9E978B]">Source:</span>
                <select
                  value={beatSourceId}
                  onChange={(e) => setBeatSourceId(e.target.value)}
                  className="bg-transparent text-[#F5F2EA] font-medium focus:outline-none cursor-pointer"
                >
                  <option value="main" className="bg-[#0D0F14]">
                    V1 Main Video Audio
                  </option>
                  {audioLayers.map((a) => (
                    <option key={a.id} value={a.id} className="bg-[#0D0F14]">
                      A1 · {a.name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141720] border border-white/8 rounded-xl px-3 min-h-[38px] flex-1 min-w-[170px]">
                <span className="text-[#9E978B] shrink-0">Sensitivity</span>
                <input
                  type="range"
                  min={20}
                  max={90}
                  value={Math.round(beatSensitivity * 100)}
                  onChange={(e) => setBeatSensitivity(Number(e.target.value) / 100)}
                  className="flex-1 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="font-mono-tabular text-[11px] w-9 text-right text-[#D4C7A8]">
                  {Math.round(beatSensitivity * 100)}%
                </span>
              </label>

              <button
                type="button"
                disabled={beatsBusy}
                onClick={() => onDetectBeats(beatSourceId, beatSensitivity)}
                className="min-h-[38px] px-3.5 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 disabled:opacity-50 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
              >
                {beatsBusy ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                    <span>Scanning Audio...</span>
                  </>
                ) : (
                  <>
                    <Music2 className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Detect Beats</span>
                  </>
                )}
              </button>
            </div>

            {beatsError && (
              <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                {beatsError}
              </div>
            )}

            {beatAnalysis && (
              <div className="bg-[#141720] border border-white/8 rounded-xl p-2.5 flex flex-col gap-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="px-2 py-0.5 rounded bg-[#D4AF37]/18 border border-[#E5C158]/50 text-[#F3D778] font-mono-tabular font-semibold">
                      {beatAnalysis.bpm > 0 ? `${beatAnalysis.bpm} BPM` : 'Tempo Ready'}
                    </span>
                    <span className="text-[#D4C7A8] font-mono-tabular">
                      {beatAnalysis.beats.length} beats detected · {beatAnalysis.sourceName}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {([1, 2, 4] as const).map((step) => (
                      <button
                        key={step}
                        type="button"
                        disabled={beatAnalysis.beats.length === 0}
                        onClick={() => onSyncClipsToBeats(step)}
                        className="min-h-[32px] px-2.5 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/45 text-[#F5E1A4] text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-40"
                      >
                        <Scissors className="w-3 h-3" aria-hidden="true" />
                        <span>Cut Every {step} Beat{step > 1 ? 's' : ''}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {beatAnalysis.beats.length > 0 && (
                  <div className="flex items-center gap-1 overflow-x-auto studio-scroll pt-1">
                    {beatAnalysis.beats.slice(0, 18).map((bSec, idx) => (
                      <button
                        key={`beat-chip-${idx}`}
                        type="button"
                        onClick={() => onSeek(bSec)}
                        className="px-2 py-0.5 rounded bg-[#090A0E] hover:bg-[#D4AF37]/20 text-[10px] font-mono-tabular text-[#D4C7A8] hover:text-[#F5F2EA] shrink-0 cursor-pointer"
                      >
                        #{idx + 1} {formatTimecode(bSec)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* SIMPLE CAPCUT-STYLE AUTO CAPTIONS PANEL */}
        {panelMode === 'captions' && (() => {
          const langChoices: Array<{
            id: CaptionLanguage;
            native: string;
            label: string;
          }> = [
            { id: 'auto', native: 'Auto', label: strings.autoDetectLanguage },
            { id: 'ur', native: 'اردو', label: 'Urdu' },
            { id: 'hi', native: 'हिन्दी', label: 'Hindi' },
            { id: 'en', native: 'English', label: 'English' },
            { id: 'sd', native: 'سنڌي', label: 'Sindhi' },
            { id: chineseVariant, native: '中文', label: 'Chinese' },
          ];

          const selectedNonAutoLang =
            captionLanguage === 'auto' ? null : (captionLanguage as TargetLanguageCode);

          const canTranslateExisting = Boolean(
            captionOverlays.length > 0 &&
              selectedNonAutoLang &&
              captionOverlays.some((c) => c.lang !== selectedNonAutoLang)
          );

          const detectedLabel = aiResult?.detectedLanguage
            ? TARGET_LANGUAGE_OPTIONS.find((o) => o.code === aiResult.detectedLanguage)?.label ??
              aiResult.detectedLanguage
            : null;

          return (
            <div className="flex flex-col gap-3">
              {/* 1. One Big Generate Captions Button */}
              <div className="flex flex-col gap-1.5">
                <button
                  type="button"
                  disabled={aiBusy}
                  onClick={onGenerateAutoCaptions}
                  className="min-h-[48px] w-full px-4 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 active:scale-[0.99] disabled:opacity-60 text-[#08090C] text-sm font-bold inline-flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/15 whitespace-nowrap transition-all cursor-pointer"
                >
                  {aiBusy ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                      <span>{strings.detectingVoice}</span>
                    </>
                  ) : (
                    <>
                      <Captions className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>{strings.generateCaptionsBtn}</span>
                    </>
                  )}
                </button>

                {captionOverlays.length > 0 && (
                  <p className="text-xs text-[#D4C7A8] px-0.5">
                    {detectedLabel ? `${detectedLabel} · ` : ''}
                    {captionOverlays.length}{' '}
                    {captionOverlays.length === 1 ? 'subtitle' : 'subtitles'}
                  </p>
                )}
              </div>

              {/* 2. Simple 5-Language Selection */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[11px] font-medium text-[#9E978B]">
                  {strings.scriptLanguageLabel}
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {langChoices.map((choice) => {
                    const isSelected =
                      choice.id === captionLanguage ||
                      (choice.label === 'Chinese' &&
                        (captionLanguage === 'zh-Hans' || captionLanguage === 'zh-Hant'));
                    return (
                      <button
                        key={choice.label}
                        type="button"
                        onClick={() => {
                          onChangeCaptionLanguage(choice.id);
                          if (choice.id !== 'auto') {
                            onChangeTranslateTargetLang(choice.id as TargetLanguageCode);
                          }
                        }}
                        className={`min-h-[44px] px-2 py-1 rounded-xl border flex flex-col items-center justify-center text-center transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                            : 'bg-[#141720] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/40 hover:text-[#F5F2EA]'
                        }`}
                      >
                        <span className="text-xs font-semibold leading-tight whitespace-nowrap">
                          {choice.native}
                        </span>
                        {choice.label !== choice.native && (
                          <span className="text-[10px] opacity-75 leading-tight whitespace-nowrap">
                            {choice.label}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {canTranslateExisting && selectedNonAutoLang && (
                  <button
                    type="button"
                    disabled={translateBusy}
                    onClick={() => onTranslateCaptions(selectedNonAutoLang)}
                    className="min-h-[42px] w-full px-3 rounded-xl bg-[#D4AF37]/16 hover:bg-[#D4AF37]/25 border border-[#E5C158]/50 disabled:opacity-50 text-[#F5E1A4] text-xs font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    {translateBusy ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                        <span>{strings.translating}</span>
                      </>
                    ) : (
                      <>
                        <Languages className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{strings.translateToSelected}</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* 3. Simple Subtitle Styles & Colors */}
              <div className="rounded-xl bg-[#141720] border border-white/8 p-2.5 flex flex-col gap-2.5">
                <div className="flex flex-col gap-1.5">
                  <span className="text-[11px] font-medium text-[#9E978B]">
                    {strings.captionStyleLabel}
                  </span>
                  <div className="grid grid-cols-5 gap-1.5">
                    {CAPTION_STYLE_ITEMS.map((st) => {
                      const active = captionStyle === st.id;
                      const previewClass =
                        st.id === 'subtitle-bar'
                          ? 'w-full bg-[#08090C] text-white px-1 py-0.5'
                          : st.id === 'boxed'
                          ? 'bg-black/80 text-white px-1.5 py-0.5 rounded'
                          : st.id === 'outline'
                          ? 'text-white [text-shadow:_-1px_-1px_0_#000,_1px_-1px_0_#000,_-1px_1px_0_#000,_1px_1px_0_#000]'
                          : st.id === 'pop'
                          ? 'text-[#F3D778] [text-shadow:_-1.5px_-1.5px_0_#000,_1.5px_-1.5px_0_#000,_-1.5px_1.5px_0_#000,_1.5px_1.5px_0_#000]'
                          : 'text-white';
                      return (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => onChangeCaptionStyle(st.id)}
                          className={`min-h-[46px] px-1 py-1 rounded-lg border flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                            active
                              ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                              : 'bg-[#090A0E] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/40'
                          }`}
                        >
                          <span
                            className={`text-xs font-bold leading-none text-center ${previewClass}`}
                          >
                            Aa
                          </span>
                          <span className="text-[10px] leading-none whitespace-nowrap">
                            {st.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[11px] font-medium text-[#9E978B]">
                    {strings.captionColorLabel}
                  </span>
                  <div className="flex items-center gap-2">
                    {CAPTION_COLORS.map((swatch) => {
                      const active = captionColor.toLowerCase() === swatch.hex.toLowerCase();
                      return (
                        <button
                          key={swatch.hex}
                          type="button"
                          aria-label={swatch.label}
                          title={swatch.label}
                          onClick={() => onChangeCaptionColor(swatch.hex)}
                          style={{ backgroundColor: swatch.hex }}
                          className={`w-9 h-9 min-w-[36px] min-h-[36px] rounded-full flex items-center justify-center border-2 transition-transform active:scale-95 cursor-pointer ${
                            active
                              ? 'border-[#E5C158] ring-2 ring-[#D4AF37]/50 scale-105'
                              : 'border-white/25 hover:border-white/60'
                          }`}
                        >
                          {active && (
                            <Check className="w-4 h-4 text-[#08090C] stroke-[2.75]" aria-hidden="true" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {aiError && (
                <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                  {aiError}
                </div>
              )}

              {/* 4. Easy Caption Text List */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#F5F2EA]">
                    {strings.panelCaptionsTitle} ({captionOverlays.length})
                  </span>
                  <div className="flex items-center gap-1.5">
                    {onAddManualCaption && (
                      <button
                        type="button"
                        onClick={onAddManualCaption}
                        className="min-h-[36px] px-3 rounded-lg bg-[#141720] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                        <span>{strings.addCaptionLineBtn}</span>
                      </button>
                    )}
                    {captionOverlays.length > 0 && (
                      <button
                        type="button"
                        onClick={onClearAllCaptions}
                        className="min-h-[36px] px-2.5 rounded-lg bg-red-500/12 hover:bg-red-500/22 text-red-300 text-xs font-medium whitespace-nowrap cursor-pointer"
                      >
                        {strings.clearCaptions}
                      </button>
                    )}
                  </div>
                </div>

                {captionOverlays.length > 0 ? (
                  <div className="flex flex-col gap-2 max-h-[200px] overflow-y-auto studio-scroll pr-0.5">
                    {captionOverlays.map((cap) => {
                      const capScript = resolveScriptRenderConfig(
                        cap.text,
                        cap.lang ?? captionLanguage,
                        cap.dir ?? 'auto'
                      );
                      return (
                        <div
                          key={cap.id}
                          className={`rounded-xl p-2.5 border transition-colors ${
                            cap.id === selectedTextId
                              ? 'bg-[#D4AF37]/12 border-[#E5C158]/60'
                              : 'bg-[#141720] border-white/8'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                onSelectTextOverlay(cap.id);
                                onSeek(cap.startTime);
                              }}
                              className="min-h-[32px] px-2 rounded-md bg-[#090A0E] hover:bg-[#D4AF37]/15 text-[11px] font-mono-tabular text-[#E5C158] hover:text-[#F3D778] cursor-pointer"
                            >
                              {formatTimecode(cap.startTime)} – {formatTimecode(cap.endTime)}
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteTextOverlay(cap.id)}
                              aria-label="Delete subtitle"
                              className="min-w-[40px] min-h-[40px] rounded-lg text-[#9E978B] hover:text-red-300 hover:bg-red-500/15 flex items-center justify-center cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" aria-hidden="true" />
                            </button>
                          </div>
                          <input
                            type="text"
                            value={cap.text}
                            dir={capScript.dir}
                            lang={capScript.langAttr}
                            style={{
                              fontFamily: capScript.fontFamily,
                              unicodeBidi: 'plaintext',
                            }}
                            placeholder={strings.subtitleTextPlaceholder}
                            onFocus={() => onSelectTextOverlay(cap.id)}
                            onChange={(e) =>
                              onUpdateTextOverlay(cap.id, { text: e.target.value })
                            }
                            maxLength={140}
                            className="w-full min-h-[44px] mt-1.5 rounded-lg bg-[#090A0E] border border-white/10 focus:border-[#E5C158] px-3 text-sm text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none"
                          />
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-[#9E978B] px-0.5">
                    {strings.fiveLanguagesNote}
                  </p>
                )}
              </div>

              {/* 5. Save Captions Footer */}
              <div className="flex items-center gap-2 pt-0.5">
                <button
                  type="button"
                  disabled={isSavingCaptions || captionOverlays.length === 0}
                  onClick={onSaveCaptions}
                  className={`flex-1 min-h-[46px] px-4 rounded-xl text-sm font-bold inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors cursor-pointer disabled:opacity-45 ${
                    captionsSaved
                      ? 'bg-[#D4AF37]/20 border border-[#E5C158] text-[#F3D778]'
                      : 'bg-[#141720] hover:bg-[#1C202B] border border-[#D4AF37]/50 text-[#F5E1A4]'
                  }`}
                >
                  {isSavingCaptions ? (
                    <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                  ) : captionsSaved ? (
                    <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                  ) : (
                    <Save className="w-4 h-4 shrink-0 text-[#E5C158]" aria-hidden="true" />
                  )}
                  <span>
                    {captionsSaved ? strings.captionsSavedLabel : strings.saveCaptionsBtn}
                  </span>
                </button>

                {captionOverlays.length > 0 && (
                  <button
                    type="button"
                    onClick={onExportSrt}
                    className="min-h-[46px] px-4 rounded-xl bg-[#141720] hover:bg-[#1C202B] border border-white/12 text-[#F5F2EA] text-xs font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0 text-[#E5C158]" aria-hidden="true" />
                    <span>{strings.exportSrt}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })()}

        {/* BEGINNER-FRIENDLY 6-STEP AI VOICE GENERATOR */}
        {panelMode === 'voice' && (() => {
          const voiceLangChoices: Array<{
            id: TargetLanguageCode;
            native: string;
            label: string;
          }> = [
            { id: 'ur', native: 'اردو', label: 'Urdu' },
            { id: 'hi', native: 'हिन्दी', label: 'Hindi' },
            { id: 'sd', native: 'سنڌي', label: 'Sindhi' },
            { id: 'en', native: 'English', label: 'English' },
            {
              id: chineseVariant,
              native: chineseVariant === 'zh-Hant' ? '繁體中文' : '简体中文',
              label: 'Chinese',
            },
          ];

          const safeDuration = Math.max(0.2, ttsResultDuration || 0);

          return (
            <div className="flex flex-col gap-3">
              {/* Step 1: Select Language */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#F5F2EA]">
                    {strings.voiceStep1Lang}
                  </span>
                  {ttsLangAutoDetected && (
                    <span className="text-[11px] font-medium text-[#E5C158]">
                      {strings.voiceAutoDetected}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                  {voiceLangChoices.map((choice) => {
                    const active =
                      ttsLang === choice.id ||
                      (choice.label === 'Chinese' &&
                        (ttsLang === 'zh-Hans' || ttsLang === 'zh-Hant'));
                    return (
                      <button
                        key={choice.label}
                        type="button"
                        onClick={() => onChangeTtsLang(choice.id)}
                        className={`min-h-[44px] px-2.5 py-1.5 rounded-xl border flex flex-col items-center justify-center text-center transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                            : 'bg-[#141720] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/40 hover:text-[#F5F2EA]'
                        }`}
                      >
                        <span className="text-xs font-semibold leading-tight whitespace-nowrap">
                          {choice.native}
                        </span>
                        {choice.label !== choice.native && (
                          <span className="text-[10px] opacity-75 leading-tight whitespace-nowrap">
                            {choice.label}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Choose a Voice + Simple Voice Mode */}
              <div className="flex flex-col gap-1.5">
                <span className="text-xs font-semibold text-[#F5F2EA]">
                  {strings.voiceStep2Voice}
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                  {TTS_VOICE_PROFILES.map((v) => {
                    const active = ttsVoice === v.id;
                    const primary = ttsLang === 'ur' ? v.urTitle : v.title;
                    const secondary = ttsLang === 'ur' ? v.urSubtitle : v.subtitle;
                    return (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => onChangeTtsVoice(v.id)}
                        className={`min-h-[46px] px-2.5 py-1.5 rounded-xl border flex flex-col items-start justify-center text-left transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                            : 'bg-[#141720] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/40 hover:text-[#F5F2EA]'
                        }`}
                      >
                        <span className="text-xs font-semibold leading-tight whitespace-nowrap">
                          {primary}
                        </span>
                        <span className="text-[10px] opacity-75 leading-tight whitespace-nowrap">
                          {secondary}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Simple 2-option Voice Mode */}
                <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                  <button
                    type="button"
                    onClick={() => onChangeTtsMode('tts')}
                    className={`min-h-[44px] px-3 py-1.5 rounded-xl border text-left flex flex-col justify-center transition-colors cursor-pointer ${
                      ttsMode === 'tts'
                        ? 'bg-[#D4AF37]/18 border-[#E5C158]/80 text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/35'
                    }`}
                  >
                    <span className="text-xs font-semibold leading-tight">
                      {strings.voiceModeStandard}
                    </span>
                    <span className="text-[10px] opacity-75 leading-tight">
                      {strings.voiceModeStandardDesc}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeTtsMode('voice_design')}
                    className={`min-h-[44px] px-3 py-1.5 rounded-xl border text-left flex flex-col justify-center transition-colors cursor-pointer ${
                      ttsMode === 'voice_design'
                        ? 'bg-[#D4AF37]/18 border-[#E5C158]/80 text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/8 text-[#D4C7A8] hover:border-[#D4AF37]/35'
                    }`}
                  >
                    <span className="text-xs font-semibold leading-tight">
                      {strings.voiceModeCustom}
                    </span>
                    <span className="text-[10px] opacity-75 leading-tight">
                      {strings.voiceModeCustomDesc}
                    </span>
                  </button>
                </div>

                {ttsMode === 'voice_design' && (
                  <div className="flex flex-col gap-1.5 rounded-xl bg-[#141720] border border-white/8 p-2">
                    <div className="flex flex-wrap gap-1.5">
                      {TTS_STYLE_CHIPS.map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => onChangeTtsStylePrompt(preset)}
                          className={`min-h-[32px] px-2.5 rounded-lg text-[11px] font-medium border transition-colors cursor-pointer ${
                            ttsStylePrompt.trim().toLowerCase() === preset.toLowerCase()
                              ? 'bg-[#D4AF37] text-[#08090C] border-[#E5C158] font-semibold'
                              : 'bg-[#090A0E] text-[#D4C7A8] border-white/10 hover:text-[#F5F2EA]'
                          }`}
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                    <input
                      type="text"
                      value={ttsStylePrompt}
                      onChange={(e) => onChangeTtsStylePrompt(e.target.value)}
                      placeholder={strings.voiceStyleHintPlaceholder}
                      maxLength={140}
                      className="w-full min-h-[38px] rounded-xl bg-[#090A0E] border border-white/12 px-3 text-xs text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#E5C158]"
                    />
                  </div>
                )}
              </div>

              {/* Step 3: Large Easy Text Input Box */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-semibold text-[#F5F2EA]">
                    {strings.voiceStep3Text}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {captionOverlays.length > 0 && (
                      <button
                        type="button"
                        onClick={onUseCaptionsForVoice}
                        className="min-h-[32px] px-2.5 rounded-lg bg-[#141720] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-medium cursor-pointer"
                      >
                        {strings.loadCaptionsIntoVoice}
                      </button>
                    )}
                    {ttsText.length > 0 && (
                      <button
                        type="button"
                        onClick={() => onChangeTtsText('')}
                        className="min-h-[32px] px-2.5 rounded-lg bg-[#141720] hover:bg-[#1C202B] border border-white/10 text-[#D4C7A8] text-xs font-medium cursor-pointer"
                      >
                        {strings.voiceClearText}
                      </button>
                    )}
                    <span className="text-[11px] font-mono-tabular text-[#9E978B]">
                      {ttsText.length}/1200
                    </span>
                  </div>
                </div>

                <textarea
                  rows={4}
                  value={ttsText}
                  dir={ttsScriptCfg.dir}
                  lang={ttsScriptCfg.langAttr}
                  style={{
                    fontFamily: ttsScriptCfg.fontFamily,
                    unicodeBidi: 'plaintext',
                  }}
                  onChange={(e) => onChangeTtsText(e.target.value)}
                  placeholder={strings.voiceTextPlaceholder}
                  maxLength={1200}
                  className="w-full min-h-[116px] sm:min-h-[128px] rounded-xl bg-[#090A0E] border border-white/15 px-3.5 py-2.5 text-sm sm:text-base leading-relaxed text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#E5C158]"
                />
              </div>

              {/* Step 4: Generate AI Voice Button */}
              <button
                type="button"
                disabled={ttsBusy}
                onClick={onGenerateVoice}
                className="min-h-[48px] w-full px-4 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 active:scale-[0.99] disabled:opacity-60 text-[#08090C] text-sm font-bold inline-flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/15 whitespace-nowrap transition-all cursor-pointer"
              >
                {ttsBusy ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                    <span>{strings.generatingVoice}</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>{strings.generateAiVoice}</span>
                  </>
                )}
              </button>

              {ttsError && (
                <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2.5 text-xs text-red-200 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{ttsError}</span>
                </div>
              )}

              {/* Step 5 & 6: Audio Preview + Download / Add to Timeline */}
              {ttsResultUrl && (
                <div className="rounded-xl bg-[#141720] border border-[#E5C158]/40 p-3 flex flex-col gap-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-[#F5E1A4] flex items-center gap-1.5">
                      <Volume2 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                      <span>{strings.voiceStep4Result}</span>
                    </span>
                    <span className="text-[11px] font-mono-tabular text-[#D4C7A8]">
                      {formatTimecode(voicePlayTime)} / {formatTimecode(safeDuration)}
                    </span>
                  </div>

                  <audio
                    ref={voiceAudioRef}
                    src={ttsResultUrl}
                    preload="metadata"
                    playsInline
                    onPlay={() => setIsVoicePlaying(true)}
                    onPause={() => setIsVoicePlaying(false)}
                    onEnded={() => {
                      setIsVoicePlaying(false);
                      setVoicePlayTime(0);
                    }}
                    onTimeUpdate={(e) => setVoicePlayTime(e.currentTarget.currentTime)}
                    className="hidden"
                  />

                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={toggleVoicePreview}
                      aria-label={isVoicePlaying ? 'Pause audio' : 'Play audio'}
                      className="min-w-[44px] min-h-[44px] rounded-xl bg-gradient-to-br from-[#F3D778] to-[#C89D28] hover:brightness-105 text-[#08090C] flex items-center justify-center shrink-0 cursor-pointer"
                    >
                      {isVoicePlaying ? (
                        <Pause className="w-4 h-4 fill-[#08090C]" aria-hidden="true" />
                      ) : (
                        <Play className="w-4 h-4 translate-x-0.5 fill-[#08090C]" aria-hidden="true" />
                      )}
                    </button>

                    <input
                      type="range"
                      min={0}
                      max={safeDuration}
                      step={0.05}
                      value={Math.min(voicePlayTime, safeDuration)}
                      onChange={(e) => {
                        const next = Number(e.target.value);
                        setVoicePlayTime(next);
                        if (voiceAudioRef.current) {
                          voiceAudioRef.current.currentTime = next;
                        }
                      }}
                      aria-label="Audio preview position"
                      className="flex-1 accent-[#8B5CF6] cursor-pointer"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        void downloadMediaFile({
                          url: ttsResultUrl,
                          filename: `meesam-voice-${ttsLang}.wav`,
                          mimeType: 'audio/wav',
                        });
                      }}
                      className="min-h-[44px] px-3 rounded-xl bg-[#090A0E] hover:bg-[#1C202B] border border-white/15 text-[#F5F2EA] text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-4 h-4 shrink-0 text-[#E5C158]" aria-hidden="true" />
                      <span>{strings.downloadWav}</span>
                    </button>

                    <button
                      type="button"
                      onClick={onAddGeneratedVoiceToTimeline}
                      className="min-h-[44px] px-3 rounded-xl bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/60 text-[#F5E1A4] text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4 shrink-0 text-[#E5C158]" aria-hidden="true" />
                      <span>{strings.addVoiceToTimeline}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* AI STUDIO PANEL */}
        {panelMode === 'ai' && (
          <div className="flex flex-col gap-2.5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                disabled={aiBusy}
                onClick={() => onRunAiEdit('auto_edit')}
                className="min-h-[48px] px-2.5 py-2 rounded-xl bg-[#141720] hover:bg-[#D4AF37]/14 border border-white/10 hover:border-[#E5C158]/60 text-left flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Wand2 className="w-4 h-4 text-[#E5C158] shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#F5F2EA] truncate">AI Auto Edit</div>
                  <div className="text-[10px] text-[#9E978B] truncate">
                    Filter + Slow-Mo + Hook
                  </div>
                </div>
              </button>

              <button
                type="button"
                disabled={aiBusy || autoCutBusy}
                onClick={() => onRunAiEdit('auto_cut')}
                className="min-h-[48px] px-2.5 py-2 rounded-xl bg-[#141720] hover:bg-[#D4AF37]/14 border border-white/10 hover:border-[#E5C158]/60 text-left flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Scissors className="w-4 h-4 text-[#E5C158] shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#F5F2EA] truncate">AI Auto Cut</div>
                  <div className="text-[10px] text-[#9E978B] truncate">
                    Best highlights & trims
                  </div>
                </div>
              </button>

              <button
                type="button"
                disabled={aiBusy}
                onClick={() => onRunAiEdit('auto_captions')}
                className="min-h-[48px] px-2.5 py-2 rounded-xl bg-[#141720] hover:bg-[#D4AF37]/14 border border-white/10 hover:border-[#E5C158]/60 text-left flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Captions className="w-4 h-4 text-[#E5C158] shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#F5F2EA] truncate">Auto Captions</div>
                  <div className="text-[10px] text-[#9E978B] truncate">
                    Timed speech & marks
                  </div>
                </div>
              </button>

              <button
                type="button"
                disabled={aiBusy}
                onClick={() => onRunAiEdit('smart_filters')}
                className="min-h-[48px] px-2.5 py-2 rounded-xl bg-[#141720] hover:bg-[#D4AF37]/14 border border-white/10 hover:border-[#E5C158]/60 text-left flex items-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Palette className="w-4 h-4 text-[#E5C158] shrink-0" aria-hidden="true" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#F5F2EA] truncate">Smart Filters</div>
                  <div className="text-[10px] text-[#9E978B] truncate">
                    Best color match
                  </div>
                </div>
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                disabled={aiBusy || autoCutBusy || mediaKind === 'image'}
                onClick={onInstantLocalAutoCut}
                className="min-h-[36px] px-3 rounded-lg bg-[#D4AF37]/14 hover:bg-[#D4AF37]/24 border border-[#E5C158]/45 disabled:opacity-45 text-[#F5E1A4] text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
              >
                {autoCutBusy ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                    <span>Scanning Highlights...</span>
                  </>
                ) : (
                  <>
                    <Scissors className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                    <span>Instant Smart Cut (Local Activity)</span>
                  </>
                )}
              </button>
              <span className="text-[11px] text-[#9E978B]">
                Detects peaks & cuts quiet pauses non-destructively
              </span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!aiBusy && aiPrompt.trim()) {
                  onRunAiEdit('custom_prompt', aiPrompt.trim());
                }
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Ask AI: e.g. Reels 9:16 with 0.5x slow-mo and moody cinema filter..."
                maxLength={400}
                disabled={aiBusy}
                className="flex-1 min-h-[42px] rounded-xl bg-[#090A0E] border border-white/12 px-3 text-xs text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#E5C158]"
              />
              <button
                type="submit"
                disabled={aiBusy || !aiPrompt.trim()}
                className="min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 disabled:opacity-45 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                {aiBusy ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                    <span>Thinking...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Ask AI</span>
                  </>
                )}
              </button>
            </form>

            {aiError && (
              <div className="rounded-xl bg-red-500/12 border border-red-500/35 px-3 py-2 text-xs text-red-200">
                {aiError}
              </div>
            )}

            {aiResult && !aiBusy && (
              <div className="rounded-xl bg-[#141720] border border-[#E5C158]/35 p-2.5 flex flex-col gap-2">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <p className="text-xs text-[#F5F2EA] flex-1 min-w-[200px]">
                    {aiResult.summary}
                  </p>
                  <button
                    type="button"
                    onClick={() => onApplyAiEdit(aiResult)}
                    className="min-h-[34px] px-3 rounded-lg bg-gradient-to-r from-[#C89D28] via-[#E5C158] to-[#D4AF37] hover:brightness-105 text-[#08090C] text-xs font-bold inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Apply AI Edit</span>
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#D4C7A8]">
                  {aiResult.recommendedFilterId && (
                    <span className="bg-[#090A0E] border border-white/8 rounded-md px-2 py-1">
                      Filter:{' '}
                      <strong className="text-[#F5F2EA]">
                        {findFilterPreset(aiResult.recommendedFilterId).label}
                      </strong>
                    </span>
                  )}
                  {aiResult.keepRanges && aiResult.keepRanges.length > 0 && (
                    <span className="bg-[#D4AF37]/14 border border-[#E5C158]/40 text-[#F5E1A4] rounded-md px-2 py-1 font-mono-tabular">
                      Keep Ranges: {aiResult.keepRanges.length} highlights
                    </span>
                  )}
                  {aiResult.slowMoRanges && aiResult.slowMoRanges.length > 0 && (
                    <span className="bg-[#090A0E] border border-white/8 rounded-md px-2 py-1 font-mono-tabular">
                      Slow-Mo: {aiResult.slowMoRanges[0].startTime.toFixed(1)}s–
                      {aiResult.slowMoRanges[0].endTime.toFixed(1)}s @{' '}
                      {aiResult.slowMoRanges[0].speed}x
                    </span>
                  )}
                  {aiResult.captions && aiResult.captions.length > 0 && (
                    <span className="bg-[#090A0E] border border-white/8 rounded-md px-2 py-1">
                      Captions: {aiResult.captions.length} marks
                    </span>
                  )}
                  {aiResult.aspectRatio && aiResult.aspectRatio !== 'original' && (
                    <span className="bg-[#090A0E] border border-white/8 rounded-md px-2 py-1">
                      Ratio: {aiResult.aspectRatio}
                    </span>
                  )}
                </div>

                {aiResult.filterRecommendations &&
                  aiResult.filterRecommendations.length > 0 && (
                    <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pt-1">
                      {aiResult.filterRecommendations.map((rec) => {
                        const preset = findFilterPreset(rec.filterId);
                        return (
                          <button
                            key={rec.filterId}
                            type="button"
                            onClick={() =>
                              onChangeAdjustments({
                                ...adjustments,
                                filterPreset: preset.id,
                                filterIntensity: 100,
                              })
                            }
                            className={`px-2.5 py-1.5 rounded-lg border text-left shrink-0 cursor-pointer ${
                              adjustments.filterPreset === preset.id
                                ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                                : 'bg-[#090A0E] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                            }`}
                          >
                            <div className="text-[11px] font-semibold">{preset.label}</div>
                            {rec.reason && (
                              <div className="text-[10px] opacity-75 max-w-[160px] truncate">
                                {rec.reason}
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
              </div>
            )}
          </div>
        )}

        {/* TRIM & CLIP MANAGEMENT PANEL */}
        {panelMode === 'trim' && selectedSegment && (
          <div className="flex flex-col gap-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="flex items-center justify-between gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                <div className="flex flex-col min-w-0">
                  <span className="text-[11px] text-[#9E978B]">Trim Start</span>
                  <span className="font-mono-tabular text-xs font-semibold text-[#F5F2EA]">
                    {formatTimecode(selectedSegment.start)}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onNudgeTrim('start', -0.1)}
                    className="min-w-[40px] min-h-[36px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-mono-tabular flex items-center justify-center cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>0.1</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onNudgeTrim('start', 0.1)}
                    className="min-w-[40px] min-h-[36px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-mono-tabular flex items-center justify-center cursor-pointer"
                  >
                    <span>0.1</span>
                    <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onSnapTrimToPlayhead('start')}
                    className="min-h-[36px] px-2.5 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/50 text-[#F5E1A4] text-xs font-semibold whitespace-nowrap cursor-pointer"
                  >
                    Set In
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                <div className="flex flex-col min-w-0">
                  <span className="text-[11px] text-[#9E978B]">Trim End</span>
                  <span className="font-mono-tabular text-xs font-semibold text-[#F5F2EA]">
                    {formatTimecode(selectedSegment.end)}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onNudgeTrim('end', -0.1)}
                    className="min-w-[40px] min-h-[36px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-mono-tabular flex items-center justify-center cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>0.1</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onNudgeTrim('end', 0.1)}
                    className="min-w-[40px] min-h-[36px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#1C202B] border border-white/10 text-[#F5F2EA] text-xs font-mono-tabular flex items-center justify-center cursor-pointer"
                  >
                    <span>0.1</span>
                    <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onSnapTrimToPlayhead('end')}
                    className="min-h-[36px] px-2.5 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/50 text-[#F5E1A4] text-xs font-semibold whitespace-nowrap cursor-pointer"
                  >
                    Set Out
                  </button>
                </div>
              </div>
            </div>

            {canDeleteSegmentPermanently && onDeleteSegmentPermanently && (
              <div className="flex items-center justify-between gap-2 bg-[#141720] border border-red-500/20 rounded-xl px-3 py-1.5 text-xs">
                <span className="text-[#9E978B]">
                  Remove this split clip completely from the timeline:
                </span>
                <button
                  type="button"
                  onClick={() => onDeleteSegmentPermanently(selectedSegment.id)}
                  className="min-h-[32px] px-2.5 rounded-lg bg-red-500/20 hover:bg-red-500/35 text-red-200 font-medium inline-flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Delete Clip Permanently</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* SPEED & CUSTOMIZABLE SPEED CURVE PANEL */}
        {panelMode === 'speed' && selectedSegment && (
          <div className="flex flex-col gap-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pb-0.5">
              {SPEED_OPTIONS.map((spd) => {
                const active =
                  !hasCustomSpeedCurve(selectedSegment) && Math.abs(selectedSpeed - spd) < 0.01;
                return (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => onChangeClipSpeed(selectedSegment.id, spd, false)}
                    className={`min-h-[38px] px-3 rounded-xl text-xs font-mono-tabular font-semibold border whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                      active
                        ? 'bg-[#D4AF37] border-[#E5C158] text-[#08090C]'
                        : spd < 1
                        ? 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#F3D778] hover:bg-[#D4AF37]/20'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-[#F5F2EA]'
                    }`}
                  >
                    {spd === 1 ? '1.0x Normal' : spd < 1 ? `${spd}x Slow` : `${spd}x Fast`}
                  </button>
                );
              })}
            </div>

            {/* Interactive Multi-Point Speed Curve Ramp */}
            <div className="bg-[#141720] rounded-xl p-2.5 flex flex-col gap-2 border border-white/8">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-[11px] font-semibold text-[#E5C158]">
                  Speed Curve Ramp
                </span>
                <div className="flex items-center gap-1 overflow-x-auto studio-scroll max-w-full">
                  {SPEED_CURVE_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedCurvePointIdx(0);
                        onApplySpeedCurvePreset(selectedSegment.id, preset.id);
                      }}
                      className="min-h-[28px] px-2.5 rounded-md bg-[#090A0E] hover:bg-[#D4AF37]/20 border border-white/10 text-[11px] font-medium text-[#F5F2EA] whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {(() => {
                const svgW = 320;
                const svgH = 74;
                const padX = 12;
                const padY = 10;
                const plotW = svgW - padX * 2;
                const plotH = svgH - padY * 2;
                const speedToY = (spd: number) => {
                  const norm = Math.max(0, Math.min(1, (spd - 0.25) / 3.75));
                  return padY + (1 - norm) * plotH;
                };
                const samples: string[] = [];
                for (let k = 0; k <= 40; k++) {
                  const u = k / 40;
                  const sVal = evaluateCurveAtProgress(activeCurve, u, 1);
                  samples.push(`${(padX + u * plotW).toFixed(1)},${speedToY(sVal).toFixed(1)}`);
                }
                const baselineY = speedToY(1.0);
                const activePt = activeCurve[safeCurvePointIdx] ?? activeCurve[0];

                return (
                  <div className="flex flex-col gap-2">
                    <svg
                      viewBox={`0 0 ${svgW} ${svgH}`}
                      className="w-full h-[74px] rounded-lg bg-[#090A0E] border border-white/8"
                    >
                      <line
                        x1={padX}
                        y1={baselineY}
                        x2={svgW - padX}
                        y2={baselineY}
                        stroke="rgba(212,175,55,0.28)"
                        strokeDasharray="4 4"
                      />
                      <polyline
                        fill="none"
                        stroke="#D4AF37"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={samples.join(' ')}
                      />
                      {activeCurve.map((pt, idx) => {
                        const cx = padX + pt.position * plotW;
                        const cy = speedToY(pt.speed);
                        const isSel = idx === safeCurvePointIdx;
                        return (
                          <g
                            key={pt.id}
                            onClick={() => setSelectedCurvePointIdx(idx)}
                            className="cursor-pointer"
                          >
                            <circle
                              cx={cx}
                              cy={cy}
                              r={isSel ? 6 : 4.5}
                              fill={isSel ? '#F3D778' : '#C89D28'}
                              stroke="#08090C"
                              strokeWidth="1.5"
                            />
                          </g>
                        );
                      })}
                    </svg>

                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                        <span className="text-[#9E978B] shrink-0">
                          Point #{safeCurvePointIdx + 1}:
                        </span>
                        <input
                          type="range"
                          min={25}
                          max={400}
                          step={5}
                          value={Math.round(activePt.speed * 100)}
                          onChange={(e) => {
                            const nextSpeed = Number(e.target.value) / 100;
                            const nextCurve = activeCurve.map((p, idx) =>
                              idx === safeCurvePointIdx ? { ...p, speed: nextSpeed } : p
                            );
                            onUpdateSpeedCurve(selectedSegment.id, nextCurve);
                          }}
                          className="flex-1 accent-[#8B5CF6] cursor-pointer"
                        />
                        <span className="font-mono-tabular text-[#F5F2EA] font-semibold w-10 text-right">
                          {activePt.speed.toFixed(2)}x
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const nextPos = Math.min(
                              0.95,
                              Math.max(0.05, Number((activePt.position + 0.12).toFixed(2)))
                            );
                            const nextPt: SpeedCurvePoint = {
                              id: `pt-${Date.now().toString(36)}`,
                              position: nextPos,
                              speed: 1.0,
                            };
                            const updated = sortAndClampCurve([...activeCurve, nextPt]);
                            const newIdx = updated.findIndex((p) => p.id === nextPt.id);
                            if (newIdx !== -1) setSelectedCurvePointIdx(newIdx);
                            onUpdateSpeedCurve(selectedSegment.id, updated);
                          }}
                          className="min-h-[28px] px-2.5 rounded bg-[#090A0E] hover:bg-[#D4AF37]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          + Point
                        </button>
                        {activeCurve.length > 2 &&
                          safeCurvePointIdx > 0 &&
                          safeCurvePointIdx < activeCurve.length - 1 && (
                            <button
                              type="button"
                              onClick={() => {
                                const updated = activeCurve.filter(
                                  (_, idx) => idx !== safeCurvePointIdx
                                );
                                setSelectedCurvePointIdx(Math.max(0, safeCurvePointIdx - 1));
                                onUpdateSpeedCurve(selectedSegment.id, updated);
                              }}
                              className="min-h-[28px] px-2 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 cursor-pointer"
                            >
                              Delete Pt
                            </button>
                          )}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onApplySlowMoHighlight(0.5)}
                  className="min-h-[34px] px-2.5 rounded-lg bg-[#D4AF37]/16 hover:bg-[#D4AF37]/25 border border-[#E5C158]/45 text-[#F5E1A4] text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                  <span>0.5x Slow-Mo Highlight at Playhead</span>
                </button>

                {(selectedSpeed < 1 || hasCustomSpeedCurve(selectedSegment)) && (
                  <button
                    type="button"
                    onClick={() => onToggleSmoothSlowMo(selectedSegment.id)}
                    className={`min-h-[34px] px-2.5 rounded-lg border text-xs font-medium cursor-pointer ${
                      selectedSmooth
                        ? 'bg-[#D4AF37]/20 border-[#E5C158] text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8]'
                    }`}
                  >
                    Smooth Slow-Mo: {selectedSmooth ? 'On' : 'Off'}
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => onChangeClipSpeed(selectedSegment.id, selectedSpeed, true)}
                className="text-[11px] text-[#E5C158] hover:text-[#F3D778] font-medium cursor-pointer"
              >
                Apply {selectedSpeed}x to all clips
              </button>
            </div>
          </div>
        )}

        {/* 200+ FILTERS & COLOR ADJUSTMENTS PANEL */}
        {panelMode === 'filters' && (
          <div className="flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pb-0.5 max-w-full">
                {FILTER_CATEGORIES.map((cat) => {
                  const catCount = getFilterCategoryCount(cat.id);
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setFilterCategory(cat.id)}
                      className={`min-h-[34px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-all ${
                        filterCategory === cat.id
                          ? 'bg-gradient-to-r from-[#7C3AED] to-[#9333EA] text-white font-semibold shadow-sm shadow-[#7C3AED]/30'
                          : 'bg-[#141722] border border-white/8 text-[#D4C7A8] hover:text-white hover:border-[#8B5CF6]/40'
                      }`}
                    >
                      {cat.label} <span className="opacity-75 text-[10px]">({catCount})</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-1.5 w-full sm:w-auto lg:w-full shrink-0">
                <div className="relative flex-1">
                  <Search
                    className="w-3.5 h-3.5 text-[#9E978B] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="text"
                    value={filterQuery}
                    onChange={(e) => setFilterQuery(e.target.value)}
                    placeholder={`Search ${TOTAL_FILTER_COUNT} filters...`}
                    className="w-full min-h-[34px] rounded-lg bg-[#090A0E] border border-white/12 pl-8 pr-2.5 text-xs text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFilterLayout((prev) => (prev === 'strip' ? 'grid' : 'strip'))
                  }
                  aria-label={
                    filterLayout === 'strip' ? 'Switch to grid view' : 'Switch to strip view'
                  }
                  title={filterLayout === 'strip' ? 'Grid View' : 'Strip View'}
                  className="min-w-[34px] min-h-[34px] px-2.5 rounded-lg bg-[#141722] hover:bg-[#1E2233] border border-white/10 text-[#F5F2EA] inline-flex items-center justify-center gap-1 text-xs cursor-pointer"
                >
                  {filterLayout === 'strip' ? (
                    <LayoutGrid className="w-3.5 h-3.5 text-[#A855F7]" aria-hidden="true" />
                  ) : (
                    <Rows3 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                  )}
                  <span className="hidden sm:inline lg:hidden">
                    {filterLayout === 'strip' ? 'Grid' : 'Strip'}
                  </span>
                </button>
              </div>
            </div>

            <div
              className={
                filterLayout === 'grid'
                  ? 'grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-3 gap-2 max-h-[196px] lg:max-h-[380px] overflow-y-auto studio-scroll pr-1'
                  : 'flex items-center gap-2 overflow-x-auto studio-scroll pb-1 lg:grid lg:grid-cols-3 lg:max-h-[380px] lg:overflow-y-auto lg:overflow-x-visible lg:pr-1'
              }
            >
              {filteredPresets.map((preset) => {
                const active = adjustments.filterPreset === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    style={{
                      contentVisibility: 'auto',
                      containIntrinsicSize: '72px 76px',
                    }}
                    onClick={() =>
                      onChangeAdjustments({ ...adjustments, filterPreset: preset.id })
                    }
                    className={`${
                      filterLayout === 'grid' ? 'w-full' : 'w-[76px] lg:w-full shrink-0'
                    } rounded-xl p-1 border-2 flex flex-col items-center gap-1 cursor-pointer transition-all ${
                      active
                        ? 'bg-[#7C3AED]/20 border-[#A855F7] text-white shadow-[0_0_14px_rgba(168,85,247,0.32)]'
                        : 'bg-[#141722] border-white/10 text-[#D4C7A8] hover:border-[#8B5CF6]/55 hover:text-white'
                    }`}
                  >
                    <div className="w-full h-11 lg:h-14 rounded-lg overflow-hidden bg-[#090A0E] relative">
                      {previewThumbnail ? (
                        <img
                          src={previewThumbnail}
                          alt={preset.label}
                          loading="lazy"
                          decoding="async"
                          style={{ filter: preset.cssFilter || 'none' }}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div
                          style={{
                            background: `linear-gradient(135deg, ${preset.swatch[0]}, ${preset.swatch[1]})`,
                            filter: preset.cssFilter || 'none',
                          }}
                          className="w-full h-full relative"
                        >
                          <div className="absolute inset-x-0 bottom-0 h-3 bg-black/25" />
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] font-medium leading-tight w-full text-center truncate">
                      {preset.label}
                    </span>
                  </button>
                );
              })}
              {filteredPresets.length === 0 && (
                <p className="text-xs text-[#9E978B] py-2 col-span-full">
                  No matching filters.
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141722] border border-white/8 rounded-xl px-3 py-2">
                <span className="w-16 shrink-0 text-[#9E978B]">Intensity</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={adjustments.filterIntensity ?? 100}
                  onChange={(e) =>
                    onChangeAdjustments({
                      ...adjustments,
                      filterIntensity: Number(e.target.value),
                    })
                  }
                  className="flex-1 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                  {adjustments.filterIntensity ?? 100}%
                </span>
              </label>

              <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141722] border border-white/8 rounded-xl px-3 py-2">
                <span className="w-14 shrink-0 text-[#9E978B]">Bright</span>
                <input
                  type="range"
                  min={50}
                  max={150}
                  value={adjustments.brightness}
                  onChange={(e) =>
                    onChangeAdjustments({
                      ...adjustments,
                      brightness: Number(e.target.value),
                    })
                  }
                  className="flex-1 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                  {adjustments.brightness}%
                </span>
              </label>

              <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141722] border border-white/8 rounded-xl px-3 py-2">
                <span className="w-14 shrink-0 text-[#9E978B]">Contrast</span>
                <input
                  type="range"
                  min={50}
                  max={150}
                  value={adjustments.contrast}
                  onChange={(e) =>
                    onChangeAdjustments({
                      ...adjustments,
                      contrast: Number(e.target.value),
                    })
                  }
                  className="flex-1 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                  {adjustments.contrast}%
                </span>
              </label>

              <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#141722] border border-white/8 rounded-xl px-3 py-2">
                <span className="w-14 shrink-0 text-[#9E978B]">Saturate</span>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={adjustments.saturation}
                  onChange={(e) =>
                    onChangeAdjustments({
                      ...adjustments,
                      saturation: Number(e.target.value),
                    })
                  }
                  className="flex-1 accent-[#8B5CF6] cursor-pointer"
                />
                <span className="w-9 text-right font-mono-tabular text-[11px] text-[#D4C7A8]">
                  {adjustments.saturation}%
                </span>
              </label>
            </div>

            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] text-[#9E978B] truncate">
                Active:{' '}
                <strong className="text-[#F3D778]">
                  {findFilterPreset(adjustments.filterPreset).label}
                </strong>{' '}
                · {adjustments.filterIntensity ?? 100}%
              </span>
              <button
                type="button"
                onClick={() => onChangeAdjustments(DEFAULT_ADJUSTMENTS)}
                className="text-[11px] text-[#D4C7A8] hover:text-[#F3D778] inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" aria-hidden="true" />
                <span>Reset color</span>
              </button>
            </div>
          </div>
        )}

        {/* 144+ EASY ONE-TAP VIDEO EFFECTS STUDIO PANEL */}
        {panelMode === 'effects' && (() => {
          const selectedEffect =
            videoEffects.find((f) => f.id === selectedEffectId) ?? videoEffects[0];
          const selectedDef = selectedEffect
            ? findEffectDefinition(selectedEffect.effectId)
            : undefined;
          const effectSpan = selectedEffect
            ? Math.max(0.25, selectedEffect.endTime - selectedEffect.startTime)
            : 0;
          const showNoneCard = !effectQuery.trim();

          return (
            <div className="flex flex-col gap-2.5">
              {/* Simple Top Status & Active Effect Chips */}
              <div className="flex flex-wrap items-center justify-between gap-2 bg-[#141722] rounded-xl px-3 py-2 border border-[#8B5CF6]/20">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll max-w-full flex-1">
                  {videoEffects.length === 0 ? (
                    <span className="text-xs text-[#D4C7A8]">
                      Tap any effect below to preview &amp; apply. Tap{' '}
                      <strong className="text-[#F3D778]">None</strong> to clear.
                    </span>
                  ) : (
                    videoEffects.map((layer) => {
                      const def = findEffectDefinition(layer.effectId);
                      const isSel = layer.id === selectedEffect?.id;
                      return (
                        <div
                          key={layer.id}
                          className={`inline-flex items-center gap-1.5 rounded-lg border pl-2.5 pr-1.5 py-1 shrink-0 text-xs ${
                            isSel
                              ? 'bg-[#7C3AED]/25 border-[#A855F7] text-white'
                              : 'bg-[#090A0E] border-white/12 text-[#D4C7A8]'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => onSelectVideoEffect(layer.id)}
                            className={`font-medium max-w-[130px] truncate cursor-pointer ${
                              layer.enabled ? '' : 'line-through opacity-55'
                            }`}
                          >
                            {def.label}
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteVideoEffect(layer.id)}
                            aria-label={`Remove ${def.label}`}
                            className="w-5 h-5 rounded-md bg-white/8 hover:bg-red-500/30 text-[#D4C7A8] hover:text-white flex items-center justify-center cursor-pointer"
                          >
                            <X className="w-3 h-3" aria-hidden="true" />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setEffectStackMode((v) => !v)}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1 cursor-pointer ${
                      effectStackMode
                        ? 'bg-gradient-to-r from-[#7C3AED] to-[#9333EA] border-[#A855F7] text-white font-semibold'
                        : 'bg-[#090A0E] border-white/12 text-[#F5F2EA] hover:border-[#8B5CF6]/55'
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5 text-[#F3D778]" aria-hidden="true" />
                    <span>{effectStackMode ? 'Adding More' : 'Add Another'}</span>
                  </button>

                  {videoEffects.length > 0 && (
                    <button
                      type="button"
                      onClick={onClearAllVideoEffects}
                      className="min-h-[34px] px-2.5 rounded-lg bg-red-500/18 hover:bg-red-500/30 border border-red-500/35 text-red-100 text-xs font-medium cursor-pointer"
                    >
                      Remove All
                    </button>
                  )}
                </div>
              </div>

              {/* Category Tabs + Search + View Toggle */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pb-0.5 max-w-full">
                  {EFFECT_CATEGORIES.map((cat) => {
                    const catCount = getEffectCategoryCount(cat.id);
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setEffectCategory(cat.id)}
                        className={`min-h-[34px] px-3 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-all ${
                          effectCategory === cat.id
                            ? 'bg-gradient-to-r from-[#7C3AED] to-[#9333EA] text-white font-semibold shadow-sm shadow-[#7C3AED]/30'
                            : 'bg-[#141722] border border-white/8 text-[#D4C7A8] hover:text-white hover:border-[#8B5CF6]/40'
                        }`}
                      >
                        {cat.label} <span className="opacity-75 text-[10px]">({catCount})</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-1.5 w-full sm:w-auto lg:w-full shrink-0">
                  <div className="relative flex-1">
                    <Search
                      className="w-3.5 h-3.5 text-[#9E978B] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                      aria-hidden="true"
                    />
                    <input
                      type="text"
                      value={effectQuery}
                      onChange={(e) => setEffectQuery(e.target.value)}
                      placeholder={`Search ${TOTAL_EFFECT_COUNT} effects...`}
                      className="w-full min-h-[34px] rounded-lg bg-[#090A0E] border border-white/12 pl-8 pr-7 text-xs text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#8B5CF6]"
                    />
                    {effectQuery && (
                      <button
                        type="button"
                        onClick={() => setEffectQuery('')}
                        aria-label="Clear search"
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-[#9E978B] hover:text-[#F5F2EA] cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setEffectLayout((prev) => (prev === 'grid' ? 'strip' : 'grid'))
                    }
                    aria-label={
                      effectLayout === 'strip' ? 'Switch to grid view' : 'Switch to strip view'
                    }
                    className="min-w-[34px] min-h-[34px] px-2.5 rounded-lg bg-[#141722] hover:bg-[#1E2233] border border-white/10 text-[#F5F2EA] inline-flex items-center justify-center gap-1 text-xs cursor-pointer"
                  >
                    {effectLayout === 'strip' ? (
                      <LayoutGrid className="w-3.5 h-3.5 text-[#A855F7]" aria-hidden="true" />
                    ) : (
                      <Rows3 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                    )}
                    <span className="hidden sm:inline lg:hidden">
                      {effectLayout === 'strip' ? 'Grid' : 'Strip'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Clean, Clear Effect Cards with One-Tap None & Live Preview Thumbnails */}
              <div
                className={
                  effectLayout === 'grid'
                    ? 'grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-3 gap-2 max-h-[224px] lg:max-h-[400px] overflow-y-auto studio-scroll pr-1'
                    : 'flex items-center gap-2 overflow-x-auto studio-scroll pb-1 lg:grid lg:grid-cols-3 lg:max-h-[400px] lg:overflow-y-auto lg:pr-1'
                }
              >
                {showNoneCard && (
                  <button
                    type="button"
                    onClick={onClearAllVideoEffects}
                    className={`${
                      effectLayout === 'grid' ? 'w-full' : 'w-[96px] lg:w-full shrink-0'
                    } rounded-xl p-1.5 border-2 flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      videoEffects.length === 0
                        ? 'bg-[#7C3AED]/18 border-[#A855F7] text-white shadow-[0_0_14px_rgba(168,85,247,0.32)]'
                        : 'bg-[#141722] border-white/10 text-[#D4C7A8] hover:border-[#8B5CF6]/55'
                    }`}
                  >
                    <div className="w-full h-14 rounded-lg bg-[#090A0E] border border-white/8 flex items-center justify-center">
                      <Ban className="w-5 h-5 text-[#E5E7EB]" aria-hidden="true" />
                    </div>
                    <span className="text-[11px] font-medium leading-tight w-full text-center truncate">
                      None
                    </span>
                  </button>
                )}

                {filteredVideoEffects.map((fx) => {
                  const appliedLayer = videoEffects.find(
                    (l) => l.effectId === fx.id && l.enabled
                  );
                  const isApplied = Boolean(appliedLayer);
                  const isCurrentSelected = selectedEffect?.effectId === fx.id;
                  const thumbUrl = effectThumbMap[fx.id];

                  return (
                    <div
                      key={fx.id}
                      style={{
                        contentVisibility: 'auto',
                        containIntrinsicSize: '96px 92px',
                      }}
                      className={`${
                        effectLayout === 'grid' ? 'w-full' : 'w-[96px] lg:w-full shrink-0'
                      } relative rounded-xl p-1.5 border-2 flex flex-col items-center gap-1.5 transition-all ${
                        isCurrentSelected
                          ? 'bg-[#7C3AED]/22 border-[#A855F7] text-white shadow-[0_0_14px_rgba(168,85,247,0.35)]'
                          : isApplied
                          ? 'bg-[#7C3AED]/12 border-[#8B5CF6]/60 text-[#E9D5FF]'
                          : 'bg-[#141722] border-white/10 text-[#F5F2EA] hover:border-[#8B5CF6]/50'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onApplyVideoEffect(fx.id, effectStackMode)}
                        title={
                          isApplied && !effectStackMode
                            ? `Tap to remove ${fx.label}`
                            : `Tap to apply ${fx.label}`
                        }
                        className="w-full flex flex-col items-center gap-1.5 cursor-pointer text-center"
                      >
                        <div className="w-full h-14 rounded-lg overflow-hidden bg-[#090A0E] relative">
                          {thumbUrl ? (
                            <img
                              src={thumbUrl}
                              alt={fx.label}
                              loading="lazy"
                              decoding="async"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div
                              style={{
                                background: `linear-gradient(135deg, ${fx.swatch[0]}, ${fx.swatch[1]})`,
                              }}
                              className="w-full h-full"
                            />
                          )}
                          {isApplied && (
                            <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded-md bg-gradient-to-r from-[#7C3AED] to-[#A855F7] text-[9px] font-bold text-white inline-flex items-center gap-0.5 shadow">
                              <Check className="w-2.5 h-2.5 text-[#F3D778]" aria-hidden="true" />
                              <span>ON</span>
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] font-medium leading-tight w-full truncate px-0.5">
                          {fx.label}
                        </span>
                      </button>

                      {videoEffects.length > 0 && !effectStackMode && !isApplied && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onApplyVideoEffect(fx.id, true);
                          }}
                          title={`Add ${fx.label} on top`}
                          aria-label={`Add ${fx.label} on top`}
                          className="absolute top-2 right-2 w-5 h-5 rounded-md bg-black/85 hover:bg-[#7C3AED] text-white border border-[#8B5CF6]/50 flex items-center justify-center cursor-pointer"
                        >
                          <Plus className="w-3 h-3" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  );
                })}

                {filteredVideoEffects.length === 0 && (
                  <p className="text-xs text-[#9E978B] py-3 col-span-full">
                    No matching effects found.
                  </p>
                )}
              </div>

              {/* Clean Active Effect Controls + Optional Duration Drawer */}
              {selectedEffect && selectedDef && (
                <div className="bg-[#141722] border border-[#8B5CF6]/35 rounded-xl p-2.5 flex flex-col gap-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                    <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-xl px-3 py-2">
                      <span className="w-16 shrink-0 text-[#9E978B]">Intensity</span>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={Math.round(selectedEffect.intensity)}
                        onChange={(e) =>
                          onUpdateVideoEffect(selectedEffect.id, {
                            intensity: Number(e.target.value),
                          })
                        }
                        className="flex-1 accent-[#8B5CF6] cursor-pointer"
                      />
                      <span className="w-9 text-right font-mono-tabular text-[11px] text-[#F5F2EA]">
                        {Math.round(selectedEffect.intensity)}%
                      </span>
                    </label>

                    <label className="flex items-center gap-2 text-xs text-[#F5F2EA] bg-[#090A0E] border border-white/8 rounded-xl px-3 py-2">
                      <span className="w-20 shrink-0 text-[#9E978B] truncate">
                        {selectedDef.speedLabel}
                      </span>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={Math.round(selectedEffect.speed)}
                        onChange={(e) =>
                          onUpdateVideoEffect(selectedEffect.id, {
                            speed: Number(e.target.value),
                          })
                        }
                        className="flex-1 accent-[#8B5CF6] cursor-pointer"
                      />
                      <span className="w-9 text-right font-mono-tabular text-[11px] text-[#F5F2EA]">
                        {Math.round(selectedEffect.speed)}%
                      </span>
                    </label>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex flex-wrap items-center gap-1.5 text-[#D4C7A8]">
                      <button
                        type="button"
                        onClick={() => setShowEffectTiming((v) => !v)}
                        className={`min-h-[32px] px-2.5 rounded-lg border font-medium inline-flex items-center gap-1.5 cursor-pointer ${
                          showEffectTiming
                            ? 'bg-[#7C3AED]/22 border-[#A855F7] text-white'
                            : 'bg-[#090A0E] border-white/10 text-[#F5F2EA] hover:border-[#8B5CF6]/45'
                        }`}
                      >
                        <span className="font-mono-tabular text-[11px]">
                          {formatTimecode(selectedEffect.startTime)} –{' '}
                          {formatTimecode(selectedEffect.endTime)} ({effectSpan.toFixed(1)}s)
                        </span>
                        <span className="text-[11px] text-[#E5C158]">
                          {showEffectTiming ? 'Hide Timing' : 'Timing'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          onUpdateVideoEffect(selectedEffect.id, {
                            startTime: 0,
                            endTime: duration,
                          })
                        }
                        className="min-h-[32px] px-2.5 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                      >
                        {strings.fullVideoBtn}
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateVideoEffect(selectedEffect.id, {
                            enabled: !selectedEffect.enabled,
                          })
                        }
                        className={`min-h-[32px] px-2.5 rounded-lg border text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer ${
                          selectedEffect.enabled
                            ? 'bg-[#D4AF37]/18 border-[#E5C158]/50 text-[#F5E1A4]'
                            : 'bg-[#090A0E] border-white/12 text-[#9E978B]'
                        }`}
                      >
                        {selectedEffect.enabled ? (
                          <Eye className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                        ) : (
                          <EyeOff className="w-3.5 h-3.5" aria-hidden="true" />
                        )}
                        <span>{selectedEffect.enabled ? 'On' : 'Off'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteVideoEffect(selectedEffect.id)}
                        className="min-h-[32px] px-3 rounded-lg bg-red-500/20 hover:bg-red-500/35 border border-red-500/40 text-red-100 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>

                  {showEffectTiming && (
                    <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1.5 border-t border-white/8 text-[11px]">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {selectedSegment && (
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateVideoEffect(selectedEffect.id, {
                                startTime: selectedSegment.start,
                                endTime: selectedSegment.end,
                              })
                            }
                            className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                          >
                            This Clip
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            const s = Math.min(currentTime, Math.max(0, duration - 0.5));
                            const e = Math.min(duration, Math.max(s + 0.5, s + 1.5));
                            onUpdateVideoEffect(selectedEffect.id, {
                              startTime: Number(s.toFixed(2)),
                              endTime: Number(e.toFixed(2)),
                            });
                          }}
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          1.5s Here
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const s = Math.min(currentTime, Math.max(0, duration - 0.5));
                            const e = Math.min(duration, Math.max(s + 0.5, s + 3));
                            onUpdateVideoEffect(selectedEffect.id, {
                              startTime: Number(s.toFixed(2)),
                              endTime: Number(e.toFixed(2)),
                            });
                          }}
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          3s Here
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            onUpdateVideoEffect(selectedEffect.id, {
                              startTime: Number(
                                Math.min(
                                  Math.max(0, selectedEffect.endTime - 0.25),
                                  Math.max(0, currentTime)
                                ).toFixed(2)
                              ),
                            })
                          }
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          Set Start
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            onUpdateVideoEffect(selectedEffect.id, {
                              endTime: Number(
                                Math.max(
                                  selectedEffect.startTime + 0.25,
                                  Math.min(duration, currentTime)
                                ).toFixed(2)
                              ),
                            })
                          }
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          Set End
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            onUpdateVideoEffect(selectedEffect.id, {
                              endTime: Number(
                                Math.max(
                                  selectedEffect.startTime + 0.25,
                                  selectedEffect.endTime - 0.5
                                ).toFixed(2)
                              ),
                            })
                          }
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          -0.5s
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            onUpdateVideoEffect(selectedEffect.id, {
                              endTime: Number(
                                Math.min(duration, selectedEffect.endTime + 0.5).toFixed(2)
                              ),
                            })
                          }
                          className="min-h-[30px] px-2 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 border border-white/10 text-[#F5F2EA] cursor-pointer"
                        >
                          +0.5s
                        </button>
                      </div>

                      {videoEffects.length > 1 && onMoveVideoEffect && (() => {
                        const selIdx = videoEffects.findIndex((f) => f.id === selectedEffect.id);
                        return (
                          <div className="inline-flex items-center gap-1">
                            <span className="text-[#9E978B] mr-1">Order:</span>
                            <button
                              type="button"
                              disabled={selIdx <= 0}
                              onClick={() => onMoveVideoEffect(selectedEffect.id, -1)}
                              aria-label="Move effect earlier in stack"
                              className="min-w-[30px] min-h-[30px] rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 disabled:opacity-35 text-[#F5F2EA] flex items-center justify-center cursor-pointer disabled:cursor-not-allowed"
                            >
                              <ChevronLeft className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                            <button
                              type="button"
                              disabled={selIdx >= videoEffects.length - 1}
                              onClick={() => onMoveVideoEffect(selectedEffect.id, 1)}
                              aria-label="Move effect later in stack"
                              className="min-w-[30px] min-h-[30px] rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/18 disabled:opacity-35 text-[#F5F2EA] flex items-center justify-center cursor-pointer disabled:cursor-not-allowed"
                            >
                              <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
                            </button>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })()}

        {/* BEGINNER-FRIENDLY MULTILINGUAL VIDEO TEXT EDITOR */}
        {panelMode === 'text' && (() => {
          const textLangChoices: Array<{
            id: TargetLanguageCode;
            native: string;
            label: string;
          }> = [
            { id: 'ur', native: 'اردو', label: 'Urdu' },
            { id: 'hi', native: 'हिन्दी', label: 'Hindi' },
            { id: 'sd', native: 'سنڌي', label: 'Sindhi' },
            { id: 'en', native: 'English', label: 'English' },
            {
              id: chineseVariant,
              native: chineseVariant === 'zh-Hant' ? '繁體中文' : '简体中文',
              label: 'Chinese',
            },
          ];

          const selectedDuration = selectedText
            ? Math.max(0.3, selectedText.endTime - selectedText.startTime)
            : 0;
          const selectedScale = selectedText ? selectedText.scale ?? 1 : 1;
          const selectedOpacityPct = Math.round(
            (selectedText ? selectedText.opacity ?? 1 : 1) * 100
          );
          const isCenteredPreset =
            selectedText &&
            selectedText.x === undefined &&
            selectedText.y === undefined;

          return (
            <div className="flex flex-col gap-3">
              {/* Sub-tabs matching reference visual hierarchy */}
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    { id: 'add', label: 'Add Text' },
                    { id: 'styles', label: 'Styles' },
                    { id: 'timing', label: 'Timing & AI' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setTextSubTab(tab.id)}
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      textSubTab === tab.id
                        ? 'bg-gradient-to-r from-[#7C3AED] to-[#9333EA] text-white shadow-sm shadow-[#7C3AED]/30'
                        : 'bg-[#141722] border border-white/8 text-[#D4C7A8] hover:text-white hover:border-[#8B5CF6]/45'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* 4 Visual Aa Quick Style Cards (matching reference screenshot) */}
              <div className="grid grid-cols-4 gap-2">
                {TEXT_AA_PRESETS.map((preset) => {
                  const isActivePreset =
                    selectedText &&
                    selectedText.style === preset.style &&
                    selectedText.color.toLowerCase() === preset.color.toLowerCase();
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        if (selectedText) {
                          onUpdateTextOverlay(selectedText.id, {
                            style: preset.style,
                            color: preset.color,
                          });
                        } else {
                          onAddTextOverlay('text', {
                            style: preset.style,
                            color: preset.color,
                          });
                        }
                      }}
                      title={`Apply ${preset.label} style`}
                      className={`min-h-[58px] rounded-xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                        preset.cardClass
                      } ${
                        isActivePreset
                          ? 'ring-2 ring-[#A855F7] ring-offset-1 ring-offset-[#0B0D14]'
                          : 'hover:border-[#8B5CF6]/70'
                      }`}
                    >
                      <span className={`text-xl leading-none ${preset.previewClass}`}>
                        Aa
                      </span>
                      <span className="text-[10px] text-[#9E978B] font-medium">
                        {preset.label}
                      </span>
                    </button>
                  );
                })}
              </div>

              {textSubTab === 'add' && (
                <>
                  {/* 1-Tap Add Text, Title, Subtitle, Watermark */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => onAddTextOverlay('text')}
                      className="min-h-[42px] px-3 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-[#7C3AED]/25"
                    >
                      <Plus className="w-4 h-4 shrink-0 text-[#F3D778]" aria-hidden="true" />
                      <span>{strings.addTextBtn}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onAddTextOverlay('title')}
                      className="min-h-[42px] px-3 rounded-xl bg-[#141722] hover:bg-[#1E2233] border border-[#D4AF37]/40 text-[#F5E1A4] text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 shrink-0 text-[#E5C158]" aria-hidden="true" />
                      <span>{strings.addTitleBtn}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onAddTextOverlay('subtitle')}
                      className="min-h-[42px] px-3 rounded-xl bg-[#141722] hover:bg-[#1E2233] border border-[#8B5CF6]/30 text-[#F5F2EA] text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Captions className="w-3.5 h-3.5 shrink-0 text-[#A855F7]" aria-hidden="true" />
                      <span>{strings.addSubtitleBtn}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onAddTextOverlay('watermark')}
                      className="min-h-[42px] px-3 rounded-xl bg-[#141722] hover:bg-[#1E2233] border border-[#8B5CF6]/30 text-[#F5F2EA] text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Scan className="w-3.5 h-3.5 shrink-0 text-[#E5C158]" aria-hidden="true" />
                      <span>{strings.addWatermarkBtn}</span>
                    </button>
                  </div>

                  {/* Quick Emojis */}
                  <div className="flex items-center gap-2 bg-[#141722] rounded-xl px-2.5 py-2 border border-white/8">
                    <span className="text-[11px] font-semibold text-[#D4C7A8] shrink-0">
                      {strings.emojiStickersLabel}
                    </span>
                    <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                      {STICKER_PRESETS.map((emoji) => (
                        <button
                          key={`add-stk-${emoji}`}
                          type="button"
                          onClick={() => onAddStickerOverlay(emoji)}
                          title={`Add ${emoji}`}
                          className="min-w-[38px] min-h-[38px] px-1.5 rounded-lg bg-[#090A0E] hover:bg-[#7C3AED]/22 border border-white/10 hover:border-[#A855F7] text-lg flex items-center justify-center shrink-0 cursor-pointer"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Active Text Layers Switcher */}
              {textOverlays.length > 0 && (
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pb-0.5">
                  {textOverlays.map((item, idx) => {
                    const active = item.id === selectedText?.id;
                    const badge =
                      item.kind === 'title'
                        ? 'Title'
                        : item.kind === 'subtitle' || item.isCaption
                        ? 'Sub'
                        : item.kind === 'watermark'
                        ? 'WM'
                        : null;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          onSelectTextOverlay(item.id);
                          if (currentTime < item.startTime || currentTime > item.endTime) {
                            onSeek(
                              Math.min(duration, Math.max(0, item.startTime + 0.05))
                            );
                          }
                        }}
                        className={`min-h-[36px] px-3 rounded-xl text-xs font-medium border whitespace-nowrap shrink-0 max-w-[165px] inline-flex items-center gap-1.5 cursor-pointer ${
                          active
                            ? 'bg-[#7C3AED]/22 border-[#A855F7] text-white'
                            : 'bg-[#141722] border-white/10 text-[#D4C7A8] hover:border-[#8B5CF6]/45 hover:text-white'
                        }`}
                      >
                        {badge && (
                          <span className="px-1.5 py-0.5 rounded bg-[#D4AF37]/20 text-[9px] font-bold uppercase tracking-wide text-[#F3D778]">
                            {badge}
                          </span>
                        )}
                        <span className="truncate">
                          {item.text.trim() || `Text ${idx + 1}`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {selectedText ? (
                <div className="flex flex-col gap-3 bg-[#141722] rounded-2xl p-3 border border-[#8B5CF6]/20">
                  {textSubTab === 'add' && (
                    <>
                      {/* Language Quick Buttons (Urdu, Hindi, Sindhi, English, Chinese) */}
                      <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-3 gap-1.5">
                        {textLangChoices.map((choice) => {
                          const active =
                            (selectedText.lang ?? 'en') === choice.id ||
                            (choice.label === 'Chinese' &&
                              (selectedText.lang === 'zh-Hans' ||
                                selectedText.lang === 'zh-Hant'));
                          return (
                            <button
                              key={choice.label}
                              type="button"
                              onClick={() => {
                                const nextDir =
                                  choice.id === 'sd' || choice.id === 'ur' ? 'rtl' : 'ltr';
                                onUpdateTextOverlay(selectedText.id, {
                                  lang: choice.id,
                                  dir: nextDir,
                                });
                              }}
                              className={`min-h-[40px] px-2.5 py-1 rounded-xl border flex flex-col items-center justify-center text-center transition-colors cursor-pointer ${
                                active
                                  ? 'bg-[#7C3AED]/22 border-[#A855F7] text-white'
                                  : 'bg-[#090A0E] border-white/8 text-[#D4C7A8] hover:border-[#8B5CF6]/45 hover:text-white'
                              }`}
                            >
                              <span className="text-xs font-semibold leading-tight whitespace-nowrap">
                                {choice.native}
                              </span>
                              {choice.label !== choice.native && (
                                <span className="text-[10px] opacity-75 leading-tight whitespace-nowrap">
                                  {choice.label}
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Text Input Box + Delete */}
                      <div className="flex items-start gap-2">
                        <textarea
                          rows={2}
                          value={selectedText.text}
                          dir={selectedTextScriptCfg.dir}
                          lang={selectedTextScriptCfg.langAttr}
                          style={{
                            fontFamily: selectedTextScriptCfg.fontFamily,
                            unicodeBidi: 'plaintext',
                          }}
                          onChange={(e) => {
                            const nextVal = e.target.value;
                            const detected = detectScriptLanguage(
                              nextVal,
                              chineseVariant,
                              selectedText.lang
                            );
                            if (detected && nextVal.trim().length > 0) {
                              onUpdateTextOverlay(selectedText.id, {
                                text: nextVal,
                                lang: detected,
                                dir:
                                  detected === 'sd' || detected === 'ur' ? 'rtl' : 'ltr',
                              });
                            } else {
                              onUpdateTextOverlay(selectedText.id, { text: nextVal });
                            }
                          }}
                          placeholder="Type in اردو, हिन्दी, سنڌي, English, or 中文..."
                          maxLength={180}
                          className="flex-1 min-h-[58px] rounded-xl bg-[#090A0E] border border-white/14 px-3 py-2 text-sm text-[#F5F2EA] placeholder:text-[#9E978B] focus:outline-none focus:border-[#8B5CF6] resize-y"
                        />
                        <button
                          type="button"
                          onClick={() => onDeleteTextOverlay(selectedText.id)}
                          aria-label="Delete selected text"
                          className="min-w-[44px] min-h-[44px] rounded-xl bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300 flex items-center justify-center shrink-0 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>

                      {/* Direct on-video move & resize tip */}
                      <div className="rounded-lg bg-[#7C3AED]/12 border border-[#8B5CF6]/30 px-2.5 py-1.5 text-[11px] text-[#E9D5FF] flex items-center justify-between gap-2 flex-wrap">
                        <span>{strings.textDragResizeTip}</span>
                        {!isCenteredPreset && (
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateTextOverlay(selectedText.id, {
                                position: 'center',
                                x: undefined,
                                y: undefined,
                              })
                            }
                            className="text-[#F3D778] hover:text-white font-semibold underline cursor-pointer"
                          >
                            Center
                          </button>
                        )}
                      </div>
                    </>
                  )}

                  {textSubTab === 'styles' && (
                    <>
                      {/* Colors & Text Styles */}
                      <div className="flex flex-wrap items-center justify-between gap-2.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          {TEXT_COLORS.map((hex) => (
                            <button
                              key={hex}
                              type="button"
                              aria-label={`Text color ${hex}`}
                              onClick={() =>
                                onUpdateTextOverlay(selectedText.id, { color: hex })
                              }
                              style={{ backgroundColor: hex }}
                              className={`w-8 h-8 rounded-full border cursor-pointer transition-transform ${
                                selectedText.color.toLowerCase() === hex.toLowerCase()
                                  ? 'ring-2 ring-[#A855F7] ring-offset-2 ring-offset-[#141722] border-white scale-105'
                                  : 'border-white/30 hover:scale-105'
                              }`}
                            />
                          ))}
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5">
                          {(
                            [
                              { id: 'clean', label: 'Clean' },
                              { id: 'outline', label: 'Outline' },
                              { id: 'boxed', label: 'Box' },
                              { id: 'subtitle-bar', label: 'Sub Bar' },
                              { id: 'pop', label: 'Pop' },
                            ] as Array<{ id: TextStylePreset; label: string }>
                          ).map((st) => (
                            <button
                              key={st.id}
                              type="button"
                              onClick={() =>
                                onUpdateTextOverlay(selectedText.id, { style: st.id })
                              }
                              className={`min-h-[34px] px-2.5 rounded-lg text-xs font-medium cursor-pointer ${
                                selectedText.style === st.id
                                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#9333EA] text-white font-semibold'
                                  : 'bg-[#090A0E] border border-white/8 text-[#D4C7A8] hover:text-white'
                              }`}
                            >
                              {st.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Position (Top / Center / Bottom) & Size Presets (Small / Medium / Large) */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                        <div className="grid grid-cols-3 gap-1.5 bg-[#090A0E] p-1 rounded-xl border border-white/8">
                          {(
                            [
                              { id: 'top', label: strings.posTop },
                              { id: 'center', label: strings.posCenter },
                              { id: 'bottom', label: strings.posBottom },
                            ] as Array<{ id: TextPosition; label: string }>
                          ).map((pos) => {
                            const active = isCenteredPreset && selectedText.position === pos.id;
                            return (
                              <button
                                key={pos.id}
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    position: pos.id,
                                    x: undefined,
                                    y: undefined,
                                  })
                                }
                                className={`min-h-[36px] px-2 rounded-lg text-xs font-semibold cursor-pointer ${
                                  active
                                    ? 'bg-[#7C3AED] text-white'
                                    : 'text-[#D4C7A8] hover:bg-white/6 hover:text-white'
                                }`}
                              >
                                {pos.label}
                              </button>
                            );
                          })}
                        </div>

                        <div className="grid grid-cols-3 gap-1.5 bg-[#090A0E] p-1 rounded-xl border border-white/8">
                          {(
                            [
                              { id: 'sm', label: strings.sizeSmall },
                              { id: 'md', label: strings.sizeMedium },
                              { id: 'lg', label: strings.sizeLarge },
                            ] as Array<{ id: TextSizePreset; label: string }>
                          ).map((sz) => (
                            <button
                              key={sz.id}
                              type="button"
                              onClick={() =>
                                onUpdateTextOverlay(selectedText.id, {
                                  size: sz.id,
                                  scale: 1,
                                })
                              }
                              className={`min-h-[36px] px-2 rounded-lg text-xs font-semibold cursor-pointer ${
                                selectedText.size === sz.id
                                  ? 'bg-[#D4AF37]/25 border border-[#E5C158]/60 text-[#F5E1A4]'
                                  : 'text-[#D4C7A8] hover:bg-white/6 hover:text-white'
                              }`}
                            >
                              {sz.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Fine Size & Opacity Sliders */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                        <label className="flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-xl px-3 py-2 text-xs">
                          <span className="text-[#9E978B] shrink-0">{strings.sizeLabel}</span>
                          <input
                            type="range"
                            min={50}
                            max={250}
                            step={5}
                            value={Math.round(selectedScale * 100)}
                            onChange={(e) =>
                              onUpdateTextOverlay(selectedText.id, {
                                scale: Number(e.target.value) / 100,
                              })
                            }
                            className="flex-1 accent-[#8B5CF6] cursor-pointer"
                          />
                          <span className="font-mono-tabular w-10 text-right text-[#F5F2EA]">
                            {Math.round(selectedScale * 100)}%
                          </span>
                        </label>

                        <label className="flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-xl px-3 py-2 text-xs">
                          <span className="text-[#9E978B] shrink-0">
                            {strings.opacityLabel}
                          </span>
                          <input
                            type="range"
                            min={20}
                            max={100}
                            step={5}
                            value={selectedOpacityPct}
                            onChange={(e) =>
                              onUpdateTextOverlay(selectedText.id, {
                                opacity: Number(e.target.value) / 100,
                              })
                            }
                            className="flex-1 accent-[#8B5CF6] cursor-pointer"
                          />
                          <span className="font-mono-tabular w-10 text-right text-[#F5F2EA]">
                            {selectedOpacityPct}%
                          </span>
                        </label>
                      </div>
                    </>
                  )}

                  {textSubTab === 'timing' && (
                    <>
                      {/* Direction, Follow Motion Track & Translate */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <div className="flex items-center gap-1 bg-[#090A0E] border border-white/10 rounded-lg p-0.5">
                            <span className="text-[10px] text-[#9E978B] px-1.5">
                              {strings.directionLabel}:
                            </span>
                            {(['auto', 'rtl', 'ltr'] as const).map((dirOpt) => (
                              <button
                                key={dirOpt}
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, { dir: dirOpt })
                                }
                                className={`min-h-[28px] px-2 rounded text-[10px] font-semibold uppercase cursor-pointer ${
                                  (selectedText.dir ?? 'auto') === dirOpt
                                    ? 'bg-[#7C3AED] text-white'
                                    : 'text-[#9E978B] hover:text-white'
                                }`}
                              >
                                {dirOpt}
                              </button>
                            ))}
                          </div>

                          {motionTracks.length > 0 && (
                            <label className="flex items-center gap-1.5 bg-[#090A0E] border border-[#8B5CF6]/35 rounded-lg px-2 py-1 min-h-[32px]">
                              <Crosshair
                                className="w-3 h-3 text-[#A855F7]"
                                aria-hidden="true"
                              />
                              <span className="text-[11px] text-[#9E978B]">Follow:</span>
                              <select
                                value={selectedText.trackId ?? ''}
                                onChange={(e) =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    trackId: e.target.value || undefined,
                                  })
                                }
                                className="bg-transparent text-[#F5F2EA] text-[11px] font-medium focus:outline-none cursor-pointer"
                              >
                                <option value="" className="bg-[#0D0F14]">
                                  None
                                </option>
                                {motionTracks.map((tr) => (
                                  <option key={tr.id} value={tr.id} className="bg-[#0D0F14]">
                                    {tr.label}
                                  </option>
                                ))}
                              </select>
                            </label>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <select
                            value={textTranslateTargetLang}
                            onChange={(e) =>
                              onChangeTextTranslateTargetLang(
                                e.target.value as TargetLanguageCode
                              )
                            }
                            className="min-h-[34px] rounded-lg bg-[#090A0E] border border-white/10 px-2 text-xs text-[#F5F2EA] focus:outline-none cursor-pointer"
                          >
                            {TARGET_LANGUAGE_OPTIONS.map((opt) => (
                              <option key={opt.code} value={opt.code} className="bg-[#0D0F14]">
                                {opt.nativeLabel} · {opt.label}
                              </option>
                            ))}
                          </select>
                          <button
                            type="button"
                            disabled={textTranslateBusy || !selectedText.text.trim()}
                            onClick={onTranslateSelectedText}
                            className="min-h-[34px] px-3 rounded-lg bg-[#7C3AED]/25 hover:bg-[#7C3AED]/40 border border-[#A855F7]/60 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            {textTranslateBusy ? (
                              <Loader2
                                className="w-3.5 h-3.5 animate-spin"
                                aria-hidden="true"
                              />
                            ) : (
                              <Languages className="w-3.5 h-3.5 text-[#F3D778]" aria-hidden="true" />
                            )}
                            <span>{strings.translateTextBtn}</span>
                          </button>
                        </div>
                      </div>

                      {aiError && (
                        <div className="rounded-lg bg-red-500/12 border border-red-500/35 px-2.5 py-1.5 text-xs text-red-200">
                          {aiError}
                        </div>
                      )}

                      {/* Timeline Duration Controls */}
                      <div className="flex flex-col gap-2 bg-[#090A0E] border border-white/8 rounded-xl p-2.5 text-xs">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-[#D4C7A8] font-medium">
                            {strings.textDurationLabel}:{' '}
                            <strong className="font-mono-tabular text-[#F5F2EA]">
                              {formatTimecode(selectedText.startTime)} –{' '}
                              {formatTimecode(selectedText.endTime)}
                            </strong>{' '}
                            <span className="text-[#9E978B]">
                              ({selectedDuration.toFixed(1)}s)
                            </span>
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                const nextStart = Math.min(
                                  Math.max(0, currentTime),
                                  Math.max(0, duration - 0.5)
                                );
                                const nextEnd = Math.min(
                                  duration,
                                  Math.max(nextStart + 0.5, nextStart + selectedDuration)
                                );
                                onUpdateTextOverlay(selectedText.id, {
                                  startTime: nextStart,
                                  endTime: nextEnd,
                                });
                              }}
                              className="min-h-[30px] px-2.5 rounded-lg bg-[#141722] hover:bg-[#1E2233] border border-white/10 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                            >
                              Start Here
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateTextOverlay(selectedText.id, {
                                  startTime: 0,
                                  endTime: duration,
                                })
                              }
                              className="min-h-[30px] px-2.5 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/45 text-[#F5E1A4] text-[11px] font-semibold cursor-pointer"
                            >
                              {strings.fullVideoBtn}
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex items-center justify-between gap-1 bg-[#141722] rounded-lg px-2 py-1">
                            <span className="text-[11px] text-[#9E978B]">In</span>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    startTime: Math.max(0, selectedText.startTime - 0.5),
                                  })
                                }
                                className="min-w-[32px] min-h-[28px] rounded bg-white/8 hover:bg-[#7C3AED]/30 text-[#F5F2EA] font-semibold cursor-pointer"
                              >
                                -0.5s
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    startTime: Math.min(
                                      selectedText.endTime - 0.3,
                                      selectedText.startTime + 0.5
                                    ),
                                  })
                                }
                                className="min-w-[32px] min-h-[28px] rounded bg-white/8 hover:bg-[#7C3AED]/30 text-[#F5F2EA] font-semibold cursor-pointer"
                              >
                                +0.5s
                              </button>
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-1 bg-[#141722] rounded-lg px-2 py-1">
                            <span className="text-[11px] text-[#9E978B]">Out</span>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    endTime: Math.max(
                                      selectedText.startTime + 0.3,
                                      selectedText.endTime - 0.5
                                    ),
                                  })
                                }
                                className="min-w-[32px] min-h-[28px] rounded bg-white/8 hover:bg-[#7C3AED]/30 text-[#F5F2EA] font-semibold cursor-pointer"
                              >
                                -0.5s
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  onUpdateTextOverlay(selectedText.id, {
                                    endTime: Math.min(duration, selectedText.endTime + 0.5),
                                  })
                                }
                                className="min-w-[32px] min-h-[28px] rounded bg-white/8 hover:bg-[#7C3AED]/30 text-[#F5F2EA] font-semibold cursor-pointer"
                              >
                                +0.5s
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="rounded-xl bg-[#141722] border border-[#8B5CF6]/20 p-3 flex flex-col gap-2 text-xs text-[#D4C7A8]">
                  <p>
                    Tap any <strong className="text-white">Aa</strong> style card above or{' '}
                    <strong className="text-[#F3D778]">{strings.addTextBtn}</strong> to add multilingual text in Urdu, Hindi, Sindhi, English, or Chinese.
                  </p>
                  {textSubTab !== 'add' && (
                    <button
                      type="button"
                      onClick={() => onAddTextOverlay('text')}
                      className="min-h-[38px] px-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#9333EA] text-white font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer self-start"
                    >
                      <Plus className="w-3.5 h-3.5 text-[#F3D778]" aria-hidden="true" />
                      <span>{strings.addTextBtn}</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })()}

        {/* CLIP TRANSITIONS PANEL */}
        {panelMode === 'transitions' && selectedSegment && onChangeClipTransition && (
          <div className="flex flex-col gap-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll pb-0.5">
              {TRANSITION_PRESETS.map((preset) => {
                const active = selectedTransition.type === preset.type;
                return (
                  <button
                    key={preset.type}
                    type="button"
                    onClick={() =>
                      onChangeClipTransition(
                        selectedSegment.id,
                        {
                          type: preset.type,
                          duration: selectedTransition.duration || 0.6,
                        },
                        false
                      )
                    }
                    className={`min-h-[42px] px-3 py-1.5 rounded-xl text-left border whitespace-nowrap shrink-0 cursor-pointer transition-colors flex flex-col justify-center ${
                      active
                        ? 'bg-[#D4AF37]/18 border-[#E5C158] text-[#F5E1A4]'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:border-[#D4AF37]/40 hover:text-[#F5F2EA]'
                    }`}
                  >
                    <span className="text-xs font-semibold">{preset.label}</span>
                    <span className="text-[10px] opacity-75">{preset.description}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2 text-xs">
              <label className="flex-1 min-w-[190px] flex items-center gap-2">
                <span className="text-[#9E978B]">Duration</span>
                <input
                  type="range"
                  min={0.2}
                  max={2.0}
                  step={0.1}
                  disabled={selectedTransition.type === 'none'}
                  value={selectedTransition.duration}
                  onChange={(e) =>
                    onChangeClipTransition(
                      selectedSegment.id,
                      {
                        type: selectedTransition.type,
                        duration: Number(e.target.value),
                      },
                      false
                    )
                  }
                  className="flex-1 accent-[#8B5CF6] cursor-pointer disabled:opacity-40"
                />
                <span className="font-mono-tabular w-10 text-right text-[#F5F2EA]">
                  {selectedTransition.duration.toFixed(1)}s
                </span>
              </label>

              <button
                type="button"
                onClick={() =>
                  onChangeClipTransition(selectedSegment.id, selectedTransition, true)
                }
                className="min-h-[34px] px-3 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/50 text-[#F5E1A4] text-xs font-medium cursor-pointer"
              >
                Apply transition to all clips
              </button>
            </div>
          </div>
        )}

        {/* SIMPLE BEGINNER-FRIENDLY AUDIO & MUSIC PANEL */}
        {panelMode === 'audio' && (
          <div className="flex flex-col gap-2.5">
            <audio
              ref={musicPreviewAudioRef}
              onEnded={() => setPreviewAudioKey(null)}
              className="hidden"
            />

            {/* Top Navigation Bar: Music Library | Added Tracks | Original Video Audio | Upload Device */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                <button
                  type="button"
                  onClick={() => setAudioSubTab('library')}
                  className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer ${
                    audioSubTab === 'library'
                      ? 'bg-[#7C3AED]/25 border-[#A855F7] text-white'
                      : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-white'
                  }`}
                >
                  <Music className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                  <span>Music</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAudioSubTab('tracks')}
                  className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer ${
                    audioSubTab === 'tracks'
                      ? 'bg-[#7C3AED]/25 border-[#A855F7] text-white'
                      : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-white'
                  }`}
                >
                  <span>My Audio ({audioLayers.length})</span>
                </button>

                {selectedSegment && mediaKind !== 'image' && (
                  <button
                    type="button"
                    onClick={() => setAudioSubTab('video')}
                    className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer ${
                      audioSubTab === 'video'
                        ? 'bg-[#7C3AED]/25 border-[#A855F7] text-white'
                        : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-white'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                    <span>Video Sound</span>
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={onRequestAddAudio}
                className="min-h-[34px] px-3 rounded-lg bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 border border-[#E5C158]/55 text-[#F5E1A4] text-xs font-semibold inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                <span>From Device</span>
              </button>
            </div>

            {/* TAB 1: BUILT-IN MUSIC LIBRARY (Select, Play Preview, Add in 1 Tap) */}
            {audioSubTab === 'library' && (
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                  {MUSIC_LIBRARY_CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setMusicCategory(cat.id)}
                      className={`min-h-[28px] px-2.5 rounded-md text-[11px] font-medium border whitespace-nowrap shrink-0 cursor-pointer ${
                        musicCategory === cat.id
                          ? 'bg-[#D4AF37] border-[#E5C158] text-[#08090C] font-semibold'
                          : 'bg-[#0D0F16] border-white/10 text-[#C4BDB0] hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[168px] overflow-y-auto studio-scroll pr-0.5">
                  {BUILTIN_MUSIC_TRACKS.filter(
                    (t) => musicCategory === 'all' || t.category === musicCategory
                  ).map((track) => {
                    const key = `preset:${track.id}`;
                    const isPreviewing = previewAudioKey === key;
                    return (
                      <div
                        key={track.id}
                        className={`rounded-xl border px-2.5 py-2 flex items-center justify-between gap-2 transition-colors ${
                          isPreviewing
                            ? 'bg-[#7C3AED]/18 border-[#A855F7]/70'
                            : 'bg-[#141720] border-white/10 hover:border-[#D4AF37]/40'
                        }`}
                      >
                        <button
                          type="button"
                          aria-label={isPreviewing ? `Pause ${track.title}` : `Preview ${track.title}`}
                          onClick={() => {
                            const aud = musicPreviewAudioRef.current;
                            if (!aud) return;
                            if (isPreviewing) {
                              aud.pause();
                              setPreviewAudioKey(null);
                              return;
                            }
                            const cached = getOrCreatePresetAudio(track.id);
                            if (!cached) return;
                            aud.src = cached.url;
                            aud.currentTime = 0;
                            aud.loop = true;
                            aud.volume = 0.8;
                            aud.play().catch(() => {});
                            setPreviewAudioKey(key);
                          }}
                          className="w-9 h-9 rounded-lg bg-[#090A0E] border border-[#D4AF37]/35 flex items-center justify-center shrink-0 text-[#E5C158] hover:brightness-110 cursor-pointer"
                        >
                          {isPreviewing ? (
                            <Pause className="w-4 h-4 fill-current" aria-hidden="true" />
                          ) : (
                            <Play className="w-4 h-4 fill-current ml-0.5" aria-hidden="true" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-[#F5F2EA] truncate">
                            {track.title}
                          </p>
                          <p className="text-[10px] text-[#9E978B] truncate">
                            {track.subtitle} · {track.bpm} BPM
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            if (musicPreviewAudioRef.current) {
                              musicPreviewAudioRef.current.pause();
                            }
                            setPreviewAudioKey(null);
                            const cached = getOrCreatePresetAudio(track.id);
                            if (!cached) return;
                            if (onAddAudioLayer) {
                              onAddAudioLayer({
                                name: track.title,
                                url: cached.url,
                                duration: cached.duration,
                                blob: cached.blob,
                              });
                            }
                            setAudioSubTab('tracks');
                          }}
                          className="min-h-[32px] px-2.5 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#8B5CF6] hover:brightness-110 text-white text-[11px] font-bold inline-flex items-center gap-1 shrink-0 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" aria-hidden="true" />
                          <span>Use</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: EDIT ADDED AUDIO TRACKS (Play Preview, Volume, Simple Trim, Remove) */}
            {audioSubTab === 'tracks' && (
              <div className="flex flex-col gap-2">
                {audioLayers.length === 0 ? (
                  <div className="rounded-xl bg-[#141720] border border-white/10 p-3 flex flex-wrap items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#F5F2EA]">
                        No music or audio added yet
                      </p>
                      <p className="text-[11px] text-[#9E978B]">
                        Pick a built-in music track or choose MP3/WAV/M4A from your device.
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setAudioSubTab('library')}
                        className="min-h-[34px] px-3 rounded-lg bg-[#7C3AED] hover:brightness-110 text-white text-xs font-semibold cursor-pointer"
                      >
                        Browse Music
                      </button>
                      <button
                        type="button"
                        onClick={onRequestAddAudio}
                        className="min-h-[34px] px-3 rounded-lg bg-[#D4AF37] text-[#08090C] text-xs font-bold cursor-pointer"
                      >
                        Upload Audio
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Track Switcher */}
                    <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
                      {audioLayers.map((aud) => (
                        <button
                          key={aud.id}
                          type="button"
                          onClick={() => onSelectAudio(aud.id)}
                          className={`min-h-[32px] px-2.5 rounded-lg text-xs font-medium border inline-flex items-center gap-1.5 shrink-0 max-w-[180px] truncate cursor-pointer ${
                            aud.id === selectedAudio?.id
                              ? 'bg-[#D4AF37]/20 border-[#E5C158] text-[#F5E1A4]'
                              : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:text-white'
                          }`}
                        >
                          <Music className="w-3 h-3 shrink-0 text-[#E5C158]" aria-hidden="true" />
                          <span className="truncate">{aud.name}</span>
                        </button>
                      ))}
                    </div>

                    {selectedAudio && (
                      <div className="rounded-xl bg-[#141720] border border-white/10 p-2.5 flex flex-col gap-2 text-xs">
                        {/* Row 1: Preview Play + Volume + Mute + Remove */}
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              const aud = musicPreviewAudioRef.current;
                              if (!aud) return;
                              const key = `layer:${selectedAudio.id}`;
                              if (previewAudioKey === key) {
                                aud.pause();
                                setPreviewAudioKey(null);
                                return;
                              }
                              aud.src = selectedAudio.url;
                              aud.currentTime = Math.max(0, selectedAudio.sourceOffsetSec ?? 0);
                              aud.loop = false;
                              aud.volume = Math.min(1, selectedAudio.volume);
                              aud.play().catch(() => {});
                              setPreviewAudioKey(key);
                            }}
                            className="min-h-[34px] px-2.5 rounded-lg bg-[#7C3AED]/25 hover:bg-[#7C3AED]/35 border border-[#A855F7]/60 text-white text-xs font-semibold inline-flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            {previewAudioKey === `layer:${selectedAudio.id}` ? (
                              <>
                                <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                                <span>Pause</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5 fill-current" aria-hidden="true" />
                                <span>Play</span>
                              </>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, { muted: !selectedAudio.muted })
                            }
                            className={`min-h-[34px] px-2.5 rounded-lg inline-flex items-center gap-1 shrink-0 cursor-pointer ${
                              selectedAudio.muted
                                ? 'bg-red-500/20 text-red-200 border border-red-500/40'
                                : 'bg-[#090A0E] border border-[#D4AF37]/30 text-[#F5E1A4]'
                            }`}
                          >
                            {selectedAudio.muted ? (
                              <VolumeX className="w-3.5 h-3.5" aria-hidden="true" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                            )}
                            <span>{selectedAudio.muted ? 'Muted' : 'Sound'}</span>
                          </button>

                          <label className="flex-1 min-w-[140px] flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                            <span className="text-[#9E978B]">Vol</span>
                            <input
                              type="range"
                              min={0}
                              max={150}
                              value={
                                selectedAudio.muted ? 0 : Math.round(selectedAudio.volume * 100)
                              }
                              onChange={(e) => {
                                const v = Number(e.target.value);
                                onUpdateAudio(selectedAudio.id, {
                                  volume: v / 100,
                                  muted: v === 0,
                                });
                              }}
                              className="flex-1 accent-[#8B5CF6] cursor-pointer"
                            />
                            <span className="font-mono-tabular w-9 text-right text-[#F5F2EA]">
                              {selectedAudio.muted
                                ? '0%'
                                : `${Math.round(selectedAudio.volume * 100)}%`}
                            </span>
                          </label>

                          <button
                            type="button"
                            onClick={() => {
                              if (
                                previewAudioKey === `layer:${selectedAudio.id}` &&
                                musicPreviewAudioRef.current
                              ) {
                                musicPreviewAudioRef.current.pause();
                                setPreviewAudioKey(null);
                              }
                              onDeleteAudio(selectedAudio.id);
                            }}
                            className="min-h-[34px] px-2.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 text-red-300 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Remove</span>
                          </button>
                        </div>

                        {/* Row 2: Simple Timeline Trim Controls (Start / End / Full Video) */}
                        <div className="flex flex-wrap items-center gap-1.5 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                          <span className="text-[11px] font-semibold text-[#E5C158] mr-1">
                            Trim ({formatTimecode(selectedAudio.startTime)}–
                            {formatTimecode(selectedAudio.endTime)})
                          </span>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, {
                                startTime: Math.max(
                                  0,
                                  Math.min(currentTime, selectedAudio.endTime - 0.5)
                                ),
                              })
                            }
                            className="min-h-[28px] px-2 rounded bg-white/8 hover:bg-[#D4AF37]/20 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                          >
                            Start Here
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, {
                                startTime: Math.max(0, selectedAudio.startTime - 0.5),
                              })
                            }
                            className="min-h-[28px] px-1.5 rounded bg-white/6 hover:bg-white/12 text-[#D4C7A8] text-[11px] font-mono-tabular cursor-pointer"
                          >
                            -0.5s
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, {
                                startTime: Math.min(
                                  selectedAudio.endTime - 0.5,
                                  selectedAudio.startTime + 0.5
                                ),
                              })
                            }
                            className="min-h-[28px] px-1.5 rounded bg-white/6 hover:bg-white/12 text-[#D4C7A8] text-[11px] font-mono-tabular cursor-pointer"
                          >
                            +0.5s
                          </button>

                          <span className="text-white/20 mx-0.5">|</span>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, {
                                endTime: Math.min(
                                  duration,
                                  Math.max(selectedAudio.startTime + 0.5, currentTime)
                                ),
                              })
                            }
                            className="min-h-[28px] px-2 rounded bg-white/8 hover:bg-[#D4AF37]/20 text-[#F5F2EA] text-[11px] font-medium cursor-pointer"
                          >
                            End Here
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateAudio(selectedAudio.id, {
                                startTime: 0,
                                endTime: Math.max(0.5, duration),
                              })
                            }
                            className="min-h-[28px] px-2 rounded bg-[#7C3AED]/20 hover:bg-[#7C3AED]/30 border border-[#A855F7]/40 text-[#E9D5FF] text-[11px] font-medium cursor-pointer"
                          >
                            Full Video
                          </button>
                        </div>

                        {/* Row 3: Song Start Trim (Skip Intro) & Soft Fades */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                          <label className="flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                            <span className="text-[#9E978B] whitespace-nowrap">Song Start</span>
                            <input
                              type="range"
                              min={0}
                              max={Math.max(0, Number((selectedAudio.duration - 0.5).toFixed(1)))}
                              step={0.5}
                              value={Math.min(
                                selectedAudio.sourceOffsetSec ?? 0,
                                Math.max(0, selectedAudio.duration - 0.5)
                              )}
                              onChange={(e) =>
                                onUpdateAudio(selectedAudio.id, {
                                  sourceOffsetSec: Number(e.target.value),
                                })
                              }
                              className="flex-1 accent-[#D4AF37] cursor-pointer"
                            />
                            <span className="font-mono-tabular w-8 text-right text-[#F5F2EA]">
                              {(selectedAudio.sourceOffsetSec ?? 0).toFixed(1)}s
                            </span>
                          </label>

                          <label className="flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                            <span className="text-[#9E978B] whitespace-nowrap">Fade In</span>
                            <input
                              type="range"
                              min={0}
                              max={3}
                              step={0.1}
                              value={selectedAudio.fadeInSec ?? 0}
                              onChange={(e) =>
                                onUpdateAudio(selectedAudio.id, {
                                  fadeInSec: Number(e.target.value),
                                })
                              }
                              className="flex-1 accent-[#8B5CF6] cursor-pointer"
                            />
                            <span className="font-mono-tabular w-8 text-right text-[#F5F2EA]">
                              {(selectedAudio.fadeInSec ?? 0).toFixed(1)}s
                            </span>
                          </label>

                          <label className="flex items-center gap-2 bg-[#090A0E] border border-white/8 rounded-lg px-2.5 py-1.5">
                            <span className="text-[#9E978B] whitespace-nowrap">Fade Out</span>
                            <input
                              type="range"
                              min={0}
                              max={3}
                              step={0.1}
                              value={selectedAudio.fadeOutSec ?? 0}
                              onChange={(e) =>
                                onUpdateAudio(selectedAudio.id, {
                                  fadeOutSec: Number(e.target.value),
                                })
                              }
                              className="flex-1 accent-[#8B5CF6] cursor-pointer"
                            />
                            <span className="font-mono-tabular w-8 text-right text-[#F5F2EA]">
                              {(selectedAudio.fadeOutSec ?? 0).toFixed(1)}s
                            </span>
                          </label>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {/* TAB 3: ORIGINAL VIDEO CLIP AUDIO */}
            {audioSubTab === 'video' && selectedSegment && (
              <div className="flex flex-col gap-2">
                <div className="flex flex-wrap items-center gap-2.5 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                  <button
                    type="button"
                    onClick={() =>
                      onChangeClipAudio(selectedSegment.id, { muted: !selectedMuted }, false)
                    }
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 shrink-0 cursor-pointer ${
                      selectedMuted
                        ? 'bg-red-500/20 text-red-200 border border-red-500/40'
                        : 'bg-[#090A0E] border border-[#D4AF37]/30 text-[#F5E1A4]'
                    }`}
                  >
                    {selectedMuted ? (
                      <VolumeX className="w-4 h-4" aria-hidden="true" />
                    ) : (
                      <Volume2 className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    )}
                    <span>{selectedMuted ? 'Video Muted' : 'Video Audio On'}</span>
                  </button>

                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={selectedMuted ? 0 : selectedVolume}
                    onChange={(e) =>
                      onChangeClipAudio(
                        selectedSegment.id,
                        {
                          volume: Number(e.target.value) / 100,
                          muted: Number(e.target.value) === 0,
                        },
                        false
                      )
                    }
                    className="flex-1 min-w-[140px] accent-[#8B5CF6] cursor-pointer"
                  />
                  <span className="w-10 text-right font-mono-tabular text-xs text-[#F5F2EA]">
                    {selectedMuted ? '0%' : `${selectedVolume}%`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                    <span className="text-[#9E978B]">Fade In</span>
                    <input
                      type="range"
                      min={0}
                      max={3}
                      step={0.1}
                      value={selectedFadeIn}
                      onChange={(e) =>
                        onChangeClipAudio(
                          selectedSegment.id,
                          { fadeInSec: Number(e.target.value) },
                          false
                        )
                      }
                      className="flex-1 accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="font-mono-tabular w-9 text-right text-[#F5F2EA]">
                      {selectedFadeIn.toFixed(1)}s
                    </span>
                  </label>

                  <label className="flex items-center gap-2 bg-[#141720] border border-white/8 rounded-xl px-3 py-2">
                    <span className="text-[#9E978B]">Fade Out</span>
                    <input
                      type="range"
                      min={0}
                      max={3}
                      step={0.1}
                      value={selectedFadeOut}
                      onChange={(e) =>
                        onChangeClipAudio(
                          selectedSegment.id,
                          { fadeOutSec: Number(e.target.value) },
                          false
                        )
                      }
                      className="flex-1 accent-[#8B5CF6] cursor-pointer"
                    />
                    <span className="font-mono-tabular w-9 text-right text-[#F5F2EA]">
                      {selectedFadeOut.toFixed(1)}s
                    </span>
                  </label>
                </div>

                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() =>
                      onChangeClipAudio(
                        selectedSegment.id,
                        {
                          volume: selectedVolume / 100,
                          muted: selectedMuted,
                          fadeInSec: selectedFadeIn,
                          fadeOutSec: selectedFadeOut,
                        },
                        true
                      )
                    }
                    className="text-[11px] text-[#E5C158] hover:text-[#F3D778] font-medium cursor-pointer"
                  >
                    Apply video audio &amp; fades to all clips
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ASPECT RATIO PANEL */}
        {panelMode === 'ratio' && (
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll">
              {ASPECT_RATIO_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeAspectRatio(opt.id)}
                  className={`min-h-[38px] px-3 rounded-xl text-xs font-medium border whitespace-nowrap shrink-0 cursor-pointer ${
                    aspectRatio === opt.id
                      ? 'bg-[#D4AF37] border-[#E5C158] text-[#08090C] font-semibold'
                      : 'bg-[#141720] border-white/10 text-[#D4C7A8] hover:border-[#D4AF37]/40 hover:text-[#F5F2EA]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {aspectRatio !== 'original' && (
              <div className="flex items-center p-0.5 rounded-lg bg-[#090A0E] border border-white/10">
                <button
                  type="button"
                  onClick={() => onChangeFrameFit('contain')}
                  className={`min-h-[32px] px-3 rounded-md text-xs font-medium cursor-pointer ${
                    frameFit === 'contain'
                      ? 'bg-[#D4AF37] text-[#08090C] font-semibold'
                      : 'text-[#9E978B] hover:text-[#F5F2EA]'
                  }`}
                >
                  Fit
                </button>
                <button
                  type="button"
                  onClick={() => onChangeFrameFit('cover')}
                  className={`min-h-[32px] px-3 rounded-md text-xs font-medium cursor-pointer ${
                    frameFit === 'cover'
                      ? 'bg-[#D4AF37] text-[#08090C] font-semibold'
                      : 'text-[#9E978B] hover:text-[#F5F2EA]'
                  }`}
                >
                  Fill
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
