import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Download, Loader2, AlertCircle } from 'lucide-react';
import { isRunningInAndroidApp } from '../utils/androidBridge';

interface ProjectZipDownloadControlProps {
  compact?: boolean;
}

const ZIP_FILENAME = 'meesam-tech-android-project.zip';
const ZIP_ENDPOINT = '/api/download-project-zip';

export const ProjectZipDownloadControl: React.FC<ProjectZipDownloadControlProps> = ({
  compact = false,
}) => {
  const [status, setStatus] = useState<'idle' | 'downloading' | 'ready' | 'error'>('idle');
  const [progressPct, setProgressPct] = useState<number>(0);
  const [loadedMb, setLoadedMb] = useState<string>('0.0');
  const [totalMb, setTotalMb] = useState<string>('');
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const blobUrlRef = useRef<string | null>(null);

  useEffect(() => {
    return () => {
      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current);
      }
    };
  }, []);

  if (isRunningInAndroidApp()) {
    return null;
  }

  const triggerBlobAnchorClick = (url: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = ZIP_FILENAME;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrepareAndDownload = async () => {
    if (status === 'downloading') return;

    if (blobUrl) {
      triggerBlobAnchorClick(blobUrl);
      return;
    }

    setStatus('downloading');
    setProgressPct(0);
    setLoadedMb('0.0');
    setTotalMb('');
    setErrorMsg(null);

    try {
      const response = await fetch(ZIP_ENDPOINT, { cache: 'no-store' });
      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('text/html')) {
        throw new Error('Download endpoint returned HTML instead of ZIP.');
      }

      const contentLength = Number(response.headers.get('content-length') || 0);
      if (contentLength > 0) {
        setTotalMb((contentLength / (1024 * 1024)).toFixed(1));
      }

      let zipBlob: Blob;
      if (response.body && typeof response.body.getReader === 'function') {
        const reader = response.body.getReader();
        const chunks: Uint8Array<ArrayBuffer>[] = [];
        let received = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(new Uint8Array(value));
            received += value.byteLength;
            setLoadedMb((received / (1024 * 1024)).toFixed(1));
            if (contentLength > 0) {
              setProgressPct(Math.min(99, Math.round((received / contentLength) * 100)));
            }
          }
        }
        zipBlob = new Blob(chunks, { type: 'application/zip' });
      } else {
        zipBlob = await response.blob();
      }

      if (zipBlob.size < 1000) {
        throw new Error('Downloaded ZIP archive was empty or invalid.');
      }

      if (blobUrlRef.current) {
        URL.revokeObjectURL(blobUrlRef.current);
      }
      const nextUrl = URL.createObjectURL(zipBlob);
      blobUrlRef.current = nextUrl;
      setBlobUrl(nextUrl);
      setTotalMb((zipBlob.size / (1024 * 1024)).toFixed(1));
      setProgressPct(100);
      setStatus('ready');

      triggerBlobAnchorClick(nextUrl);
    } catch (err) {
      setStatus('error');
      setErrorMsg(
        err instanceof Error ? err.message : 'Unable to fetch project ZIP right now.'
      );
    }
  };

  return (
    <div
      className={
        compact
          ? 'flex flex-col gap-2'
          : 'rounded-xl bg-[#0D0F16] border border-[#D4AF37]/30 p-3.5 sm:p-4 flex flex-col gap-2.5'
      }
    >
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-[#F5F2EA]">
            Android Studio &amp; GitHub Project (.ZIP)
          </p>
          <p className="text-[11px] text-[#9E978B]">
            Includes all source code, Android Gradle files, and .github/workflows/android-apk.yml
          </p>
        </div>

        {status === 'ready' && blobUrl ? (
          <a
            href={blobUrl}
            download={ZIP_FILENAME}
            className="min-h-[38px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold inline-flex items-center gap-1.5 shrink-0 shadow-[0_2px_14px_rgba(16,185,129,0.3)]"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Save {ZIP_FILENAME} ({totalMb} MB)</span>
          </a>
        ) : (
          <button
            type="button"
            disabled={status === 'downloading'}
            onClick={handlePrepareAndDownload}
            className="min-h-[38px] px-4 rounded-xl bg-[#D4AF37]/18 hover:bg-[#D4AF37]/28 disabled:opacity-70 border border-[#E5C158]/60 text-[#F5E1A4] text-xs font-semibold inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            {status === 'downloading' ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E5C158]" aria-hidden="true" />
                <span>
                  Preparing {loadedMb}
                  {totalMb ? ` / ${totalMb}` : ''} MB{progressPct > 0 ? ` (${progressPct}%)` : '...'}
                </span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
                <span>Download Project (.ZIP)</span>
              </>
            )}
          </button>
        )}
      </div>

      {status === 'downloading' && (
        <div dir="ltr" className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
          <div
            style={{ width: `${Math.max(8, progressPct)}%` }}
            className="h-full bg-gradient-to-r from-[#7C3AED] via-[#A855F7] to-[#E5C158] transition-all duration-150"
          />
        </div>
      )}

      {status === 'ready' && blobUrl && (
        <p className="text-[11px] text-emerald-300/90">
          ZIP is ready in your browser. If your phone did not start saving automatically, tap the green{' '}
          <a
            href={blobUrl}
            download={ZIP_FILENAME}
            className="underline font-semibold text-emerald-200"
          >
            Save {ZIP_FILENAME}
          </a>{' '}
          button above.
        </p>
      )}

      {status === 'error' && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-red-500/12 border border-red-500/35 px-3 py-2 text-[11px] text-red-200">
          <span className="inline-flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>{errorMsg || 'Failed to prepare ZIP.'}</span>
          </span>
          <a
            href="/download/meesam-tech-android-project.zip"
            download={ZIP_FILENAME}
            className="underline font-semibold text-[#F5E1A4]"
          >
            Try Direct Download Link
          </a>
        </div>
      )}
    </div>
  );
};
