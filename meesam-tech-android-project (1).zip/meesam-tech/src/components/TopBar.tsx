import React from 'react';
import { Check, Download, FolderOpen, Globe, Loader2, Save, Upload } from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import { AppLanguage, ChineseVariant, VideoAsset } from '../types/editor';
import { FIVE_SUPPORTED_LANGUAGES } from '../utils/languages';
import { formatDurationShort } from '../utils/time';

interface TopBarProps {
  asset: VideoAsset | null;
  editedDuration: number;
  uiLanguage: AppLanguage;
  chineseVariant: ChineseVariant;
  strings: UiStrings;
  savedProjectsCount: number;
  isSavingProject: boolean;
  justSaved: boolean;
  onOpenLanguageSettings: () => void;
  onOpenProjects: () => void;
  onSaveProject: () => void;
  onTriggerUpload: () => void;
  onOpenExport: () => void;
  canExport: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  asset,
  editedDuration,
  uiLanguage,
  chineseVariant,
  strings,
  savedProjectsCount,
  isSavingProject,
  justSaved,
  onOpenLanguageSettings,
  onOpenProjects,
  onSaveProject,
  onTriggerUpload,
  onOpenExport,
  canExport,
}) => {
  const activeLang =
    FIVE_SUPPORTED_LANGUAGES.find((l) => l.id === uiLanguage) ??
    FIVE_SUPPORTED_LANGUAGES[3];
  const langBadgeLabel =
    uiLanguage === 'zh'
      ? chineseVariant === 'zh-Hant'
        ? '中文·繁體'
        : '中文·简体'
      : activeLang.nativeName;

  return (
    <header className="h-[52px] shrink-0 border-b border-[#8B5CF6]/25 bg-[#08090D]/95 backdrop-blur-md px-3 sm:px-6 flex items-center justify-between gap-2 sm:gap-4 z-30">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center shrink-0">
        <span className="text-[15px] sm:text-base font-bold tracking-tight text-[#F5F2EA] whitespace-nowrap shrink-0">
          MEESAM<span className="text-[#E5C158] ml-1">TECH</span>
        </span>
      </div>

      {/* Zone 2: Clean unboxed clip metadata on tablet/desktop */}
      <div className="hidden md:flex items-center justify-center gap-2 text-xs text-[#9E978B] min-w-0 truncate">
        {asset ? (
          <>
            <span className="text-[#EAE4D7] font-medium truncate max-w-[220px]">
              {asset.name}
            </span>
            <span aria-hidden="true" className="text-[#A855F7]/70">·</span>
            <span className="font-mono-tabular whitespace-nowrap text-[#D4C7A8]">
              {asset.width}×{asset.height}
            </span>
            <span aria-hidden="true" className="text-[#A855F7]/70">·</span>
            <span className="font-mono-tabular whitespace-nowrap text-[#E5C158]">
              {formatDurationShort(editedDuration)}
            </span>
          </>
        ) : (
          <span className="whitespace-nowrap">{strings.appSubtitle}</span>
        )}
      </div>

      {/* Zone 3: Projects, Save, Language Switcher & Primary Action */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {asset && (
          <button
            type="button"
            disabled={isSavingProject}
            onClick={onSaveProject}
            aria-label={strings.saveProject}
            className={`min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7] ${
              justSaved
                ? 'bg-emerald-600/20 border-emerald-500/45 text-emerald-200'
                : 'bg-[#12141C] hover:bg-[#1A1D29] border-white/12 hover:border-[#A855F7]/50 text-[#EAE4D7]'
            }`}
          >
            {isSavingProject ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E5C158] shrink-0" aria-hidden="true" />
            ) : justSaved ? (
              <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
            ) : (
              <Save className="w-3.5 h-3.5 text-[#E5C158] shrink-0" aria-hidden="true" />
            )}
            <span className="hidden sm:inline">
              {justSaved ? strings.savedLabel : strings.saveProject}
            </span>
          </button>
        )}

        <button
          type="button"
          onClick={onOpenProjects}
          aria-label={strings.savedProjectsTitle}
          className="min-h-[38px] px-2.5 py-1.5 rounded-lg bg-[#12141C] hover:bg-[#1A1D29] border border-white/12 hover:border-[#A855F7]/50 text-[#EAE4D7] text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7]"
        >
          <FolderOpen className="w-3.5 h-3.5 text-[#E5C158] shrink-0" aria-hidden="true" />
          <span className="hidden sm:inline">{strings.projectsBtn}</span>
          {savedProjectsCount > 0 && (
            <span className="text-[10px] font-mono-tabular text-[#C4B5FD]">
              ({savedProjectsCount})
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={onOpenLanguageSettings}
          aria-label={strings.languageSettingsTitle}
          className="min-h-[38px] px-2.5 sm:px-3 py-1.5 rounded-lg bg-[#12141C] hover:bg-[#1A1D29] border border-white/12 hover:border-[#A855F7]/50 text-[#EAE4D7] text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7]"
        >
          <Globe className="w-3.5 h-3.5 text-[#A855F7] shrink-0" aria-hidden="true" />
          <span dir={activeLang.dir} style={{ unicodeBidi: 'plaintext' }}>
            {langBadgeLabel}
          </span>
        </button>

        {asset ? (
          <button
            type="button"
            onClick={onOpenExport}
            disabled={!canExport}
            className="min-h-[38px] px-3.5 sm:px-4 py-1.5 rounded-lg bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none text-white text-xs sm:text-sm font-bold inline-flex items-center gap-2 transition-all whitespace-nowrap shrink-0 cursor-pointer border border-[#A855F7]/60 shadow-[0_2px_18px_rgba(124,58,237,0.38)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7]"
          >
            <Download className="w-4 h-4 shrink-0 text-[#F3D778]" aria-hidden="true" />
            <span>{strings.exportBtn}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onTriggerUpload}
            className="min-h-[38px] px-3.5 sm:px-4 py-1.5 rounded-lg bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 active:scale-[0.98] text-white text-xs sm:text-sm font-bold inline-flex items-center gap-2 transition-all whitespace-nowrap shrink-0 cursor-pointer border border-[#A855F7]/60 shadow-[0_2px_18px_rgba(124,58,237,0.38)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7]"
          >
            <Upload className="w-4 h-4 shrink-0 text-[#F3D778]" aria-hidden="true" />
            <span>{strings.uploadVideoBtn}</span>
          </button>
        )}
      </div>
    </header>
  );
};
