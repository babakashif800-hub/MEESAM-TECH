import React, { useState } from 'react';
import {
  Activity,
  ArrowLeftRight,
  Blend,
  Captions,
  Crosshair,
  Diamond,
  FolderOpen,
  Gauge,
  Layers,
  LayoutGrid,
  Maximize2,
  Mic,
  Music,
  Music2,
  Palette,
  Redo2,
  RotateCcw,
  Scan,
  Scissors,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Type,
  Undo2,
  UserCheck,
  Wand2,
  X,
} from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import { EditorPanelMode, TimelineSegment } from '../types/editor';

interface EditorToolbarProps {
  panelMode: EditorPanelMode;
  strings: UiStrings;
  selectedSegment: TimelineSegment | undefined;
  canSplitAtPlayhead: boolean;
  canDeleteSelected: boolean;
  canUndo: boolean;
  canRedo: boolean;
  hasEdits: boolean;
  activeEffectsCount?: number;
  activeAudioCount?: number;
  onSplit: () => void;
  onSelectPanelMode: (mode: EditorPanelMode) => void;
  onToggleDeleteSelected: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onReset: () => void;
  onReplaceVideo: () => void;
}

const PRIMARY_MODES: ReadonlySet<EditorPanelMode> = new Set([
  'effects',
  'text',
  'filters',
  'audio',
  'layers',
]);

export const EditorToolbar: React.FC<EditorToolbarProps> = ({
  panelMode,
  strings,
  selectedSegment,
  canSplitAtPlayhead,
  canDeleteSelected,
  canUndo,
  canRedo,
  hasEdits,
  activeEffectsCount = 0,
  activeAudioCount = 0,
  onSplit,
  onSelectPanelMode,
  onToggleDeleteSelected,
  onUndo,
  onRedo,
  onReset,
  onReplaceVideo,
}) => {
  const [moreOpen, setMoreOpen] = useState(false);
  const isDeleted = Boolean(selectedSegment?.deleted);

  const toggleMode = (target: Exclude<EditorPanelMode, 'default'>) => {
    setMoreOpen(false);
    onSelectPanelMode(panelMode === target ? 'default' : target);
  };

  const isSecondaryActive = panelMode !== 'default' && !PRIMARY_MODES.has(panelMode);

  const primaryBtnBase =
    'relative flex-1 min-w-0 min-h-[54px] px-1.5 py-1 rounded-xl flex flex-col items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer border focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[#A855F7]';

  const primaryActive =
    'bg-gradient-to-b from-[#7C3AED]/28 to-[#7C3AED]/12 text-white border-[#A855F7]/75 shadow-[0_0_14px_rgba(124,58,237,0.28)]';

  const primaryIdle =
    'border-transparent text-[#D4CEC2] hover:bg-white/6 hover:text-white';

  const drawerItemBase =
    'min-h-[54px] px-2 py-2 rounded-xl flex flex-col items-center justify-center gap-1 text-center border active:scale-95 transition-all cursor-pointer';

  const drawerItemActive =
    'bg-[#7C3AED]/25 border-[#A855F7] text-white shadow-[0_0_12px_rgba(168,85,247,0.25)]';

  const drawerItemIdle =
    'bg-[#131621] border-white/10 text-[#D4CEC2] hover:border-[#A855F7]/50 hover:text-white';

  return (
    <nav
      aria-label="Editing tools"
      className="relative shrink-0 bg-[#07080B] px-2 sm:px-4 pt-1.5 pb-2 pb-safe z-30"
    >
      {/* Expandable More Tools Drawer */}
      {moreOpen && (
        <>
          <div
            onClick={() => setMoreOpen(false)}
            className="fixed inset-0 z-30 bg-black/45 backdrop-blur-[1px]"
            aria-hidden="true"
          />
          <div
            role="dialog"
            aria-label="More editing tools"
            className="absolute bottom-full left-2 right-2 sm:left-4 sm:right-4 mb-2 z-40 max-w-4xl mx-auto rounded-2xl bg-[#0C0E15] border border-[#8B5CF6]/40 shadow-[0_-12px_40px_rgba(0,0,0,0.85)] p-3 sm:p-4 max-h-[62dvh] overflow-y-auto studio-scroll"
          >
            <div className="flex items-center justify-between gap-2 pb-2 mb-3 border-b border-white/8">
              <div className="flex items-center gap-2">
                <LayoutGrid className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                <span className="text-xs sm:text-sm font-bold text-[#F5F2EA]">
                  More Editing Tools
                </span>
              </div>
              <button
                type="button"
                onClick={() => setMoreOpen(false)}
                aria-label="Close more tools"
                className="min-w-[32px] min-h-[32px] rounded-lg bg-[#151824] hover:bg-[#1E2232] border border-white/10 text-[#D4CEC2] flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            <div className="flex flex-col gap-3">
              {/* Group 1: AI & Captions */}
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#E5C158] mb-1.5 px-0.5">
                  AI &amp; Captions
                </div>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                  <button
                    type="button"
                    onClick={() => toggleMode('captions')}
                    className={`${drawerItemBase} ${panelMode === 'captions' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Captions className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolCaptions}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('voice')}
                    className={`${drawerItemBase} ${panelMode === 'voice' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Mic className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolVoice}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('ai')}
                    className={`${drawerItemBase} ${panelMode === 'ai' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Sparkles className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolAiStudio}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('beats')}
                    className={`${drawerItemBase} ${panelMode === 'beats' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Music2 className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolBeatSync}</span>
                  </button>
                </div>
              </div>

              {/* Group 2: Clip & Timing */}
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#E5C158] mb-1.5 px-0.5">
                  Clip &amp; Timing
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onSplit();
                      setMoreOpen(false);
                    }}
                    disabled={!canSplitAtPlayhead}
                    className={`${drawerItemBase} ${drawerItemIdle} disabled:opacity-35 disabled:pointer-events-none`}
                  >
                    <Scissors className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolSplit}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('trim')}
                    className={`${drawerItemBase} ${panelMode === 'trim' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <SlidersHorizontal className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolTrim}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('speed')}
                    className={`${drawerItemBase} ${panelMode === 'speed' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Gauge className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolSpeed}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('transitions')}
                    className={`${drawerItemBase} ${panelMode === 'transitions' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <ArrowLeftRight className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolTransitions}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('ratio')}
                    className={`${drawerItemBase} ${panelMode === 'ratio' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Maximize2 className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolRatio}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onToggleDeleteSelected();
                      setMoreOpen(false);
                    }}
                    disabled={!isDeleted && !canDeleteSelected}
                    className={`${drawerItemBase} disabled:opacity-35 disabled:pointer-events-none ${
                      isDeleted
                        ? 'bg-emerald-500/12 border-emerald-500/35 text-emerald-200'
                        : 'bg-red-500/10 border-red-500/25 text-red-200 hover:bg-red-500/20'
                    }`}
                  >
                    {isDeleted ? (
                      <>
                        <RotateCcw className="w-4 h-4" aria-hidden="true" />
                        <span className="text-[11px] font-medium leading-tight">{strings.toolRestore}</span>
                      </>
                    ) : (
                      <>
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                        <span className="text-[11px] font-medium leading-tight">{strings.toolCutOut}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Group 3: Pro VFX & Motion */}
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#E5C158] mb-1.5 px-0.5">
                  Pro VFX &amp; Motion
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  <button
                    type="button"
                    onClick={() => toggleMode('keyframes')}
                    className={`${drawerItemBase} ${panelMode === 'keyframes' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Diamond className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolKeyframes}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('bgremove')}
                    className={`${drawerItemBase} ${panelMode === 'bgremove' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <UserCheck className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolBgRemove}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('chroma')}
                    className={`${drawerItemBase} ${panelMode === 'chroma' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Blend className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolChromaKey}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('motion')}
                    className={`${drawerItemBase} ${panelMode === 'motion' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Crosshair className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolMotionTrack}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('stabilize')}
                    className={`${drawerItemBase} ${panelMode === 'stabilize' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Activity className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolStabilize}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleMode('mask')}
                    className={`${drawerItemBase} ${panelMode === 'mask' ? drawerItemActive : drawerItemIdle}`}
                  >
                    <Scan className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolMask}</span>
                  </button>
                </div>
              </div>

              {/* Group 4: History & Project */}
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#E5C158] mb-1.5 px-0.5">
                  History &amp; Clip
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                  <button
                    type="button"
                    onClick={onUndo}
                    disabled={!canUndo}
                    className={`${drawerItemBase} ${drawerItemIdle} disabled:opacity-35 disabled:pointer-events-none`}
                  >
                    <Undo2 className="w-4 h-4" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolUndo}</span>
                  </button>

                  <button
                    type="button"
                    onClick={onRedo}
                    disabled={!canRedo}
                    className={`${drawerItemBase} ${drawerItemIdle} disabled:opacity-35 disabled:pointer-events-none`}
                  >
                    <Redo2 className="w-4 h-4" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolRedo}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onReset();
                      setMoreOpen(false);
                    }}
                    disabled={!hasEdits}
                    className={`${drawerItemBase} ${drawerItemIdle} disabled:opacity-35 disabled:pointer-events-none`}
                  >
                    <RotateCcw className="w-4 h-4" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolReset}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onReplaceVideo();
                      setMoreOpen(false);
                    }}
                    className={`${drawerItemBase} ${drawerItemIdle}`}
                  >
                    <FolderOpen className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
                    <span className="text-[11px] font-medium leading-tight">{strings.toolNewClip}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Gold-framed 6-button primary studio dock: Effects, Text, Filters, Audio, Layers, More */}
      <div className="max-w-3xl mx-auto rounded-2xl bg-[#0B0D14] border border-[#D4AF37]/55 shadow-[0_0_20px_rgba(212,175,55,0.12)] px-1.5 py-1 flex items-center justify-between gap-1">
        <button
          type="button"
          onClick={() => toggleMode('effects')}
          className={`${primaryBtnBase} ${
            panelMode === 'effects'
              ? primaryActive
              : activeEffectsCount > 0
              ? 'bg-[#7C3AED]/14 border-[#A855F7]/40 text-white'
              : primaryIdle
          }`}
        >
          <Wand2
            className={`w-[18px] h-[18px] ${
              panelMode === 'effects' || activeEffectsCount > 0
                ? 'text-[#E5C158]'
                : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-semibold whitespace-nowrap truncate max-w-full">
            {strings.toolEffects}
          </span>
          {activeEffectsCount > 0 && (
            <span className="absolute top-1 right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-[#7C3AED] border border-[#A855F7] text-white text-[9px] font-bold flex items-center justify-center">
              {activeEffectsCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => toggleMode('text')}
          className={`${primaryBtnBase} ${panelMode === 'text' ? primaryActive : primaryIdle}`}
        >
          <Type
            className={`w-[18px] h-[18px] ${
              panelMode === 'text' ? 'text-[#E5C158]' : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-medium whitespace-nowrap truncate max-w-full">
            {strings.toolText}
          </span>
        </button>

        <button
          type="button"
          onClick={() => toggleMode('filters')}
          className={`${primaryBtnBase} ${panelMode === 'filters' ? primaryActive : primaryIdle}`}
        >
          <Palette
            className={`w-[18px] h-[18px] ${
              panelMode === 'filters' ? 'text-[#E5C158]' : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-medium whitespace-nowrap truncate max-w-full">
            {strings.toolFilters}
          </span>
        </button>

        <button
          type="button"
          onClick={() => toggleMode('audio')}
          className={`${primaryBtnBase} ${
            panelMode === 'audio'
              ? primaryActive
              : activeAudioCount > 0
              ? 'bg-[#7C3AED]/14 border-[#A855F7]/40 text-white'
              : primaryIdle
          }`}
        >
          <Music
            className={`w-[18px] h-[18px] ${
              panelMode === 'audio' || activeAudioCount > 0
                ? 'text-[#E5C158]'
                : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-medium whitespace-nowrap truncate max-w-full">
            {strings.toolAudio}
          </span>
          {activeAudioCount > 0 && (
            <span className="absolute top-1 right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-[#7C3AED] border border-[#A855F7] text-white text-[9px] font-bold flex items-center justify-center">
              {activeAudioCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => toggleMode('layers')}
          className={`${primaryBtnBase} ${panelMode === 'layers' ? primaryActive : primaryIdle}`}
        >
          <Layers
            className={`w-[18px] h-[18px] ${
              panelMode === 'layers' ? 'text-[#E5C158]' : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-medium whitespace-nowrap truncate max-w-full">
            {strings.toolLayers}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setMoreOpen((v) => !v)}
          aria-expanded={moreOpen}
          className={`${primaryBtnBase} ${
            moreOpen || isSecondaryActive ? primaryActive : primaryIdle
          }`}
        >
          <LayoutGrid
            className={`w-[18px] h-[18px] ${
              moreOpen || isSecondaryActive ? 'text-[#E5C158]' : 'text-[#EAE4D7]'
            }`}
            aria-hidden="true"
          />
          <span className="text-[11px] font-medium whitespace-nowrap truncate max-w-full">
            More
          </span>
          {isSecondaryActive && !moreOpen && (
            <span className="absolute top-1.5 right-2 w-2 h-2 rounded-full bg-[#E5C158]" />
          )}
        </button>
      </div>
    </nav>
  );
};
