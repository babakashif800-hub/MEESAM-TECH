import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { ImageSegmenter } from '@mediapipe/tasks-vision';
import {
  Crosshair,
  Loader2,
  Pause,
  Play,
  Redo2,
  RotateCcw,
  RotateCw,
  Undo2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  AspectRatioPreset,
  AudioLayer,
  BgRemovalSettings,
  ChromaKeySettings,
  EditorPanelMode,
  FrameFitMode,
  MaskSettings,
  MotionTrack,
  OverlayLayer,
  PreviewScope,
  StabilizationSettings,
  TextOverlay,
  TimelineSegment,
  TransformKeyframe,
  VideoAdjustments,
  VideoAsset,
  VideoEffectLayer,
} from '../types/editor';
import { getBgSegmenter, renderSegmentedFrame } from '../utils/bgRemover';
import { renderChromaKeyFrame } from '../utils/chromaKey';
import { applyVideoEffectsToCanvas, EffectsRenderPool } from '../utils/effectsEngine';
import { buildCssFilter, getTargetAspectNumber } from '../utils/filters';
import { DEFAULT_TRANSFORM, evaluateKeyframes } from '../utils/keyframes';
import { resolveScriptRenderConfig } from '../utils/languages';
import { evaluateMotionTrack } from '../utils/motionTracker';
import { evaluateSegmentSpeedAtTime } from '../utils/speedCurve';
import { evaluateStabilization } from '../utils/stabilizer';
import {
  computeAudioFadeMultiplier,
  getTransitionProgress,
} from '../utils/transitions';
import { UiStrings } from '../i18n/translations';
import {
  clamp,
  formatTimecode,
  findSegmentAtTime,
  getActiveSegments,
  getEditedDuration,
  sourceTimeToEditedTime,
} from '../utils/time';

interface VideoPreviewProps {
  asset: VideoAsset;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  segments: TimelineSegment[];
  mainKeyframes: TransformKeyframe[];
  motionTracks: MotionTrack[];
  overlayLayers: OverlayLayer[];
  audioLayers: AudioLayer[];
  bgRemoval: BgRemovalSettings;
  chromaKey: ChromaKeySettings;
  stabilization: StabilizationSettings;
  mask: MaskSettings;
  adjustments: VideoAdjustments;
  videoEffects?: VideoEffectLayer[];
  textOverlays: TextOverlay[];
  selectedTextId?: string;
  aspectRatio: AspectRatioPreset;
  frameFit: FrameFitMode;
  currentTime: number;
  isPlaying: boolean;
  isMuted: boolean;
  previewScope: PreviewScope;
  panelMode: EditorPanelMode;
  pendingTrackTarget?: { x: number; y: number } | null;
  strings?: UiStrings;
  onTimeUpdate: (time: number) => void;
  onPlayingChange: (playing: boolean) => void;
  onTogglePlay: () => void;
  onStepTime: (delta: number) => void;
  onToggleMute: () => void;
  onChangePreviewScope: (scope: PreviewScope) => void;
  onPickTrackTarget?: (x: number, y: number) => void;
  onBgModelError?: (msg: string | null) => void;
  onSelectTextOverlay?: (id: string, isCaption?: boolean) => void;
  onUpdateTextOverlay?: (id: string, patch: Partial<TextOverlay>) => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
}

function buildMaskSvgDataUri(mask: MaskSettings): string | undefined {
  if (!mask || mask.shape === 'none') return undefined;
  const cx = 50 + mask.x;
  const cy = 50 + mask.y;
  const rw = Math.max(4, mask.width);
  const rh = Math.max(4, mask.height);
  const stdDev = Math.max(0, (mask.feather / 40) * 8);

  let shapeSvg = '';
  if (mask.shape === 'rect') {
    shapeSvg = `<rect x="${cx - rw / 2}" y="${cy - rh / 2}" width="${rw}" height="${rh}" fill="white"/>`;
  } else if (mask.shape === 'circle') {
    shapeSvg = `<ellipse cx="${cx}" cy="${cy}" rx="${rw / 2}" ry="${rh / 2}" fill="white"/>`;
  } else if (mask.shape === 'split') {
    shapeSvg = `<rect x="${cx - 120}" y="${cy - 200}" width="240" height="200" fill="white"/>`;
  } else if (mask.shape === 'linear') {
    shapeSvg = `<rect x="${cx - 120}" y="${cy - rh / 2}" width="240" height="${rh}" fill="white"/>`;
  }

  const filterDef =
    stdDev > 0.05
      ? `<filter id="f" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${stdDev.toFixed(2)}"/></filter>`
      : '';
  const filterAttr = stdDev > 0.05 ? ' filter="url(#f)"' : '';
  const bgFill = mask.invert ? 'white' : 'black';
  const shapeFill = mask.invert ? 'black' : 'white';
  const coloredShape = shapeSvg.replace('fill="white"', `fill="${shapeFill}"`);

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><defs>${filterDef}<mask id="m"><rect x="0" y="0" width="100" height="100" fill="${bgFill}"/><g transform="rotate(${mask.rotation} ${cx} ${cy})"${filterAttr}>${coloredShape}</g></mask></defs><rect x="0" y="0" width="100" height="100" fill="white" mask="url(#m)"/></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
}

export const VideoPreview: React.FC<VideoPreviewProps> = ({
  asset,
  videoRef,
  segments,
  mainKeyframes,
  motionTracks,
  overlayLayers,
  audioLayers,
  bgRemoval,
  chromaKey,
  stabilization,
  mask,
  adjustments,
  videoEffects = [],
  textOverlays,
  selectedTextId,
  aspectRatio,
  frameFit,
  currentTime,
  isPlaying,
  isMuted,
  previewScope,
  panelMode,
  pendingTrackTarget,
  strings,
  onTimeUpdate,
  onPlayingChange,
  onTogglePlay,
  onStepTime,
  onToggleMute,
  onChangePreviewScope,
  onPickTrackTarget,
  onBgModelError,
  onSelectTextOverlay,
  onUpdateTextOverlay,
  canUndo = false,
  canRedo = false,
  onUndo,
  onRedo,
}) => {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const segCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const effectsCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const effectsPoolRef = useRef<EffectsRenderPool | null>(null);
  const photoRef = useRef<HTMLImageElement | null>(null);
  const bgSegmenterRef = useRef<ImageSegmenter | null>(null);
  const bgImgRef = useRef<HTMLImageElement | null>(null);
  const chromaImgRef = useRef<HTMLImageElement | null>(null);
  const chromaVidRef = useRef<HTMLVideoElement | null>(null);
  const overlayVideoRefs = useRef<Record<string, HTMLVideoElement | null>>({});
  const audioLayerRefs = useRef<Record<string, HTMLAudioElement | null>>({});
  const photoTimeRef = useRef<number>(currentTime);
  const [mediaReadyTick, setMediaReadyTick] = useState(0);
  const textDragRef = useRef<{
    mode: 'move' | 'resize';
    id: string;
    startClientX: number;
    startClientY: number;
    startX: number;
    startY: number;
    startScale: number;
  } | null>(null);

  const [bgLoading, setBgLoading] = useState(false);

  const isPhoto = asset.mediaKind === 'image';
  const activeSegments = getActiveSegments(segments);
  const editedDuration = getEditedDuration(segments);
  const cssFilter = buildCssFilter(adjustments);

  useEffect(() => {
    photoTimeRef.current = currentTime;
  }, [currentTime]);

  // Load custom backdrop image for AI BG removal
  useEffect(() => {
    if (bgRemoval.mode === 'image' && bgRemoval.bgImageUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = bgRemoval.bgImageUrl;
      bgImgRef.current = img;
    } else {
      bgImgRef.current = null;
    }
  }, [bgRemoval.mode, bgRemoval.bgImageUrl]);

  // Load custom backdrop image for Chroma Key
  useEffect(() => {
    if (chromaKey.enabled && chromaKey.bgMode === 'image' && chromaKey.bgImageUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = chromaKey.bgImageUrl;
      chromaImgRef.current = img;
    } else {
      chromaImgRef.current = null;
    }
  }, [chromaKey.enabled, chromaKey.bgMode, chromaKey.bgImageUrl]);

  // Sync Chroma Key backdrop video element when bgMode === 'video'
  useEffect(() => {
    const vid = chromaVidRef.current;
    if (!vid || !chromaKey.enabled || chromaKey.bgMode !== 'video' || !chromaKey.bgVideoUrl) {
      return;
    }
    const target = currentTime % Math.max(0.2, vid.duration || 5);
    if (Math.abs(vid.currentTime - target) > 0.25) {
      vid.currentTime = Math.max(0, target);
    }
    if (isPlaying && vid.paused) {
      vid.play().catch(() => {});
    } else if (!isPlaying && !vid.paused) {
      vid.pause();
    }
  }, [chromaKey.enabled, chromaKey.bgMode, chromaKey.bgVideoUrl, currentTime, isPlaying]);

  // Lazy-load MediaPipe SelfieSegmenter model when AI BG removal is turned on (and Chroma Key is off)
  useEffect(() => {
    if (chromaKey.enabled || bgRemoval.mode === 'off') {
      setBgLoading(false);
      return;
    }
    if (bgSegmenterRef.current) return;

    let cancelled = false;
    setBgLoading(true);
    onBgModelError?.(null);

    getBgSegmenter()
      .then((segmenter) => {
        if (cancelled) return;
        bgSegmenterRef.current = segmenter;
        setBgLoading(false);
      })
      .catch((err) => {
        if (cancelled) return;
        setBgLoading(false);
        onBgModelError?.(
          err instanceof Error ? err.message : 'Unable to load AI background remover.'
        );
      });

    return () => {
      cancelled = true;
    };
  }, [bgRemoval.mode, chromaKey.enabled, onBgModelError]);

  // Render live Chroma Key or AI Segmented Canvas frames
  const useEffectCanvas = chromaKey.enabled || bgRemoval.mode !== 'off';
  useEffect(() => {
    if (!useEffectCanvas) return;
    const sourceEl: HTMLVideoElement | HTMLImageElement | null = isPhoto
      ? photoRef.current
      : videoRef.current;
    const canvas = segCanvasRef.current;
    if (!sourceEl || !canvas) return;

    const targetW = Math.min(640, asset.width || 640);
    const targetH = Math.max(
      180,
      Math.round((targetW / Math.max(1, asset.width)) * (asset.height || 360))
    );
    if (canvas.width !== targetW) canvas.width = targetW;
    if (canvas.height !== targetH) canvas.height = targetH;

    let cancelled = false;
    let rafId = 0;

    const drawCurrent = () => {
      if (cancelled) return;
      const isSourceReady =
        sourceEl instanceof HTMLImageElement
          ? sourceEl.complete && sourceEl.naturalWidth > 0
          : sourceEl.readyState >= 2;
      if (isSourceReady) {
        if (chromaKey.enabled) {
          renderChromaKeyFrame(
            sourceEl,
            canvas,
            chromaKey,
            chromaImgRef.current,
            chromaVidRef.current
          );
        } else if (bgSegmenterRef.current && bgRemoval.mode !== 'off') {
          renderSegmentedFrame(
            bgSegmenterRef.current,
            sourceEl,
            canvas,
            bgRemoval,
            bgImgRef.current,
            320
          );
        }
      }
      if (isPlaying && !isPhoto) {
        rafId = requestAnimationFrame(drawCurrent);
      }
    };

    drawCurrent();
    return () => {
      cancelled = true;
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [
    asset.height,
    asset.width,
    bgLoading,
    bgRemoval,
    chromaKey,
    currentTime,
    isPhoto,
    isPlaying,
    mediaReadyTick,
    useEffectCanvas,
    videoRef,
  ]);

  const stageAspect = getTargetAspectNumber(aspectRatio, asset.width, asset.height);
  const mainTf = evaluateKeyframes(mainKeyframes, currentTime, DEFAULT_TRANSFORM);
  const stabTf = evaluateStabilization(stabilization, currentTime);
  const combinedX = mainTf.x + stabTf.x;
  const combinedY = mainTf.y + stabTf.y;
  const combinedScale = mainTf.scale * stabTf.scale;

  const activeEffectsAtTime = useMemo(() => {
    if (previewScope !== 'edited') return [];
    return videoEffects.filter(
      (fx) =>
        fx.enabled &&
        fx.intensity > 0 &&
        currentTime >= fx.startTime - 0.02 &&
        currentTime <= fx.endTime + 0.02
    );
  }, [currentTime, previewScope, videoEffects]);

  const showEffectsCanvas = previewScope === 'edited' && activeEffectsAtTime.length > 0;
  const isTransparentStageBg =
    (chromaKey.enabled && chromaKey.bgMode === 'transparent') ||
    (!chromaKey.enabled && bgRemoval.mode === 'transparent');

  // Render real-time Video Effects canvas stage (respects playhead, keyframe/stabilization transforms, color filters, chroma/BG removal)
  useEffect(() => {
    if (!showEffectsCanvas) return;
    const effCanvas = effectsCanvasRef.current;
    if (!effCanvas) return;

    if (!effectsPoolRef.current) {
      effectsPoolRef.current = new EffectsRenderPool();
    }
    const pool = effectsPoolRef.current;

    const maxDim = isPlaying ? 760 : 1080;
    const targetW =
      stageAspect >= 1
        ? maxDim
        : Math.max(180, Math.round(maxDim * stageAspect));
    const targetH =
      stageAspect >= 1
        ? Math.max(180, Math.round(maxDim / Math.max(0.1, stageAspect)))
        : maxDim;

    if (effCanvas.width !== targetW) effCanvas.width = targetW;
    if (effCanvas.height !== targetH) effCanvas.height = targetH;

    let cancelled = false;
    let rafId = 0;

    const drawEffectsFrame = () => {
      if (cancelled) return;
      const ctx = effCanvas.getContext('2d');
      if (!ctx) return;

      const t = isPhoto ? photoTimeRef.current : videoRef.current?.currentTime ?? currentTime;
      const useSegSource =
        chromaKey.enabled || (bgRemoval.mode !== 'off' && !bgLoading);
      const sourceEl: HTMLCanvasElement | HTMLImageElement | HTMLVideoElement | null =
        useSegSource
          ? segCanvasRef.current
          : isPhoto
          ? photoRef.current
          : videoRef.current;

      if (sourceEl) {
        let ready = false;
        let sw = asset.width || 1280;
        let sh = asset.height || 720;
        if (sourceEl instanceof HTMLCanvasElement) {
          ready = sourceEl.width > 0 && sourceEl.height > 0;
          sw = sourceEl.width;
          sh = sourceEl.height;
        } else if (sourceEl instanceof HTMLImageElement) {
          ready = sourceEl.complete && sourceEl.naturalWidth > 0;
          sw = sourceEl.naturalWidth || sw;
          sh = sourceEl.naturalHeight || sh;
        } else {
          ready = sourceEl.readyState >= 2;
          sw = sourceEl.videoWidth || sw;
          sh = sourceEl.videoHeight || sh;
        }

        if (ready) {
          ctx.clearRect(0, 0, targetW, targetH);
          if (!isTransparentStageBg) {
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, targetW, targetH);
          }

          const srcRatio = sw / Math.max(1, sh);
          const dstRatio = targetW / Math.max(1, targetH);
          const useCover = aspectRatio !== 'original' && frameFit === 'cover';
          let drawW = targetW;
          let drawH = targetH;
          if (useCover ? srcRatio > dstRatio : srcRatio < dstRatio) {
            drawH = targetH;
            drawW = drawH * srcRatio;
          } else {
            drawW = targetW;
            drawH = drawW / Math.max(0.01, srcRatio);
          }

          const tf = evaluateKeyframes(mainKeyframes, t, DEFAULT_TRANSFORM);
          const st = evaluateStabilization(stabilization, t);
          const cx = targetW / 2 + ((tf.x + st.x) / 100) * targetW;
          const cy = targetH / 2 + ((tf.y + st.y) / 100) * targetH;
          const sc = tf.scale * st.scale;

          ctx.save();
          ctx.globalAlpha = tf.opacity;
          ctx.translate(cx, cy);
          ctx.rotate((tf.rotation * Math.PI) / 180);
          ctx.scale(sc, sc);
          ctx.filter = cssFilter || 'none';
          ctx.drawImage(sourceEl, -drawW / 2, -drawH / 2, drawW, drawH);
          ctx.filter = 'none';
          ctx.restore();

          const liveEffects = videoEffects.filter(
            (fx) =>
              fx.enabled &&
              fx.intensity > 0 &&
              t >= fx.startTime - 0.02 &&
              t <= fx.endTime + 0.02
          );
          if (liveEffects.length > 0) {
            applyVideoEffectsToCanvas(
              effCanvas,
              liveEffects,
              t,
              pool,
              isPlaying ? 560 : 860
            );
          }
        }
      }

      if (isPlaying) {
        rafId = requestAnimationFrame(drawEffectsFrame);
      }
    };

    drawEffectsFrame();
    return () => {
      cancelled = true;
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [
    aspectRatio,
    asset.height,
    asset.width,
    bgLoading,
    bgRemoval.mode,
    chromaKey.enabled,
    cssFilter,
    currentTime,
    frameFit,
    isPhoto,
    isPlaying,
    isTransparentStageBg,
    mainKeyframes,
    mediaReadyTick,
    showEffectsCanvas,
    stabilization,
    stageAspect,
    videoEffects,
    videoRef,
  ]);

  // Sync mute, per-clip volume, and per-clip speed (including Speed Curve!) in real time
  useEffect(() => {
    if (isPhoto) return;
    const vid = videoRef.current;
    if (!vid) return;

    const currentSeg = findSegmentAtTime(currentTime, segments);
    if (previewScope === 'edited' && currentSeg && !currentSeg.deleted) {
      const targetSpeed = evaluateSegmentSpeedAtTime(currentSeg, currentTime);
      if (Math.abs(vid.playbackRate - targetSpeed) > 0.02) {
        try {
          vid.playbackRate = clamp(targetSpeed, 0.25, 4.0);
        } catch {
          // Ignore unsupported rate
        }
      }
      const clipMuted = isMuted || Boolean(currentSeg.meta?.muted);
      const clipSpan = Math.max(0.01, currentSeg.end - currentSeg.start);
      const fadeMult = computeAudioFadeMultiplier(
        currentTime - currentSeg.start,
        clipSpan,
        currentSeg.meta?.fadeInSec,
        currentSeg.meta?.fadeOutSec
      );
      vid.muted = clipMuted;
      vid.volume = clipMuted
        ? 0
        : clamp((currentSeg.meta?.volume ?? 1) * fadeMult, 0, 1);
    } else {
      if (Math.abs(vid.playbackRate - 1.0) > 0.01) {
        try {
          vid.playbackRate = 1.0;
        } catch {
          // Ignore
        }
      }
      vid.muted = isMuted;
      vid.volume = isMuted ? 0 : 1;
    }
  }, [currentTime, isMuted, isPhoto, previewScope, segments, videoRef]);

  // Sync V2 overlay videos & A1 extra audio tracks to playhead & play/pause state
  useEffect(() => {
    for (const layer of overlayLayers) {
      if (layer.kind !== 'video') continue;
      const ovVid = overlayVideoRefs.current[layer.id];
      if (!ovVid) continue;
      const inRange =
        currentTime >= layer.startTime - 0.02 && currentTime <= layer.endTime + 0.02;
      ovVid.muted = isMuted || layer.muted;
      ovVid.volume = isMuted || layer.muted ? 0 : layer.volume;

      if (inRange) {
        const target = (currentTime - layer.startTime) % Math.max(0.1, layer.duration);
        if (Math.abs(ovVid.currentTime - target) > 0.25) {
          ovVid.currentTime = Math.max(0, target);
        }
        if (isPlaying && ovVid.paused) {
          ovVid.play().catch(() => {});
        } else if (!isPlaying && !ovVid.paused) {
          ovVid.pause();
        }
      } else if (!ovVid.paused) {
        ovVid.pause();
      }
    }

    for (const aLayer of audioLayers) {
      const aud = audioLayerRefs.current[aLayer.id];
      if (!aud) continue;
      const inRange =
        currentTime >= aLayer.startTime - 0.02 && currentTime <= aLayer.endTime + 0.02;
      const span = Math.max(0.01, aLayer.endTime - aLayer.startTime);
      const fadeMult = inRange
        ? computeAudioFadeMultiplier(
            currentTime - aLayer.startTime,
            span,
            aLayer.fadeInSec,
            aLayer.fadeOutSec
          )
        : 1;
      aud.muted = isMuted || aLayer.muted;
      aud.volume =
        isMuted || aLayer.muted ? 0 : clamp(aLayer.volume * fadeMult, 0, 1);

      if (inRange) {
        const sourceOffset = Math.max(0, aLayer.sourceOffsetSec ?? 0);
        const target =
          (sourceOffset + (currentTime - aLayer.startTime)) % Math.max(0.1, aLayer.duration);
        if (Math.abs(aud.currentTime - target) > 0.22) {
          aud.currentTime = Math.max(0, target);
        }
        if (isPlaying && aud.paused) {
          aud.play().catch(() => {});
        } else if (!isPlaying && !aud.paused) {
          aud.pause();
        }
      } else if (!aud.paused) {
        aud.pause();
      }
    }
  }, [audioLayers, currentTime, isMuted, isPlaying, overlayLayers]);

  // Smooth RAF playback tracker for both photo timelines and video clips
  useEffect(() => {
    if (!isPlaying) return;
    let rafId = 0;

    if (isPhoto) {
      let lastNow = performance.now();
      const tickPhoto = (now: number) => {
        const dt = Math.min(0.1, Math.max(0, (now - lastNow) / 1000));
        lastNow = now;
        let t = photoTimeRef.current;

        if (previewScope === 'edited' && activeSegments.length > 0) {
          let inside = activeSegments.find((s) => t >= s.start - 0.04 && t < s.end - 0.02);
          if (!inside) {
            const next = activeSegments.find((s) => s.start > t - 0.04);
            if (next) {
              t = next.start;
              inside = next;
            } else {
              const firstStart = activeSegments[0].start;
              photoTimeRef.current = firstStart;
              onTimeUpdate(firstStart);
              onPlayingChange(false);
              return;
            }
          }
          t += dt * evaluateSegmentSpeedAtTime(inside, t);
          if (t >= inside.end) {
            const nextAfter = activeSegments.find(
              (s) => s.start >= inside!.end - 0.02 && s.id !== inside!.id
            );
            if (nextAfter) {
              t = nextAfter.start;
            } else {
              const firstStart = activeSegments[0].start;
              photoTimeRef.current = firstStart;
              onTimeUpdate(firstStart);
              onPlayingChange(false);
              return;
            }
          }
        } else {
          t += dt;
          if (t >= asset.duration) {
            photoTimeRef.current = 0;
            onTimeUpdate(0);
            onPlayingChange(false);
            return;
          }
        }

        photoTimeRef.current = t;
        onTimeUpdate(t);
        rafId = requestAnimationFrame(tickPhoto);
      };

      rafId = requestAnimationFrame(tickPhoto);
      return () => cancelAnimationFrame(rafId);
    }

    const tick = () => {
      const vid = videoRef.current;
      if (!vid) return;

      const t = vid.currentTime;
      onTimeUpdate(t);

      if (previewScope === 'edited' && activeSegments.length > 0) {
        const inside = activeSegments.find((s) => t >= s.start - 0.04 && t < s.end - 0.03);
        if (!inside) {
          const next = activeSegments.find((s) => s.start > t - 0.04);
          if (next) {
            vid.currentTime = next.start;
            try {
              vid.playbackRate = clamp(evaluateSegmentSpeedAtTime(next, next.start), 0.25, 4.0);
            } catch {
              // Ignore
            }
            onTimeUpdate(next.start);
          } else {
            vid.pause();
            const firstStart = activeSegments[0].start;
            vid.currentTime = firstStart;
            onTimeUpdate(firstStart);
            onPlayingChange(false);
            return;
          }
        } else {
          const segSpeed = clamp(evaluateSegmentSpeedAtTime(inside, t), 0.25, 4.0);
          if (Math.abs(vid.playbackRate - segSpeed) > 0.02) {
            try {
              vid.playbackRate = segSpeed;
            } catch {
              // Ignore
            }
          }
          const clipMuted = isMuted || Boolean(inside.meta?.muted);
          const clipSpan = Math.max(0.01, inside.end - inside.start);
          const fadeMult = computeAudioFadeMultiplier(
            t - inside.start,
            clipSpan,
            inside.meta?.fadeInSec,
            inside.meta?.fadeOutSec
          );
          vid.muted = clipMuted;
          vid.volume = clipMuted
            ? 0
            : clamp((inside.meta?.volume ?? 1) * fadeMult, 0, 1);
        }
      }

      if (!vid.paused && !vid.ended) {
        rafId = requestAnimationFrame(tick);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [
    asset.duration,
    isMuted,
    isPhoto,
    isPlaying,
    previewScope,
    activeSegments,
    videoRef,
    onTimeUpdate,
    onPlayingChange,
  ]);

  const displayedTime =
    previewScope === 'edited'
      ? sourceTimeToEditedTime(currentTime, segments)
      : currentTime;
  const displayedTotal =
    previewScope === 'edited' ? editedDuration : asset.duration;

  const activeTexts = textOverlays.filter(
    (item) =>
      item.text.trim().length > 0 &&
      currentTime >= item.startTime - 0.02 &&
      currentTime <= item.endTime + 0.02
  );

  const showEffectCanvas =
    chromaKey.enabled || (bgRemoval.mode !== 'off' && !bgLoading);
  const hideUnderlyingMainMedia = showEffectCanvas || showEffectsCanvas;
  const hideSegCanvas = showEffectsCanvas;
  const showCheckerboard =
    (chromaKey.enabled && chromaKey.bgMode === 'transparent') ||
    (!chromaKey.enabled && bgRemoval.mode === 'transparent') ||
    mask.shape !== 'none';

  const maskDataUri = useMemo(() => buildMaskSvgDataUri(mask), [mask]);

  const activeSeg = findSegmentAtTime(currentTime, segments);
  const activeTransition =
    previewScope === 'edited' && activeSeg && !activeSeg.deleted
      ? getTransitionProgress(activeSeg, currentTime)
      : null;

  const transitionWrapperStyle: React.CSSProperties = useMemo(() => {
    if (!activeTransition) return {};
    const p = clamp(activeTransition.progress, 0, 1);
    switch (activeTransition.type) {
      case 'fade':
      case 'dissolve':
        return { opacity: p };
      case 'wipe-left':
        return { clipPath: `inset(0 ${((1 - p) * 100).toFixed(2)}% 0 0)` };
      case 'wipe-right':
        return { clipPath: `inset(0 0 0 ${((1 - p) * 100).toFixed(2)}%)` };
      case 'slide-up':
        return {
          transform: `translateY(${((1 - p) * 18).toFixed(2)}%)`,
          opacity: 0.25 + 0.75 * p,
        };
      case 'zoom':
        return {
          transform: `scale(${(0.82 + 0.18 * p).toFixed(4)})`,
          opacity: 0.25 + 0.75 * p,
        };
      default:
        return {};
    }
  }, [activeTransition]);

  const handleStageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (panelMode === 'motion' && onPickTrackTarget && stageRef.current) {
      e.stopPropagation();
      const rect = stageRef.current.getBoundingClientRect();
      const xPct = clamp(((e.clientX - rect.left) / Math.max(1, rect.width)) * 100 - 50, -48, 48);
      const yPct = clamp(((e.clientY - rect.top) / Math.max(1, rect.height)) * 100 - 50, -48, 48);
      onPickTrackTarget(Number(xPct.toFixed(1)), Number(yPct.toFixed(1)));
      return;
    }
    onTogglePlay();
  };

  return (
    <section
      aria-label="Video preview"
      className="flex-1 min-h-0 flex flex-col bg-[#050608]"
    >
      {/* Hidden A1 Audio Track elements synced to playhead */}
      {audioLayers.map((aLayer) => (
        <audio
          key={aLayer.id}
          ref={(el) => {
            audioLayerRefs.current[aLayer.id] = el;
          }}
          src={aLayer.url}
          preload="auto"
          className="hidden"
        />
      ))}

      {/* Hidden Chroma Key Backdrop Video if selected */}
      {chromaKey.enabled && chromaKey.bgMode === 'video' && chromaKey.bgVideoUrl && (
        <video
          ref={chromaVidRef}
          src={chromaKey.bgVideoUrl}
          muted
          loop
          playsInline
          preload="auto"
          crossOrigin="anonymous"
          className="hidden"
        />
      )}

      {/* Centered video viewport */}
      <div
        onClick={handleStageClick}
        className={`relative flex-1 min-h-0 w-full p-2 sm:p-4 select-none overflow-hidden ${
          panelMode === 'motion' ? 'cursor-crosshair' : 'cursor-pointer'
        }`}
      >
        <div
          style={{ containerType: 'size' }}
          className="w-full h-full flex items-center justify-center"
        >
          <div
            ref={stageRef}
            style={{
              width: `min(100cqw, calc(100cqh * ${stageAspect}))`,
              height: `min(100cqh, calc(100cqw / ${stageAspect}))`,
              backgroundImage: showCheckerboard
                ? 'linear-gradient(45deg, #161922 25%, transparent 25%), linear-gradient(-45deg, #161922 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #161922 75%), linear-gradient(-45deg, transparent 75%, #161922 75%)'
                : undefined,
              backgroundSize: showCheckerboard ? '20px 20px' : undefined,
              backgroundPosition: showCheckerboard
                ? '0 0, 0 10px, 10px -10px, -10px 0px'
                : undefined,
            }}
            className="relative flex items-center justify-center bg-black rounded-lg overflow-hidden ring-1 ring-[#D4AF37]/20 shadow-2xl"
          >
            {/* V1 Masked Video / Photo Layer Wrapper */}
            <div
              style={{
                maskImage: maskDataUri,
                WebkitMaskImage: maskDataUri,
                maskSize: '100% 100%',
                WebkitMaskSize: '100% 100%',
                maskRepeat: 'no-repeat',
                WebkitMaskRepeat: 'no-repeat',
                ...transitionWrapperStyle,
              }}
              className="relative w-full h-full flex items-center justify-center"
            >
              {isPhoto ? (
                <img
                  ref={photoRef}
                  src={asset.url}
                  alt={asset.name}
                  draggable={false}
                  onLoad={() => setMediaReadyTick((n) => n + 1)}
                  style={{
                    filter: cssFilter,
                    opacity: hideUnderlyingMainMedia ? 0 : mainTf.opacity,
                    transform: `translate(${combinedX}%, ${combinedY}%) scale(${combinedScale}) rotate(${mainTf.rotation}deg)`,
                  }}
                  className={`w-full h-full transition-none ${
                    aspectRatio !== 'original' && frameFit === 'cover'
                      ? 'object-cover'
                      : 'object-contain'
                  }`}
                />
              ) : (
                <video
                  ref={videoRef}
                  src={asset.url}
                  playsInline
                  preload="auto"
                  muted={isMuted}
                  onLoadedData={() => setMediaReadyTick((n) => n + 1)}
                  onSeeked={() => setMediaReadyTick((n) => n + 1)}
                  style={{
                    filter: cssFilter,
                    opacity: hideUnderlyingMainMedia ? 0 : mainTf.opacity,
                    transform: `translate(${combinedX}%, ${combinedY}%) scale(${combinedScale}) rotate(${mainTf.rotation}deg)`,
                  }}
                  onPlay={() => onPlayingChange(true)}
                  onPause={() => onPlayingChange(false)}
                  onEnded={() => {
                    onPlayingChange(false);
                    if (videoRef.current) {
                      const startTarget =
                        previewScope === 'edited' && activeSegments[0]
                          ? activeSegments[0].start
                          : 0;
                      videoRef.current.currentTime = startTarget;
                      onTimeUpdate(startTarget);
                    }
                  }}
                  onTimeUpdate={(e) => {
                    if (!isPlaying) {
                      onTimeUpdate(e.currentTarget.currentTime);
                    }
                  }}
                  className={`w-full h-full transition-none ${
                    aspectRatio !== 'original' && frameFit === 'cover'
                      ? 'object-cover'
                      : 'object-contain'
                  }`}
                />
              )}

              {/* Live Chroma Key / AI Segmented Foreground Canvas */}
              {useEffectCanvas && (
                <canvas
                  ref={segCanvasRef}
                  style={{
                    filter: cssFilter,
                    opacity: showEffectCanvas && !hideSegCanvas ? mainTf.opacity : 0,
                    transform: `translate(${combinedX}%, ${combinedY}%) scale(${combinedScale}) rotate(${mainTf.rotation}deg)`,
                  }}
                  className={`pointer-events-none absolute inset-0 w-full h-full ${
                    aspectRatio !== 'original' && frameFit === 'cover'
                      ? 'object-cover'
                      : 'object-contain'
                  }`}
                />
              )}

              {/* Live Video Effects Stage Canvas */}
              {showEffectsCanvas && (
                <canvas
                  ref={effectsCanvasRef}
                  className="pointer-events-none absolute inset-0 w-full h-full object-contain"
                />
              )}
            </div>

            {/* Interactive Mask Outline Helper while Mask tool is open */}
            {panelMode === 'mask' && mask.shape !== 'none' && (
              <div
                style={{
                  left: `${50 + mask.x}%`,
                  top: `${50 + mask.y}%`,
                  width:
                    mask.shape === 'split' || mask.shape === 'linear' ? '100%' : `${mask.width}%`,
                  height:
                    mask.shape === 'split' ? '2px' : `${mask.height}%`,
                  transform: `translate(-50%, -50%) rotate(${mask.rotation}deg)`,
                  borderRadius: mask.shape === 'circle' ? '9999px' : '4px',
                }}
                className="pointer-events-none absolute border border-dashed border-amber-400/80 shadow-[0_0_0_1px_rgba(0,0,0,0.6)] z-20"
              />
            )}

            {/* Interactive Motion Tracking Target Reticle & Active Track Markers */}
            {panelMode === 'motion' && (
              <>
                {pendingTrackTarget && (
                  <div
                    style={{
                      left: `${50 + pendingTrackTarget.x}%`,
                      top: `${50 + pendingTrackTarget.y}%`,
                    }}
                    className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 z-30 flex flex-col items-center"
                  >
                    <div className="w-9 h-9 rounded-full border-2 border-amber-400 bg-amber-400/15 flex items-center justify-center shadow-lg">
                      <Crosshair className="w-4 h-4 text-amber-300" aria-hidden="true" />
                    </div>
                  </div>
                )}

                {motionTracks.map((tr) => {
                  const pt = evaluateMotionTrack(tr, currentTime);
                  if (!pt) return null;
                  return (
                    <div
                      key={tr.id}
                      style={{
                        left: `${50 + pt.x}%`,
                        top: `${50 + pt.y}%`,
                      }}
                      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center"
                    >
                      <div className="w-5 h-5 rounded-full border-2 border-emerald-400 bg-emerald-400/20" />
                      <span className="mt-0.5 px-1.5 py-0.2 rounded bg-black/75 text-[9px] text-emerald-200 whitespace-nowrap">
                        {tr.label}
                      </span>
                    </div>
                  );
                })}
              </>
            )}

            {/* V2 Overlay / Picture-in-Picture Layers (with Motion Track follow!) */}
            {overlayLayers.map((layer) => {
              const visible =
                currentTime >= layer.startTime - 0.02 &&
                currentTime <= layer.endTime + 0.02;
              const tf = evaluateKeyframes(layer.keyframes, currentTime, {
                x: layer.x,
                y: layer.y,
                scale: layer.scale,
                rotation: layer.rotation,
                opacity: layer.opacity,
              });
              const track = layer.trackId
                ? motionTracks.find((m) => m.id === layer.trackId)
                : undefined;
              const tracked = evaluateMotionTrack(track, currentTime);
              const posX = tracked && track ? tf.x + (tracked.x - track.anchorX) : tf.x;
              const posY = tracked && track ? tf.y + (tracked.y - track.anchorY) : tf.y;

              return (
                <div
                  key={layer.id}
                  style={{
                    left: `${50 + posX}%`,
                    top: `${50 + posY}%`,
                    opacity: visible ? tf.opacity : 0,
                    transform: `translate(-50%, -50%) scale(${tf.scale}) rotate(${tf.rotation}deg)`,
                    height: '48%',
                  }}
                  className={`pointer-events-none absolute flex items-center justify-center ${
                    visible ? '' : 'hidden'
                  }`}
                >
                  {layer.kind === 'image' ? (
                    <img
                      src={layer.url}
                      alt={layer.name}
                      className="h-full w-auto max-w-none rounded-md shadow-lg object-contain"
                    />
                  ) : (
                    <video
                      ref={(el) => {
                        overlayVideoRefs.current[layer.id] = el;
                      }}
                      src={layer.url}
                      playsInline
                      preload="auto"
                      className="h-full w-auto max-w-none rounded-md shadow-lg object-contain"
                    />
                  )}
                </div>
              );
            })}

            {/* AI BG Model Loading Indicator */}
            {bgLoading && (
              <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg bg-black/85 border border-[#D4AF37]/30 text-xs text-[#F5F2EA] flex items-center gap-2 z-20">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E5C158]" aria-hidden="true" />
                <span>Loading AI BG Remover...</span>
              </div>
            )}

            {/* Live Text Overlays, Stickers & Auto Captions (Tap to select, Drag to move & Resize on video) */}
            {activeTexts.map((item) => {
              const track = item.trackId
                ? motionTracks.find((m) => m.id === item.trackId)
                : undefined;
              const tracked = evaluateMotionTrack(track, currentTime);
              const isSelected = item.id === selectedTextId;
              const canEditDirectly = panelMode !== 'motion' && Boolean(onUpdateTextOverlay);
              const itemScale = clamp(item.scale ?? 1, 0.5, 2.5);
              const itemOpacity = clamp(item.opacity ?? 1, 0.15, 1);

              const defaultY =
                item.position === 'top' ? -36 : item.position === 'bottom' ? 36 : 0;
              const hasFreeCoords =
                typeof item.x === 'number' || typeof item.y === 'number' || Boolean(tracked);

              const baseX = typeof item.x === 'number' ? item.x : track ? track.anchorX : 0;
              const baseY =
                typeof item.y === 'number' ? item.y : track ? track.anchorY : defaultY;
              const posX = tracked && track ? baseX + (tracked.x - track.anchorX) : baseX;
              const posY = tracked && track ? baseY + (tracked.y - track.anchorY) : baseY;

              const scriptCfg = resolveScriptRenderConfig(
                item.text,
                item.lang,
                item.dir ?? 'auto'
              );
              const stickerSize =
                item.size === 'sm'
                  ? 'text-2xl sm:text-3xl'
                  : item.size === 'lg'
                  ? 'text-4xl sm:text-6xl'
                  : 'text-3xl sm:text-5xl';
              const textSize =
                item.size === 'sm'
                  ? 'text-xs sm:text-sm'
                  : item.size === 'lg'
                  ? 'text-lg sm:text-2xl'
                  : 'text-sm sm:text-lg';
              const textColor =
                item.color || (item.style === 'pop' ? '#facc15' : '#ffffff');

              const styleClass =
                item.isSticker
                  ? 'drop-shadow-[0_3px_10px_rgba(0,0,0,0.75)] select-none'
                  : item.style === 'subtitle-bar'
                  ? hasFreeCoords
                    ? 'bg-[#080a10]/85 px-4 py-1.5 rounded-lg'
                    : 'w-full bg-[#080a10]/85 px-4 py-1.5'
                  : item.style === 'boxed'
                  ? 'bg-black/75 px-3 py-1 rounded-lg'
                  : item.style === 'pop'
                  ? '[text-shadow:_-2px_-2px_0_#000,_2px_-2px_0_#000,_-2px_2px_0_#000,_2px_2px_0_#000,_0_3px_10px_rgba(0,0,0,0.9)] tracking-wide'
                  : item.style === 'outline'
                  ? '[text-shadow:_-1.5px_-1.5px_0_#000,_1.5px_-1.5px_0_#000,_-1.5px_1.5px_0_#000,_1.5px_1.5px_0_#000]'
                  : '[text-shadow:0_2px_8px_rgba(0,0,0,0.85)]';

              const handleTextPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
                if (!canEditDirectly) return;
                e.stopPropagation();
                onSelectTextOverlay?.(item.id, item.isCaption);
                try {
                  e.currentTarget.setPointerCapture(e.pointerId);
                } catch {
                  // Ignore capture errors
                }
                textDragRef.current = {
                  mode: 'move',
                  id: item.id,
                  startClientX: e.clientX,
                  startClientY: e.clientY,
                  startX: baseX,
                  startY: baseY,
                  startScale: itemScale,
                };
              };

              const handleTextPointerMove = (e: React.PointerEvent<HTMLElement>) => {
                const drag = textDragRef.current;
                if (!drag || drag.id !== item.id || !stageRef.current || !onUpdateTextOverlay) return;
                e.stopPropagation();
                if (drag.mode === 'move') {
                  const rect = stageRef.current.getBoundingClientRect();
                  const dxPct = ((e.clientX - drag.startClientX) / Math.max(1, rect.width)) * 100;
                  const dyPct = ((e.clientY - drag.startClientY) / Math.max(1, rect.height)) * 100;
                  const nextX = clamp(drag.startX + dxPct, -46, 46);
                  const nextY = clamp(drag.startY + dyPct, -46, 46);
                  onUpdateTextOverlay(item.id, {
                    x: Number(nextX.toFixed(1)),
                    y: Number(nextY.toFixed(1)),
                  });
                } else if (drag.mode === 'resize') {
                  const delta = (e.clientX - drag.startClientX + (e.clientY - drag.startClientY)) / 120;
                  const nextScale = clamp(drag.startScale + delta, 0.5, 2.5);
                  onUpdateTextOverlay(item.id, {
                    scale: Number(nextScale.toFixed(2)),
                  });
                }
              };

              const handleTextPointerUp = (e: React.PointerEvent<HTMLElement>) => {
                if (textDragRef.current?.id === item.id) {
                  e.stopPropagation();
                  try {
                    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
                      e.currentTarget.releasePointerCapture(e.pointerId);
                    }
                  } catch {
                    // Ignore
                  }
                  textDragRef.current = null;
                }
              };

              const handleResizeHandleDown = (e: React.PointerEvent<HTMLButtonElement>) => {
                if (!canEditDirectly) return;
                e.stopPropagation();
                e.preventDefault();
                try {
                  e.currentTarget.setPointerCapture(e.pointerId);
                } catch {
                  // Ignore
                }
                textDragRef.current = {
                  mode: 'resize',
                  id: item.id,
                  startClientX: e.clientX,
                  startClientY: e.clientY,
                  startX: baseX,
                  startY: baseY,
                  startScale: itemScale,
                };
              };

              if (hasFreeCoords) {
                return (
                  <div
                    key={item.id}
                    dir={scriptCfg.dir}
                    lang={scriptCfg.langAttr}
                    onClick={(e) => e.stopPropagation()}
                    onPointerDown={handleTextPointerDown}
                    onPointerMove={handleTextPointerMove}
                    onPointerUp={handleTextPointerUp}
                    onPointerCancel={handleTextPointerUp}
                    style={{
                      left: `${50 + posX}%`,
                      top: `${50 + posY}%`,
                      transform: `translate(-50%, -50%) scale(${itemScale})`,
                      color: textColor,
                      opacity: itemOpacity,
                      fontFamily: scriptCfg.fontFamily,
                      unicodeBidi: 'plaintext',
                    }}
                    className={`absolute text-center font-bold whitespace-pre-wrap max-w-[90%] z-20 ${
                      canEditDirectly ? 'touch-none cursor-grab active:cursor-grabbing select-none' : 'pointer-events-none'
                    } ${
                      isSelected && canEditDirectly
                        ? 'ring-2 ring-[#E5C158] rounded-lg px-1.5 py-0.5'
                        : ''
                    } ${item.isSticker ? stickerSize : textSize}`}
                  >
                    <span className={styleClass}>{item.text}</span>
                    {isSelected && canEditDirectly && (
                      <button
                        type="button"
                        aria-label="Drag corner to resize text"
                        onPointerDown={handleResizeHandleDown}
                        onPointerMove={handleTextPointerMove}
                        onPointerUp={handleTextPointerUp}
                        onPointerCancel={handleTextPointerUp}
                        onClick={(e) => e.stopPropagation()}
                        className="absolute -bottom-3 -right-3 w-6 h-6 rounded-full bg-[#D4AF37] border-2 border-[#08090C] shadow-md flex items-center justify-center cursor-nwse-resize touch-none"
                      >
                        <span className="w-2 h-2 rounded-xs bg-[#08090C]" />
                      </button>
                    )}
                  </div>
                );
              }

              const posClass =
                item.position === 'top'
                  ? 'top-[10%]'
                  : item.position === 'bottom'
                  ? 'bottom-[8%]'
                  : 'top-1/2 -translate-y-1/2';

              return (
                <div
                  key={item.id}
                  dir={scriptCfg.dir}
                  lang={scriptCfg.langAttr}
                  onClick={(e) => e.stopPropagation()}
                  onPointerDown={handleTextPointerDown}
                  onPointerMove={handleTextPointerMove}
                  onPointerUp={handleTextPointerUp}
                  onPointerCancel={handleTextPointerUp}
                  style={{
                    color: textColor,
                    opacity: itemOpacity,
                    fontFamily: scriptCfg.fontFamily,
                    unicodeBidi: 'plaintext',
                    transform:
                      item.position === 'center'
                        ? `translateY(-50%) scale(${itemScale})`
                        : `scale(${itemScale})`,
                  }}
                  className={`absolute z-20 ${
                    item.style === 'subtitle-bar' ? 'left-0 right-0' : 'left-4 right-4'
                  } flex justify-center text-center font-bold leading-snug whitespace-pre-wrap ${posClass} ${
                    item.isSticker ? stickerSize : textSize
                  } ${
                    canEditDirectly ? 'touch-none cursor-grab active:cursor-grabbing select-none' : 'pointer-events-none'
                  }`}
                >
                  <div
                    className={`relative inline-flex justify-center ${
                      item.style === 'subtitle-bar' ? 'w-full' : ''
                    } ${
                      isSelected && canEditDirectly
                        ? 'ring-2 ring-[#E5C158] rounded-lg'
                        : ''
                    }`}
                  >
                    <span className={styleClass}>{item.text}</span>
                    {isSelected && canEditDirectly && (
                      <button
                        type="button"
                        aria-label="Drag corner to resize text"
                        onPointerDown={handleResizeHandleDown}
                        onPointerMove={handleTextPointerMove}
                        onPointerUp={handleTextPointerUp}
                        onPointerCancel={handleTextPointerUp}
                        onClick={(e) => e.stopPropagation()}
                        className="absolute -bottom-3 -right-3 w-6 h-6 rounded-full bg-[#D4AF37] border-2 border-[#08090C] shadow-md flex items-center justify-center cursor-nwse-resize touch-none"
                      >
                        <span className="w-2 h-2 rounded-xs bg-[#08090C]" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Subtle Play indicator when paused */}
        {!isPlaying && panelMode !== 'motion' && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-black/75 backdrop-blur-sm border border-[#A855F7]/55 flex items-center justify-center text-[#F3D778] shadow-[0_0_28px_rgba(124,58,237,0.35)]">
              <Play className="w-6 h-6 translate-x-0.5 fill-[#F3D778]" aria-hidden="true" />
            </div>
          </div>
        )}
      </div>

      {/* Clean transport & timecode bar */}
      <div
        dir="ltr"
        className="shrink-0 border-t border-[#8B5CF6]/20 bg-[#08090D] px-3 sm:px-5 py-1.5 flex items-center justify-between gap-2"
      >
        {/* Left: Timecode */}
        <div className="font-mono-tabular text-xs sm:text-sm text-[#F5F2EA] tracking-tight whitespace-nowrap flex items-center gap-1 min-w-0">
          <span className="text-[#F5F2EA] font-semibold">{formatTimecode(displayedTime)}</span>
          <span className="text-[#6E6A75]">/</span>
          <span className="text-[#9E978B]">{formatTimecode(displayedTotal)}</span>
        </div>

        {/* Center: Step -1s, Play/Pause, Step +1s */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onStepTime(-1)}
            aria-label="Rewind 1 second"
            className="hidden sm:flex min-w-[38px] min-h-[38px] rounded-lg items-center justify-center text-[#B9B2A6] hover:text-[#F5F2EA] hover:bg-white/8 active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={onTogglePlay}
            aria-label={isPlaying ? 'Pause video' : 'Play video'}
            className="min-w-[44px] min-h-[40px] px-3 rounded-xl flex items-center justify-center bg-gradient-to-r from-[#7C3AED]/25 to-[#D4AF37]/18 hover:from-[#7C3AED]/38 hover:to-[#D4AF37]/28 border border-[#A855F7]/50 text-[#F5F2EA] active:scale-95 transition-all cursor-pointer shadow-[0_0_14px_rgba(124,58,237,0.22)]"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current text-[#F3D778]" aria-hidden="true" />
            ) : (
              <Play className="w-4 h-4 translate-x-0.5 fill-current text-white" aria-hidden="true" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onStepTime(1)}
            aria-label="Forward 1 second"
            className="hidden sm:flex min-w-[38px] min-h-[38px] rounded-lg items-center justify-center text-[#B9B2A6] hover:text-[#F5F2EA] hover:bg-white/8 active:scale-95 transition-all cursor-pointer"
          >
            <RotateCw className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        {/* Right: Undo/Redo, Edited/Original Scope & Mute */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {onUndo && (
            <button
              type="button"
              onClick={onUndo}
              disabled={!canUndo}
              aria-label={strings?.toolUndo ?? 'Undo'}
              title={strings?.toolUndo ?? 'Undo'}
              className="min-w-[36px] min-h-[38px] rounded-lg flex items-center justify-center text-[#C4BDB0] hover:text-[#F5F2EA] hover:bg-white/8 disabled:opacity-30 disabled:pointer-events-none active:scale-95 transition-all cursor-pointer"
            >
              <Undo2 className="w-4 h-4" aria-hidden="true" />
            </button>
          )}
          {onRedo && (
            <button
              type="button"
              onClick={onRedo}
              disabled={!canRedo}
              aria-label={strings?.toolRedo ?? 'Redo'}
              title={strings?.toolRedo ?? 'Redo'}
              className="min-w-[36px] min-h-[38px] rounded-lg flex items-center justify-center text-[#C4BDB0] hover:text-[#F5F2EA] hover:bg-white/8 disabled:opacity-30 disabled:pointer-events-none active:scale-95 transition-all cursor-pointer"
            >
              <Redo2 className="w-4 h-4" aria-hidden="true" />
            </button>
          )}

          <div
            role="group"
            aria-label="Preview mode"
            className="flex items-center p-0.5 rounded-lg bg-[#12141C] border border-white/10"
          >
            <button
              type="button"
              onClick={() => onChangePreviewScope('edited')}
              className={`min-h-[30px] px-2 sm:px-2.5 rounded-md text-[11px] sm:text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                previewScope === 'edited'
                  ? 'bg-[#7C3AED] text-white shadow-sm'
                  : 'text-[#A59D8F] hover:text-[#F5F2EA]'
              }`}
            >
              {strings?.editedScope ?? 'Edited'}
            </button>
            <button
              type="button"
              onClick={() => onChangePreviewScope('source')}
              className={`min-h-[30px] px-2 sm:px-2.5 rounded-md text-[11px] sm:text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                previewScope === 'source'
                  ? 'bg-white/14 text-[#F5F2EA]'
                  : 'text-[#A59D8F] hover:text-[#F5F2EA]'
              }`}
            >
              {strings?.originalScope ?? 'Original'}
            </button>
          </div>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="min-w-[38px] min-h-[38px] rounded-lg flex items-center justify-center text-[#C4BDB0] hover:text-[#F5F2EA] hover:bg-white/8 active:scale-95 transition-all cursor-pointer"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-[#8D8578]" aria-hidden="true" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>
    </section>
  );
};
