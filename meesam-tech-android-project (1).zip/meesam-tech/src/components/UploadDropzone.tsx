import React, { useState } from 'react';
import {
  Download,
  Film,
  FolderOpen,
  Loader2,
  Play,
  Scissors,
  SlidersHorizontal,
  Trash2,
  Upload,
} from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import { SavedProjectSummary } from '../types/editor';
import { formatDurationShort } from '../utils/time';
import { ProjectZipDownloadControl } from './ProjectZipDownloadControl';

interface UploadDropzoneProps {
  strings: UiStrings;
  savedProjects: SavedProjectSummary[];
  loadingProjectId: string | null;
  onFileSelected: (file: File) => void;
  onTriggerUpload: () => void;
  onLoadSample: () => void;
  onOpenProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  isLoadingSample: boolean;
  errorMessage: string | null;
}

export const UploadDropzone: React.FC<UploadDropzoneProps> = ({
  strings,
  savedProjects,
  loadingProjectId,
  onFileSelected,
  onTriggerUpload,
  onLoadSample,
  onOpenProject,
  onDeleteProject,
  isLoadingSample,
  errorMessage,
}) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onFileSelected(file);
    }
  };

  return (
    <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 sm:py-10 flex flex-col items-center justify-center bg-[#07080B]">
      <div className="w-full max-w-2xl mx-auto flex flex-col gap-8">
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`rounded-2xl border transition-colors p-6 sm:p-10 flex flex-col items-center text-center gap-5 ${
            isDragging
              ? 'border-[#A855F7] bg-[#7C3AED]/12 shadow-[0_0_28px_rgba(124,58,237,0.22)]'
              : 'border-[#8B5CF6]/30 bg-[#0D0F16] hover:border-[#D4AF37]/50 shadow-[0_0_32px_rgba(0,0,0,0.65)]'
          }`}
        >
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#7C3AED]/20 to-[#D4AF37]/15 border border-[#A855F7]/40 flex items-center justify-center text-[#F3D778]">
            <Film className="w-7 h-7" aria-hidden="true" />
          </div>

          <div className="space-y-2 max-w-md">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F5F2EA] [text-wrap:balance]">
              {strings.heroTitle}
            </h1>
            <p className="text-sm text-[#A59D8F] leading-relaxed">
              {strings.heroSubtitle}
            </p>
          </div>

          {errorMessage && (
            <div
              role="alert"
              className="w-full max-w-md rounded-lg border border-red-500/35 bg-red-500/10 px-4 py-2.5 text-xs sm:text-sm text-red-300"
            >
              {errorMessage}
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 w-full sm:w-auto pt-1">
            <button
              type="button"
              onClick={onTriggerUpload}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 active:scale-[0.98] text-white border border-[#A855F7]/60 text-sm font-bold inline-flex items-center justify-center gap-2 transition-all whitespace-nowrap cursor-pointer shadow-[0_4px_22px_rgba(124,58,237,0.35)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A855F7]"
            >
              <Upload className="w-4 h-4 shrink-0 text-[#F3D778]" aria-hidden="true" />
              <span>{strings.selectVideoFile}</span>
            </button>

            <button
              type="button"
              onClick={onLoadSample}
              disabled={isLoadingSample}
              className="min-h-[48px] px-5 py-3 rounded-xl border border-[#D4AF37]/35 bg-[#141722] hover:bg-[#1C202E] hover:border-[#E5C158]/65 active:scale-[0.98] disabled:opacity-60 text-[#EAE4D7] text-sm font-medium inline-flex items-center justify-center gap-2 transition-all whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5C158]"
            >
              <Play className="w-4 h-4 shrink-0 text-[#E5C158]" aria-hidden="true" />
              <span>{isLoadingSample ? strings.preparingSample : strings.trySampleClip}</span>
            </button>
          </div>

          <p className="text-xs text-[#8D8578]">{strings.formatsNote}</p>
        </div>

        {savedProjects.length > 0 && (
          <div className="flex flex-col gap-3 pt-2 border-t border-white/8">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-[#EAE4D7] flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-[#A855F7]" aria-hidden="true" />
                <span>{strings.savedProjectsTitle}</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {savedProjects.slice(0, 4).map((proj) => {
                const isBusy = loadingProjectId === proj.id;
                return (
                  <div
                    key={proj.id}
                    className="rounded-xl bg-[#0F1118] border border-white/10 hover:border-[#A855F7]/50 p-2.5 flex items-center gap-3 transition-colors"
                  >
                    <div className="w-14 h-10 rounded-lg bg-black/70 overflow-hidden shrink-0 flex items-center justify-center border border-[#D4AF37]/25">
                      {proj.thumbnailDataUrl ? (
                        <img
                          src={proj.thumbnailDataUrl}
                          alt={proj.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Film className="w-4 h-4 text-[#8D8578]" aria-hidden="true" />
                      )}
                    </div>

                    <button
                      type="button"
                      disabled={Boolean(loadingProjectId)}
                      onClick={() => onOpenProject(proj.id)}
                      className="min-w-0 flex-1 text-left cursor-pointer disabled:opacity-50"
                    >
                      <div className="text-xs font-semibold text-[#F5F2EA] truncate flex items-center gap-1.5">
                        {isBusy && <Loader2 className="w-3 h-3 animate-spin text-[#E5C158] shrink-0" />}
                        <span className="truncate">{proj.name}</span>
                      </div>
                      <div className="text-[11px] text-[#9E978B] font-mono-tabular mt-0.5">
                        {proj.width}×{proj.height} · {formatDurationShort(proj.duration)}
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onDeleteProject(proj.id)}
                      aria-label={strings.deleteProject}
                      className="min-w-[34px] min-h-[34px] rounded-lg text-[#9E978B] hover:text-red-300 hover:bg-red-500/15 flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2 border-t border-white/8">
          <div className="flex items-start gap-3">
            <SlidersHorizontal className="w-4 h-4 text-[#E5C158] mt-0.5 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-sm font-semibold text-[#EAE4D7]">{strings.featureTrimTitle}</h2>
              <p className="text-xs text-[#9E978B] mt-0.5 leading-relaxed">
                {strings.featureTrimDesc}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Scissors className="w-4 h-4 text-[#E5C158] mt-0.5 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-sm font-semibold text-[#EAE4D7]">{strings.featureSplitTitle}</h2>
              <p className="text-xs text-[#9E978B] mt-0.5 leading-relaxed">
                {strings.featureSplitDesc}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Download className="w-4 h-4 text-[#E5C158] mt-0.5 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-sm font-semibold text-[#EAE4D7]">{strings.featureExportTitle}</h2>
              <p className="text-xs text-[#9E978B] mt-0.5 leading-relaxed">
                {strings.featureExportDesc}
              </p>
            </div>
          </div>
        </div>

        <ProjectZipDownloadControl />
      </div>
    </main>
  );
};
