import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Download, Image as ImageIcon, X, AlertCircle } from 'lucide-react';
import {
  AspectRatioPreset,
  AudioLayer,
  BgRemovalSettings,
  ChromaKeySettings,
  ExportResolution,
  ExportState,
  FrameFitMode,
  MaskSettings,
  MotionTrack,
  OverlayLayer,
  StabilizationSettings,
  TextOverlay,
  TimelineSegment,
  TransformKeyframe,
  VideoAdjustments,
  VideoAsset,
  VideoEffectLayer,
} from '../types/editor';
import {
  formatDurationShort,
  formatFileSize,
  getActiveSegments,
  getEditedDuration,
} from '../utils/time';
import { exportEditedPhoto, exportEditedVideo, getScaledDimensions } from '../utils/videoEngine';
import { downloadMediaFile } from '../utils/androidBridge';
import { UiStrings } from '../i18n/translations';

interface ExportModalProps {
  asset: VideoAsset;
  segments: TimelineSegment[];
  mainKeyframes: TransformKeyframe[];
  motionTracks: MotionTrack[];
  overlayLayers: OverlayLayer[];
  audioLayers: AudioLayer[];
  bgRemoval: BgRemovalSettings;
  chromaKey: ChromaKeySettings;
  stabilization: StabilizationSettings;
  mask: MaskSettings;
  adjustments: VideoAdjustments;
  videoEffects?: VideoEffectLayer[];
  textOverlays: TextOverlay[];
  aspectRatio: AspectRatioPreset;
  frameFit: FrameFitMode;
  strings: UiStrings;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  asset,
  segments,
  mainKeyframes,
  motionTracks,
  overlayLayers,
  audioLayers,
  bgRemoval,
  chromaKey,
  stabilization,
  mask,
  adjustments,
  videoEffects = [],
  textOverlays,
  aspectRatio,
  frameFit,
  strings,
  onClose,
}) => {
  const [resolution, setResolution] = useState<ExportResolution>('1080p');
  const [exportState, setExportState] = useState<ExportState>({
    status: 'idle',
    progress: 0,
  });
  const abortRef = useRef<AbortController | null>(null);

  const isPhoto = asset.mediaKind === 'image';
  const activeSegments = getActiveSegments(segments);
  const editedDuration = getEditedDuration(segments);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      if (exportState.blobUrl) {
        URL.revokeObjectURL(exportState.blobUrl);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleStartExport = async (asPhoto = false) => {
    if (exportState.blobUrl) {
      URL.revokeObjectURL(exportState.blobUrl);
    }

    const controller = new AbortController();
    abortRef.current = controller;

    setExportState({
      status: 'rendering',
      progress: asPhoto ? 35 : 0,
      detail: asPhoto ? 'Rendering filtered photo...' : 'Preparing video encoder...',
    });

    try {
      const result = asPhoto
        ? await exportEditedPhoto({
            sourceUrl: asset.url,
            sourceWidth: asset.width,
            sourceHeight: asset.height,
            resolution,
            adjustments,
            videoEffects,
            textOverlays,
            aspectRatio,
            frameFit,
            mainKeyframes,
            motionTracks,
            overlayLayers,
            bgRemoval,
            chromaKey,
            stabilization,
            mask,
            previewTime: activeSegments[0]?.start ?? 0,
          })
        : await exportEditedVideo({
            sourceUrl: asset.url,
            sourceWidth: asset.width,
            sourceHeight: asset.height,
            sourceMediaKind: asset.mediaKind,
            segments,
            mainKeyframes,
            motionTracks,
            overlayLayers,
            audioLayers,
            bgRemoval,
            chromaKey,
            stabilization,
            mask,
            resolution,
            adjustments,
            videoEffects,
            textOverlays,
            aspectRatio,
            frameFit,
            signal: controller.signal,
            onProgress: (progress, detail) => {
              setExportState({
                status: 'rendering',
                progress,
                detail,
              });
            },
          });

      const baseName = asset.name.replace(/\.[^/.]+$/, '') || 'meesam-media';
      const filename = asPhoto
        ? `${baseName}-filtered.${result.extension}`
        : `${baseName}-${resolution}.${result.extension}`;

      setExportState({
        status: 'complete',
        progress: 100,
        blobUrl: result.blobUrl,
        filename,
        outputSize: result.blob.size,
        outputMime: result.mimeType,
      });

      void downloadMediaFile({
        blob: result.blob,
        url: result.blobUrl,
        filename,
        mimeType: result.mimeType,
      });
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setExportState({ status: 'idle', progress: 0 });
        return;
      }
      setExportState({
        status: 'error',
        progress: 0,
        detail: err instanceof Error ? err.message : 'Export failed.',
      });
    }
  };

  const handleCancelOrClose = () => {
    if (exportState.status === 'rendering') {
      abortRef.current?.abort();
      return;
    }
    onClose();
  };

  const resolutionOptions: Array<{ id: ExportResolution; label: string; badge?: string }> = [
    { id: '720p', label: '720p HD' },
    { id: '1080p', label: '1080p Full HD', badge: 'Recommended' },
    { id: '4k', label: '4K Ultra HD', badge: 'UHD' },
    { id: 'original', label: 'Original' },
    { id: '480p', label: '480p Fast' },
  ];

  const selectedDims = getScaledDimensions(
    asset.width,
    asset.height,
    resolution,
    aspectRatio
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-modal-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
    >
      <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl bg-[#0D0F16] border-t sm:border border-[#8B5CF6]/35 p-5 sm:p-6 pb-safe shadow-2xl">
        <div className="w-10 h-1 rounded-full bg-[#A855F7]/40 mx-auto mb-4 sm:hidden" />

        <div className="flex items-center justify-between gap-4 mb-5">
          <h2 id="export-modal-title" className="text-lg font-bold text-[#F5F2EA]">
            {strings.exportModalTitle}
          </h2>
          <button
            type="button"
            onClick={handleCancelOrClose}
            aria-label="Close export dialog"
            className="min-w-[40px] min-h-[40px] rounded-lg flex items-center justify-center text-[#9E978B] hover:text-[#F5F2EA] hover:bg-white/8 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Clean Unboxed Summary */}
        <div className="flex items-center justify-between py-3 border-y border-white/8 text-xs sm:text-sm mb-5">
          <div className="text-[#9E978B]">
            <span>{activeSegments.length} {activeSegments.length === 1 ? 'clip' : 'clips'}</span>
            <span className="mx-2 text-[#A855F7]/70" aria-hidden="true">·</span>
            <span className="font-mono-tabular text-[#EAE4D7]">
              {formatDurationShort(editedDuration)}
            </span>
          </div>
          <span className="text-[#E5C158] font-mono-tabular font-medium">
            {selectedDims.width}×{selectedDims.height}
          </span>
        </div>

        {exportState.status === 'idle' && (
          <div className="space-y-4">
            <div>
              <span className="block text-xs font-medium text-[#D4C7A8] mb-2">
                {strings.outputResolution}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {resolutionOptions.map((opt) => {
                  const dims = getScaledDimensions(
                    asset.width,
                    asset.height,
                    opt.id,
                    aspectRatio
                  );
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setResolution(opt.id)}
                      className={`min-h-[48px] px-2.5 py-1.5 rounded-xl text-left border transition-colors cursor-pointer flex flex-col justify-center ${
                        resolution === opt.id
                          ? 'bg-[#7C3AED]/20 border-[#A855F7] text-[#F5F2EA] shadow-[0_0_12px_rgba(168,85,247,0.22)]'
                          : 'bg-[#141722] border-white/10 text-[#C4BDB0] hover:border-[#A855F7]/45 hover:bg-[#1B1F2E]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-semibold whitespace-nowrap">
                          {opt.label}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono-tabular text-[#9E978B]">
                        {dims.width}×{dims.height}
                      </span>
                    </button>
                  );
                })}
              </div>
              {resolution === '4k' && (
                <p className="text-[11px] text-[#E5C158]/90 mt-2 leading-relaxed">
                  4K UHD (24 Mbps) uses browser WebCodecs H.264 Level 5.1 / VP9 hardware encoding where supported by your device GPU.
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              {isPhoto && (
                <button
                  type="button"
                  onClick={() => handleStartExport(true)}
                  className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 active:scale-[0.98] text-white border border-[#A855F7]/60 text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <ImageIcon className="w-4 h-4 text-[#F3D778]" aria-hidden="true" />
                  <span>Download Filtered Photo (.PNG)</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => handleStartExport(false)}
                className={`w-full min-h-[48px] rounded-xl active:scale-[0.98] text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  isPhoto
                    ? 'bg-[#151824] hover:bg-[#1D2132] border border-[#D4AF37]/35 text-[#F5F2EA] font-semibold'
                    : 'bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 text-white border border-[#A855F7]/60 font-bold shadow-[0_4px_20px_rgba(124,58,237,0.38)]'
                }`}
              >
                <Download className="w-4 h-4 text-[#F3D778]" aria-hidden="true" />
                <span>{isPhoto ? 'Export as Video (.MP4)' : strings.exportDownload}</span>
              </button>
            </div>
          </div>
        )}

        {exportState.status === 'rendering' && (
          <div className="space-y-4 py-2">
            <div className="flex items-center justify-between text-xs sm:text-sm">
              <span className="text-[#EAE4D7]">{exportState.detail || 'Rendering...'}</span>
              <span className="font-mono-tabular font-semibold text-[#E5C158]">
                {exportState.progress}%
              </span>
            </div>
            <div dir="ltr" className="w-full h-2.5 rounded-full bg-white/10 overflow-hidden">
              <div
                style={{ width: `${exportState.progress}%` }}
                className="h-full bg-gradient-to-r from-[#7C3AED] via-[#A855F7] to-[#E5C158] transition-all duration-150"
              />
            </div>
            <p className="text-xs text-[#9E978B]">
              Keep this tab open until rendering finishes.
            </p>
            <button
              type="button"
              onClick={handleCancelOrClose}
              className="w-full min-h-[44px] rounded-xl border border-white/12 bg-[#141722] hover:bg-[#1C202E] text-[#EAE4D7] text-sm font-medium transition-colors cursor-pointer"
            >
              {strings.cancelExport}
            </button>
          </div>
        )}

        {exportState.status === 'complete' && exportState.blobUrl && (
          <div className="space-y-4">
            <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 p-3.5 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div className="min-w-0">
                <p className="text-sm font-semibold text-emerald-200">
                  {strings.videoReady}
                </p>
                <p className="text-xs text-emerald-300/80 mt-0.5 truncate font-mono-tabular">
                  {exportState.filename} · {formatFileSize(exportState.outputSize ?? 0)}
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={() => {
                  if (!exportState.blobUrl || !exportState.filename) return;
                  void downloadMediaFile({
                    url: exportState.blobUrl,
                    filename: exportState.filename,
                    mimeType: exportState.outputMime || 'video/mp4',
                  });
                }}
                className="flex-1 min-h-[48px] rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 active:scale-[0.98] text-white border border-[#A855F7]/60 text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 text-[#F3D778]" aria-hidden="true" />
                <span>
                  {exportState.outputMime?.startsWith('image/')
                    ? 'Download Photo'
                    : strings.downloadVideo}
                </span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[48px] px-5 rounded-xl border border-white/12 bg-[#141722] hover:bg-[#1C202E] text-[#EAE4D7] text-sm font-medium transition-colors cursor-pointer"
              >
                {strings.done}
              </button>
            </div>
          </div>
        )}

        {exportState.status === 'error' && (
          <div className="space-y-4">
            <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-3.5 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="text-sm font-semibold text-red-200">{strings.exportFailed}</p>
                <p className="text-xs text-red-300/80 mt-0.5">
                  {exportState.detail || 'Could not encode this video in the browser.'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setExportState({ status: 'idle', progress: 0 })}
              className="w-full min-h-[44px] rounded-xl bg-[#161922] hover:bg-[#1E222E] border border-white/12 text-[#F5F2EA] text-sm font-medium transition-colors cursor-pointer"
            >
              {strings.tryAgain}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
