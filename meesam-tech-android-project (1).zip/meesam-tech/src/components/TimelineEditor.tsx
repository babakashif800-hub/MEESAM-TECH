import React, { useRef, useState } from 'react';
import {
  ArrowLeftRight,
  Diamond,
  Layers,
  Music,
  Plus,
  Scissors,
  Type,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  AudioLayer,
  BeatAnalysis,
  OverlayLayer,
  TextOverlay,
  TimelineSegment,
  TransformKeyframe,
} from '../types/editor';
import { hasCustomSpeedCurve } from '../utils/speedCurve';
import {
  clamp,
  formatDurationShort,
  formatTimecode,
  getEditedDuration,
  getSegmentDisplaySpeed,
  getSegmentEditedDuration,
} from '../utils/time';
import { UiStrings } from '../i18n/translations';

interface TimelineEditorProps {
  duration: number;
  currentTime: number;
  segments: TimelineSegment[];
  selectedSegmentId: string;
  thumbnails: string[];
  mainKeyframes: TransformKeyframe[];
  overlayLayers: OverlayLayer[];
  selectedOverlayId: string;
  audioLayers: AudioLayer[];
  selectedAudioId: string;
  textOverlays: TextOverlay[];
  selectedTextId: string;
  beatAnalysis?: BeatAnalysis | null;
  onSelectSegment: (id: string) => void;
  onSelectOverlay: (id: string) => void;
  onSelectAudio: (id: string) => void;
  onSelectText: (id: string, isCaption?: boolean) => void;
  onSelectKeyframe: (time: number) => void;
  onRequestAddOverlay: () => void;
  onRequestAddAudio: () => void;
  onSeek: (time: number) => void;
  onTrimSegment: (segmentId: string, newStart: number, newEnd: number, previewTime?: number) => void;
  onUpdateTextOverlay?: (id: string, patch: Partial<TextOverlay>) => void;
  isMuted?: boolean;
  onToggleMute?: () => void;
  strings?: UiStrings;
}

type DragTarget =
  | { type: 'scrub' }
  | { type: 'start'; segmentId: string }
  | { type: 'end'; segmentId: string }
  | { type: 'text-start'; textId: string }
  | { type: 'text-end'; textId: string }
  | { type: 'text-move'; textId: string; offsetSec: number; spanSec: number }
  | null;

const MIN_SEGMENT_DURATION = 0.25;

export const TimelineEditor: React.FC<TimelineEditorProps> = ({
  duration,
  currentTime,
  segments,
  selectedSegmentId,
  thumbnails,
  mainKeyframes,
  overlayLayers,
  selectedOverlayId,
  audioLayers,
  selectedAudioId,
  textOverlays,
  selectedTextId,
  beatAnalysis,
  onSelectSegment,
  onSelectOverlay,
  onSelectAudio,
  onSelectText,
  onSelectKeyframe,
  onRequestAddOverlay,
  onRequestAddAudio,
  onSeek,
  onTrimSegment,
  onUpdateTextOverlay,
  isMuted = false,
  onToggleMute,
  strings,
}) => {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const [dragTarget, setDragTarget] = useState<DragTarget>(null);
  const [dragBadge, setDragBadge] = useState<{ label: string; pct: number } | null>(null);

  const safeDuration = Math.max(0.1, duration);
  const editedDuration = getEditedDuration(segments);
  const selectedSegment = segments.find((s) => s.id === selectedSegmentId) ?? segments[0];

  const getBoundsForSegment = (segId: string) => {
    const idx = segments.findIndex((s) => s.id === segId);
    if (idx === -1) return { minStart: 0, maxEnd: safeDuration };
    const prev = idx > 0 ? segments[idx - 1] : null;
    const next = idx < segments.length - 1 ? segments[idx + 1] : null;
    return {
      minStart: prev ? prev.end : 0,
      maxEnd: next ? next.start : safeDuration,
    };
  };

  const clientXToTime = (clientX: number): number => {
    const el = trackRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const ratio = clamp((clientX - rect.left) / Math.max(1, rect.width), 0, 1);
    return ratio * safeDuration;
  };

  const handleTrackPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const t = clientXToTime(e.clientX);
    setDragTarget({ type: 'scrub' });
    setDragBadge({ label: formatTimecode(t), pct: (t / safeDuration) * 100 });
    onSeek(t);

    const tappedSeg = segments.find((s) => t >= s.start && t <= s.end);
    if (tappedSeg) {
      onSelectSegment(tappedSeg.id);
    }
  };

  const handleHandlePointerDown = (
    e: React.PointerEvent<HTMLButtonElement>,
    type: 'start' | 'end',
    seg: TimelineSegment
  ) => {
    e.stopPropagation();
    e.preventDefault();
    onSelectSegment(seg.id);
    e.currentTarget.setPointerCapture(e.pointerId);
    setDragTarget({ type, segmentId: seg.id });
    const edgeTime = type === 'start' ? seg.start : seg.end;
    setDragBadge({
      label: `${type === 'start' ? 'In' : 'Out'} ${formatTimecode(edgeTime)}`,
      pct: (edgeTime / safeDuration) * 100,
    });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragTarget) return;
    const t = clientXToTime(e.clientX);

    if (dragTarget.type === 'scrub') {
      setDragBadge({ label: formatTimecode(t), pct: (t / safeDuration) * 100 });
      onSeek(t);
      return;
    }

    if (
      dragTarget.type === 'text-start' ||
      dragTarget.type === 'text-end' ||
      dragTarget.type === 'text-move'
    ) {
      const txt = textOverlays.find((item) => item.id === dragTarget.textId);
      if (!txt || !onUpdateTextOverlay) return;
      const MIN_TEXT_DUR = 0.3;

      if (dragTarget.type === 'text-start') {
        const nextStart = clamp(t, 0, Math.max(0, txt.endTime - MIN_TEXT_DUR));
        onUpdateTextOverlay(txt.id, { startTime: Number(nextStart.toFixed(2)) });
        setDragBadge({
          label: `Text In ${formatTimecode(nextStart)}`,
          pct: (nextStart / safeDuration) * 100,
        });
      } else if (dragTarget.type === 'text-end') {
        const nextEnd = clamp(t, Math.min(safeDuration, txt.startTime + MIN_TEXT_DUR), safeDuration);
        onUpdateTextOverlay(txt.id, { endTime: Number(nextEnd.toFixed(2)) });
        setDragBadge({
          label: `Text Out ${formatTimecode(nextEnd)}`,
          pct: (nextEnd / safeDuration) * 100,
        });
      } else {
        const nextStart = clamp(
          t - dragTarget.offsetSec,
          0,
          Math.max(0, safeDuration - dragTarget.spanSec)
        );
        const nextEnd = clamp(nextStart + dragTarget.spanSec, nextStart + MIN_TEXT_DUR, safeDuration);
        onUpdateTextOverlay(txt.id, {
          startTime: Number(nextStart.toFixed(2)),
          endTime: Number(nextEnd.toFixed(2)),
        });
        setDragBadge({
          label: `${formatTimecode(nextStart)} – ${formatTimecode(nextEnd)}`,
          pct: (nextStart / safeDuration) * 100,
        });
      }
      return;
    }

    const seg = segments.find((s) => s.id === dragTarget.segmentId);
    if (!seg) return;
    const { minStart, maxEnd } = getBoundsForSegment(seg.id);

    if (dragTarget.type === 'start') {
      const clampedStart = clamp(t, minStart, seg.end - MIN_SEGMENT_DURATION);
      onTrimSegment(seg.id, clampedStart, seg.end, clampedStart);
      setDragBadge({
        label: `In ${formatTimecode(clampedStart)}`,
        pct: (clampedStart / safeDuration) * 100,
      });
    } else if (dragTarget.type === 'end') {
      const clampedEnd = clamp(t, seg.start + MIN_SEGMENT_DURATION, maxEnd);
      onTrimSegment(seg.id, seg.start, clampedEnd, Math.max(seg.start, clampedEnd - 0.05));
      setDragBadge({
        label: `Out ${formatTimecode(clampedEnd)}`,
        pct: (clampedEnd / safeDuration) * 100,
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!dragTarget) return;
    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {
      // Ignore if pointer capture already released
    }
    setDragTarget(null);
    setDragBadge(null);
  };

  const playheadPct = clamp((currentTime / safeDuration) * 100, 0, 100);
  const rulerTicks = [0, 0.25, 0.5, 0.75, 1];

  return (
    <section
      aria-label="Multi-layer video timeline"
      className="shrink-0 bg-[#08090D] border-t border-[#8B5CF6]/20 px-3 sm:px-5 pt-2 pb-2 flex flex-col gap-1.5 select-none"
    >
      {/* Top Timeline Metadata + Segment Switcher + Quick Layer Add */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs text-[#9E978B]">
          <span className="font-semibold text-[#EAE4D7]">{strings?.editedScope ?? 'Edited'}</span>
          <span className="font-mono-tabular whitespace-nowrap text-[#E5C158]">
            {formatDurationShort(editedDuration)}
          </span>
          <span className="hidden sm:inline text-[#A855F7]/60" aria-hidden="true">
            ·
          </span>
          <span className="hidden sm:inline font-mono-tabular whitespace-nowrap">
            {strings?.originalScope ?? 'Original'} {formatDurationShort(duration)}
          </span>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto studio-scroll max-w-full">
          {segments.map((seg, index) => {
            const isSelected = seg.id === selectedSegment?.id;
            const speed = getSegmentDisplaySpeed(seg);
            const hasCurve = hasCustomSpeedCurve(seg);
            const segLen = getSegmentEditedDuration(seg);
            const isSegMuted = Boolean(seg.meta?.muted);

            return (
              <button
                key={seg.id}
                type="button"
                onClick={() => {
                  onSelectSegment(seg.id);
                  onSeek(seg.start);
                }}
                className={`min-h-[30px] px-2.5 py-0.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer flex items-center gap-1.5 border ${
                  isSelected
                    ? seg.deleted
                      ? 'bg-red-500/20 border-red-400/50 text-red-200'
                      : 'bg-[#7C3AED]/22 border-[#A855F7] text-white shadow-[0_0_10px_rgba(168,85,247,0.22)]'
                    : seg.deleted
                    ? 'bg-white/3 border-white/8 text-neutral-500 line-through'
                    : 'bg-[#12141C] border-white/10 text-[#C4BDB0] hover:border-[#A855F7]/50 hover:text-[#F5F2EA]'
                }`}
              >
                <span>V1·{index + 1}</span>
                <span className="font-mono-tabular text-[11px] opacity-80">
                  {seg.deleted ? 'Cut' : `${segLen.toFixed(1)}s`}
                </span>
                {!seg.deleted && (Math.abs(speed - 1) > 0.01 || hasCurve) && (
                  <span className="font-mono-tabular text-[10px] text-[#E5C158]">
                    {hasCurve ? `~${speed}x Curve` : `${speed}x`}
                  </span>
                )}
                {!seg.deleted &&
                  seg.meta?.transition &&
                  seg.meta.transition.type !== 'none' && (
                    <span
                      title={`Transition: ${seg.meta.transition.type} (${seg.meta.transition.duration.toFixed(1)}s)`}
                      className="inline-flex items-center gap-0.5 text-[10px] text-[#F3D778]"
                    >
                      <ArrowLeftRight className="w-2.5 h-2.5" aria-hidden="true" />
                    </span>
                  )}
                {!seg.deleted && isSegMuted && (
                  <VolumeX className="w-3 h-3 text-[#8D8578]" aria-hidden="true" />
                )}
              </button>
            );
          })}

          <button
            type="button"
            onClick={onRequestAddOverlay}
            className="min-h-[30px] px-2.5 rounded-md text-[11px] font-medium bg-[#12141C] hover:bg-[#1A1D29] border border-[#8B5CF6]/35 hover:border-[#A855F7] text-[#E5C158] inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3 h-3 text-[#A855F7]" aria-hidden="true" />
            <span>{strings?.addOverlayShort.replace(/^\+\s*/, '') ?? 'Overlay'}</span>
          </button>

          <button
            type="button"
            onClick={onRequestAddAudio}
            className="min-h-[30px] px-2.5 rounded-md text-[11px] font-medium bg-[#12141C] hover:bg-[#1A1D29] border border-[#8B5CF6]/35 hover:border-[#A855F7] text-[#E5C158] inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3 h-3 text-[#A855F7]" aria-hidden="true" />
            <span>{strings?.addAudioShort.replace(/^\+\s*/, '') ?? 'Audio'}</span>
          </button>
        </div>
      </div>

      {/* Time Ruler (always LTR left->right time flow) */}
      <div
        dir="ltr"
        className="relative h-3.5 mx-1 sm:mx-2 flex items-center justify-between text-[10px] font-mono-tabular text-[#8D8578] pointer-events-none"
      >
        {rulerTicks.map((ratio) => (
          <span key={ratio}>{formatTimecode(ratio * safeDuration)}</span>
        ))}
      </div>

      {/* Multi-Layer Track Stack */}
      <div
        dir="ltr"
        className="relative mx-1 sm:mx-2 flex flex-col gap-1.5 max-h-[176px] overflow-y-auto studio-scroll pr-0.5"
      >
        {dragBadge && (
          <div
            style={{ left: `${clamp(dragBadge.pct, 8, 92)}%` }}
            className="absolute -top-6 -translate-x-1/2 z-30 px-2 py-0.5 rounded bg-[#7C3AED] border border-[#A855F7] text-white text-[11px] font-mono-tabular font-bold whitespace-nowrap shadow-md pointer-events-none"
          >
            {dragBadge.label}
          </div>
        )}

        {/* Row 1: Quick Mute + V1 Main Video Filmstrip + Quick Add Overlay (+) */}
        <div className="flex items-stretch gap-1.5 shrink-0">
          {onToggleMute && (
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={isMuted ? 'Unmute track audio' : 'Mute track audio'}
              className={`w-11 sm:w-12 rounded-xl border flex flex-col items-center justify-center gap-0.5 shrink-0 transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-red-500/15 border-red-500/40 text-red-200'
                  : 'bg-[#12141C] hover:bg-[#191C28] border-white/10 text-[#EAE4D7]'
              }`}
            >
              {isMuted ? (
                <VolumeX className="w-3.5 h-3.5 text-red-300" aria-hidden="true" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-[#E5C158]" aria-hidden="true" />
              )}
              <span className="text-[9px] font-medium leading-none">
                {isMuted ? 'Muted' : 'Mute'}
              </span>
            </button>
          )}

          {/* V1 Main Video Track */}
          <div
            ref={trackRef}
            onPointerDown={handleTrackPointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="relative h-12 sm:h-14 flex-1 min-w-0 rounded-xl bg-[#050608] border border-[#8B5CF6]/25 overflow-visible touch-none cursor-pointer"
          >
            <div className="absolute inset-0 rounded-xl overflow-hidden flex pointer-events-none">
              {thumbnails.length > 0 ? (
                thumbnails.map((src, idx) => (
                  <img
                    key={idx}
                    src={src}
                    alt=""
                    referrerPolicy="no-referrer"
                    draggable={false}
                    className="h-full flex-1 object-cover opacity-80 border-r border-black/40 last:border-r-0"
                  />
                ))
              ) : (
                <div className="w-full h-full bg-gradient-to-r from-[#0F1117] via-[#191C24] to-[#0F1117]" />
              )}
            </div>

            <div className="absolute inset-0 rounded-xl bg-black/28 pointer-events-none" />

            {segments.map((seg) => {
              const leftPct = (seg.start / safeDuration) * 100;
              const widthPct = ((seg.end - seg.start) / safeDuration) * 100;
              const isSelected = seg.id === selectedSegment?.id;
              const speed = getSegmentDisplaySpeed(seg);
              const hasCurve = hasCustomSpeedCurve(seg);

              return (
                <div
                  key={seg.id}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  className={`absolute top-0 bottom-0 transition-colors ${
                    seg.deleted
                      ? 'bg-black/80 border-y border-dashed border-red-400/45'
                      : isSelected
                      ? 'border-2 border-[#A855F7] rounded-lg bg-[#7C3AED]/10 z-10 shadow-[inset_0_0_12px_rgba(168,85,247,0.2)]'
                      : 'border border-white/25 bg-transparent rounded-sm'
                  }`}
                >
                  {seg.deleted && widthPct > 8 && (
                    <div className="w-full h-full flex items-center justify-center gap-1 text-[11px] font-medium text-red-300/85 pointer-events-none overflow-hidden px-1">
                      <Scissors className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span className="truncate">Cut</span>
                    </div>
                  )}

                  {!seg.deleted && (Math.abs(speed - 1) > 0.01 || hasCurve) && widthPct > 9 && (
                    <div className="absolute bottom-1 left-1.5 text-[10px] font-mono-tabular font-semibold text-[#F3D778] bg-black/75 border border-[#D4AF37]/35 px-1.5 rounded pointer-events-none">
                      {hasCurve ? `~${speed}x Curve` : `${speed}x`}
                    </div>
                  )}

                  {!seg.deleted &&
                    seg.meta?.transition &&
                    seg.meta.transition.type !== 'none' &&
                    widthPct > 6 && (
                      <div className="absolute top-1 left-1 text-[9px] font-medium text-[#F5E1A4] bg-black/80 border border-[#A855F7]/50 px-1 rounded pointer-events-none inline-flex items-center gap-0.5">
                        <ArrowLeftRight className="w-2.5 h-2.5 text-[#E5C158]" aria-hidden="true" />
                        <span className="uppercase">{seg.meta.transition.type.slice(0, 4)}</span>
                      </div>
                    )}

                  {isSelected && !seg.deleted && (
                    <>
                      <button
                        type="button"
                        aria-label="Drag to trim clip start"
                        onPointerDown={(e) => handleHandlePointerDown(e, 'start', seg)}
                        onPointerMove={handlePointerMove}
                        onPointerUp={handlePointerUp}
                        onPointerCancel={handlePointerUp}
                        className="absolute -left-[22px] -top-1 -bottom-1 w-[44px] flex items-center justify-center touch-none cursor-ew-resize z-20 group focus-visible:outline-none"
                      >
                        <span className="w-3.5 h-full rounded-l-md bg-gradient-to-b from-[#F3D778] via-[#E5C158] to-[#A68018] group-hover:brightness-110 flex items-center justify-center shadow-md">
                          <span className="w-0.5 h-4 rounded-full bg-[#08090C]/85" />
                        </span>
                      </button>

                      <button
                        type="button"
                        aria-label="Drag to trim clip end"
                        onPointerDown={(e) => handleHandlePointerDown(e, 'end', seg)}
                        onPointerMove={handlePointerMove}
                        onPointerUp={handlePointerUp}
                        onPointerCancel={handlePointerUp}
                        className="absolute -right-[22px] -top-1 -bottom-1 w-[44px] flex items-center justify-center touch-none cursor-ew-resize z-20 group focus-visible:outline-none"
                      >
                        <span className="w-3.5 h-full rounded-r-md bg-gradient-to-b from-[#F3D778] via-[#E5C158] to-[#A68018] group-hover:brightness-110 flex items-center justify-center shadow-md">
                          <span className="w-0.5 h-4 rounded-full bg-[#08090C]/85" />
                        </span>
                      </button>
                    </>
                  )}
                </div>
              );
            })}

            {/* Keyframe Diamond Markers on V1 */}
            {mainKeyframes.map((kf) => {
              const pct = clamp((kf.time / safeDuration) * 100, 0, 100);
              const active = Math.abs(kf.time - currentTime) < 0.08;
              return (
                <button
                  key={kf.id}
                  type="button"
                  title={`Keyframe @ ${formatTimecode(kf.time)}`}
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectKeyframe(kf.time);
                  }}
                  style={{ left: `${pct}%` }}
                  className="absolute top-1 -translate-x-1/2 z-20 w-5 h-5 flex items-center justify-center cursor-pointer"
                >
                  <Diamond
                    className={`w-3 h-3 ${
                      active
                        ? 'text-white fill-[#F3D778]'
                        : 'text-[#F3D778] fill-[#D4AF37]'
                    }`}
                    aria-hidden="true"
                  />
                </button>
              );
            })}

            {/* Beat Sync Tick Markers on V1 */}
            {beatAnalysis &&
              beatAnalysis.beats.map((bTime, bIdx) => {
                const pct = clamp((bTime / safeDuration) * 100, 0, 100);
                return (
                  <button
                    key={`v1-beat-${bIdx}`}
                    type="button"
                    title={`Beat ${bIdx + 1} @ ${formatTimecode(bTime)}`}
                    onPointerDown={(e) => e.stopPropagation()}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSeek(bTime);
                    }}
                    style={{ left: `${pct}%` }}
                    className="absolute bottom-0 -translate-x-1/2 z-15 w-2.5 h-3.5 flex items-end justify-center cursor-pointer group"
                  >
                    <span className="w-0.5 h-2 rounded-full bg-[#E5C158]/85 group-hover:bg-[#F3D778] group-hover:h-3 transition-all" />
                  </button>
                );
              })}

            {/* Playhead Vertical Line */}
            <div
              style={{ left: `${playheadPct}%` }}
              className="absolute -top-1.5 -bottom-1.5 w-0.5 bg-white z-20 pointer-events-none shadow-[0_0_8px_rgba(0,0,0,0.9)]"
            >
              <div className="w-2.5 h-2.5 -ml-[4px] -mt-0.5 rounded-full bg-white border-2 border-[#7C3AED] shadow" />
            </div>
          </div>

          {/* Quick + Overlay Button at end of track strip */}
          <button
            type="button"
            onClick={onRequestAddOverlay}
            aria-label="Add video or image overlay"
            title={strings?.addOverlayShort ?? '+ Overlay'}
            className="w-10 sm:w-11 rounded-xl bg-white hover:bg-[#F5F2EA] text-[#08090C] flex items-center justify-center shrink-0 active:scale-95 transition-all cursor-pointer shadow-sm"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" aria-hidden="true" />
          </button>
        </div>

        {/* V2 Overlay / Picture-in-Picture Track */}
        {overlayLayers.length > 0 && (
          <div className="relative h-6 w-full rounded-md bg-[#12141C] border border-[#8B5CF6]/25 overflow-hidden shrink-0">
            {overlayLayers.map((ov) => {
              const leftPct = clamp((ov.startTime / safeDuration) * 100, 0, 100);
              const widthPct = clamp(
                ((ov.endTime - ov.startTime) / safeDuration) * 100,
                4,
                100 - leftPct
              );
              const isSelected = ov.id === selectedOverlayId;
              return (
                <button
                  key={ov.id}
                  type="button"
                  onClick={() => {
                    onSelectOverlay(ov.id);
                    onSeek(ov.startTime);
                  }}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  className={`absolute top-0.5 bottom-0.5 px-1.5 rounded text-[10px] font-medium flex items-center gap-1 truncate cursor-pointer ${
                    isSelected
                      ? 'bg-[#7C3AED]/35 border border-[#A855F7] text-white'
                      : 'bg-white/8 border border-white/20 text-[#D4C7A8]'
                  }`}
                >
                  <Layers className="w-2.5 h-2.5 shrink-0 text-[#E5C158]" aria-hidden="true" />
                  <span className="truncate">V2·{ov.name}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* T1 Captions & Text Marks Track (Drag edges to resize duration or slide bar to move) */}
        {textOverlays.length > 0 && (
          <div
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="relative h-7 w-full rounded-md bg-[#16130D] border border-[#D4AF37]/25 overflow-visible shrink-0 touch-none"
          >
            {textOverlays.map((item) => {
              const leftPct = clamp((item.startTime / safeDuration) * 100, 0, 100);
              const widthPct = clamp(
                ((item.endTime - item.startTime) / safeDuration) * 100,
                4,
                100 - leftPct
              );
              const isSelected = item.id === selectedTextId;
              return (
                <div
                  key={item.id}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onSelectText(item.id, item.isCaption);
                    onSeek(item.startTime);
                    if (!onUpdateTextOverlay) return;
                    const t = clientXToTime(e.clientX);
                    try {
                      e.currentTarget.setPointerCapture(e.pointerId);
                    } catch {
                      // Ignore
                    }
                    setDragTarget({
                      type: 'text-move',
                      textId: item.id,
                      offsetSec: clamp(t - item.startTime, 0, Math.max(0.3, item.endTime - item.startTime)),
                      spanSec: Math.max(0.3, item.endTime - item.startTime),
                    });
                  }}
                  className={`absolute top-0.5 bottom-0.5 rounded flex items-center text-[10px] font-medium touch-none select-none ${
                    isSelected
                      ? 'bg-[#D4AF37]/28 border border-[#E5C158] text-[#F5F2EA] z-10 cursor-grab active:cursor-grabbing'
                      : 'bg-[#D4AF37]/14 border border-[#D4AF37]/30 text-[#D4C7A8] cursor-pointer'
                  }`}
                >
                  {isSelected && onUpdateTextOverlay && (
                    <button
                      type="button"
                      aria-label="Adjust text start time"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        try {
                          e.currentTarget.parentElement?.setPointerCapture(e.pointerId);
                        } catch {
                          // Ignore
                        }
                        setDragTarget({ type: 'text-start', textId: item.id });
                        setDragBadge({
                          label: `Text In ${formatTimecode(item.startTime)}`,
                          pct: leftPct,
                        });
                      }}
                      className="h-full w-3 min-w-[12px] bg-[#E5C158] hover:bg-[#F3D778] rounded-l flex items-center justify-center cursor-ew-resize touch-none shrink-0"
                    >
                      <span className="w-0.5 h-3 bg-[#08090C] rounded-full" />
                    </button>
                  )}

                  <div className="flex-1 min-w-0 px-1.5 flex items-center gap-1 overflow-hidden">
                    <Type className="w-2.5 h-2.5 shrink-0 text-[#E5C158]" aria-hidden="true" />
                    <span className="truncate">{item.text || 'Text'}</span>
                  </div>

                  {isSelected && onUpdateTextOverlay && (
                    <button
                      type="button"
                      aria-label="Adjust text end time"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        try {
                          e.currentTarget.parentElement?.setPointerCapture(e.pointerId);
                        } catch {
                          // Ignore
                        }
                        setDragTarget({ type: 'text-end', textId: item.id });
                        setDragBadge({
                          label: `Text Out ${formatTimecode(item.endTime)}`,
                          pct: leftPct + widthPct,
                        });
                      }}
                      className="h-full w-3 min-w-[12px] bg-[#E5C158] hover:bg-[#F3D778] rounded-r flex items-center justify-center cursor-ew-resize touch-none shrink-0"
                    >
                      <span className="w-0.5 h-3 bg-[#08090C] rounded-full" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* A1 Extra Audio / Music Track — clickable Add Audio prompt when empty */}
        {audioLayers.length > 0 ? (
          <div className="relative h-6 w-full rounded-md bg-[#12101A] border border-[#8B5CF6]/25 overflow-hidden shrink-0">
            {audioLayers.map((aud) => {
              const leftPct = clamp((aud.startTime / safeDuration) * 100, 0, 100);
              const widthPct = clamp(
                ((aud.endTime - aud.startTime) / safeDuration) * 100,
                4,
                100 - leftPct
              );
              const isSelected = aud.id === selectedAudioId;
              return (
                <button
                  key={aud.id}
                  type="button"
                  onClick={() => {
                    onSelectAudio(aud.id);
                    onSeek(aud.startTime);
                  }}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  className={`absolute top-0.5 bottom-0.5 px-1.5 rounded text-[10px] font-medium flex items-center gap-1 truncate cursor-pointer ${
                    isSelected
                      ? 'bg-[#7C3AED]/35 border border-[#A855F7] text-white'
                      : 'bg-[#7C3AED]/18 border border-[#8B5CF6]/35 text-[#DDD6FE]'
                  }`}
                >
                  <Music className="w-2.5 h-2.5 shrink-0 text-[#E5C158]" aria-hidden="true" />
                  <span className="truncate">A1·{aud.name}</span>
                  {aud.muted && <VolumeX className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />}
                </button>
              );
            })}
            {beatAnalysis &&
              beatAnalysis.beats.map((bTime, bIdx) => {
                const pct = clamp((bTime / safeDuration) * 100, 0, 100);
                return (
                  <span
                    key={`a1-beat-${bIdx}`}
                    style={{ left: `${pct}%` }}
                    className="absolute top-0 bottom-0 w-px bg-[#E5C158]/65 pointer-events-none"
                  />
                );
              })}
          </div>
        ) : (
          <button
            type="button"
            onClick={onRequestAddAudio}
            className="h-8 w-full rounded-lg bg-[#12141C] hover:bg-[#191C28] border border-white/10 hover:border-[#A855F7]/50 px-3 flex items-center gap-2 text-xs font-medium text-[#D4CEC2] hover:text-white transition-colors shrink-0 cursor-pointer"
          >
            <Music className="w-3.5 h-3.5 text-[#E5C158] shrink-0" aria-hidden="true" />
            <span>Add Audio</span>
          </button>
        )}
      </div>
    </section>
  );
};
