import React from 'react';
import { Check, Globe, X } from 'lucide-react';
import { UiStrings } from '../i18n/translations';
import { AppLanguage, ChineseVariant } from '../types/editor';
import { FIVE_SUPPORTED_LANGUAGES } from '../utils/languages';

interface LanguageModalProps {
  uiLanguage: AppLanguage;
  chineseVariant: ChineseVariant;
  strings: UiStrings;
  onSelectLanguage: (lang: AppLanguage) => void;
  onSelectChineseVariant: (variant: ChineseVariant) => void;
  onClose: () => void;
}

export const LanguageModal: React.FC<LanguageModalProps> = ({
  uiLanguage,
  chineseVariant,
  strings,
  onSelectLanguage,
  onSelectChineseVariant,
  onClose,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="lang-settings-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
    >
      <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl bg-[#0D0F16] border-t sm:border border-[#8B5CF6]/35 p-5 sm:p-6 pb-safe shadow-2xl">
        <div className="w-10 h-1 rounded-full bg-[#A855F7]/40 mx-auto mb-4 sm:hidden" />

        <div className="flex items-center justify-between gap-3 mb-4">
          <h2
            id="lang-settings-title"
            className="text-base sm:text-lg font-bold text-[#F5F2EA] flex items-center gap-2"
          >
            <Globe className="w-5 h-5 text-[#A855F7] shrink-0" aria-hidden="true" />
            <span>{strings.languageSettingsTitle}</span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close language settings"
            className="min-w-[38px] min-h-[38px] rounded-lg flex items-center justify-center text-[#9E978B] hover:text-[#F5F2EA] hover:bg-white/8 cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <p className="text-xs text-[#9E978B] mb-3">{strings.fiveLanguagesNote}</p>

        <div className="flex flex-col gap-2">
          {FIVE_SUPPORTED_LANGUAGES.map((lang) => {
            const active = uiLanguage === lang.id;
            return (
              <div key={lang.id} className="flex flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => onSelectLanguage(lang.id)}
                  className={`w-full min-h-[48px] px-3.5 py-2 rounded-xl border flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#7C3AED]/18 border-[#A855F7] text-[#F5F2EA] shadow-[0_0_12px_rgba(168,85,247,0.2)]'
                      : 'bg-[#141722] border-white/10 text-[#EAE4D7] hover:border-[#A855F7]/45'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      dir={lang.dir}
                      className="text-sm font-bold text-[#F5F2EA]"
                      style={{ unicodeBidi: 'plaintext' }}
                    >
                      {lang.nativeName}
                    </span>
                    <span className="text-xs text-[#9E978B]">{lang.englishName}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] font-mono-tabular text-[#B6AD9C]">
                      {lang.dir.toUpperCase()}
                    </span>
                    {active && <Check className="w-4 h-4 text-[#E5C158]" aria-hidden="true" />}
                  </div>
                </button>

                {lang.id === 'zh' && active && (
                  <div className="grid grid-cols-2 gap-2 ps-3">
                    <button
                      type="button"
                      onClick={() => onSelectChineseVariant('zh-Hans')}
                      className={`min-h-[38px] px-3 rounded-xl text-xs font-semibold border cursor-pointer ${
                        chineseVariant === 'zh-Hans'
                          ? 'bg-[#7C3AED] border-[#A855F7] text-white'
                          : 'bg-[#141722] border-white/10 text-[#C4BDB0] hover:bg-[#1C202E]'
                      }`}
                    >
                      {strings.simplifiedLabel}
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectChineseVariant('zh-Hant')}
                      className={`min-h-[38px] px-3 rounded-xl text-xs font-semibold border cursor-pointer ${
                        chineseVariant === 'zh-Hant'
                          ? 'bg-[#7C3AED] border-[#A855F7] text-white'
                          : 'bg-[#141722] border-white/10 text-[#C4BDB0] hover:bg-[#1C202E]'
                      }`}
                    >
                      {strings.traditionalLabel}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full min-h-[44px] rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#8B5CF6] to-[#6D28D9] hover:brightness-110 text-white border border-[#A855F7]/60 text-sm font-bold cursor-pointer"
        >
          {strings.done}
        </button>
      </div>
    </div>
  );
};
