import {
  EditorProjectEdits,
  SavedProjectRecord,
  SavedProjectSummary,
  VideoAsset,
} from '../types/editor';

const DB_NAME = 'meesam_tech_projects_v1';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_BLOBS = 'blobs';
const ASSET_REF_PREFIX = 'idb-blob://';

function openProjectsDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is unavailable in this browser.'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Unable to open project database.'));
  });
}

async function resolveBlobForUrl(
  url: string | undefined,
  urlToBlobMap: Map<string, Blob>
): Promise<Blob | null> {
  if (!url) return null;
  const cached = urlToBlobMap.get(url);
  if (cached) return cached;
  try {
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const blob = await resp.blob();
    urlToBlobMap.set(url, blob);
    return blob;
  } catch {
    return null;
  }
}

function collectReferencedBlobKeys(record: SavedProjectRecord): Set<string> {
  const keys = new Set<string>();
  keys.add(record.assetBlobKey);

  const checkRef = (val?: string) => {
    if (val && val.startsWith(ASSET_REF_PREFIX)) {
      keys.add(val.slice(ASSET_REF_PREFIX.length));
    }
  };

  for (const ov of record.edits.overlayLayers) {
    checkRef(ov.url);
  }
  for (const aud of record.edits.audioLayers) {
    checkRef(aud.url);
  }
  checkRef(record.edits.bgRemoval.bgImageUrl);
  checkRef(record.edits.chromaKey.bgImageUrl);
  checkRef(record.edits.chromaKey.bgVideoUrl);
  return keys;
}

export async function listSavedProjects(): Promise<SavedProjectSummary[]> {
  try {
    const db = await openProjectsDb();
    const tx = db.transaction(STORE_PROJECTS, 'readonly');
    const store = tx.objectStore(STORE_PROJECTS);
    const all = await new Promise<SavedProjectRecord[]>((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve((req.result as SavedProjectRecord[]) ?? []);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return all
      .map(
        ({
          id,
          name,
          updatedAt,
          createdAt,
          duration,
          width,
          height,
          mediaKind,
          mimeType,
          aspectRatio,
          thumbnailDataUrl,
        }): SavedProjectSummary => ({
          id,
          name,
          updatedAt,
          createdAt,
          duration,
          width,
          height,
          mediaKind,
          mimeType,
          aspectRatio,
          thumbnailDataUrl,
        })
      )
      .sort((a, b) => b.updatedAt - a.updatedAt);
  } catch {
    return [];
  }
}

export async function saveProjectToIdb(params: {
  existingId?: string | null;
  projectName?: string;
  asset: VideoAsset;
  edits: EditorProjectEdits;
  thumbnailDataUrl?: string;
  urlToBlobMap: Map<string, Blob>;
}): Promise<SavedProjectSummary> {
  const db = await openProjectsDb();
  const projectId =
    params.existingId ||
    `proj-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  const now = Date.now();

  let existingCreatedAt = now;
  if (params.existingId) {
    try {
      const readTx = db.transaction(STORE_PROJECTS, 'readonly');
      const prev = await new Promise<SavedProjectRecord | undefined>((resolve) => {
        const r = readTx.objectStore(STORE_PROJECTS).get(projectId);
        r.onsuccess = () => resolve(r.result as SavedProjectRecord | undefined);
        r.onerror = () => resolve(undefined);
      });
      if (prev?.createdAt) existingCreatedAt = prev.createdAt;
    } catch {
      // Ignore
    }
  }

  const blobsToWrite: Array<{ key: string; blob: Blob }> = [];
  const mainBlob =
    params.asset.file ?? (await resolveBlobForUrl(params.asset.url, params.urlToBlobMap));
  if (!mainBlob) {
    db.close();
    throw new Error('Original media file could not be read for saving.');
  }

  const assetBlobKey = `${projectId}:main`;
  blobsToWrite.push({ key: assetBlobKey, blob: mainBlob });

  const serializeUrl = async (url: string | undefined, slotKey: string): Promise<string | undefined> => {
    if (!url) return undefined;
    if (url.startsWith(ASSET_REF_PREFIX)) return url;
    const blob = await resolveBlobForUrl(url, params.urlToBlobMap);
    if (!blob) return undefined;
    const key = `${projectId}:${slotKey}`;
    blobsToWrite.push({ key, blob });
    return `${ASSET_REF_PREFIX}${key}`;
  };

  const serializedOverlays = await Promise.all(
    params.edits.overlayLayers.map(async (ov) => ({
      ...ov,
      url: (await serializeUrl(ov.url, `ov:${ov.id}`)) ?? ov.url,
      keyframes: ov.keyframes.map((k) => ({ ...k })),
    }))
  );

  const serializedAudios = await Promise.all(
    params.edits.audioLayers.map(async (aud) => ({
      ...aud,
      url: (await serializeUrl(aud.url, `aud:${aud.id}`)) ?? aud.url,
    }))
  );

  const serializedBgImage = await serializeUrl(
    params.edits.bgRemoval.bgImageUrl,
    'bg-remove-img'
  );
  const serializedChromaImg = await serializeUrl(
    params.edits.chromaKey.bgImageUrl,
    'chroma-bg-img'
  );
  const serializedChromaVid = await serializeUrl(
    params.edits.chromaKey.bgVideoUrl,
    'chroma-bg-vid'
  );

  const record: SavedProjectRecord = {
    id: projectId,
    name: params.projectName?.trim() || params.asset.name || 'Untitled Project',
    createdAt: existingCreatedAt,
    updatedAt: now,
    duration: params.asset.duration,
    width: params.asset.width,
    height: params.asset.height,
    mediaKind: params.asset.mediaKind ?? 'video',
    mimeType: params.asset.mimeType,
    aspectRatio: params.edits.aspectRatio,
    thumbnailDataUrl: params.thumbnailDataUrl,
    assetBlobKey,
    assetSize: mainBlob.size || params.asset.size,
    isSample: params.asset.isSample,
    edits: {
      ...params.edits,
      overlayLayers: serializedOverlays,
      audioLayers: serializedAudios,
      bgRemoval: {
        ...params.edits.bgRemoval,
        bgImageUrl: serializedBgImage,
      },
      chromaKey: {
        ...params.edits.chromaKey,
        bgImageUrl: serializedChromaImg,
        bgVideoUrl: serializedChromaVid,
      },
    },
  };

  const tx = db.transaction([STORE_PROJECTS, STORE_BLOBS], 'readwrite');
  const projectStore = tx.objectStore(STORE_PROJECTS);
  const blobStore = tx.objectStore(STORE_BLOBS);

  for (const item of blobsToWrite) {
    blobStore.put({ key: item.key, blob: item.blob });
  }
  projectStore.put(record);

  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Failed to write project to storage.'));
    tx.onabort = () => reject(tx.error ?? new Error('Project save aborted (storage quota may be full).'));
  });

  db.close();

  return {
    id: record.id,
    name: record.name,
    updatedAt: record.updatedAt,
    createdAt: record.createdAt,
    duration: record.duration,
    width: record.width,
    height: record.height,
    mediaKind: record.mediaKind,
    mimeType: record.mimeType,
    aspectRatio: record.aspectRatio,
    thumbnailDataUrl: record.thumbnailDataUrl,
  };
}

export async function loadProjectFromIdb(
  projectId: string,
  registerUrl: (url: string, blob: Blob) => string
): Promise<{ asset: VideoAsset; edits: EditorProjectEdits; summary: SavedProjectSummary }> {
  const db = await openProjectsDb();
  const tx = db.transaction([STORE_PROJECTS, STORE_BLOBS], 'readonly');
  const projectStore = tx.objectStore(STORE_PROJECTS);
  const blobStore = tx.objectStore(STORE_BLOBS);

  const record = await new Promise<SavedProjectRecord | undefined>((resolve, reject) => {
    const req = projectStore.get(projectId);
    req.onsuccess = () => resolve(req.result as SavedProjectRecord | undefined);
    req.onerror = () => reject(req.error);
  });

  if (!record) {
    db.close();
    throw new Error('Saved project was not found.');
  }

  const getBlob = (key: string): Promise<Blob | null> =>
    new Promise((resolve) => {
      const req = blobStore.get(key);
      req.onsuccess = () => {
        const res = req.result as { key: string; blob: Blob } | undefined;
        resolve(res?.blob ?? null);
      };
      req.onerror = () => resolve(null);
    });

  const mainBlob = await getBlob(record.assetBlobKey);
  if (!mainBlob) {
    db.close();
    throw new Error('Main media file for this saved project is missing.');
  }

  const mainFile =
    mainBlob instanceof File
      ? mainBlob
      : new File([mainBlob], record.name, { type: record.mimeType || mainBlob.type });
  const mainUrl = registerUrl(URL.createObjectURL(mainFile), mainFile);

  const hydrateUrl = async (refUrl: string | undefined): Promise<string | undefined> => {
    if (!refUrl) return undefined;
    if (!refUrl.startsWith(ASSET_REF_PREFIX)) return refUrl;
    const blobKey = refUrl.slice(ASSET_REF_PREFIX.length);
    const blob = await getBlob(blobKey);
    if (!blob) return undefined;
    return registerUrl(URL.createObjectURL(blob), blob);
  };

  const hydratedOverlays = await Promise.all(
    record.edits.overlayLayers.map(async (ov) => ({
      ...ov,
      url: (await hydrateUrl(ov.url)) ?? ov.url,
    }))
  );

  const hydratedAudios = await Promise.all(
    record.edits.audioLayers.map(async (aud) => ({
      ...aud,
      url: (await hydrateUrl(aud.url)) ?? aud.url,
    }))
  );

  const hydratedBgImg = await hydrateUrl(record.edits.bgRemoval.bgImageUrl);
  const hydratedChromaImg = await hydrateUrl(record.edits.chromaKey.bgImageUrl);
  const hydratedChromaVid = await hydrateUrl(record.edits.chromaKey.bgVideoUrl);

  db.close();

  const asset: VideoAsset = {
    id: `asset-${record.id}`,
    name: record.name,
    size: record.assetSize || mainFile.size,
    duration: record.duration,
    width: record.width,
    height: record.height,
    mimeType: record.mimeType,
    url: mainUrl,
    file: mainFile,
    isSample: record.isSample,
    mediaKind: record.mediaKind,
  };

  const edits: EditorProjectEdits = {
    ...record.edits,
    overlayLayers: hydratedOverlays,
    audioLayers: hydratedAudios,
    bgRemoval: {
      ...record.edits.bgRemoval,
      bgImageUrl: hydratedBgImg,
    },
    chromaKey: {
      ...record.edits.chromaKey,
      bgImageUrl: hydratedChromaImg,
      bgVideoUrl: hydratedChromaVid,
    },
  };

  const summary: SavedProjectSummary = {
    id: record.id,
    name: record.name,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
    duration: record.duration,
    width: record.width,
    height: record.height,
    mediaKind: record.mediaKind,
    mimeType: record.mimeType,
    aspectRatio: record.aspectRatio,
    thumbnailDataUrl: record.thumbnailDataUrl,
  };

  return { asset, edits, summary };
}

export async function deleteSavedProject(projectId: string): Promise<void> {
  const db = await openProjectsDb();
  const readTx = db.transaction(STORE_PROJECTS, 'readonly');
  const record = await new Promise<SavedProjectRecord | undefined>((resolve) => {
    const req = readTx.objectStore(STORE_PROJECTS).get(projectId);
    req.onsuccess = () => resolve(req.result as SavedProjectRecord | undefined);
    req.onerror = () => resolve(undefined);
  });

  const keysToDelete = record ? collectReferencedBlobKeys(record) : new Set<string>();
  const tx = db.transaction([STORE_PROJECTS, STORE_BLOBS], 'readwrite');
  tx.objectStore(STORE_PROJECTS).delete(projectId);
  const blobStore = tx.objectStore(STORE_BLOBS);
  for (const key of keysToDelete) {
    blobStore.delete(key);
  }

  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}
