import { FilesetResolver, ImageSegmenter } from '@mediapipe/tasks-vision';
import { BgRemovalSettings } from '../types/editor';

export const DEFAULT_BG_REMOVAL: BgRemovalSettings = {
  mode: 'off',
  threshold: 0.5,
  edgeSoftness: 4,
  blurAmount: 14,
  bgColor: '#00b140',
};

let segmenterPromise: Promise<ImageSegmenter> | null = null;
let segmenterError: string | null = null;

/**
 * Loads the official Google MediaPipe SelfieSegmenter WASM/TFLite model locally once and caches it.
 * Falls back cleanly from GPU delegate to CPU delegate for wide Android compatibility.
 */
export async function getBgSegmenter(): Promise<ImageSegmenter> {
  if (segmenterPromise) {
    return segmenterPromise;
  }

  segmenterError = null;
  segmenterPromise = (async () => {
    const vision = await FilesetResolver.forVisionTasks('/mediapipe/wasm');
    const modelUrl = '/api/models/selfie-segmenter.tflite';

    try {
      return await ImageSegmenter.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: modelUrl,
          delegate: 'GPU',
        },
        runningMode: 'IMAGE',
        outputCategoryMask: false,
        outputConfidenceMasks: true,
      });
    } catch {
      return await ImageSegmenter.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: modelUrl,
          delegate: 'CPU',
        },
        runningMode: 'IMAGE',
        outputCategoryMask: false,
        outputConfidenceMasks: true,
      });
    }
  })().catch((err) => {
    segmenterPromise = null;
    segmenterError =
      err instanceof Error ? err.message : 'Unable to initialize AI Background Remover model.';
    throw new Error(segmenterError);
  });

  return segmenterPromise;
}

export function getLastBgSegmenterError(): string | null {
  return segmenterError;
}

// Reusable scratch canvases for Android-friendly zero-allocation per-frame segmentation
let workCanvas: HTMLCanvasElement | null = null;
let maskCanvas: HTMLCanvasElement | null = null;
let fgCanvas: HTMLCanvasElement | null = null;
let bgCanvas: HTMLCanvasElement | null = null;

function ensureScratchCanvas(
  existing: HTMLCanvasElement | null,
  w: number,
  h: number
): HTMLCanvasElement {
  const c = existing ?? document.createElement('canvas');
  if (c.width !== w) c.width = w;
  if (c.height !== h) c.height = h;
  return c;
}

/**
 * Segments the foreground subject from a video/image source using MediaPipe SelfieSegmenter
 * and composites it onto the selected backdrop (`transparent`, `blur`, `color`, or `image`).
 */
export function renderSegmentedFrame(
  segmenter: ImageSegmenter,
  source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | VideoFrame,
  targetCanvas: HTMLCanvasElement,
  settings: BgRemovalSettings,
  customBgImage?: HTMLImageElement | null,
  maxSegmentEdge = 384
): void {
  const outW = targetCanvas.width;
  const outH = targetCanvas.height;
  const outCtx = targetCanvas.getContext('2d');
  if (!outCtx || outW <= 0 || outH <= 0) return;

  const srcW =
    source instanceof HTMLVideoElement
      ? source.videoWidth || outW
      : source instanceof HTMLImageElement
      ? source.naturalWidth || source.width || outW
      : source instanceof HTMLCanvasElement
      ? source.width || outW
      : source.displayWidth || source.codedWidth || outW;
  const srcH =
    source instanceof HTMLVideoElement
      ? source.videoHeight || outH
      : source instanceof HTMLImageElement
      ? source.naturalHeight || source.height || outH
      : source instanceof HTMLCanvasElement
      ? source.height || outH
      : source.displayHeight || source.codedHeight || outH;
  if (srcW <= 0 || srcH <= 0) return;

  const scale = Math.min(1, maxSegmentEdge / Math.max(srcW, srcH));
  const segW = Math.max(64, Math.round(srcW * scale));
  const segH = Math.max(64, Math.round(srcH * scale));

  workCanvas = ensureScratchCanvas(workCanvas, segW, segH);
  maskCanvas = ensureScratchCanvas(maskCanvas, segW, segH);
  fgCanvas = ensureScratchCanvas(fgCanvas, outW, outH);

  const workCtx = workCanvas.getContext('2d');
  const maskCtx = maskCanvas.getContext('2d');
  const fgCtx = fgCanvas.getContext('2d');
  if (!workCtx || !maskCtx || !fgCtx) return;

  workCtx.drawImage(source, 0, 0, segW, segH);

  let hasValidMask = false;
  segmenter.segment(workCanvas, (result) => {
    const conf = result.confidenceMasks?.[0];
    if (!conf) return;
    const maskFloat = conf.getAsFloat32Array();
    if (!maskFloat || maskFloat.length !== segW * segH) return;

    const maskImg = maskCtx.createImageData(segW, segH);
    const pixels = maskImg.data;
    const thresh = Math.max(0.1, Math.min(0.9, settings.threshold));
    const ramp = 0.14;
    const low = Math.max(0, thresh - ramp);
    const high = Math.min(1, thresh + ramp);
    const invSpan = 1 / Math.max(0.01, high - low);

    for (let i = 0; i < maskFloat.length; i++) {
      const v = maskFloat[i];
      let alpha = 0;
      if (v >= high) {
        alpha = 255;
      } else if (v > low) {
        alpha = Math.round(((v - low) * invSpan) * 255);
      }
      const p = i * 4;
      pixels[p] = 255;
      pixels[p + 1] = 255;
      pixels[p + 2] = 255;
      pixels[p + 3] = alpha;
    }
    maskCtx.putImageData(maskImg, 0, 0);
    hasValidMask = true;
  });

  if (!hasValidMask) {
    outCtx.clearRect(0, 0, outW, outH);
    outCtx.drawImage(source, 0, 0, outW, outH);
    return;
  }

  // Build masked foreground at target dimensions
  fgCtx.save();
  fgCtx.clearRect(0, 0, outW, outH);
  fgCtx.filter =
    settings.edgeSoftness > 0 ? `blur(${settings.edgeSoftness.toFixed(1)}px)` : 'none';
  fgCtx.drawImage(maskCanvas, 0, 0, outW, outH);
  fgCtx.filter = 'none';
  fgCtx.globalCompositeOperation = 'source-in';
  fgCtx.drawImage(source, 0, 0, outW, outH);
  fgCtx.restore();

  // Draw chosen backdrop onto targetCanvas
  outCtx.save();
  outCtx.clearRect(0, 0, outW, outH);

  if (settings.mode === 'blur') {
    bgCanvas = ensureScratchCanvas(bgCanvas, outW, outH);
    const bgCtx = bgCanvas.getContext('2d');
    if (bgCtx) {
      bgCtx.save();
      bgCtx.clearRect(0, 0, outW, outH);
      bgCtx.filter = `blur(${Math.max(4, settings.blurAmount)}px) brightness(0.92)`;
      bgCtx.drawImage(source, 0, 0, outW, outH);
      bgCtx.restore();
      outCtx.drawImage(bgCanvas, 0, 0, outW, outH);
    }
  } else if (settings.mode === 'color') {
    outCtx.fillStyle = settings.bgColor || '#00b140';
    outCtx.fillRect(0, 0, outW, outH);
  } else if (settings.mode === 'image' && customBgImage && customBgImage.complete) {
    const imgRatio = customBgImage.naturalWidth / Math.max(1, customBgImage.naturalHeight);
    const outRatio = outW / Math.max(1, outH);
    let dw = outW;
    let dh = outH;
    let dx = 0;
    let dy = 0;
    if (imgRatio > outRatio) {
      dh = outH;
      dw = outH * imgRatio;
      dx = (outW - dw) / 2;
    } else {
      dw = outW;
      dh = outW / imgRatio;
      dy = (outH - dh) / 2;
    }
    outCtx.drawImage(customBgImage, dx, dy, dw, dh);
  }

  // Composite cutout foreground cleanly on top
  outCtx.drawImage(fgCanvas, 0, 0, outW, outH);
  outCtx.restore();
}
