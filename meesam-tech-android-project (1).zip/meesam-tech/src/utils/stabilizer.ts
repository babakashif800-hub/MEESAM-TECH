import { StabilizationOffset, StabilizationSettings } from '../types/editor';

export const DEFAULT_STABILIZATION: StabilizationSettings = {
  enabled: false,
  strength: 75,
  autoScale: 1.0,
  analyzed: false,
  offsets: [],
};

/**
 * Pure block-matching frame translation estimator on grayscale luminance buffers.
 */
export function estimateFrameShift(
  prevLuma: Float32Array,
  currLuma: Float32Array,
  w: number,
  h: number,
  maxShift = 10
): { dx: number; dy: number } {
  const margin = maxShift + 6;
  if (w <= margin * 2 || h <= margin * 2) return { dx: 0, dy: 0 };

  let bestDx = 0;
  let bestDy = 0;
  let bestSad = Infinity;
  const stepX = Math.max(2, Math.floor((w - margin * 2) / 14));
  const stepY = Math.max(2, Math.floor((h - margin * 2) / 10));

  for (let dy = -maxShift; dy <= maxShift; dy += 2) {
    for (let dx = -maxShift; dx <= maxShift; dx += 2) {
      let sad = 0;
      for (let y = margin; y < h - margin; y += stepY) {
        const rowA = y * w;
        const rowB = (y + dy) * w;
        for (let x = margin; x < w - margin; x += stepX) {
          sad += Math.abs(prevLuma[rowA + x] - currLuma[rowB + x + dx]);
        }
      }
      if (sad < bestSad) {
        bestSad = sad;
        bestDx = dx;
        bestDy = dy;
      }
    }
  }

  // Refine 1px around best coarse shift
  const rMinX = Math.max(-maxShift, bestDx - 1);
  const rMaxX = Math.min(maxShift, bestDx + 1);
  const rMinY = Math.max(-maxShift, bestDy - 1);
  const rMaxY = Math.min(maxShift, bestDy + 1);

  for (let dy = rMinY; dy <= rMaxY; dy++) {
    for (let dx = rMinX; dx <= rMaxX; dx++) {
      let sad = 0;
      for (let y = margin; y < h - margin; y += stepY) {
        const rowA = y * w;
        const rowB = (y + dy) * w;
        for (let x = margin; x < w - margin; x += stepX) {
          sad += Math.abs(prevLuma[rowA + x] - currLuma[rowB + x + dx]);
        }
      }
      if (sad < bestSad) {
        bestSad = sad;
        bestDx = dx;
        bestDy = dy;
      }
    }
  }

  return { dx: bestDx, dy: bestDy };
}

/**
 * Pure trajectory smoother: converts raw cumulative camera path into high-pass shake compensation offsets (% of stage)
 * plus safe zoom margin `autoScale` to keep stabilized frame borders free of black edges.
 */
export function smoothCameraTrajectory(
  rawSamples: Array<{ time: number; dxNorm: number; dyNorm: number }>,
  strength = 75
): { offsets: StabilizationOffset[]; autoScale: number } {
  if (rawSamples.length === 0) return { offsets: [], autoScale: 1.0 };

  const cumX: number[] = [];
  const cumY: number[] = [];
  let sx = 0;
  let sy = 0;

  for (let i = 0; i < rawSamples.length; i++) {
    sx += rawSamples[i].dxNorm;
    sy += rawSamples[i].dyNorm;
    cumX.push(sx);
    cumY.push(sy);
  }

  // Gaussian temporal smoothing window
  const windowHalf = 7;
  const smoothScale = Math.max(0, Math.min(1, strength / 100));
  const maxAllowedShiftPct = 8.5;

  const offsets: StabilizationOffset[] = [];
  let maxDeviation = 0;

  for (let i = 0; i < rawSamples.length; i++) {
    let wSum = 0;
    let avgX = 0;
    let avgY = 0;
    for (let j = -windowHalf; j <= windowHalf; j++) {
      const idx = Math.max(0, Math.min(rawSamples.length - 1, i + j));
      const weight = Math.exp(-(j * j) / (2 * 3.2 * 3.2));
      avgX += cumX[idx] * weight;
      avgY += cumY[idx] * weight;
      wSum += weight;
    }
    avgX /= Math.max(1e-6, wSum);
    avgY /= Math.max(1e-6, wSum);

    // Compensation shift removes unwanted high-frequency shake while keeping slow pans
    const compX = Math.max(
      -maxAllowedShiftPct,
      Math.min(maxAllowedShiftPct, (avgX - cumX[i]) * smoothScale)
    );
    const compY = Math.max(
      -maxAllowedShiftPct,
      Math.min(maxAllowedShiftPct, (avgY - cumY[i]) * smoothScale)
    );

    maxDeviation = Math.max(maxDeviation, Math.abs(compX), Math.abs(compY));
    offsets.push({
      time: rawSamples[i].time,
      x: Number(compX.toFixed(3)),
      y: Number(compY.toFixed(3)),
    });
  }

  // Required zoom = 1 + 2 * (maxShiftPct / 100) + tiny 1% safety margin
  const autoScale =
    maxDeviation < 0.1
      ? 1.0
      : Number(Math.min(1.26, 1 + (maxDeviation * 2) / 100 + 0.015).toFixed(3));

  return { offsets, autoScale };
}

/**
 * Analyzes camera shake across frames of a video clip and produces smoothed stabilization compensation offsets.
 */
export async function analyzeVideoStabilization(params: {
  videoUrl: string;
  duration: number;
  strength: number;
  onProgress?: (pct: number) => void;
}): Promise<StabilizationSettings> {
  const { videoUrl, duration, strength, onProgress } = params;
  const video = document.createElement('video');
  video.src = videoUrl;
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error('Video load timed out')), 8000);
      video.onloadeddata = () => {
        window.clearTimeout(timer);
        resolve();
      };
      video.onerror = () => {
        window.clearTimeout(timer);
        reject(new Error('Unable to decode video for stabilization.'));
      };
    });

    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 360;
    const fw = 128;
    const fh = Math.max(64, Math.round((fw / Math.max(1, vw)) * vh));

    const canvas = document.createElement('canvas');
    canvas.width = fw;
    canvas.height = fh;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) throw new Error('Canvas unavailable.');

    const stepFps = duration > 15 ? 8 : 12;
    const totalSamples = Math.max(4, Math.min(180, Math.round(duration * stepFps)));

    const rawSamples: Array<{ time: number; dxNorm: number; dyNorm: number }> = [];
    let prevLuma: Float32Array | null = null;

    const seekFrame = (t: number) =>
      new Promise<void>((resolve) => {
        const safeT = Math.max(0, Math.min(Math.max(0, duration - 0.02), t));
        if (Math.abs(video.currentTime - safeT) < 0.008) {
          resolve();
          return;
        }
        video.addEventListener('seeked', () => resolve(), { once: true });
        video.currentTime = safeT;
      });

    for (let i = 0; i <= totalSamples; i++) {
      const t = (i / totalSamples) * duration;
      await seekFrame(t);
      ctx.drawImage(video, 0, 0, fw, fh);
      const rgba = ctx.getImageData(0, 0, fw, fh).data;
      const luma = new Float32Array(fw * fh);
      for (let p = 0; p < luma.length; p++) {
        const idx = p * 4;
        luma[p] = rgba[idx] * 0.3 + rgba[idx + 1] * 0.59 + rgba[idx + 2] * 0.11;
      }

      if (!prevLuma) {
        rawSamples.push({ time: Number(t.toFixed(3)), dxNorm: 0, dyNorm: 0 });
      } else {
        const { dx, dy } = estimateFrameShift(prevLuma, luma, fw, fh, 10);
        rawSamples.push({
          time: Number(t.toFixed(3)),
          dxNorm: (dx / fw) * 100,
          dyNorm: (dy / fh) * 100,
        });
      }
      prevLuma = luma;
      onProgress?.(Math.round((i / totalSamples) * 100));
    }

    const { offsets, autoScale } = smoothCameraTrajectory(rawSamples, strength);
    return {
      enabled: true,
      strength,
      autoScale,
      analyzed: true,
      offsets,
    };
  } finally {
    video.removeAttribute('src');
    video.load();
  }
}

export function evaluateStabilization(
  stab: StabilizationSettings | undefined,
  time: number
): { x: number; y: number; scale: number } {
  if (!stab || !stab.enabled || !stab.analyzed || stab.offsets.length === 0) {
    return { x: 0, y: 0, scale: 1 };
  }
  const scaleFactor = Math.max(0, Math.min(1, stab.strength / 100));
  const autoScale = 1 + (stab.autoScale - 1) * scaleFactor;
  const pts = stab.offsets;
  if (time <= pts[0].time) {
    return { x: pts[0].x * scaleFactor, y: pts[0].y * scaleFactor, scale: autoScale };
  }
  const last = pts[pts.length - 1];
  if (time >= last.time) {
    return { x: last.x * scaleFactor, y: last.y * scaleFactor, scale: autoScale };
  }

  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (time >= a.time && time <= b.time) {
      const span = b.time - a.time;
      const t = span > 1e-6 ? (time - a.time) / span : 0;
      return {
        x: (a.x + (b.x - a.x) * t) * scaleFactor,
        y: (a.y + (b.y - a.y) * t) * scaleFactor,
        scale: autoScale,
      };
    }
  }
  return { x: 0, y: 0, scale: 1 };
}
