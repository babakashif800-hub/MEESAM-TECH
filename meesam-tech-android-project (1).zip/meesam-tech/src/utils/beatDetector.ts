import { BeatAnalysis, TimelineSegment } from '../types/editor';

/**
 * Pure PCM beat onset detector using short-window energy flux and adaptive local thresholding.
 */
export function detectBeatsFromPcm(
  samples: Float32Array,
  sampleRate: number,
  sensitivity = 0.55,
  timeOffsetSec = 0,
  maxTimeSec = Infinity
): { bpm: number; beats: number[] } {
  if (!samples || samples.length === 0 || sampleRate <= 0) {
    return { bpm: 0, beats: [] };
  }

  const hopSamples = Math.max(128, Math.round(sampleRate * 0.02)); // 20ms hop -> 50 Hz envelope
  const windowCount = Math.floor(samples.length / hopSamples);
  if (windowCount < 6) return { bpm: 0, beats: [] };

  // Compute low-pass bass-emphasized energy per 20ms hop (1-pole filter emphasizes drums/transients)
  const energies = new Float32Array(windowCount);
  let lp = 0;
  const alpha = 0.08;
  for (let w = 0; w < windowCount; w++) {
    const start = w * hopSamples;
    const end = Math.min(samples.length, start + hopSamples);
    let sumSq = 0;
    for (let i = start; i < end; i++) {
      lp += alpha * (samples[i] - lp);
      const val = samples[i] * 0.35 + lp * 0.65;
      sumSq += val * val;
    }
    energies[w] = Math.sqrt(sumSq / Math.max(1, end - start));
  }

  // Positive onset flux envelope (half-wave rectified derivative)
  const flux = new Float32Array(windowCount);
  for (let w = 1; w < windowCount; w++) {
    flux[w] = Math.max(0, energies[w] - energies[w - 1]);
  }

  // Adaptive local threshold over ~0.7s neighborhood
  const localRadius = 18;
  const sensMultiplier = 2.6 - Math.max(0.15, Math.min(0.95, sensitivity)) * 1.45; // higher sensitivity => lower threshold
  const minPeakGapSec = 0.24; // up to ~250 BPM max

  let maxEnergy = 0;
  for (let w = 0; w < windowCount; w++) {
    if (energies[w] > maxEnergy) maxEnergy = energies[w];
  }
  const noiseFloor = maxEnergy * 0.08;

  const beats: number[] = [];
  let lastBeatTime = -minPeakGapSec;

  for (let w = 2; w < windowCount - 1; w++) {
    const score = flux[w] * 0.7 + energies[w] * 0.3;
    const prevScore = flux[w - 1] * 0.7 + energies[w - 1] * 0.3;
    const nextScore = flux[w + 1] * 0.7 + energies[w + 1] * 0.3;
    if (score < prevScore || score < nextScore) continue;
    if (energies[w] < noiseFloor) continue;

    let sumFlux = 0;
    let count = 0;
    const lo = Math.max(0, w - localRadius);
    const hi = Math.min(windowCount - 1, w + localRadius);
    for (let k = lo; k <= hi; k++) {
      sumFlux += flux[k] * 0.7 + energies[k] * 0.3;
      count += 1;
    }
    const localAvg = sumFlux / Math.max(1, count);
    if (score < localAvg * sensMultiplier) continue;

    const tSec = timeOffsetSec + (w * hopSamples) / sampleRate;
    if (tSec > maxTimeSec) break;
    if (tSec - lastBeatTime >= minPeakGapSec) {
      beats.push(Number(tSec.toFixed(3)));
      lastBeatTime = tSec;
    }
  }

  // Estimate dominant BPM from inter-beat intervals
  let bpm = 0;
  if (beats.length >= 2) {
    const intervals: number[] = [];
    for (let i = 1; i < beats.length; i++) {
      const dt = beats[i] - beats[i - 1];
      if (dt >= 0.25 && dt <= 1.8) {
        intervals.push(dt);
      }
    }
    if (intervals.length > 0) {
      intervals.sort((a, b) => a - b);
      const medianDt = intervals[Math.floor(intervals.length / 2)];
      bpm = Math.round(60 / medianDt);
      while (bpm > 180) bpm = Math.round(bpm / 2);
      while (bpm > 0 && bpm < 60) bpm = Math.round(bpm * 2);
    }
  }

  return { bpm, beats };
}

/**
 * Decodes audio from an audio layer or main video and returns detected beats + BPM.
 */
export async function analyzeAudioBeats(params: {
  mediaUrl: string;
  sensitivity: number;
  sourceId: string;
  sourceName: string;
  startOffsetSec?: number;
  projectDuration: number;
}): Promise<BeatAnalysis> {
  const {
    mediaUrl,
    sensitivity,
    sourceId,
    sourceName,
    startOffsetSec = 0,
    projectDuration,
  } = params;

  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) {
    throw new Error('Web Audio API is unavailable in this browser.');
  }

  const audioCtx = new AudioContextClass();
  try {
    const resp = await fetch(mediaUrl);
    const arr = await resp.arrayBuffer();
    const decoded = await audioCtx.decodeAudioData(arr);
    if (!decoded || decoded.numberOfChannels === 0) {
      throw new Error('No playable audio stream found for beat detection.');
    }

    // Mix down to mono PCM
    const len = decoded.length;
    const mono = new Float32Array(len);
    const chCount = decoded.numberOfChannels;
    for (let ch = 0; ch < chCount; ch++) {
      const chData = decoded.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        mono[i] += chData[i] / chCount;
      }
    }

    const { bpm, beats } = detectBeatsFromPcm(
      mono,
      decoded.sampleRate,
      sensitivity,
      startOffsetSec,
      projectDuration
    );

    return {
      bpm,
      beats,
      sensitivity,
      sourceId,
      sourceName,
    };
  } finally {
    audioCtx.close().catch(() => {});
  }
}

/**
 * Splits active timeline segments along every Nth detected beat timestamp so clips cut cleanly on music beats.
 */
export function splitSegmentsOnBeats(
  segments: TimelineSegment[],
  beats: number[],
  beatStep: 1 | 2 | 4,
  makeId: () => string,
  minSegDuration = 0.25
): TimelineSegment[] {
  const selectedBeats = beats.filter((_, idx) => idx % beatStep === 0);
  if (selectedBeats.length === 0) return segments;

  const result: TimelineSegment[] = [];
  for (const seg of segments) {
    if (seg.deleted || seg.end - seg.start < minSegDuration * 2) {
      result.push(seg);
      continue;
    }

    const interiorCuts: number[] = [];
    let lastBound = seg.start;
    for (const b of selectedBeats) {
      if (b - lastBound >= minSegDuration && seg.end - b >= minSegDuration) {
        interiorCuts.push(Number(b.toFixed(3)));
        lastBound = b;
      }
    }

    if (interiorCuts.length === 0) {
      result.push(seg);
      continue;
    }

    let cursor = seg.start;
    interiorCuts.forEach((cut, idx) => {
      result.push({
        id: idx === 0 ? seg.id : makeId(),
        start: cursor,
        end: cut,
        deleted: false,
        meta: seg.meta ? { ...seg.meta } : undefined,
      });
      cursor = cut;
    });
    result.push({
      id: makeId(),
      start: cursor,
      end: seg.end,
      deleted: false,
      meta: seg.meta ? { ...seg.meta } : undefined,
    });
  }

  return result;
}
