import { MaskSettings } from '../types/editor';

export const DEFAULT_MASK_SETTINGS: MaskSettings = {
  shape: 'none',
  x: 0,
  y: 0,
  width: 65,
  height: 65,
  rotation: 0,
  feather: 6,
  invert: false,
};

/**
 * Generates an offscreen alpha mask matching the preview's SVG mask geometry, rotation, feather, and invert flag,
 * then composites it onto the main target canvas using `destination-in` or `destination-out`.
 */
export function applyMaskToCanvas(
  targetCtx: CanvasRenderingContext2D,
  sourceCanvas: HTMLCanvasElement,
  maskCanvas: HTMLCanvasElement,
  canvasW: number,
  canvasH: number,
  mask: MaskSettings
): void {
  if (!mask || mask.shape === 'none') {
    targetCtx.drawImage(sourceCanvas, 0, 0, canvasW, canvasH);
    return;
  }

  if (maskCanvas.width !== canvasW) maskCanvas.width = canvasW;
  if (maskCanvas.height !== canvasH) maskCanvas.height = canvasH;
  const mCtx = maskCanvas.getContext('2d');
  if (!mCtx) {
    targetCtx.drawImage(sourceCanvas, 0, 0, canvasW, canvasH);
    return;
  }

  // First draw the filtered/masked video content onto sourceCanvas, then draw it clipped to targetCtx
  mCtx.save();
  mCtx.clearRect(0, 0, canvasW, canvasH);

  // Build white alpha shape in maskCanvas
  const scaleFactor = Math.min(canvasW, canvasH) / 420;
  const blurPx = Math.max(0, mask.feather * scaleFactor);

  mCtx.filter = blurPx > 0.4 ? `blur(${blurPx.toFixed(1)}px)` : 'none';
  mCtx.fillStyle = '#ffffff';

  const cx = canvasW * (0.5 + mask.x / 100);
  const cy = canvasH * (0.5 + mask.y / 100);
  const rw = Math.max(8, (mask.width / 100) * canvasW);
  const rh = Math.max(8, (mask.height / 100) * canvasH);

  mCtx.translate(cx, cy);
  if (mask.rotation !== 0) {
    mCtx.rotate((mask.rotation * Math.PI) / 180);
  }

  if (mask.shape === 'rect') {
    mCtx.fillRect(-rw / 2, -rh / 2, rw, rh);
  } else if (mask.shape === 'circle') {
    mCtx.beginPath();
    mCtx.ellipse(0, 0, rw / 2, rh / 2, 0, 0, Math.PI * 2);
    mCtx.fill();
  } else if (mask.shape === 'split') {
    // Half-plane split mask (reveals upper half above center line)
    const span = Math.max(canvasW, canvasH) * 2.5;
    mCtx.fillRect(-span / 2, -span, span, span);
  } else if (mask.shape === 'linear') {
    // Adjustable strip filmstrip mask
    const span = Math.max(canvasW, canvasH) * 2.5;
    mCtx.fillRect(-span / 2, -rh / 2, span, rh);
  }
  mCtx.restore();

  // Apply mask alpha onto sourceCanvas cleanly
  const sCtx = sourceCanvas.getContext('2d');
  if (sCtx) {
    sCtx.save();
    sCtx.globalCompositeOperation = mask.invert ? 'destination-out' : 'destination-in';
    sCtx.drawImage(maskCanvas, 0, 0, canvasW, canvasH);
    sCtx.restore();
  }

  targetCtx.drawImage(sourceCanvas, 0, 0, canvasW, canvasH);
}
