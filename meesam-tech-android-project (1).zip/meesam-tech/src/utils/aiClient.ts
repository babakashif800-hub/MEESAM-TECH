import {
  AiEditMode,
  AiEditResult,
  CaptionLanguage,
  TargetLanguageCode,
  TextOverlay,
  TextStylePreset,
  TtsGenerationMode,
  TtsVoiceName,
  VideoAsset,
} from '../types/editor';
import { analyzeClipActivityWindows } from './autoCut';
import { FILTER_PRESETS } from './filters';

interface CapturedFrame {
  timestampSec: number;
  mimeType: 'image/jpeg';
  data: string;
}

function getApiUrl(endpoint: string): string {
  const customBase =
    (typeof window !== 'undefined' &&
      (window as unknown as { __MEESAM_API_BASE__?: string }).__MEESAM_API_BASE__) ||
    (import.meta.env.VITE_API_BASE_URL as string | undefined) ||
    '';
  const cleanBase = customBase.trim().replace(/\/+$/, '');
  return cleanBase ? `${cleanBase}${endpoint}` : endpoint;
}

/**
 * Captures evenly spaced compact JPEG frames from the uploaded video for AI visual analysis.
 * Attaches an offscreen hidden video element briefly so mobile Chrome/Android decoders never stall.
 */
async function captureFramesForAi(
  videoUrl: string,
  duration: number,
  count = 5
): Promise<CapturedFrame[]> {
  if (!Number.isFinite(duration) || duration <= 0) return [];

  return new Promise((resolve) => {
    const wrapper = document.createElement('div');
    wrapper.style.position = 'fixed';
    wrapper.style.left = '-9999px';
    wrapper.style.top = '0';
    wrapper.style.width = '2px';
    wrapper.style.height = '2px';
    wrapper.style.opacity = '0.01';
    wrapper.style.pointerEvents = 'none';
    wrapper.setAttribute('aria-hidden', 'true');

    const video = document.createElement('video');
    video.src = videoUrl;
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';
    wrapper.appendChild(video);
    document.body.appendChild(wrapper);

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const frames: CapturedFrame[] = [];
    let index = 0;
    let settled = false;
    let startedCapture = false;
    let perSeekTimer: number | null = null;

    const finish = () => {
      if (settled) return;
      settled = true;
      if (perSeekTimer !== null) window.clearTimeout(perSeekTimer);
      window.clearTimeout(overallTimer);
      video.removeAttribute('src');
      video.load();
      wrapper.remove();
      resolve(frames);
    };

    const overallTimer = window.setTimeout(finish, 8000);

    video.addEventListener('error', finish);

    const startSeeking = () => {
      if (startedCapture || settled) return;
      startedCapture = true;
      const vw = video.videoWidth || 640;
      const vh = video.videoHeight || 360;
      const scale = Math.min(1, 448 / Math.max(vw, vh));
      canvas.width = Math.max(160, Math.round(vw * scale));
      canvas.height = Math.max(90, Math.round(vh * scale));

      const grabFrame = () => {
        try {
          if (ctx && video.readyState >= 2) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.68);
            const commaIdx = dataUrl.indexOf(',');
            if (commaIdx !== -1) {
              frames.push({
                timestampSec: Number(video.currentTime.toFixed(2)),
                mimeType: 'image/jpeg',
                data: dataUrl.slice(commaIdx + 1),
              });
            }
          }
        } catch {
          // Ignore single frame capture issues
        }
      };

      const seekNext = () => {
        if (settled) return;
        if (perSeekTimer !== null) {
          window.clearTimeout(perSeekTimer);
          perSeekTimer = null;
        }
        if (index >= count) {
          finish();
          return;
        }
        const t = Math.min(
          Math.max(0.05, ((index + 0.5) / count) * duration),
          Math.max(0.05, duration - 0.05)
        );
        perSeekTimer = window.setTimeout(() => {
          grabFrame();
          index += 1;
          seekNext();
        }, 1400);
        try {
          video.currentTime = t;
        } catch {
          grabFrame();
          index += 1;
          seekNext();
        }
      };

      video.addEventListener('seeked', () => {
        grabFrame();
        index += 1;
        seekNext();
      });

      seekNext();
    };

    video.addEventListener('loadeddata', startSeeking);
    video.addEventListener('canplay', startSeeking);
    if (video.readyState >= 2) {
      startSeeking();
    }
  });
}

function encodeMonoWavBase64(samples: Float32Array, sampleRate: number): string {
  const numSamples = samples.length;
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += 2;
  }

  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function normalizeSpeechPcm(pcm: Float32Array): Float32Array | null {
  let peak = 0;
  for (let i = 0; i < pcm.length; i += 8) {
    const a = Math.abs(pcm[i]);
    if (a > peak) peak = a;
  }
  if (peak < 0.0004) {
    return null;
  }
  if (peak >= 0.35) {
    return pcm;
  }
  const gain = Math.min(8, 0.72 / peak);
  const boosted = new Float32Array(pcm.length);
  for (let i = 0; i < pcm.length; i++) {
    boosted[i] = Math.max(-1, Math.min(1, pcm[i] * gain));
  }
  return boosted;
}

function downsampleLinear(samples: Float32Array, fromRate: number, toRate: number): Float32Array {
  if (fromRate === toRate || samples.length === 0) return samples;
  const ratio = fromRate / toRate;
  const outLen = Math.max(1, Math.floor(samples.length / ratio));
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const pos = i * ratio;
    const idx = Math.floor(pos);
    const frac = pos - idx;
    const a = samples[idx] ?? 0;
    const b = samples[Math.min(samples.length - 1, idx + 1)] ?? a;
    out[i] = a + (b - a) * frac;
  }
  return out;
}

/**
 * Fallback audio capture for large (>140MB) or codec-restricted videos when decodeAudioData fails.
 * Plays through a zero-gain Web Audio node so speakers stay silent while capturing clean PCM speech.
 */
async function captureAudioViaElementFallback(
  mediaUrl: string,
  maxSeconds = 40
): Promise<{ mimeType: 'audio/wav'; data: string } | null> {
  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;

  return new Promise((resolve) => {
    const wrapper = document.createElement('div');
    wrapper.style.position = 'fixed';
    wrapper.style.left = '-9999px';
    wrapper.style.width = '2px';
    wrapper.style.height = '2px';
    wrapper.style.opacity = '0.01';
    wrapper.setAttribute('aria-hidden', 'true');

    const video = document.createElement('video');
    video.src = mediaUrl;
    video.playsInline = true;
    video.muted = false;
    video.volume = 1;
    video.preload = 'auto';
    wrapper.appendChild(video);
    document.body.appendChild(wrapper);

    let audioCtx: AudioContext | null = null;
    let settled = false;
    const chunks: Float32Array[] = [];
    let totalSamples = 0;
    let safetyTimer = 0;

    const cleanup = (result: { mimeType: 'audio/wav'; data: string } | null) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(safetyTimer);
      try {
        video.pause();
        video.removeAttribute('src');
        video.load();
      } catch {
        // Ignore
      }
      wrapper.remove();
      if (audioCtx) {
        audioCtx.close().catch(() => {});
      }
      resolve(result);
    };

    const finalizeChunks = (nativeRate: number) => {
      if (totalSamples < 1000) {
        cleanup(null);
        return;
      }
      const merged = new Float32Array(totalSamples);
      let off = 0;
      for (const ch of chunks) {
        merged.set(ch, off);
        off += ch.length;
      }
      const resampled = downsampleLinear(merged, nativeRate, 11025);
      const normalized = normalizeSpeechPcm(resampled);
      if (!normalized) {
        cleanup(null);
        return;
      }
      const b64 = encodeMonoWavBase64(normalized, 11025);
      if (b64.length > 5_000_000) {
        cleanup(null);
        return;
      }
      cleanup({ mimeType: 'audio/wav', data: b64 });
    };

    video.addEventListener('error', () => cleanup(null));

    video.addEventListener(
      'loadedmetadata',
      async () => {
        try {
          audioCtx = new AudioContextClass();
          if (audioCtx.state === 'suspended') {
            await audioCtx.resume().catch(() => {});
          }
          const nativeRate = audioCtx.sampleRate || 44100;
          const source = audioCtx.createMediaElementSource(video);
          const processor = audioCtx.createScriptProcessor(4096, 1, 1);
          const zeroGain = audioCtx.createGain();
          zeroGain.gain.value = 0;

          processor.onaudioprocess = (ev) => {
            if (settled) return;
            const input = ev.inputBuffer.getChannelData(0);
            const copy = new Float32Array(input.length);
            copy.set(input);
            chunks.push(copy);
            totalSamples += copy.length;
          };

          source.connect(processor);
          processor.connect(zeroGain);
          zeroGain.connect(audioCtx.destination);

          const clipLimit = Math.min(video.duration || maxSeconds, maxSeconds);

          safetyTimer = window.setTimeout(
            () => finalizeChunks(nativeRate),
            Math.ceil(clipLimit * 1000) + 2500
          );

          video.addEventListener('ended', () => finalizeChunks(nativeRate));
          video.addEventListener('timeupdate', () => {
            if (video.currentTime >= clipLimit - 0.05) {
              finalizeChunks(nativeRate);
            }
          });

          await video.play();
        } catch {
          cleanup(null);
        }
      },
      { once: true }
    );
  });
}

/**
 * Extracts a compact mono WAV slice for AI Speech-to-Text and Auto Captions.
 * Uses fast direct decodeAudioData first; falls back to muted element capture for >140MB or exotic codecs.
 */
export async function extractCompactWavForAi(
  mediaUrl: string,
  maxSeconds = 45,
  sourceFile?: File
): Promise<{ mimeType: 'audio/wav'; data: string } | null> {
  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;

  const shouldTryDirectDecode = !sourceFile || sourceFile.size <= 140 * 1024 * 1024;
  let audioCtx: AudioContext | null = null;

  if (shouldTryDirectDecode) {
    try {
      const arrBuf = sourceFile
        ? await sourceFile.arrayBuffer()
        : await (await fetch(mediaUrl)).arrayBuffer();

      if (arrBuf.byteLength <= 140 * 1024 * 1024) {
        audioCtx = new AudioContextClass();
        const decoded = await audioCtx.decodeAudioData(arrBuf);
        if (decoded && decoded.duration > 0.15 && decoded.numberOfChannels > 0) {
          const renderWav = async (targetRate: number, clipLimitSec: number) => {
            const clipSec = Math.min(decoded.duration, clipLimitSec);
            const outSamples = Math.max(1, Math.floor(clipSec * targetRate));
            const offline = new OfflineAudioContext(1, outSamples, targetRate);
            const src = offline.createBufferSource();
            src.buffer = decoded;
            src.connect(offline.destination);
            src.start(0, 0, clipSec);
            const rendered = await offline.startRendering();
            const normalized = normalizeSpeechPcm(rendered.getChannelData(0));
            if (!normalized) return null;
            return encodeMonoWavBase64(normalized, targetRate);
          };

          let base64Wav = await renderWav(16000, maxSeconds);
          if (!base64Wav) {
            return null;
          }
          if (base64Wav.length > 5_000_000) {
            base64Wav = await renderWav(11025, maxSeconds);
          }
          if (base64Wav && base64Wav.length > 5_000_000) {
            base64Wav = await renderWav(11025, 45);
          }
          if (base64Wav && base64Wav.length <= 5_000_000) {
            return { mimeType: 'audio/wav', data: base64Wav };
          }
        }
      }
    } catch {
      // Fall through to media element capture fallback
    } finally {
      if (audioCtx) {
        audioCtx.close().catch(() => {});
      }
    }
  }

  return captureAudioViaElementFallback(mediaUrl, Math.min(maxSeconds, 40));
}

export async function requestAiStudioEdit(params: {
  asset: VideoAsset;
  mode: AiEditMode;
  prompt?: string;
  language?: CaptionLanguage;
  captionStyle?: TextStylePreset;
  captionColor?: string;
}): Promise<AiEditResult> {
  const isImage = params.asset.mediaKind === 'image';

  if (params.mode === 'auto_captions' && isImage) {
    throw new Error('Auto Captions requires a video with spoken audio.');
  }

  let frames: CapturedFrame[] = [];
  let audio: { mimeType: 'audio/wav'; data: string } | undefined;

  if (params.mode === 'auto_captions') {
    const [wav, capturedFrames] = await Promise.all([
      extractCompactWavForAi(params.asset.url, 90, params.asset.file),
      captureFramesForAi(params.asset.url, params.asset.duration, 2).catch(() => []),
    ]);
    if (!wav) {
      throw new Error(
        'No spoken audio track was found in this video. Please upload a video with clear sound.'
      );
    }
    audio = wav;
    frames = capturedFrames;
  } else {
    const frameCount = params.mode === 'smart_filters' ? 3 : params.mode === 'auto_cut' ? 6 : 5;
    frames = isImage
      ? []
      : await captureFramesForAi(params.asset.url, params.asset.duration, frameCount);

    if (frames.length === 0 && !isImage) {
      throw new Error('Could not read video frames for AI analysis.');
    }

    if (params.mode === 'custom_prompt' || params.mode === 'auto_cut') {
      const wav = await extractCompactWavForAi(params.asset.url, 45, params.asset.file);
      if (wav) audio = wav;
    }
  }

  let activityHints: Array<{ startTime: number; endTime: number; score: number }> | undefined;
  if (params.mode === 'auto_cut') {
    activityHints = await analyzeClipActivityWindows(
      params.asset.url,
      params.asset.duration
    ).catch(() => undefined);
  }

  let response: Response;
  try {
    response = await fetch(getApiUrl('/api/ai-edit'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(45000),
      body: JSON.stringify({
        mode: params.mode,
        duration: params.asset.duration,
        width: params.asset.width,
        height: params.asset.height,
        prompt: params.prompt ?? '',
        language: params.language ?? 'auto',
        captionStyle: params.captionStyle ?? 'subtitle-bar',
        captionColor: params.captionColor,
        frames,
        audio,
        activityHints,
        availableFilters:
          params.mode === 'auto_captions'
            ? []
            : FILTER_PRESETS.map((f) => ({
                id: f.id,
                label: f.label,
                category: f.category,
              })),
      }),
    });
  } catch (err) {
    if (err instanceof Error && err.name === 'TimeoutError') {
      throw new Error('AI server timed out. Please try again with a shorter clip.');
    }
    throw new Error('Network error while contacting AI server. Please try again.');
  }

  const payload = (await response.json().catch(() => ({}))) as AiEditResult & {
    error?: string;
  };

  if (!response.ok) {
    throw new Error(payload.error || 'AI Studio request failed.');
  }

  return payload;
}

export async function requestSpeechToText(params: {
  mediaUrl: string;
  language: CaptionLanguage;
}): Promise<{ text: string; language: string }> {
  const wav = await extractCompactWavForAi(params.mediaUrl, 45);
  if (!wav) {
    throw new Error('No clear speech audio track found to transcribe.');
  }

  const response = await fetch(getApiUrl('/api/speech-to-text'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal: AbortSignal.timeout(30000),
    body: JSON.stringify({
      audio: wav,
      language: params.language,
    }),
  });

  const payload = (await response.json().catch(() => ({}))) as {
    text?: string;
    language?: string;
    error?: string;
  };

  if (!response.ok || !payload.text) {
    throw new Error(payload.error || 'Speech-to-Text failed.');
  }

  return {
    text: payload.text,
    language: payload.language ?? params.language,
  };
}

export async function requestTranslation(params: {
  texts: string[];
  targetLanguage: TargetLanguageCode;
}): Promise<string[]> {
  let response: Response;
  try {
    response = await fetch(getApiUrl('/api/translate'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(30000),
      body: JSON.stringify({
        texts: params.texts,
        targetLanguage: params.targetLanguage,
      }),
    });
  } catch (err) {
    if (err instanceof Error && err.name === 'TimeoutError') {
      throw new Error('Translation timed out. Please try again.');
    }
    throw new Error('Network error during translation. Please try again.');
  }

  const payload = (await response.json().catch(() => ({}))) as {
    translations?: string[];
    error?: string;
  };

  if (!response.ok || !Array.isArray(payload.translations)) {
    throw new Error(payload.error || 'Translation request failed.');
  }

  return payload.translations;
}

function parseWavDurationSeconds(bytes: Uint8Array): number | null {
  try {
    if (bytes.length < 44) return null;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const riff =
      String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) === 'RIFF' &&
      String.fromCharCode(bytes[8], bytes[9], bytes[10], bytes[11]) === 'WAVE';
    if (!riff) return null;
    let offset = 12;
    let byteRate = 0;
    while (offset + 8 <= bytes.length) {
      const id = String.fromCharCode(
        bytes[offset],
        bytes[offset + 1],
        bytes[offset + 2],
        bytes[offset + 3]
      );
      const size = view.getUint32(offset + 4, true);
      if (id === 'fmt ' && offset + 20 <= bytes.length) {
        byteRate = view.getUint32(offset + 16, true);
      } else if (id === 'data' && byteRate > 0) {
        return Math.max(0.2, size / byteRate);
      }
      offset += 8 + size + (size % 2);
    }
  } catch {
    return null;
  }
  return null;
}

export async function requestAiTtsVoice(params: {
  text: string;
  language: TargetLanguageCode;
  voiceName: TtsVoiceName;
  voiceGender?: 'female' | 'male';
  voiceMode: TtsGenerationMode;
  stylePrompt?: string;
}): Promise<{
  blobUrl: string;
  duration: number;
  mimeType: string;
  model: string;
}> {
  let response: Response;
  try {
    response = await fetch(getApiUrl('/api/tts'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(45000),
      body: JSON.stringify(params),
    });
  } catch (err) {
    if (err instanceof Error && err.name === 'TimeoutError') {
      throw new Error('Voice generation timed out. Try shorter text or try again.');
    }
    throw new Error('Could not reach the AI Voice server. Please check your connection.');
  }

  const payload = (await response.json().catch(() => ({}))) as {
    audioBase64?: string;
    mimeType?: string;
    model?: string;
    error?: string;
  };

  if (!response.ok || !payload.audioBase64) {
    throw new Error(payload.error || 'AI Voice generation failed.');
  }

  const binaryStr = atob(payload.audioBase64);
  const bytes = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) {
    bytes[i] = binaryStr.charCodeAt(i);
  }
  const mimeType = payload.mimeType || 'audio/wav';
  const wavDuration = parseWavDurationSeconds(bytes);
  const blob = new Blob([bytes], { type: mimeType });
  const blobUrl = URL.createObjectURL(blob);

  const duration =
    wavDuration && Number.isFinite(wavDuration)
      ? wavDuration
      : await new Promise<number>((resolve) => {
          const aud = new Audio();
          aud.preload = 'metadata';
          aud.src = blobUrl;
          aud.onloadedmetadata = () => {
            resolve(Number.isFinite(aud.duration) && aud.duration > 0 ? aud.duration : 3);
          };
          aud.onerror = () => resolve(3);
        });

  return {
    blobUrl,
    duration,
    mimeType,
    model: payload.model ?? 'gemini-3.8-flash-lite-tts',
  };
}

function formatSrtTimestamp(seconds: number): string {
  const safe = Math.max(0, seconds);
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = Math.floor(safe % 60);
  const ms = Math.round((safe - Math.floor(safe)) * 1000);
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(
    secs
  ).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

export function buildSrtContent(items: TextOverlay[]): string {
  const sorted = [...items]
    .filter((i) => i.text.trim().length > 0)
    .sort((a, b) => a.startTime - b.startTime);

  return sorted
    .map(
      (item, idx) =>
        `${idx + 1}\n${formatSrtTimestamp(item.startTime)} --> ${formatSrtTimestamp(
          Math.max(item.startTime + 0.1, item.endTime)
        )}\n${item.text.trim()}\n`
    )
    .join('\n');
}
