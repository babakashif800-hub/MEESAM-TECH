import { ClipTransition, TimelineSegment, TransitionType } from '../types/editor';

export interface TransitionPresetMeta {
  type: TransitionType;
  label: string;
  description: string;
}

export const TRANSITION_PRESETS: TransitionPresetMeta[] = [
  { type: 'none', label: 'Cut (None)', description: 'Direct hard cut' },
  { type: 'fade', label: 'Fade Black', description: 'Smooth dip from black' },
  { type: 'dissolve', label: 'Cross Dissolve', description: 'Blend from previous clip' },
  { type: 'wipe-left', label: 'Wipe Left', description: 'Reveal left-to-right' },
  { type: 'wipe-right', label: 'Wipe Right', description: 'Reveal right-to-left' },
  { type: 'slide-up', label: 'Slide Up', description: 'Push up over previous clip' },
  { type: 'zoom', label: 'Zoom In', description: 'Dynamic scale-in entry' },
];

export const DEFAULT_TRANSITION: ClipTransition = {
  type: 'none',
  duration: 0.6,
};

/**
 * Computes normalized transition progress [0..1] when inside a segment's entry transition window.
 * Returns null if no transition is active at `sourceTime`.
 */
export function getTransitionProgress(
  seg: TimelineSegment | undefined,
  sourceTime: number
): { type: TransitionType; progress: number } | null {
  if (!seg || seg.deleted) return null;
  const tr = seg.meta?.transition;
  if (!tr || tr.type === 'none' || tr.duration <= 0.05) return null;

  const segSpan = Math.max(0.05, seg.end - seg.start);
  const effDur = Math.min(tr.duration, segSpan * 0.75);
  const elapsed = sourceTime - seg.start;
  if (elapsed < -0.01 || elapsed >= effDur) return null;

  const raw = Math.max(0, Math.min(1, elapsed / effDur));
  // Smooth cubic ease-out for clean visual motion
  const eased = 1 - Math.pow(1 - raw, 2.2);
  return { type: tr.type, progress: eased };
}

/**
 * Draws a clip entry transition onto the export canvas using the outgoing clip's final frame (when available).
 */
export function applyExportCanvasTransition(
  ctx: CanvasRenderingContext2D,
  incomingCanvas: HTMLCanvasElement,
  outgoingCanvas: HTMLCanvasElement | null,
  hasOutgoingFrame: boolean,
  width: number,
  height: number,
  type: TransitionType,
  progress: number
): void {
  const p = Math.max(0, Math.min(1, progress));
  ctx.save();
  ctx.filter = 'none';

  if (type === 'fade') {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);
    ctx.globalAlpha = p;
    ctx.drawImage(incomingCanvas, 0, 0, width, height);
    ctx.restore();
    return;
  }

  if (type === 'dissolve') {
    if (hasOutgoingFrame && outgoingCanvas) {
      ctx.drawImage(outgoingCanvas, 0, 0, width, height);
    } else {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
    ctx.globalAlpha = p;
    ctx.drawImage(incomingCanvas, 0, 0, width, height);
    ctx.restore();
    return;
  }

  if (type === 'wipe-left') {
    if (hasOutgoingFrame && outgoingCanvas) {
      ctx.drawImage(outgoingCanvas, 0, 0, width, height);
    } else {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
    const revealW = Math.max(1, width * p);
    ctx.beginPath();
    ctx.rect(0, 0, revealW, height);
    ctx.clip();
    ctx.drawImage(incomingCanvas, 0, 0, width, height);
    ctx.restore();
    return;
  }

  if (type === 'wipe-right') {
    if (hasOutgoingFrame && outgoingCanvas) {
      ctx.drawImage(outgoingCanvas, 0, 0, width, height);
    } else {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
    const revealW = Math.max(1, width * p);
    const startX = width - revealW;
    ctx.beginPath();
    ctx.rect(startX, 0, revealW, height);
    ctx.clip();
    ctx.drawImage(incomingCanvas, 0, 0, width, height);
    ctx.restore();
    return;
  }

  if (type === 'slide-up') {
    if (hasOutgoingFrame && outgoingCanvas) {
      ctx.drawImage(outgoingCanvas, 0, 0, width, height);
    } else {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
    const offsetY = (1 - p) * height;
    ctx.drawImage(incomingCanvas, 0, offsetY, width, height);
    ctx.restore();
    return;
  }

  if (type === 'zoom') {
    if (hasOutgoingFrame && outgoingCanvas) {
      ctx.drawImage(outgoingCanvas, 0, 0, width, height);
    } else {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }
    const scale = 0.72 + 0.28 * p;
    ctx.globalAlpha = Math.min(1, p * 1.15);
    ctx.translate(width / 2, height / 2);
    ctx.scale(scale, scale);
    ctx.drawImage(incomingCanvas, -width / 2, -height / 2, width, height);
    ctx.restore();
    return;
  }

  ctx.drawImage(incomingCanvas, 0, 0, width, height);
  ctx.restore();
}

/**
 * Computes audio volume multiplier [0..1] for segment or audio layer fade-in / fade-out envelopes.
 */
export function computeAudioFadeMultiplier(
  elapsedSec: number,
  clipSpanSec: number,
  fadeInSec = 0,
  fadeOutSec = 0
): number {
  const safeSpan = Math.max(0.05, clipSpanSec);
  const fIn = Math.max(0, Math.min(fadeInSec, safeSpan * 0.5));
  const fOut = Math.max(0, Math.min(fadeOutSec, safeSpan * 0.5));
  let mult = 1;
  if (fIn > 0.01 && elapsedSec < fIn) {
    mult *= Math.max(0, Math.min(1, elapsedSec / fIn));
  }
  const remaining = safeSpan - elapsedSec;
  if (fOut > 0.01 && remaining < fOut) {
    mult *= Math.max(0, Math.min(1, remaining / fOut));
  }
  return mult;
}
