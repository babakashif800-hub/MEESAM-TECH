import { EffectCategory, VideoEffectId } from '../types/editor';

export interface VideoEffectDefinition {
  id: VideoEffectId;
  label: string;
  category: Exclude<EffectCategory, 'all'>;
  swatch: [string, string];
  defaultIntensity: number; // 0..100
  defaultSpeed: number; // 0..100
  speedLabel: string;
}

export const EFFECT_CATEGORIES: Array<{ id: EffectCategory; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'blur', label: 'Blur' },
  { id: '3d', label: '3D' },
  { id: 'glitch', label: 'Glitch' },
  { id: 'vintage', label: 'Vintage' },
  { id: 'color', label: 'Color' },
  { id: 'light', label: 'Light' },
  { id: 'beauty', label: 'Beauty' },
  { id: 'ai', label: 'AI' },
  { id: 'magic', label: 'Magic' },
  { id: 'transition', label: 'Transition FX' },
];

function fx(
  id: VideoEffectId,
  label: string,
  category: Exclude<EffectCategory, 'all'>,
  swatch: [string, string],
  speedLabel = 'Speed',
  defaultIntensity = 80,
  defaultSpeed = 50
): VideoEffectDefinition {
  return {
    id,
    label,
    category,
    swatch,
    defaultIntensity,
    defaultSpeed,
    speedLabel,
  };
}

export const VIDEO_EFFECTS: VideoEffectDefinition[] = [
  // ============================================================================
  // 1. CINEMATIC (16 = 12 original + 4 Hollywood Pro)
  // ============================================================================
  fx('cin_letterbox_239', 'Cinema 2.39:1', 'cinematic', ['#0f172a', '#f59e0b'], 'Bar Ratio', 85, 50),
  fx('cin_anamorphic_flare', 'Anamorphic Flare', 'cinematic', ['#0ea5e9', '#1e3a8a'], 'Streak Drift', 80, 50),
  fx('cin_teal_orange', 'Teal & Orange', 'cinematic', ['#0d9488', '#ea580c'], 'Warmth', 80, 55),
  fx('cin_noir_spotlight', 'Noir Spotlight', 'cinematic', ['#09090b', '#71717a'], 'Beam Size', 85, 50),
  fx('cin_halation_film', '35mm Halation', 'cinematic', ['#991b1b', '#f97316'], 'Glow Spread', 78, 50),
  fx('cin_bleach_bypass', 'Bleach Bypass', 'cinematic', ['#334155', '#94a3b8'], 'Contrast', 80, 55),
  fx('cin_dramatic_vignette', 'Theatre Vignette', 'cinematic', ['#020617', '#475569'], 'Feather', 82, 50),
  fx('cin_zoom_breathe', 'Cinema Breathe', 'cinematic', ['#1e293b', '#38bdf8'], 'Pulse Speed', 75, 45),
  fx('cin_sunset_grad', 'Sunset ND Grad', 'cinematic', ['#b45309', '#facc15'], 'Grad Depth', 80, 50),
  fx('cin_action_shake', 'Action Cam Shake', 'cinematic', ['#dc2626', '#1e293b'], 'Shake Speed', 70, 55),
  fx('cin_widescreen_soft', 'Univisium Glow', 'cinematic', ['#1d4ed8', '#fbbf24'], 'Bloom', 80, 50),
  fx('cin_cold_thriller', 'Cold Thriller', 'cinematic', ['#0f172a', '#38bdf8'], 'Vignette', 82, 50),
  fx('cin_imax_teal', 'IMAX Blockbuster', 'cinematic', ['#0c4a6e', '#f97316'], 'Filmic Punch', 85, 55),
  fx('cin_blockbuster_gold', 'Hollywood Amber', 'cinematic', ['#78350f', '#fbbf24'], 'Gold Richness', 82, 55),
  fx('cin_blade_neon', 'Cyber Noir 2049', 'cinematic', ['#0f172a', '#ec4899'], 'Neon Mist', 84, 55),
  fx('cin_scope_reveal', 'Cinema Scope Open', 'cinematic', ['#020617', '#e2e8f0'], 'Open Speed', 90, 55),

  // ============================================================================
  // 2. BLUR (14 = 12 original + 2 Motion Blur Pro)
  // ============================================================================
  fx('blur_gaussian', 'Gaussian Blur', 'blur', ['#475569', '#cbd5e1'], 'Radius', 75, 55),
  fx('blur_frosted', 'Frosted Glass', 'blur', ['#94a3b8', '#f8fafc'], 'Frost Depth', 80, 55),
  fx('blur_motion_h', 'Horizontal Blur', 'blur', ['#334155', '#60a5fa'], 'Streak Span', 80, 55),
  fx('blur_motion_v', 'Vertical Whip', 'blur', ['#1e3a8a', '#93c5fd'], 'Streak Span', 80, 55),
  fx('blur_radial_spin', 'Radial Spin Blur', 'blur', ['#4c1d95', '#a78bfa'], 'Spin Angle', 75, 50),
  fx('blur_zoom_burst', 'Zoom Burst Blur', 'blur', ['#2563eb', '#38bdf8'], 'Burst Scale', 75, 55),
  fx('blur_tilt_shift', 'Tilt-Shift Mini', 'blur', ['#0d9488', '#a7f3d0'], 'Focus Band', 85, 50),
  fx('blur_halo_focus', 'Focus Halo Blur', 'blur', ['#312e81', '#818cf8'], 'Clear Zone', 85, 50),
  fx('blur_bokeh_dream', 'Bokeh Dream', 'blur', ['#7c3aed', '#f472b6'], 'Glow Size', 80, 50),
  fx('blur_pixelate', 'Mosaic Pixelate', 'blur', ['#0284c7', '#22d3ee'], 'Block Size', 80, 45),
  fx('blur_soft_mist', 'Pro-Mist Soft', 'blur', ['#64748b', '#fde68a'], 'Mist Spread', 75, 50),
  fx('blur_motion_trail', 'Ghost Motion', 'blur', ['#1e293b', '#38bdf8'], 'Trail Drift', 78, 55),
  fx('blur_whip_diagonal', 'Whip Diagonal Blur', 'blur', ['#1e40af', '#38bdf8'], 'Whip Span', 82, 55),
  fx('blur_speed_lines', 'Hyper Speed Blur', 'blur', ['#0f172a', '#22d3ee'], 'Warp Speed', 82, 60),

  // ============================================================================
  // 3. 3D (15 = 12 original + 3 Spatial Pro)
  // ============================================================================
  fx('3d_anaglyph', '3D Red / Cyan', '3d', ['#ef4444', '#06b6d4'], 'Separation', 85, 50),
  fx('3d_card_float', '3D Floating Card', '3d', ['#1e3a8a', '#60a5fa'], 'Float Motion', 85, 50),
  fx('3d_tilt_left', '3D Tilt Left', '3d', ['#312e81', '#818cf8'], 'Tilt Depth', 80, 55),
  fx('3d_tilt_right', '3D Tilt Right', '3d', ['#1e1b4b', '#a855f7'], 'Tilt Depth', 80, 55),
  fx('3d_flip_mirror', '3D Mirror Flip', '3d', ['#0f766e', '#2dd4bf'], 'Shading', 100, 50),
  fx('3d_swing_pendulum', '3D Swing Rock', '3d', ['#4338ca', '#38bdf8'], 'Swing Speed', 80, 50),
  fx('3d_fisheye_barrel', '3D Fisheye Lens', '3d', ['#0369a1', '#7dd3fc'], 'Curvature', 80, 55),
  fx('3d_pincushion_warp', '3D Tunnel Warp', '3d', ['#6d28d9', '#ec4899'], 'Warp Pull', 80, 55),
  fx('3d_parallax_depth', '3D Parallax Zoom', '3d', ['#1d4ed8', '#22d3ee'], 'Cycle Speed', 80, 50),
  fx('3d_ripple_wave', '3D Water Ripple', '3d', ['#0284c7', '#34d399'], 'Wave Speed', 75, 55),
  fx('3d_horizon_roll', '3D Horizon Roll', '3d', ['#0f172a', '#60a5fa'], 'Roll Speed', 78, 45),
  fx('3d_split_prism', '3D Glass Prism', '3d', ['#7c3aed', '#38bdf8'], 'Refraction', 80, 50),
  fx('3d_zoom_bounce', '3D Zoom Bounce', '3d', ['#4f46e5', '#22d3ee'], 'Bounce Rate', 82, 55),
  fx('3d_cube_rotate', '3D Cube Spin', '3d', ['#1e293b', '#818cf8'], 'Spin Speed', 85, 50),
  fx('3d_shockwave', '3D Shockwave Pulse', '3d', ['#0369a1', '#f472b6'], 'Pulse Rate', 82, 55),

  // ============================================================================
  // 4. GLITCH (14 = 12 original + 2 RGB Glitch Pro)
  // ============================================================================
  fx('gl_rgb_split', 'RGB Split', 'glitch', ['#ef4444', '#06b6d4'], 'Glitch Speed', 80, 55),
  fx('gl_vhs_tear', 'VHS Tape Tear', 'glitch', ['#a855f7', '#22d3ee'], 'Tear Speed', 80, 55),
  fx('gl_block_corrupt', 'Block Corrupt', 'glitch', ['#ec4899', '#3b82f6'], 'Chaos Rate', 80, 60),
  fx('gl_scanline_slice', 'Cyber Scan Slice', 'glitch', ['#06b6d4', '#0f172a'], 'Slice Speed', 82, 55),
  fx('gl_static_snow', 'TV Static Snow', 'glitch', ['#52525b', '#e4e4e7'], 'Grain Speed', 75, 60),
  fx('gl_chromatic_jitter', 'Chromatic Jitter', 'glitch', ['#f43f5e', '#38bdf8'], 'Pulse Rate', 80, 60),
  fx('gl_crt_monitor', 'CRT Tube Mesh', 'glitch', ['#047857', '#020617'], 'Scan Density', 85, 50),
  fx('gl_bad_reception', 'Bad Signal', 'glitch', ['#475569', '#facc15'], 'Wave Speed', 80, 55),
  fx('gl_neon_glitch', 'Neon Flash Glitch', 'glitch', ['#d946ef', '#22d3ee'], 'Flash Rate', 80, 60),
  fx('gl_pixel_melt', 'Pixel Melt Drip', 'glitch', ['#6366f1', '#ec4899'], 'Melt Depth', 80, 50),
  fx('gl_cyber_scramble', 'Matrix Scramble', 'glitch', ['#15803d', '#4ade80'], 'Scramble', 80, 55),
  fx('gl_vhs_double', 'Tape Ghost Echo', 'glitch', ['#7e22ce', '#94a3b8'], 'Echo Offset', 80, 50),
  fx('gl_rgb_wave', 'RGB Wave Distortion', 'glitch', ['#f43f5e', '#22d3ee'], 'Wave Freq', 84, 55),
  fx('gl_flash_cut', 'Beat Glitch Flash', 'glitch', ['#06b6d4', '#f43f5e'], 'Beat Rate', 84, 60),

  // ============================================================================
  // 5. VINTAGE (14 = 12 original + 2 Film Pro)
  // ============================================================================
  fx('vin_8mm_gate', 'Super 8mm Gate', 'vintage', ['#78350f', '#fbbf24'], 'Flicker', 85, 50),
  fx('vin_16mm_grain', '16mm Film Grain', 'vintage', ['#92400e', '#fde68a'], 'Grain Level', 80, 55),
  fx('vin_sepia_dust', 'Sepia Scratches', 'vintage', ['#713f12', '#d6d3d1'], 'Wear Level', 82, 50),
  fx('vin_burned_edges', '70s Burned Edges', 'vintage', ['#c2410c', '#fb923c'], 'Burn Depth', 82, 50),
  fx('vin_polaroid_frame', 'Polaroid Frame', 'vintage', ['#f8fafc', '#d97706'], 'Border Size', 90, 45),
  fx('vin_camcorder_98', 'Camcorder 1998', 'vintage', ['#1e293b', '#ef4444'], 'Tape Wear', 85, 50),
  fx('vin_silent_movie', '1920s Silent Film', 'vintage', ['#18181b', '#a1a1aa'], 'Projector Hz', 85, 55),
  fx('vin_kodak_warm', 'Kodak Gold Halo', 'vintage', ['#b45309', '#fde047'], 'Warm Glow', 80, 50),
  fx('vin_retro_tv', 'Retro 80s TV', 'vintage', ['#475569', '#fbbf24'], 'Scanlines', 82, 50),
  fx('vin_faded_print', 'Faded Print', 'vintage', ['#a8a29e', '#fef3c7'], 'Fade Lift', 80, 50),
  fx('vin_projector_flicker', 'Projector Pulse', 'vintage', ['#451a03', '#f59e0b'], 'Pulse Speed', 80, 55),
  fx('vin_sun_bleached', 'Sun-Bleached 60s', 'vintage', ['#f59e0b', '#bae6fd'], 'Wash Out', 80, 50),
  fx('vin_kodak_2383', 'Kodak 2383 Print', 'vintage', ['#164e63', '#f59e0b'], 'Print Contrast', 85, 55),
  fx('vin_cine_reel', 'Super 16 Reel', 'vintage', ['#18181b', '#f97316'], 'Sprocket Roll', 86, 55),

  // ============================================================================
  // 6. COLOR (12)
  // ============================================================================
  fx('col_duotone_cyber', 'Cyber Duotone', 'color', ['#ec4899', '#06b6d4'], 'Split Mix', 85, 50),
  fx('col_infrared', 'Infrared Film', 'color', ['#be123c', '#fda4af'], 'IR Shift', 85, 55),
  fx('col_thermal', 'Thermal Heat Map', 'color', ['#1e1b4b', '#facc15'], 'Heat Gain', 85, 55),
  fx('col_solarize', 'Darkroom Solarize', 'color', ['#4338ca', '#f472b6'], 'Threshold', 85, 50),
  fx('col_electric_invert', 'Electric Negative', 'color', ['#0f172a', '#22d3ee'], 'Invert Mix', 85, 50),
  fx('col_posterize', 'Posterize 5-Tone', 'color', ['#ef4444', '#facc15'], 'Tone Steps', 85, 50),
  fx('col_cyanotype', 'Cyanotype Print', 'color', ['#1e3a8a', '#93c5fd'], 'Ink Depth', 85, 50),
  fx('col_matrix_tint', 'Emerald Matrix', 'color', ['#052e16', '#22c55e'], 'Phosphor', 85, 55),
  fx('col_sunset_duotone', 'Sunset Duotone', 'color', ['#581c87', '#f59e0b'], 'Contrast', 85, 50),
  fx('col_vibrant_hdr', 'HDR Color Boost', 'color', ['#2563eb', '#f97316'], 'Punch', 80, 55),
  fx('col_pastel_wash', 'Pastel Dream', 'color', ['#f9a8d4', '#bfdbfe'], 'Lift', 80, 50),
  fx('col_color_cycle', 'Rainbow Hue Wave', 'color', ['#ec4899', '#22c55e'], 'Cycle Speed', 80, 55),

  // ============================================================================
  // 7. LIGHT (16 = 12 original + 4 Neon / Lens Flare / Light Leak Pro)
  // ============================================================================
  fx('lgt_sun_flare', 'Warm Sun Flare', 'light', ['#f59e0b', '#fef08a'], 'Drift Speed', 80, 50),
  fx('lgt_rainbow_prism', 'Prism Rainbow', 'light', ['#f43f5e', '#38bdf8'], 'Angle', 80, 50),
  fx('lgt_light_sweep', 'Light Sweep', 'light', ['#f8fafc', '#38bdf8'], 'Sweep Speed', 85, 55),
  fx('lgt_bokeh_orbs', 'Golden Bokeh', 'light', ['#fbbf24', '#fb923c'], 'Float Speed', 80, 50),
  fx('lgt_disco_strobe', 'Club Disco Pulse', 'light', ['#d946ef', '#3b82f6'], 'Beat Speed', 75, 60),
  fx('lgt_spotlight', 'Stage Spotlight', 'light', ['#fef9c3', '#0f172a'], 'Beam Width', 85, 50),
  fx('lgt_halo_bloom', 'Orton Halo Bloom', 'light', ['#fde68a', '#f8fafc'], 'Bloom Size', 80, 55),
  fx('lgt_sunset_leak', 'Amber Light Leak', 'light', ['#ea580c', '#ef4444'], 'Leak Pulse', 82, 50),
  fx('lgt_moonlight', 'Moonlight Sheen', 'light', ['#1e3a8a', '#bae6fd'], 'Cool Glow', 80, 50),
  fx('lgt_starburst', 'Starburst Glints', 'light', ['#facc15', '#ffffff'], 'Twinkle', 82, 55),
  fx('lgt_neon_rim', 'Neon Rim Aura', 'light', ['#06b6d4', '#ec4899'], 'Glow Width', 82, 50),
  fx('lgt_studio_ring', 'Ring Light Fill', 'light', ['#e2e8f0', '#93c5fd'], 'Fill Boost', 80, 50),
  fx('lgt_neon_tunnel', 'Neon Glow Tunnel', 'light', ['#d946ef', '#22d3ee'], 'Pulse Speed', 85, 55),
  fx('lgt_lens_flare_pro', 'Hollywood Lens Flare', 'light', ['#f59e0b', '#38bdf8'], 'Flare Sweep', 84, 55),
  fx('lgt_prism_leak_pro', '70mm Optical Leak', 'light', ['#fb7185', '#f59e0b'], 'Leak Drift', 84, 55),
  fx('lgt_cyber_bloom', 'Cyber Neon Bloom', 'light', ['#7c3aed', '#06b6d4'], 'Glow Threshold', 84, 55),

  // ============================================================================
  // 8. BEAUTY (13 = 12 original + 1 Hollywood Glam Pro)
  // ============================================================================
  fx('bty_skin_smooth', 'Skin Smooth Pro', 'beauty', ['#fda4af', '#fff1f2'], 'Smoothness', 80, 55),
  fx('bty_glamour_glow', 'Glamour Soft', 'beauty', ['#fbcfe8', '#fef3c7'], 'Diffusion', 80, 50),
  fx('bty_peach_warm', 'Peach Radiance', 'beauty', ['#fb923c', '#fecdd3'], 'Warmth', 78, 50),
  fx('bty_rose_radiance', 'Rose Cheek Glow', 'beauty', ['#f43f5e', '#fbcfe8'], 'Rosiness', 78, 50),
  fx('bty_studio_bright', 'Studio Fill Lift', 'beauty', ['#f8fafc', '#e2e8f0'], 'Lift', 78, 50),
  fx('bty_airbrush', 'Airbrush Matte', 'beauty', ['#fed7aa', '#f5d0fe'], 'Softness', 82, 55),
  fx('bty_pearl_glow', 'Pearl Skin Tone', 'beauty', ['#f1f5f9', '#dbeafe'], 'Brightness', 78, 50),
  fx('bty_golden_tan', 'Golden Bronze', 'beauty', ['#d97706', '#fde68a'], 'Tan Depth', 78, 50),
  fx('bty_angel_halo', 'Ethereal Angel', 'beauty', ['#fefce8', '#fbcfe8'], 'Glow', 80, 55),
  fx('bty_crisp_detail', 'Eye & Hair Crisp', 'beauty', ['#38bdf8', '#f8fafc'], 'Sharpness', 80, 55),
  fx('bty_velvet_matte', 'Velvet Matte', 'beauty', ['#d6d3d1', '#fda4af'], 'Matte', 80, 50),
  fx('bty_satin_diffuse', 'Satin Beauty Veil', 'beauty', ['#e7e5e4', '#fecdd3'], 'Veil', 78, 50),
  fx('bty_hollywood_glam', 'Hollywood Soft Glam', 'beauty', ['#fbbf24', '#fbcfe8'], 'Key Glow', 82, 55),

  // ============================================================================
  // 9. AI (12)
  // ============================================================================
  fx('ai_neon_edges', 'AI Neon Edges', 'ai', ['#06b6d4', '#d946ef'], 'Sensitivity', 85, 55),
  fx('ai_comic_ink', 'AI Comic Ink', 'ai', ['#facc15', '#ef4444'], 'Ink Line', 88, 50),
  fx('ai_pencil_sketch', 'AI Pencil Sketch', 'ai', ['#e7e5e4', '#52525b'], 'Stroke', 88, 50),
  fx('ai_charcoal_draw', 'AI Charcoal Art', 'ai', ['#18181b', '#d4d4d8'], 'Density', 88, 55),
  fx('ai_oil_paint', 'AI Oil Paint', 'ai', ['#ea580c', '#2563eb'], 'Brush Size', 85, 50),
  fx('ai_night_vision', 'AI Night Vision', 'ai', ['#052e16', '#4ade80'], 'Gain', 88, 55),
  fx('ai_xray_scan', 'AI X-Ray Scan', 'ai', ['#0c4a6e', '#67e8f9'], 'Edge Glow', 88, 50),
  fx('ai_emboss_3d', 'AI 3D Emboss', 'ai', ['#64748b', '#e2e8f0'], 'Relief Depth', 85, 55),
  fx('ai_hologram', 'AI Hologram', 'ai', ['#0891b2', '#67e8f9'], 'Scan Speed', 85, 55),
  fx('ai_pop_art', 'AI Pop Art 4x', 'ai', ['#f43f5e', '#facc15'], 'Vibrance', 90, 50),
  fx('ai_kaleidoscope', 'AI Kaleidoscope', 'ai', ['#8b5cf6', '#ec4899'], 'Spin Drift', 90, 50),
  fx('ai_depth_portrait', 'AI Depth Focus', 'ai', ['#1e3a8a', '#38bdf8'], 'Blur Depth', 85, 55),

  // ============================================================================
  // 10. MAGIC (9 New CapCut-style Magic / Particle FX)
  // ============================================================================
  fx('mag_fireflies', 'Golden Fireflies', 'magic', ['#fbbf24', '#92400e'], 'Drift Speed', 85, 55),
  fx('mag_stardust', 'Fairy Stardust', 'magic', ['#e879f9', '#fef08a'], 'Sparkle Rate', 85, 55),
  fx('mag_galaxy_nebula', 'Cosmic Aurora', 'magic', ['#3b82f6', '#c026d3'], 'Flow Speed', 80, 55),
  fx('mag_snowfall', 'Soft Snowfall', 'magic', ['#e2e8f0', '#64748b'], 'Fall Speed', 84, 55),
  fx('mag_rain_streak', 'Cinematic Rain', 'magic', ['#38bdf8', '#0f172a'], 'Rain Rate', 84, 60),
  fx('mag_ember_sparks', 'Cinema Ember Sparks', 'magic', ['#f97316', '#dc2626'], 'Rise Speed', 86, 55),
  fx('mag_lightning_arc', 'Thunder Flash', 'magic', ['#e0f2fe', '#312e81'], 'Strike Rate', 84, 55),
  fx('mag_prism_shimmer', 'Crystal Shimmer', 'magic', ['#22d3ee', '#f472b6'], 'Shimmer Rate', 82, 55),
  fx('mag_heart_float', 'Dream Hearts', 'magic', ['#fb7185', '#f43f5e'], 'Float Speed', 85, 55),

  // ============================================================================
  // 11. TRANSITION FX (9 New Animated In/Out / Beat Transition FX)
  // ============================================================================
  fx('trn_flash_white', 'Beat White Flash', 'transition', ['#ffffff', '#94a3b8'], 'Flash Curve', 90, 55),
  fx('trn_black_fade', 'Cinema Fade In', 'transition', ['#020617', '#475569'], 'Fade Curve', 92, 55),
  fx('trn_zoom_in_punch', 'Zoom In Punch', 'transition', ['#6366f1', '#22d3ee'], 'Zoom Depth', 88, 55),
  fx('trn_zoom_out_drop', 'Zoom Out Drop', 'transition', ['#7c3aed', '#f43f5e'], 'Drop Depth', 88, 55),
  fx('trn_whip_pan_left', 'Whip Pan Swipe', 'transition', ['#0ea5e9', '#1e293b'], 'Whip Curve', 88, 55),
  fx('trn_iris_circle', 'Iris Open Reveal', 'transition', ['#0f172a', '#fbbf24'], 'Feather', 92, 55),
  fx('trn_shutter_split', 'Cinema Shutter', 'transition', ['#18181b', '#e2e8f0'], 'Blade Angle', 90, 55),
  fx('trn_burn_flash', 'Film Burn Flash', 'transition', ['#ea580c', '#fef08a'], 'Burn Heat', 88, 55),
  fx('trn_shake_impact', 'Bass Shake Hit', 'transition', ['#ec4899', '#1e1b4b'], 'Hit Decay', 88, 60),
];

export const TOTAL_EFFECT_COUNT = VIDEO_EFFECTS.length;

export function getEffectCategoryCount(category: EffectCategory): number {
  if (category === 'all') return TOTAL_EFFECT_COUNT;
  return VIDEO_EFFECTS.filter((e) => e.category === category).length;
}

export function findEffectDefinition(id: VideoEffectId): VideoEffectDefinition {
  return VIDEO_EFFECTS.find((e) => e.id === id) ?? VIDEO_EFFECTS[0];
}
