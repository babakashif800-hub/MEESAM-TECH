export type MusicLibraryCategory = 'all' | 'chill' | 'upbeat' | 'cinematic' | 'vlog';

export interface BuiltinMusicTrack {
  id: string;
  title: string;
  subtitle: string;
  category: Exclude<MusicLibraryCategory, 'all'>;
  bpm: number;
  durationSec: number;
  accentHex: string;
}

export const MUSIC_LIBRARY_CATEGORIES: Array<{
  id: MusicLibraryCategory;
  label: string;
}> = [
  { id: 'all', label: 'All' },
  { id: 'chill', label: 'Chill' },
  { id: 'upbeat', label: 'Upbeat' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'vlog', label: 'Vlog' },
];

export const BUILTIN_MUSIC_TRACKS: BuiltinMusicTrack[] = [
  {
    id: 'lofi-gold',
    title: 'Golden Hour Lo-Fi',
    subtitle: 'Warm Rhodes & soft boom-bap',
    category: 'chill',
    bpm: 86,
    durationSec: 16,
    accentHex: '#E5C158',
  },
  {
    id: 'reels-groove',
    title: 'Reels Pop Groove',
    subtitle: 'Punchy bass & crisp hi-hats',
    category: 'upbeat',
    bpm: 118,
    durationSec: 16,
    accentHex: '#A855F7',
  },
  {
    id: 'cinematic-rise',
    title: 'Epic Horizon',
    subtitle: 'Deep sub & atmospheric strings',
    category: 'cinematic',
    bpm: 92,
    durationSec: 16,
    accentHex: '#38BDF8',
  },
  {
    id: 'vlog-morning',
    title: 'Morning Coffee Vlog',
    subtitle: 'Light plucks & easy rhythm',
    category: 'vlog',
    bpm: 104,
    durationSec: 16,
    accentHex: '#34D399',
  },
  {
    id: 'neon-drive',
    title: 'Neon Night Drive',
    subtitle: 'Retro synthwave pulse',
    category: 'upbeat',
    bpm: 122,
    durationSec: 16,
    accentHex: '#F472B6',
  },
  {
    id: 'piano-dream',
    title: 'Soft Piano Memory',
    subtitle: 'Gentle emotional keys',
    category: 'cinematic',
    bpm: 78,
    durationSec: 16,
    accentHex: '#FBBF24',
  },
  {
    id: 'chill-breeze',
    title: 'Sunset Breeze',
    subtitle: 'Mellow pads & subtle shaker',
    category: 'chill',
    bpm: 90,
    durationSec: 16,
    accentHex: '#60A5FA',
  },
  {
    id: 'studio-energy',
    title: 'Creator Energy',
    subtitle: 'Modern trap snap & bright arp',
    category: 'vlog',
    bpm: 128,
    durationSec: 16,
    accentHex: '#C084FC',
  },
];

interface CachedTrackAudio {
  url: string;
  blob: Blob;
  duration: number;
}

const trackAudioCache = new Map<string, CachedTrackAudio>();

function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

function encodeStereoWavBlob(left: Float32Array, right: Float32Array, sampleRate: number): Blob {
  const numSamples = left.length;
  const byteLength = 44 + numSamples * 4;
  const buffer = new ArrayBuffer(byteLength);
  const view = new DataView(buffer);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) {
      view.setUint8(offset + i, s.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 4, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 2, true); // Stereo
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 4, true);
  view.setUint16(32, 4, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, numSamples * 4, true);

  let pos = 44;
  for (let i = 0; i < numSamples; i++) {
    const l = Math.max(-1, Math.min(1, left[i]));
    const r = Math.max(-1, Math.min(1, right[i]));
    view.setInt16(pos, l < 0 ? l * 0x8000 : l * 0x7fff, true);
    view.setInt16(pos + 2, r < 0 ? r * 0x8000 : r * 0x7fff, true);
    pos += 4;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

interface SynthRecipe {
  chords: number[][];
  arpNotes: number[];
  kickPattern: number[];
  snarePattern: number[];
  hatPattern: number[];
  padMix: number;
  pluckMix: number;
  bassMix: number;
  drumMix: number;
  cutoffBright: number;
}

const RECIPES: Record<string, SynthRecipe> = {
  'lofi-gold': {
    chords: [
      [53, 57, 60, 64],
      [55, 59, 62, 65],
      [57, 60, 64, 67],
      [52, 55, 59, 64],
    ],
    arpNotes: [69, 72, 76, 72, 71, 74, 79, 74],
    kickPattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
    hatPattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1],
    padMix: 0.34,
    pluckMix: 0.16,
    bassMix: 0.28,
    drumMix: 0.28,
    cutoffBright: 0.45,
  },
  'reels-groove': {
    chords: [
      [57, 60, 64, 69],
      [53, 57, 60, 65],
      [48, 55, 60, 64],
      [55, 59, 62, 67],
    ],
    arpNotes: [72, 76, 79, 76, 74, 79, 81, 79],
    kickPattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hatPattern: [0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1],
    padMix: 0.24,
    pluckMix: 0.26,
    bassMix: 0.32,
    drumMix: 0.38,
    cutoffBright: 0.85,
  },
  'cinematic-rise': {
    chords: [
      [45, 52, 57, 60, 64],
      [41, 48, 53, 57, 60],
      [48, 55, 60, 64, 67],
      [43, 50, 55, 59, 62],
    ],
    arpNotes: [64, 69, 72, 76, 72, 69, 67, 71],
    kickPattern: [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
    snarePattern: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hatPattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1],
    padMix: 0.42,
    pluckMix: 0.14,
    bassMix: 0.36,
    drumMix: 0.22,
    cutoffBright: 0.6,
  },
  'vlog-morning': {
    chords: [
      [60, 64, 67, 71],
      [57, 60, 64, 69],
      [53, 57, 60, 65],
      [55, 59, 62, 67],
    ],
    arpNotes: [72, 76, 79, 83, 79, 76, 74, 79],
    kickPattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hatPattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0],
    padMix: 0.22,
    pluckMix: 0.28,
    bassMix: 0.24,
    drumMix: 0.30,
    cutoffBright: 0.78,
  },
  'neon-drive': {
    chords: [
      [50, 57, 62, 65],
      [46, 53, 58, 62],
      [48, 55, 60, 64],
      [45, 52, 57, 61],
    ],
    arpNotes: [62, 69, 74, 77, 74, 69, 72, 76],
    kickPattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1],
    hatPattern: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1],
    padMix: 0.28,
    pluckMix: 0.25,
    bassMix: 0.34,
    drumMix: 0.36,
    cutoffBright: 0.9,
  },
  'piano-dream': {
    chords: [
      [60, 64, 67, 72],
      [55, 59, 62, 67],
      [57, 60, 64, 69],
      [53, 57, 60, 65],
    ],
    arpNotes: [72, 74, 76, 79, 76, 74, 72, 67],
    kickPattern: [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    snarePattern: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    hatPattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    padMix: 0.38,
    pluckMix: 0.30,
    bassMix: 0.22,
    drumMix: 0.12,
    cutoffBright: 0.55,
  },
  'chill-breeze': {
    chords: [
      [55, 59, 62, 66],
      [52, 55, 59, 64],
      [57, 60, 64, 67],
      [50, 54, 57, 62],
    ],
    arpNotes: [71, 74, 78, 74, 71, 69, 72, 76],
    kickPattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hatPattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    padMix: 0.36,
    pluckMix: 0.18,
    bassMix: 0.25,
    drumMix: 0.20,
    cutoffBright: 0.5,
  },
  'studio-energy': {
    chords: [
      [52, 55, 59, 64],
      [48, 52, 55, 60],
      [55, 59, 62, 67],
      [54, 57, 62, 66],
    ],
    arpNotes: [76, 79, 83, 79, 76, 74, 79, 83],
    kickPattern: [1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0],
    snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    hatPattern: [1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1],
    padMix: 0.22,
    pluckMix: 0.26,
    bassMix: 0.35,
    drumMix: 0.36,
    cutoffBright: 0.88,
  },
};

function synthesizeTrackWav(track: BuiltinMusicTrack): CachedTrackAudio {
  const sr = 22050; // Crisp, compact, fast stereo generation (~1.4 MB for 16s)
  const totalSamples = Math.round(track.durationSec * sr);
  const left = new Float32Array(totalSamples);
  const right = new Float32Array(totalSamples);
  const recipe = RECIPES[track.id] ?? RECIPES['lofi-gold'];

  const beatSec = 60 / track.bpm;
  const stepSec = beatSec / 4; // 16th-note grid
  const barSec = beatSec * 4;

  // Deterministic pseudo-noise generator for hi-hat & snare crispness
  let seed = 0x51a7b3c9;
  const nextNoise = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return (seed / 0xffffffff) * 2 - 1;
  };

  let lpL = 0;
  let lpR = 0;
  const lpAlpha = 0.08 + recipe.cutoffBright * 0.24;

  for (let i = 0; i < totalSamples; i++) {
    const t = i / sr;
    const barIdx = Math.floor(t / barSec) % recipe.chords.length;
    const chord = recipe.chords[barIdx];
    const barElapsed = t % barSec;
    const stepFloat = t / stepSec;
    const stepIdx = Math.floor(stepFloat) % 16;
    const stepPos = (stepFloat - Math.floor(stepFloat)) * stepSec;

    // 1. Warm chord pad with gentle stereo chorus
    let padL = 0;
    let padR = 0;
    const padEnv =
      Math.min(1, barElapsed / 0.14) *
      Math.min(1, Math.max(0, (barSec - barElapsed) / 0.16) + 0.35);
    for (let c = 0; c < chord.length; c++) {
      const f = midiToFreq(chord[c]);
      const detune = 1 + (c % 2 === 0 ? 0.0025 : -0.0025);
      const s1 = Math.sin(2 * Math.PI * f * t);
      const s2 = 0.4 * Math.sin(2 * Math.PI * f * 2 * detune * t);
      const val = (s1 + s2) * 0.22;
      padL += val * (c % 2 === 0 ? 1.05 : 0.85);
      padR += val * (c % 2 === 0 ? 0.85 : 1.05);
    }
    padL *= padEnv * recipe.padMix;
    padR *= padEnv * recipe.padMix;

    // 2. Sub/Warm bass on root note
    const bassFreq = midiToFreq(chord[0] - 12);
    const beatPos = t % beatSec;
    const bassEnv = Math.exp(-beatPos * 2.2) * Math.min(1, beatPos / 0.015);
    const bassVal =
      (Math.sin(2 * Math.PI * bassFreq * t) +
        0.3 * Math.sin(2 * Math.PI * bassFreq * 2 * t)) *
      bassEnv *
      recipe.bassMix;

    // 3. Rhythmic Pluck / Arpeggio on 8th notes
    const eighthFloat = t / (stepSec * 2);
    const eighthIdx = Math.floor(eighthFloat) % recipe.arpNotes.length;
    const eighthPos = (eighthFloat - Math.floor(eighthFloat)) * stepSec * 2;
    const arpFreq = midiToFreq(recipe.arpNotes[eighthIdx]);
    const arpEnv = Math.exp(-eighthPos * 8.5) * Math.min(1, eighthPos / 0.006);
    const arpRaw =
      (Math.sin(2 * Math.PI * arpFreq * t) +
        0.35 * Math.sin(2 * Math.PI * arpFreq * 2 * t)) *
      arpEnv *
      recipe.pluckMix;
    const pan = eighthIdx % 2 === 0 ? 0.72 : 1.0;
    const arpL = arpRaw * pan;
    const arpR = arpRaw * (1.72 - pan);

    // 4. Drums (Kick, Snare/Clap, Hat)
    let drumL = 0;
    let drumR = 0;
    if (recipe.kickPattern[stepIdx]) {
      const kEnv = Math.exp(-stepPos * 16) * Math.min(1, stepPos / 0.003);
      const kFreq = 46 + 92 * Math.exp(-stepPos * 35);
      const kick = Math.sin(2 * Math.PI * kFreq * stepPos) * kEnv * 0.7;
      drumL += kick;
      drumR += kick;
    }
    if (recipe.snarePattern[stepIdx]) {
      const sEnv = Math.exp(-stepPos * 19) * Math.min(1, stepPos / 0.002);
      const body = Math.sin(2 * Math.PI * 195 * stepPos) * 0.25;
      const snap = nextNoise() * 0.45;
      drumL += (body + snap) * sEnv * 0.52;
      drumR += (body - snap * 0.8) * sEnv * 0.52;
    }
    if (recipe.hatPattern[stepIdx]) {
      const hEnv = Math.exp(-stepPos * 55);
      const hat = nextNoise() * hEnv * 0.16;
      drumL += hat * 0.85;
      drumR += hat * 1.1;
    }
    drumL *= recipe.drumMix;
    drumR *= recipe.drumMix;

    // Gentle loop fade at very beginning/end (25ms) for click-free looping
    const edgeEnv =
      Math.min(1, t / 0.025) * Math.min(1, (track.durationSec - t) / 0.025);

    const rawL = (padL + bassVal + arpL + drumL) * edgeEnv;
    const rawR = (padR + bassVal + arpR + drumR) * edgeEnv;

    lpL = lpL + lpAlpha * (rawL - lpL);
    lpR = lpR + lpAlpha * (rawR - lpR);

    left[i] = Math.tanh((lpL * 0.82 + rawL * 0.28) * 1.15);
    right[i] = Math.tanh((lpR * 0.82 + rawR * 0.28) * 1.15);
  }

  const blob = encodeStereoWavBlob(left, right, sr);
  const url = URL.createObjectURL(blob);
  return { url, blob, duration: track.durationSec };
}

export function getOrCreatePresetAudio(trackId: string): CachedTrackAudio | null {
  const existing = trackAudioCache.get(trackId);
  if (existing) return existing;
  const track = BUILTIN_MUSIC_TRACKS.find((t) => t.id === trackId);
  if (!track) return null;
  const created = synthesizeTrackWav(track);
  trackAudioCache.set(trackId, created);
  return created;
}
