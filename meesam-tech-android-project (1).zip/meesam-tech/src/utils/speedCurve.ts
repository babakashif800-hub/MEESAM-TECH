import { SpeedCurvePoint, TimelineSegment } from '../types/editor';

export type SpeedCurvePresetId =
  | 'normal'
  | 'montage'
  | 'hero'
  | 'bullet'
  | 'jump_cut'
  | 'flash_in'
  | 'flash_out';

export const SPEED_CURVE_PRESETS: Array<{
  id: SpeedCurvePresetId;
  label: string;
  points: Array<{ position: number; speed: number }>;
}> = [
  {
    id: 'normal',
    label: 'Reset Flat',
    points: [
      { position: 0, speed: 1.0 },
      { position: 0.5, speed: 1.0 },
      { position: 1, speed: 1.0 },
    ],
  },
  {
    id: 'montage',
    label: 'Montage',
    points: [
      { position: 0, speed: 0.8 },
      { position: 0.25, speed: 2.2 },
      { position: 0.5, speed: 0.45 },
      { position: 0.75, speed: 2.0 },
      { position: 1, speed: 0.9 },
    ],
  },
  {
    id: 'hero',
    label: 'Hero',
    points: [
      { position: 0, speed: 1.0 },
      { position: 0.28, speed: 2.8 },
      { position: 0.5, speed: 0.35 },
      { position: 0.72, speed: 2.8 },
      { position: 1, speed: 1.0 },
    ],
  },
  {
    id: 'bullet',
    label: 'Bullet Time',
    points: [
      { position: 0, speed: 2.4 },
      { position: 0.32, speed: 2.4 },
      { position: 0.48, speed: 0.3 },
      { position: 0.68, speed: 0.3 },
      { position: 0.84, speed: 2.4 },
      { position: 1, speed: 2.4 },
    ],
  },
  {
    id: 'jump_cut',
    label: 'Jump Cut',
    points: [
      { position: 0, speed: 1.0 },
      { position: 0.22, speed: 3.0 },
      { position: 0.45, speed: 0.5 },
      { position: 0.7, speed: 3.0 },
      { position: 1, speed: 1.0 },
    ],
  },
  {
    id: 'flash_in',
    label: 'Flash In',
    points: [
      { position: 0, speed: 3.2 },
      { position: 0.35, speed: 1.5 },
      { position: 0.7, speed: 1.0 },
      { position: 1, speed: 1.0 },
    ],
  },
  {
    id: 'flash_out',
    label: 'Flash Out',
    points: [
      { position: 0, speed: 1.0 },
      { position: 0.35, speed: 1.0 },
      { position: 0.7, speed: 1.8 },
      { position: 1, speed: 3.2 },
    ],
  },
];

export function createCurveFromPreset(
  presetId: SpeedCurvePresetId,
  makeId: () => string
): SpeedCurvePoint[] {
  const preset =
    SPEED_CURVE_PRESETS.find((p) => p.id === presetId) ?? SPEED_CURVE_PRESETS[0];
  return preset.points.map((pt) => ({
    id: makeId(),
    position: pt.position,
    speed: pt.speed,
  }));
}

export function sortAndClampCurve(curve: SpeedCurvePoint[]): SpeedCurvePoint[] {
  if (!curve || curve.length === 0) return [];
  const cleaned = curve
    .map((pt) => ({
      ...pt,
      position: Math.max(0, Math.min(1, Number.isFinite(pt.position) ? pt.position : 0)),
      speed: Math.max(0.25, Math.min(4.0, Number.isFinite(pt.speed) ? pt.speed : 1)),
    }))
    .sort((a, b) => a.position - b.position);

  if (cleaned[0].position > 0.001) {
    cleaned.unshift({ id: `${cleaned[0].id}-s`, position: 0, speed: cleaned[0].speed });
  } else {
    cleaned[0] = { ...cleaned[0], position: 0 };
  }

  const last = cleaned[cleaned.length - 1];
  if (last.position < 0.999) {
    cleaned.push({ id: `${last.id}-e`, position: 1, speed: last.speed });
  } else {
    cleaned[cleaned.length - 1] = { ...last, position: 1 };
  }

  return cleaned;
}

export function hasCustomSpeedCurve(seg: TimelineSegment): boolean {
  const curve = seg.meta?.speedCurve;
  if (!curve || curve.length < 2) return false;
  return curve.some((p) => Math.abs(p.speed - 1) > 0.01);
}

/**
 * Evaluates instantaneous playback speed at normalized segment position u in [0, 1].
 */
export function evaluateCurveAtProgress(
  curve: SpeedCurvePoint[] | undefined,
  u: number,
  fallbackSpeed = 1
): number {
  if (!curve || curve.length === 0) {
    return Math.max(0.1, Math.min(4.0, fallbackSpeed > 0 ? fallbackSpeed : 1));
  }
  const pts = sortAndClampCurve(curve);
  const clampedU = Math.max(0, Math.min(1, u));
  if (clampedU <= pts[0].position) return pts[0].speed;
  if (clampedU >= pts[pts.length - 1].position) return pts[pts.length - 1].speed;

  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (clampedU >= a.position && clampedU <= b.position) {
      const span = b.position - a.position;
      if (span <= 1e-6) return b.speed;
      const t = (clampedU - a.position) / span;
      // Smooth cosine blend between control points for musical CapCut-style speed ramps
      const eased = 0.5 - 0.5 * Math.cos(Math.PI * t);
      return a.speed + (b.speed - a.speed) * eased;
    }
  }
  return fallbackSpeed;
}

export function evaluateSegmentSpeedAtTime(seg: TimelineSegment, sourceTime: number): number {
  const baseSpeed = seg.meta?.speed && seg.meta.speed > 0 ? seg.meta.speed : 1;
  if (!seg.meta?.speedCurve || seg.meta.speedCurve.length < 2) {
    return baseSpeed;
  }
  const len = Math.max(0.001, seg.end - seg.start);
  const u = Math.max(0, Math.min(1, (sourceTime - seg.start) / len));
  return evaluateCurveAtProgress(seg.meta.speedCurve, u, baseSpeed);
}

const INTEGRATION_STEPS = 64;

/**
 * Maps a source offset within a segment [0 .. segLen] to the integrated edited output duration in seconds.
 */
export function integrateSegmentSourceToEdited(
  seg: TimelineSegment,
  sourceOffsetSec: number
): number {
  const segLen = Math.max(0, seg.end - seg.start);
  if (segLen <= 0 || sourceOffsetSec <= 0) return 0;
  const clampedOffset = Math.min(segLen, sourceOffsetSec);

  const curve = seg.meta?.speedCurve;
  const baseSpeed = seg.meta?.speed && seg.meta.speed > 0 ? seg.meta.speed : 1;
  if (!curve || curve.length < 2) {
    return clampedOffset / baseSpeed;
  }

  const endU = clampedOffset / segLen;
  const steps = Math.max(4, Math.ceil(endU * INTEGRATION_STEPS));
  const du = endU / steps;
  let total = 0;
  for (let i = 0; i < steps; i++) {
    const midU = (i + 0.5) * du;
    const spd = Math.max(0.2, evaluateCurveAtProgress(curve, midU, baseSpeed));
    total += (du * segLen) / spd;
  }
  return total;
}

export function getCurveSegmentEditedDuration(seg: TimelineSegment): number {
  return integrateSegmentSourceToEdited(seg, Math.max(0, seg.end - seg.start));
}

/**
 * Maps an edited output offset [0 .. segEditedDuration] back to the source offset [0 .. segLen].
 */
export function editedTimeToSegmentSourceOffset(
  seg: TimelineSegment,
  editedOffsetSec: number
): number {
  const segLen = Math.max(0, seg.end - seg.start);
  if (segLen <= 0 || editedOffsetSec <= 0) return 0;

  const curve = seg.meta?.speedCurve;
  const baseSpeed = seg.meta?.speed && seg.meta.speed > 0 ? seg.meta.speed : 1;
  if (!curve || curve.length < 2) {
    return Math.min(segLen, Math.max(0, editedOffsetSec * baseSpeed));
  }

  const totalEdited = getCurveSegmentEditedDuration(seg);
  if (editedOffsetSec >= totalEdited) return segLen;

  let lo = 0;
  let hi = segLen;
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) * 0.5;
    if (integrateSegmentSourceToEdited(seg, mid) <= editedOffsetSec) {
      lo = mid;
    } else {
      hi = mid;
    }
  }
  return (lo + hi) * 0.5;
}

export function getSegmentAverageSpeed(seg: TimelineSegment): number {
  const srcLen = Math.max(0.001, seg.end - seg.start);
  const outLen = Math.max(0.001, getCurveSegmentEditedDuration(seg));
  return srcLen / outLen;
}
