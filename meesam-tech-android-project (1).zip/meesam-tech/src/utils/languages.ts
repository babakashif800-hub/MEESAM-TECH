import {
  AppLanguage,
  CaptionLanguage,
  ChineseVariant,
  TargetLanguageCode,
} from '../types/editor';

export interface SupportedLanguageMeta {
  id: AppLanguage;
  nativeName: string;
  englishName: string;
  dir: 'rtl' | 'ltr';
  scriptLabel: string;
  defaultSampleText: string;
  traditionalSampleText?: string;
}

/**
 * Strictly the FIVE supported languages in MEESAM TECH:
 * 1. Sindhi (sd)
 * 2. Urdu (ur)
 * 3. Hindi (hi)
 * 4. English (en)
 * 5. Chinese (zh — Simplified zh-Hans & Traditional zh-Hant)
 */
export const FIVE_SUPPORTED_LANGUAGES: SupportedLanguageMeta[] = [
  {
    id: 'sd',
    nativeName: 'سنڌي',
    englishName: 'Sindhi',
    dir: 'rtl',
    scriptLabel: 'سنڌي (RTL)',
    defaultSampleText: 'ميثم ٽيڪ سنڌي وڊيو',
  },
  {
    id: 'ur',
    nativeName: 'اردو',
    englishName: 'Urdu',
    dir: 'rtl',
    scriptLabel: 'اردو (RTL)',
    defaultSampleText: 'میثم ٹیک اردو ویڈیو',
  },
  {
    id: 'hi',
    nativeName: 'हिन्दी',
    englishName: 'Hindi',
    dir: 'ltr',
    scriptLabel: 'देवनागरी',
    defaultSampleText: 'मीसम टेक हिन्दी वीडियो',
  },
  {
    id: 'en',
    nativeName: 'English',
    englishName: 'English',
    dir: 'ltr',
    scriptLabel: 'Latin',
    defaultSampleText: 'MEESAM TECH Studio',
  },
  {
    id: 'zh',
    nativeName: '中文',
    englishName: 'Chinese',
    dir: 'ltr',
    scriptLabel: '简体 / 繁體',
    defaultSampleText: '米萨姆科技视频编辑',
    traditionalSampleText: '米薩姆科技影片編輯',
  },
];

export const TARGET_LANGUAGE_OPTIONS: Array<{
  code: TargetLanguageCode;
  base: AppLanguage;
  label: string;
  nativeLabel: string;
  dir: 'rtl' | 'ltr';
}> = [
  { code: 'sd', base: 'sd', label: 'Sindhi', nativeLabel: 'سنڌي', dir: 'rtl' },
  { code: 'ur', base: 'ur', label: 'Urdu', nativeLabel: 'اردو', dir: 'rtl' },
  { code: 'hi', base: 'hi', label: 'Hindi', nativeLabel: 'हिन्दी', dir: 'ltr' },
  { code: 'en', base: 'en', label: 'English', nativeLabel: 'English', dir: 'ltr' },
  {
    code: 'zh-Hans',
    base: 'zh',
    label: 'Chinese (Simplified)',
    nativeLabel: '中文 (简体)',
    dir: 'ltr',
  },
  {
    code: 'zh-Hant',
    base: 'zh',
    label: 'Chinese (Traditional)',
    nativeLabel: '中文 (繁體)',
    dir: 'ltr',
  },
];

export function resolveTargetLanguageCode(
  lang: AppLanguage,
  zhVariant: ChineseVariant
): TargetLanguageCode {
  if (lang === 'zh') return zhVariant;
  return lang;
}

export function getHtmlLangAndDir(
  lang: AppLanguage,
  zhVariant: ChineseVariant
): { htmlLang: TargetLanguageCode; dir: 'rtl' | 'ltr' } {
  const htmlLang = resolveTargetLanguageCode(lang, zhVariant);
  const dir = lang === 'sd' || lang === 'ur' ? 'rtl' : 'ltr';
  return { htmlLang, dir };
}

export function getTargetLanguageLabel(code: CaptionLanguage): string {
  if (code === 'auto') return 'Auto (5 Languages)';
  const found = TARGET_LANGUAGE_OPTIONS.find((o) => o.code === code);
  return found ? `${found.nativeLabel} · ${found.label}` : code;
}

const ARABIC_SCRIPT_RE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
const SINDHI_SPECIFIC_RE =
  /[\u067B\u067D\u0680\u0683\u0684\u0687\u068A\u068C\u068D\u068F\u0699\u06A6\u06AA\u06B1\u06B3\u06BB\u06BD\u06FD\u06FE]/;
const DEVANAGARI_RE = /[\u0900-\u097F]/;
const CJK_RE = /[\u4E00-\u9FFF\u3400-\u4DBF]/;

export interface ScriptRenderConfig {
  dir: 'rtl' | 'ltr';
  fontFamily: string;
  langAttr: TargetLanguageCode;
}

/**
 * Resolves exact font stack, direction (RTL/LTR), and BCP-47 lang attribute
 * for live DOM previews, text editors, and HTML5 canvas video exports.
 */
export function resolveScriptRenderConfig(
  text: string,
  hint?: TargetLanguageCode | CaptionLanguage,
  explicitDir: 'auto' | 'rtl' | 'ltr' = 'auto'
): ScriptRenderConfig {
  let detected: TargetLanguageCode = 'en';

  if (hint && hint !== 'auto') {
    detected = hint;
  }

  // Override/infer from actual Unicode content when auto or mixed text is typed
  if (!hint || hint === 'auto' || detected === 'en') {
    if (SINDHI_SPECIFIC_RE.test(text)) {
      detected = 'sd';
    } else if (ARABIC_SCRIPT_RE.test(text)) {
      detected = hint === 'sd' ? 'sd' : 'ur';
    } else if (DEVANAGARI_RE.test(text)) {
      detected = 'hi';
    } else if (CJK_RE.test(text)) {
      detected = hint === 'zh-Hant' ? 'zh-Hant' : 'zh-Hans';
    }
  } else {
    // Respect explicit script detection even if user pasted another script
    if (SINDHI_SPECIFIC_RE.test(text)) {
      detected = 'sd';
    } else if (DEVANAGARI_RE.test(text)) {
      detected = 'hi';
    } else if (CJK_RE.test(text) && detected !== 'zh-Hans' && detected !== 'zh-Hant') {
      detected = 'zh-Hans';
    } else if (ARABIC_SCRIPT_RE.test(text) && detected !== 'sd' && detected !== 'ur') {
      detected = 'ur';
    }
  }

  const autoDir: 'rtl' | 'ltr' =
    detected === 'sd' || detected === 'ur' || ARABIC_SCRIPT_RE.test(text) ? 'rtl' : 'ltr';
  const dir = explicitDir === 'auto' ? autoDir : explicitDir;

  let fontFamily =
    '"Plus Jakarta Sans", "Noto Sans Devanagari", "Noto Sans SC", "Noto Sans TC", "Noto Naskh Arabic", system-ui, sans-serif';
  if (detected === 'sd') {
    fontFamily = '"Noto Naskh Arabic", "Plus Jakarta Sans", system-ui, sans-serif';
  } else if (detected === 'ur') {
    fontFamily =
      '"Noto Nastaliq Urdu", "Noto Naskh Arabic", "Plus Jakarta Sans", system-ui, sans-serif';
  } else if (detected === 'hi') {
    fontFamily = '"Noto Sans Devanagari", "Plus Jakarta Sans", system-ui, sans-serif';
  } else if (detected === 'zh-Hans') {
    fontFamily = '"Noto Sans SC", "Plus Jakarta Sans", system-ui, sans-serif';
  } else if (detected === 'zh-Hant') {
    fontFamily = '"Noto Sans TC", "Plus Jakarta Sans", system-ui, sans-serif';
  }

  return {
    dir,
    fontFamily,
    langAttr: detected,
  };
}

const LATIN_LETTER_RE = /[A-Za-z]{2,}/;

/**
 * Automatically detects the primary script language of typed/pasted text
 * across the 5 supported languages (Sindhi, Urdu, Hindi, English, Chinese).
 */
export function detectScriptLanguage(
  text: string,
  chineseVariant: ChineseVariant = 'zh-Hans',
  currentLang?: TargetLanguageCode
): TargetLanguageCode | null {
  const trimmed = text.trim();
  if (!trimmed) return null;

  if (SINDHI_SPECIFIC_RE.test(trimmed)) {
    return 'sd';
  }
  if (ARABIC_SCRIPT_RE.test(trimmed)) {
    return currentLang === 'sd' ? 'sd' : 'ur';
  }
  if (DEVANAGARI_RE.test(trimmed)) {
    return 'hi';
  }
  if (CJK_RE.test(trimmed)) {
    return chineseVariant;
  }
  if (LATIN_LETTER_RE.test(trimmed)) {
    return 'en';
  }
  return null;
}

