import { ChromaKeySettings } from '../types/editor';

export const DEFAULT_CHROMA_KEY: ChromaKeySettings = {
  enabled: false,
  keyColor: '#00b140',
  similarity: 0.28,
  smoothness: 0.09,
  spillSuppression: 0.65,
  bgMode: 'transparent',
  bgColor: '#0f172a',
};

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  if (clean.length === 3) {
    const r = parseInt(clean[0] + clean[0], 16) || 0;
    const g = parseInt(clean[1] + clean[1], 16) || 0;
    const b = parseInt(clean[2] + clean[2], 16) || 0;
    return [r, g, b];
  }
  if (clean.length === 6) {
    const r = parseInt(clean.slice(0, 2), 16) || 0;
    const g = parseInt(clean.slice(2, 4), 16) || 0;
    const b = parseInt(clean.slice(4, 6), 16) || 0;
    return [r, g, b];
  }
  return [0, 177, 64];
}

function rgbToCbCr(r: number, g: number, b: number): [number, number] {
  const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
  const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
  return [cb, cr];
}

/**
 * Pure pixel-buffer YCbCr Chroma Key processor with smooth edge ramp and color spill suppression.
 */
export function applyChromaKeyToRgba(
  rgba: Uint8ClampedArray,
  keyColorHex: string,
  similarity: number,
  smoothness: number,
  spillSuppression: number
): void {
  const [kr, kg, kb] = hexToRgb(keyColorHex);
  const [keyCb, keyCr] = rgbToCbCr(kr, kg, kb);

  // Max Euclidean CbCr distance ~180; map normalized similarity/smoothness cleanly
  const tolDist = Math.max(4, similarity * 145);
  const edgeDist = Math.max(2, smoothness * 110);
  const outerDist = tolDist + edgeDist;
  const isGreenScreen = kg >= kr && kg >= kb;
  const isBlueScreen = kb > kr && kb > kg;

  for (let i = 0; i < rgba.length; i += 4) {
    const r = rgba[i];
    const g = rgba[i + 1];
    const b = rgba[i + 2];
    const origA = rgba[i + 3];
    if (origA === 0) continue;

    const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
    const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
    const dCb = cb - keyCb;
    const dCr = cr - keyCr;
    const dist = Math.sqrt(dCb * dCb + dCr * dCr);

    let maskAlpha = 1;
    if (dist <= tolDist) {
      maskAlpha = 0;
    } else if (dist < outerDist) {
      maskAlpha = (dist - tolDist) / edgeDist;
    }

    // Gentle spill suppression on foreground fringe pixels
    if (spillSuppression > 0 && maskAlpha > 0) {
      if (isGreenScreen && g > r && g > b) {
        const avgRB = (r + b) * 0.5;
        const maxAllowed = avgRB + (g - avgRB) * (1 - spillSuppression * 0.88);
        if (g > maxAllowed) {
          rgba[i + 1] = Math.round(maxAllowed);
        }
      } else if (isBlueScreen && b > r && b > g) {
        const avgRG = (r + g) * 0.5;
        const maxAllowed = avgRG + (b - avgRG) * (1 - spillSuppression * 0.88);
        if (b > maxAllowed) {
          rgba[i + 2] = Math.round(maxAllowed);
        }
      }
    }

    rgba[i + 3] = Math.round(origA * maskAlpha);
  }
}

let cachedFgCanvas: HTMLCanvasElement | null = null;

function drawCoverBackdrop(
  ctx: CanvasRenderingContext2D,
  backdrop: HTMLImageElement | HTMLVideoElement,
  outW: number,
  outH: number
) {
  const bw =
    backdrop instanceof HTMLVideoElement
      ? backdrop.videoWidth || outW
      : backdrop.naturalWidth || outW;
  const bh =
    backdrop instanceof HTMLVideoElement
      ? backdrop.videoHeight || outH
      : backdrop.naturalHeight || outH;
  const bRatio = bw / Math.max(1, bh);
  const oRatio = outW / Math.max(1, outH);
  let dw = outW;
  let dh = outH;
  let dx = 0;
  let dy = 0;
  if (bRatio > oRatio) {
    dh = outH;
    dw = outH * bRatio;
    dx = (outW - dw) / 2;
  } else {
    dw = outW;
    dh = outW / bRatio;
    dy = (outH - dh) / 2;
  }
  ctx.drawImage(backdrop, dx, dy, dw, dh);
}

/**
 * Renders a Chroma-Keyed foreground frame onto `outputCanvas` with transparent, solid color, image, or video backdrop.
 */
export function renderChromaKeyFrame(
  source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | VideoFrame,
  outputCanvas: HTMLCanvasElement,
  settings: ChromaKeySettings,
  backdropImage?: HTMLImageElement | null,
  backdropVideo?: HTMLVideoElement | null
): void {
  const outW = outputCanvas.width;
  const outH = outputCanvas.height;
  const outCtx = outputCanvas.getContext('2d', { willReadFrequently: true });
  if (!outCtx || outW < 2 || outH < 2) return;

  if (!cachedFgCanvas) {
    cachedFgCanvas = document.createElement('canvas');
  }
  // Keep working keying canvas crisp yet responsive on mobile phones
  const workW = Math.min(outW, 640);
  const workH = Math.max(4, Math.round((workW / outW) * outH));
  if (cachedFgCanvas.width !== workW) cachedFgCanvas.width = workW;
  if (cachedFgCanvas.height !== workH) cachedFgCanvas.height = workH;

  const fgCtx = cachedFgCanvas.getContext('2d', { willReadFrequently: true });
  if (!fgCtx) return;

  fgCtx.clearRect(0, 0, workW, workH);
  fgCtx.drawImage(source, 0, 0, workW, workH);
  const imgData = fgCtx.getImageData(0, 0, workW, workH);
  applyChromaKeyToRgba(
    imgData.data,
    settings.keyColor,
    settings.similarity,
    settings.smoothness,
    settings.spillSuppression
  );
  fgCtx.putImageData(imgData, 0, 0);

  outCtx.save();
  outCtx.clearRect(0, 0, outW, outH);

  if (settings.bgMode === 'color') {
    outCtx.fillStyle = settings.bgColor || '#0f172a';
    outCtx.fillRect(0, 0, outW, outH);
  } else if (
    settings.bgMode === 'image' &&
    backdropImage &&
    backdropImage.complete &&
    backdropImage.naturalWidth > 0
  ) {
    drawCoverBackdrop(outCtx, backdropImage, outW, outH);
  } else if (
    settings.bgMode === 'video' &&
    backdropVideo &&
    backdropVideo.readyState >= 2
  ) {
    drawCoverBackdrop(outCtx, backdropVideo, outW, outH);
  }

  outCtx.drawImage(cachedFgCanvas, 0, 0, outW, outH);
  outCtx.restore();
}
