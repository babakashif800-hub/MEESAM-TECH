import {
  AspectRatioPreset,
  FilterCategory,
  FilterPresetId,
  VideoAdjustments,
} from '../types/editor';

export interface FilterColorRecipe {
  brightness?: number; // neutral 1.0
  contrast?: number; // neutral 1.0
  saturate?: number; // neutral 1.0
  sepia?: number; // neutral 0.0
  grayscale?: number; // neutral 0.0
  hueRotate?: number; // neutral 0 deg
}

export interface FilterPresetDefinition {
  id: FilterPresetId;
  label: string;
  category: Exclude<FilterCategory, 'all'>;
  recipe: FilterColorRecipe;
  cssFilter: string;
  swatch: [string, string];
}

export const FILTER_CATEGORIES: Array<{ id: FilterCategory; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'nature', label: 'Nature' },
  { id: 'portrait', label: 'Portrait' },
  { id: 'vintage', label: 'Vintage' },
  { id: 'dark', label: 'Dark' },
  { id: 'food', label: 'Food' },
  { id: 'bw', label: 'Black & White' },
  { id: 'social', label: 'Social Media' },
];

/**
 * Compiles a structured color recipe into a hardware-accelerated CSS/Canvas2D filter chain.
 * Designed as an extensible foundation for expanding from 200 presets toward 100,000+ looks.
 */
export function compileFilterRecipe(recipe: FilterColorRecipe): string {
  const parts: string[] = [];
  if (recipe.grayscale !== undefined && recipe.grayscale > 0) {
    parts.push(`grayscale(${recipe.grayscale})`);
  }
  if (recipe.sepia !== undefined && recipe.sepia > 0) {
    parts.push(`sepia(${recipe.sepia})`);
  }
  if (recipe.hueRotate !== undefined && recipe.hueRotate !== 0) {
    parts.push(`hue-rotate(${recipe.hueRotate}deg)`);
  }
  if (recipe.contrast !== undefined && recipe.contrast !== 1) {
    parts.push(`contrast(${recipe.contrast})`);
  }
  if (recipe.brightness !== undefined && recipe.brightness !== 1) {
    parts.push(`brightness(${recipe.brightness})`);
  }
  if (recipe.saturate !== undefined && recipe.saturate !== 1) {
    parts.push(`saturate(${recipe.saturate})`);
  }
  return parts.join(' ');
}

function makePreset(
  id: FilterPresetId,
  label: string,
  category: Exclude<FilterCategory, 'all'>,
  recipe: FilterColorRecipe,
  swatch: [string, string]
): FilterPresetDefinition {
  return {
    id,
    label,
    category,
    recipe,
    cssFilter: compileFilterRecipe(recipe),
    swatch,
  };
}

export const FILTER_PRESETS: FilterPresetDefinition[] = [
  {
    id: 'none',
    label: 'Normal',
    category: 'cinematic',
    recipe: {},
    cssFilter: '',
    swatch: ['#334155', '#1e293b'],
  },

  // ============================================================================
  // 1. CINEMATIC (25)
  // ============================================================================
  makePreset('cinema', 'Cinema', 'cinematic', { contrast: 1.22, saturate: 0.86, brightness: 0.96 }, ['#1e3a8a', '#f59e0b']),
  makePreset('blockbuster', 'Blockbuster', 'cinematic', { contrast: 1.28, saturate: 1.12, hueRotate: -10, brightness: 0.95 }, ['#0f766e', '#ea580c']),
  makePreset('anamorphic', 'Anamorphic', 'cinematic', { contrast: 1.24, saturate: 0.82, hueRotate: 8, brightness: 0.94 }, ['#1d4ed8', '#334155']),
  makePreset('teal_orange', 'Teal & Orange', 'cinematic', { contrast: 1.22, saturate: 1.25, hueRotate: -8 }, ['#0d9488', '#f97316']),
  makePreset('midnight_blue', 'Midnight Blue', 'cinematic', { hueRotate: 18, contrast: 1.18, brightness: 0.88, saturate: 0.95 }, ['#1e1b4b', '#3b82f6']),
  makePreset('thriller', 'Thriller', 'cinematic', { contrast: 1.32, saturate: 0.68, brightness: 0.9 }, ['#0f172a', '#475569']),
  makePreset('indie_film', 'Indie Film', 'cinematic', { sepia: 0.18, contrast: 1.1, brightness: 0.98, saturate: 0.88 }, ['#57534e', '#a8a29e']),
  makePreset('emerald_city', 'Emerald City', 'cinematic', { hueRotate: 28, contrast: 1.18, saturate: 0.92, brightness: 0.94 }, ['#064e3b', '#10b981']),
  makePreset('dune_epic', 'Dune Epic', 'cinematic', { sepia: 0.35, contrast: 1.2, saturate: 1.15, brightness: 0.96 }, ['#92400e', '#f59e0b']),
  makePreset('silver_screen', 'Silver Screen', 'cinematic', { saturate: 0.55, contrast: 1.25, brightness: 0.97 }, ['#64748b', '#cbd5e1']),
  makePreset('dark_knight', 'Dark Knight', 'cinematic', { contrast: 1.34, brightness: 0.84, saturate: 0.75 }, ['#09090b', '#27272a']),
  makePreset('imax_gold', 'IMAX Gold', 'cinematic', { sepia: 0.22, contrast: 1.26, brightness: 0.97, saturate: 1.22, hueRotate: -5 }, ['#854d0e', '#f59e0b']),
  makePreset('neo_noir_blue', 'Neo Noir Blue', 'cinematic', { contrast: 1.3, brightness: 0.88, saturate: 0.78, hueRotate: 24 }, ['#0f172a', '#0284c7']),
  makePreset('amber_anamorph', 'Amber Flare', 'cinematic', { sepia: 0.26, contrast: 1.24, saturate: 1.16, hueRotate: -11 }, ['#7c2d12', '#fb923c']),
  makePreset('blade_steel', 'Blade Steel', 'cinematic', { contrast: 1.29, brightness: 0.91, saturate: 0.62, hueRotate: 15 }, ['#1e293b', '#64748b']),
  makePreset('spy_thrill', 'Cold Espionage', 'cinematic', { contrast: 1.2, brightness: 0.93, saturate: 0.7, hueRotate: 12 }, ['#1e3a8a', '#94a3b8']),
  makePreset('sci_fi_cyan', 'Sci-Fi Cyan', 'cinematic', { contrast: 1.23, brightness: 0.95, saturate: 1.18, hueRotate: 32 }, ['#164e63', '#22d3ee']),
  makePreset('epilogue_warm', 'Epilogue Warm', 'cinematic', { sepia: 0.21, contrast: 1.15, brightness: 1.01, saturate: 1.04 }, ['#78350f', '#fde68a']),
  makePreset('hollywood_35', 'Hollywood 35mm', 'cinematic', { contrast: 1.19, brightness: 0.98, saturate: 1.09, hueRotate: -4 }, ['#9a3412', '#38bdf8']),
  makePreset('velvet_drama', 'Velvet Drama', 'cinematic', { sepia: 0.14, contrast: 1.27, brightness: 0.9, saturate: 0.92, hueRotate: -16 }, ['#4c1d95', '#be185d']),
  makePreset('desert_mirage', 'Desert Mirage', 'cinematic', { sepia: 0.4, contrast: 1.16, brightness: 1.02, saturate: 1.24, hueRotate: -7 }, ['#b45309', '#fbbf24']),
  makePreset('western_dust', 'Western Dust', 'cinematic', { sepia: 0.34, contrast: 1.14, brightness: 0.94, saturate: 0.84 }, ['#713f12', '#a8a29e']),
  makePreset('crimson_scene', 'Crimson Scene', 'cinematic', { contrast: 1.26, brightness: 0.92, saturate: 1.18, hueRotate: -22 }, ['#7f1d1d', '#ef4444']),
  makePreset('prologue_soft', 'Prologue Soft', 'cinematic', { contrast: 1.06, brightness: 0.99, saturate: 0.8, hueRotate: 6 }, ['#334155', '#cbd5e1']),
  makePreset('panavision', 'Panavision', 'cinematic', { sepia: 0.12, contrast: 1.25, brightness: 0.95, saturate: 1.05, hueRotate: 4 }, ['#0f766e', '#1e293b']),

  // ============================================================================
  // 2. NATURE (25)
  // ============================================================================
  makePreset('morning_dew', 'Morning Dew', 'nature', { brightness: 1.09, contrast: 0.95, saturate: 1.14, hueRotate: 6 }, ['#bae6fd', '#a7f3d0']),
  makePreset('fresh_mint', 'Fresh Mint', 'nature', { hueRotate: 16, saturate: 1.15, brightness: 1.05 }, ['#10b981', '#6ee7b7']),
  makePreset('sunny_day', 'Sunny Day', 'nature', { brightness: 1.1, saturate: 1.3, contrast: 1.05 }, ['#eab308', '#38bdf8']),
  makePreset('weekend', 'Weekend Meadow', 'nature', { brightness: 1.06, saturate: 1.26, contrast: 1.04 }, ['#22c55e', '#facc15']),
  makePreset('deep_forest', 'Deep Forest', 'nature', { hueRotate: 24, brightness: 0.88, contrast: 1.16, saturate: 0.85 }, ['#064e3b', '#065f46']),
  makePreset('arctic', 'Arctic', 'nature', { hueRotate: 18, brightness: 1.08, saturate: 0.86, contrast: 1.08 }, ['#e0f2fe', '#38bdf8']),
  makePreset('glacier', 'Glacier', 'nature', { hueRotate: 16, contrast: 1.14, saturate: 1.08, brightness: 1.03 }, ['#0284c7', '#7dd3fc']),
  makePreset('autumn', 'Autumn Leaves', 'nature', { sepia: 0.32, hueRotate: -12, saturate: 1.32, contrast: 1.1 }, ['#b91c1c', '#ea580c']),
  makePreset('alpine_pine', 'Alpine Pine', 'nature', { hueRotate: 20, contrast: 1.12, brightness: 0.96, saturate: 1.06 }, ['#14532d', '#4ade80']),
  makePreset('ocean_breeze', 'Ocean Breeze', 'nature', { hueRotate: 26, brightness: 1.04, contrast: 1.06, saturate: 1.18 }, ['#0369a1', '#2dd4bf']),
  makePreset('tropical_palm', 'Tropical Palm', 'nature', { brightness: 1.07, contrast: 1.11, saturate: 1.42, hueRotate: 9 }, ['#16a34a', '#06b6d4']),
  makePreset('meadow_bloom', 'Meadow Bloom', 'nature', { brightness: 1.08, contrast: 1.02, saturate: 1.34, hueRotate: -4 }, ['#4ade80', '#f472b6']),
  makePreset('waterfall_mist', 'Waterfall Mist', 'nature', { brightness: 1.06, contrast: 0.94, saturate: 0.92, hueRotate: 22 }, ['#94a3b8', '#67e8f9']),
  makePreset('canyon_rock', 'Canyon Rock', 'nature', { sepia: 0.25, contrast: 1.18, brightness: 1.0, saturate: 1.24, hueRotate: -9 }, ['#9a3412', '#f59e0b']),
  makePreset('moss_valley', 'Moss Valley', 'nature', { sepia: 0.14, hueRotate: 19, contrast: 1.09, brightness: 0.94, saturate: 0.96 }, ['#3f6212', '#10b981']),
  makePreset('sky_horizon', 'Sky Horizon', 'nature', { brightness: 1.07, contrast: 1.08, saturate: 1.2, hueRotate: 13 }, ['#0ea5e9', '#bae6fd']),
  makePreset('spring_sprout', 'Spring Sprout', 'nature', { brightness: 1.09, contrast: 1.0, saturate: 1.28, hueRotate: 11 }, ['#84cc16', '#bef264']),
  makePreset('nordic_fjord', 'Nordic Fjord', 'nature', { hueRotate: 29, contrast: 1.15, brightness: 0.95, saturate: 0.78 }, ['#1e3a8a', '#64748b']),
  makePreset('savanna_sun', 'Savanna Sun', 'nature', { sepia: 0.29, brightness: 1.05, contrast: 1.1, saturate: 1.29 }, ['#ca8a04', '#fde047']),
  makePreset('coral_lagoon', 'Coral Lagoon', 'nature', { hueRotate: 34, brightness: 1.06, contrast: 1.12, saturate: 1.38 }, ['#0d9488', '#38bdf8']),
  makePreset('aurora_green', 'Aurora Green', 'nature', { hueRotate: 42, contrast: 1.17, brightness: 0.93, saturate: 1.35 }, ['#059669', '#22d3ee']),
  makePreset('redwood_shade', 'Redwood Shade', 'nature', { sepia: 0.2, contrast: 1.14, brightness: 0.9, saturate: 0.9, hueRotate: -6 }, ['#7c2d12', '#14532d']),
  makePreset('birch_morning', 'Birch Morning', 'nature', { brightness: 1.11, contrast: 0.92, saturate: 0.88, hueRotate: 4 }, ['#d9f99d', '#e2e8f0']),
  makePreset('mountain_air', 'Mountain Air', 'nature', { brightness: 1.05, contrast: 1.16, saturate: 0.94, hueRotate: 14 }, ['#38bdf8', '#475569']),
  makePreset('rainforest', 'Rainforest', 'nature', { hueRotate: 23, brightness: 0.92, contrast: 1.2, saturate: 1.26 }, ['#065f46', '#22c55e']),

  // ============================================================================
  // 3. PORTRAIT (25)
  // ============================================================================
  makePreset('clear_skin', 'Clear Skin', 'portrait', { brightness: 1.08, contrast: 0.96, saturate: 1.06 }, ['#fecdd3', '#fff1f2']),
  makePreset('rosy_glow', 'Rosy Glow', 'portrait', { brightness: 1.07, saturate: 1.16, hueRotate: -8 }, ['#fb7185', '#fbcfe8']),
  makePreset('warm_honey', 'Warm Honey', 'portrait', { sepia: 0.18, brightness: 1.07, saturate: 1.2, contrast: 1.02 }, ['#f59e0b', '#fed7aa']),
  makePreset('soft_dream', 'Soft Dream', 'portrait', { brightness: 1.12, contrast: 0.88, saturate: 1.04 }, ['#f5d0fe', '#bfdbfe']),
  makePreset('milk_tea', 'Milk Tea', 'portrait', { sepia: 0.2, brightness: 1.06, contrast: 0.92, saturate: 0.92 }, ['#d6d3d1', '#fde68a']),
  makePreset('studio_light', 'Studio Light', 'portrait', { brightness: 1.1, contrast: 1.1, saturate: 1.04 }, ['#f8fafc', '#cbd5e1']),
  makePreset('golden_tan', 'Golden Tan', 'portrait', { sepia: 0.26, saturate: 1.28, contrast: 1.06 }, ['#b45309', '#f59e0b']),
  makePreset('airy_pink', 'Airy Pink', 'portrait', { brightness: 1.1, saturate: 1.12, hueRotate: -12, contrast: 0.94 }, ['#f472b6', '#fce7f3']),
  makePreset('ivory', 'Ivory', 'portrait', { brightness: 1.11, contrast: 0.95, saturate: 0.95 }, ['#fefce8', '#e2e8f0']),
  makePreset('velvet_skin', 'Velvet Skin', 'portrait', { brightness: 1.05, contrast: 1.04, sepia: 0.1, saturate: 1.1 }, ['#fda4af', '#fdba74']),
  makePreset('k_drama', 'K-Drama Soft', 'portrait', { brightness: 1.08, contrast: 0.96, saturate: 1.12, sepia: 0.08 }, ['#f472b6', '#93c5fd']),
  makePreset('soft_pastel', 'Soft Pastel', 'portrait', { brightness: 1.1, contrast: 0.88, saturate: 1.05, sepia: 0.05 }, ['#fbcfe8', '#ddd6fe']),
  makePreset('porcelain', 'Porcelain', 'portrait', { brightness: 1.13, contrast: 0.93, saturate: 0.91, hueRotate: -3 }, ['#fff1f2', '#e2e8f0']),
  makePreset('apricot_blush', 'Apricot Blush', 'portrait', { sepia: 0.15, brightness: 1.08, contrast: 0.98, saturate: 1.18, hueRotate: -6 }, ['#fb923c', '#fda4af']),
  makePreset('pearl_radiance', 'Pearl Radiance', 'portrait', { brightness: 1.14, contrast: 1.01, saturate: 0.97 }, ['#f1f5f9', '#fce7f3']),
  makePreset('silk_matte', 'Silk Matte', 'portrait', { sepia: 0.11, brightness: 1.04, contrast: 0.89, saturate: 0.94 }, ['#e7e5e4', '#fecdd3']),
  makePreset('bridal_glow', 'Bridal Glow', 'portrait', { sepia: 0.09, brightness: 1.12, contrast: 0.97, saturate: 1.08 }, ['#fff7ed', '#fbcfe8']),
  makePreset('bronze_sun', 'Bronze Sun', 'portrait', { sepia: 0.31, brightness: 1.01, contrast: 1.09, saturate: 1.24, hueRotate: -4 }, ['#92400e', '#fbbf24']),
  makePreset('editorial_face', 'Editorial Face', 'portrait', { contrast: 1.14, brightness: 1.03, saturate: 0.89, sepia: 0.06 }, ['#78716c', '#e7e5e4']),
  makePreset('sweet_peach', 'Sweet Peach', 'portrait', { brightness: 1.09, contrast: 0.96, saturate: 1.22, hueRotate: -9 }, ['#fda4af', '#fed7aa']),
  makePreset('luminous_skin', 'Luminous Skin', 'portrait', { brightness: 1.15, contrast: 1.04, saturate: 1.02 }, ['#fef2f2', '#dbeafe']),
  makePreset('caramel_beauty', 'Caramel Beauty', 'portrait', { sepia: 0.23, brightness: 1.02, contrast: 1.07, saturate: 1.15 }, ['#b45309', '#fed7aa']),
  makePreset('cherry_cheek', 'Cherry Cheek', 'portrait', { brightness: 1.06, contrast: 1.02, saturate: 1.25, hueRotate: -14 }, ['#f43f5e', '#fbcfe8']),
  makePreset('clean_headshot', 'Clean Headshot', 'portrait', { brightness: 1.06, contrast: 1.08, saturate: 0.98 }, ['#e2e8f0', '#94a3b8']),
  makePreset('champagne_tone', 'Champagne Tone', 'portrait', { sepia: 0.19, brightness: 1.09, contrast: 0.99, saturate: 1.01 }, ['#fef3c7', '#e7e5e4']),

  // ============================================================================
  // 4. VINTAGE (25)
  // ============================================================================
  makePreset('vintage', 'Vintage 1978', 'vintage', { sepia: 0.42, contrast: 0.95, brightness: 1.04, saturate: 0.85 }, ['#a16207', '#fef08a']),
  makePreset('kodak_400', 'Kodak 400', 'vintage', { sepia: 0.24, contrast: 1.12, saturate: 1.18, brightness: 1.02 }, ['#dc2626', '#facc15']),
  makePreset('fuji_superia', 'Fuji Superia', 'vintage', { hueRotate: 10, contrast: 1.08, saturate: 1.16, brightness: 1.01 }, ['#16a34a', '#e2e8f0']),
  makePreset('polaroid', 'Polaroid Fade', 'vintage', { sepia: 0.22, contrast: 0.88, brightness: 1.08, saturate: 0.9 }, ['#fef3c7', '#60a5fa']),
  makePreset('vhs_90s', 'VHS 90s', 'vintage', { contrast: 1.15, saturate: 1.22, hueRotate: -14, brightness: 0.96 }, ['#a855f7', '#06b6d4']),
  makePreset('sepia_gold', 'Sepia Gold', 'vintage', { sepia: 0.65, contrast: 1.08, brightness: 1.02 }, ['#713f12', '#eab308']),
  makePreset('grain_70s', '70s Classic', 'vintage', { sepia: 0.36, contrast: 0.92, saturate: 1.22, brightness: 1.01 }, ['#c2410c', '#fbbf24']),
  makePreset('warm_fade', 'Warm Fade', 'vintage', { sepia: 0.3, contrast: 0.84, brightness: 1.08, saturate: 0.92 }, ['#d97706', '#fde68a']),
  makePreset('old_reel', 'Old Reel', 'vintage', { sepia: 0.55, contrast: 1.22, brightness: 0.92, saturate: 0.75 }, ['#451a03', '#a16207']),
  makePreset('faded_memory', 'Faded Memory', 'vintage', { contrast: 0.82, brightness: 1.1, saturate: 0.72, sepia: 0.18 }, ['#cbd5e1', '#fde68a']),
  makePreset('fade', 'Soft Matte Fade', 'vintage', { contrast: 0.84, brightness: 1.08, saturate: 0.88 }, ['#64748b', '#94a3b8']),
  makePreset('portra_800', 'Portra 800', 'vintage', { sepia: 0.17, contrast: 0.98, brightness: 1.05, saturate: 1.1, hueRotate: -3 }, ['#f59e0b', '#fda4af']),
  makePreset('agfa_vista', 'Agfa Vista', 'vintage', { sepia: 0.15, contrast: 1.16, brightness: 1.0, saturate: 1.28, hueRotate: -8 }, ['#ef4444', '#22c55e']),
  makePreset('ektar_100', 'Ektar 100', 'vintage', { sepia: 0.12, contrast: 1.19, brightness: 0.99, saturate: 1.32, hueRotate: -5 }, ['#dc2626', '#3b82f6']),
  makePreset('cinestill_800t', 'CineStill 800T', 'vintage', { contrast: 1.14, brightness: 0.95, saturate: 1.12, hueRotate: 19 }, ['#0284c7', '#ef4444']),
  makePreset('super_8', 'Super 8mm', 'vintage', { sepia: 0.48, contrast: 1.15, brightness: 0.96, saturate: 0.94, hueRotate: -6 }, ['#78350f', '#fbbf24']),
  makePreset('retro_camcorder', 'Camcorder 98', 'vintage', { sepia: 0.16, contrast: 1.07, brightness: 0.97, saturate: 1.14, hueRotate: 8 }, ['#475569', '#22d3ee']),
  makePreset('kodachrome_64', 'Kodachrome 64', 'vintage', { sepia: 0.28, contrast: 1.24, brightness: 0.98, saturate: 1.14, hueRotate: -10 }, ['#b91c1c', '#ca8a04']),
  makePreset('cross_process', 'Cross Process', 'vintage', { contrast: 1.22, brightness: 1.01, saturate: 1.24, hueRotate: 36 }, ['#10b981', '#eab308']),
  makePreset('daguerreotype', 'Antique Tint', 'vintage', { sepia: 0.78, contrast: 1.12, brightness: 0.95, saturate: 0.68 }, ['#44403c', '#d6d3d1']),
  makePreset('analog_dust', 'Analog Dust', 'vintage', { sepia: 0.33, contrast: 0.86, brightness: 1.05, saturate: 0.78 }, ['#a8a29e', '#fde68a']),
  makePreset('lomo_lc', 'Lomo Chrome', 'vintage', { contrast: 1.29, brightness: 0.97, saturate: 1.38, hueRotate: 14 }, ['#0f766e', '#f43f5e']),
  makePreset('nostalgia_85', 'Nostalgia 85', 'vintage', { sepia: 0.39, contrast: 0.91, brightness: 1.07, saturate: 0.86, hueRotate: 5 }, ['#b45309', '#93c5fd']),
  makePreset('retro_chrome', 'Retro Chrome', 'vintage', { sepia: 0.21, contrast: 1.18, brightness: 1.02, saturate: 0.82, hueRotate: 9 }, ['#334155', '#fbbf24']),
  makePreset('amber_slide', 'Amber Slide', 'vintage', { sepia: 0.52, contrast: 1.04, brightness: 1.03, saturate: 1.16, hueRotate: -7 }, ['#9a3412', '#fde047']),

  // ============================================================================
  // 5. DARK (25)
  // ============================================================================
  makePreset('moody_dark', 'Moody Dark', 'dark', { contrast: 1.22, brightness: 0.88, saturate: 0.72 }, ['#1e293b', '#0f172a']),
  makePreset('dark_matte', 'Dark Matte', 'dark', { contrast: 0.92, brightness: 0.86, saturate: 0.68 }, ['#27272a', '#52525b']),
  makePreset('storm', 'Storm', 'dark', { contrast: 1.26, brightness: 0.85, saturate: 0.62, hueRotate: 12 }, ['#1e3a8a', '#334155']),
  makePreset('shadowed', 'Shadowed', 'dark', { brightness: 0.82, contrast: 1.28, saturate: 0.82 }, ['#09090b', '#3f3f46']),
  makePreset('obsidian', 'Obsidian', 'dark', { brightness: 0.8, contrast: 1.36, saturate: 0.7 }, ['#020617', '#1e293b']),
  makePreset('rainy_day', 'Rainy Day', 'dark', { hueRotate: 14, brightness: 0.92, contrast: 1.06, saturate: 0.65 }, ['#334155', '#60a5fa']),
  makePreset('cold_steel', 'Cold Steel', 'dark', { saturate: 0.5, contrast: 1.22, hueRotate: 10, brightness: 0.94 }, ['#475569', '#94a3b8']),
  makePreset('velvet_night', 'Velvet Night', 'dark', { hueRotate: -20, brightness: 0.86, contrast: 1.2, saturate: 0.95 }, ['#4c1d95', '#1e1b4b']),
  makePreset('ice_mist', 'Dark Ice Mist', 'dark', { brightness: 0.91, contrast: 0.96, saturate: 0.64, hueRotate: 18 }, ['#334155', '#bae6fd']),
  makePreset('eclipse', 'Eclipse', 'dark', { brightness: 0.76, contrast: 1.42, saturate: 0.6 }, ['#020617', '#475569']),
  makePreset('gotham_shadow', 'Gotham Shadow', 'dark', { sepia: 0.12, brightness: 0.81, contrast: 1.33, saturate: 0.58, hueRotate: 16 }, ['#09090b', '#1e3a8a']),
  makePreset('midnight_ink', 'Midnight Ink', 'dark', { brightness: 0.79, contrast: 1.25, saturate: 0.86, hueRotate: 26 }, ['#172554', '#020617']),
  makePreset('crimson_dusk', 'Crimson Dusk', 'dark', { brightness: 0.84, contrast: 1.24, saturate: 0.92, hueRotate: -24 }, ['#450a0a', '#7f1d1d']),
  makePreset('onyx_fade', 'Onyx Fade', 'dark', { brightness: 0.85, contrast: 0.89, saturate: 0.55 }, ['#18181b', '#3f3f46']),
  makePreset('slate_storm', 'Slate Storm', 'dark', { brightness: 0.87, contrast: 1.18, saturate: 0.48, hueRotate: 21 }, ['#1e293b', '#64748b']),
  makePreset('dark_emerald', 'Dark Emerald', 'dark', { brightness: 0.83, contrast: 1.21, saturate: 0.79, hueRotate: 35 }, ['#022c22', '#065f46']),
  makePreset('ashen_dusk', 'Ashen Dusk', 'dark', { sepia: 0.16, brightness: 0.84, contrast: 1.14, saturate: 0.52 }, ['#292524', '#57534e']),
  makePreset('phantom_plum', 'Phantom Plum', 'dark', { brightness: 0.82, contrast: 1.19, saturate: 0.88, hueRotate: -30 }, ['#3b0764', '#1e1b4b']),
  makePreset('after_hours', 'After Hours', 'dark', { brightness: 0.78, contrast: 1.3, saturate: 1.05, hueRotate: -12 }, ['#0f172a', '#b45309']),
  makePreset('deep_abyss', 'Deep Abyss', 'dark', { brightness: 0.74, contrast: 1.38, saturate: 0.74, hueRotate: 28 }, ['#020617', '#0e7490']),
  makePreset('carbon_matte', 'Carbon Matte', 'dark', { brightness: 0.89, contrast: 0.95, saturate: 0.42 }, ['#18181b', '#27272a']),
  makePreset('cobalt_night', 'Cobalt Night', 'dark', { brightness: 0.81, contrast: 1.27, saturate: 1.08, hueRotate: 22 }, ['#1e3a8a', '#020617']),
  makePreset('umber_night', 'Umber Night', 'dark', { sepia: 0.28, brightness: 0.83, contrast: 1.22, saturate: 0.78 }, ['#451a03', '#1c1917']),
  makePreset('twilight_fog', 'Twilight Fog', 'dark', { brightness: 0.89, contrast: 0.86, saturate: 0.66, hueRotate: -15 }, ['#312e81', '#64748b']),
  makePreset('low_key_pro', 'Low Key Pro', 'dark', { brightness: 0.77, contrast: 1.35, saturate: 0.84 }, ['#000000', '#334155']),

  // ============================================================================
  // 6. FOOD (25)
  // ============================================================================
  makePreset('latte', 'Latte', 'food', { sepia: 0.22, contrast: 0.96, brightness: 1.04, saturate: 0.95 }, ['#b45309', '#fde68a']),
  makePreset('peach_cream', 'Peach Cream', 'food', { sepia: 0.16, saturate: 1.24, brightness: 1.08 }, ['#fb923c', '#fda4af']),
  makePreset('cozy_cafe', 'Cozy Cafe', 'food', { sepia: 0.28, contrast: 1.08, brightness: 0.96, saturate: 1.06 }, ['#78350f', '#d97706']),
  makePreset('golden_hour', 'Golden Platter', 'food', { sepia: 0.28, saturate: 1.42, brightness: 1.06, contrast: 1.05 }, ['#f59e0b', '#fbbf24']),
  makePreset('warm', 'Warm Taste', 'food', { sepia: 0.24, saturate: 1.24, brightness: 1.04 }, ['#f97316', '#fde047']),
  makePreset('amber', 'Amber Roast', 'food', { sepia: 0.38, saturate: 1.36, contrast: 1.08 }, ['#d97706', '#f59e0b']),
  makePreset('candlelight', 'Candlelit Dinner', 'food', { sepia: 0.42, brightness: 0.95, contrast: 1.14, saturate: 1.26 }, ['#7c2d12', '#f59e0b']),
  makePreset('honeycomb', 'Honeycomb', 'food', { sepia: 0.22, brightness: 1.08, saturate: 1.38 }, ['#eab308', '#fde047']),
  makePreset('terracotta', 'Terracotta Spice', 'food', { sepia: 0.36, hueRotate: -8, contrast: 1.12, saturate: 1.18 }, ['#9a3412', '#fb923c']),
  makePreset('fresh_salad', 'Fresh Salad', 'food', { brightness: 1.06, contrast: 1.1, saturate: 1.44, hueRotate: 8 }, ['#16a34a', '#a3e635']),
  makePreset('espresso_bean', 'Espresso Bean', 'food', { sepia: 0.34, brightness: 0.92, contrast: 1.2, saturate: 1.08 }, ['#451a03', '#78350f']),
  makePreset('juicy_berry', 'Juicy Berry', 'food', { brightness: 1.04, contrast: 1.14, saturate: 1.48, hueRotate: -11 }, ['#e11d48', '#fb7185']),
  makePreset('citrus_zing', 'Citrus Zing', 'food', { brightness: 1.09, contrast: 1.09, saturate: 1.45, hueRotate: 4 }, ['#f59e0b', '#facc15']),
  makePreset('matcha_cream', 'Matcha Cream', 'food', { sepia: 0.1, brightness: 1.06, contrast: 0.98, saturate: 1.2, hueRotate: 18 }, ['#4d7c0f', '#bef264']),
  makePreset('bakery_crust', 'Bakery Crust', 'food', { sepia: 0.27, brightness: 1.05, contrast: 1.06, saturate: 1.22, hueRotate: -4 }, ['#b45309', '#fed7aa']),
  makePreset('saffron_rice', 'Saffron Glow', 'food', { sepia: 0.31, brightness: 1.07, contrast: 1.11, saturate: 1.4 }, ['#d97706', '#fde047']),
  makePreset('grill_char', 'Grill Char', 'food', { sepia: 0.18, brightness: 0.97, contrast: 1.25, saturate: 1.32, hueRotate: -6 }, ['#7c2d12', '#ef4444']),
  makePreset('vanilla_frost', 'Vanilla Frost', 'food', { brightness: 1.12, contrast: 0.94, saturate: 1.05, sepia: 0.12 }, ['#fef9c3', '#f8fafc']),
  makePreset('caramel_drizzle', 'Caramel Drizzle', 'food', { sepia: 0.44, brightness: 1.01, contrast: 1.1, saturate: 1.29 }, ['#92400e', '#f59e0b']),
  makePreset('sushi_crisp', 'Sushi Crisp', 'food', { brightness: 1.06, contrast: 1.16, saturate: 1.34, hueRotate: -3 }, ['#fb7185', '#f8fafc']),
  makePreset('pastry_morning', 'Pastry Morning', 'food', { sepia: 0.19, brightness: 1.09, contrast: 0.99, saturate: 1.17 }, ['#fde68a', '#fdba74']),
  makePreset('chili_heat', 'Chili Heat', 'food', { brightness: 1.01, contrast: 1.19, saturate: 1.54, hueRotate: -15 }, ['#b91c1c', '#f97316']),
  makePreset('cocoa_velvet', 'Cocoa Velvet', 'food', { sepia: 0.32, brightness: 0.93, contrast: 1.16, saturate: 0.96 }, ['#3f200e', '#a16207']),
  makePreset('mint_gelato', 'Mint Gelato', 'food', { brightness: 1.08, contrast: 1.02, saturate: 1.26, hueRotate: 22 }, ['#34d399', '#a7f3d0']),
  makePreset('bistro_plate', 'Bistro Plate', 'food', { sepia: 0.14, brightness: 1.03, contrast: 1.14, saturate: 1.27 }, ['#ea580c', '#cbd5e1']),

  // ============================================================================
  // 7. BLACK & WHITE (25) — Strictly distinct monochrome luminance/contrast/toning
  // ============================================================================
  makePreset('bw', 'Pure B&W', 'bw', { grayscale: 1, contrast: 1.18 }, ['#18181b', '#e4e4e7']),
  makePreset('leica_mono', 'Leica Mono', 'bw', { grayscale: 1, contrast: 1.32, brightness: 0.96 }, ['#09090b', '#a1a1aa']),
  makePreset('hi_con_bw', 'Punch B&W', 'bw', { grayscale: 1, contrast: 1.48, brightness: 1.02 }, ['#000000', '#ffffff']),
  makePreset('silver_gelatin', 'Silver Film', 'bw', { grayscale: 1, contrast: 1.12, brightness: 1.06 }, ['#52525b', '#f4f4f5']),
  makePreset('charcoal', 'Charcoal', 'bw', { grayscale: 1, contrast: 1.25, brightness: 0.88 }, ['#18181b', '#52525b']),
  makePreset('newspaper', 'Newspaper', 'bw', { grayscale: 1, contrast: 0.88, brightness: 1.08 }, ['#71717a', '#d4d4d8']),
  makePreset('matte_gray', 'Matte Gray', 'bw', { grayscale: 1, contrast: 0.84, brightness: 0.96 }, ['#3f3f46', '#a1a1aa']),
  makePreset('classic_noir', 'Classic Noir', 'bw', { grayscale: 1, contrast: 1.4, brightness: 0.86 }, ['#000000', '#52525b']),
  makePreset('soft_mono', 'Soft Mono', 'bw', { grayscale: 1, contrast: 0.95, brightness: 1.05 }, ['#a1a1aa', '#f4f4f5']),
  makePreset('high_key_bw', 'High Key B&W', 'bw', { grayscale: 1, contrast: 1.08, brightness: 1.16 }, ['#d4d4d8', '#ffffff']),
  makePreset('ink_contrast', 'Deep Ink B&W', 'bw', { grayscale: 1, contrast: 1.58, brightness: 0.91 }, ['#000000', '#3f3f46']),
  makePreset('ilford_hp5', 'Ilford HP5', 'bw', { grayscale: 1, contrast: 1.22, brightness: 1.01 }, ['#27272a', '#e4e4e7']),
  makePreset('tri_x_400', 'Tri-X 400', 'bw', { grayscale: 1, contrast: 1.36, brightness: 0.99 }, ['#18181b', '#d4d4d8']),
  makePreset('graphite_fade', 'Graphite Fade', 'bw', { grayscale: 1, contrast: 0.78, brightness: 1.02 }, ['#52525b', '#a1a1aa']),
  makePreset('darkroom_shadow', 'Darkroom Shadow', 'bw', { grayscale: 1, contrast: 1.15, brightness: 0.82 }, ['#09090b', '#3f3f46']),
  makePreset('chrome_silver', 'Chrome Silver', 'bw', { grayscale: 1, contrast: 1.28, brightness: 1.09 }, ['#71717a', '#f8fafc']),
  makePreset('selenium_tone', 'Selenium Tone', 'bw', { grayscale: 1, sepia: 0.14, hueRotate: -40, contrast: 1.2, brightness: 0.98 }, ['#3f3f46', '#a8a29e']),
  makePreset('platinum_warm', 'Platinum Warm', 'bw', { grayscale: 1, sepia: 0.22, contrast: 1.14, brightness: 1.03 }, ['#57534e', '#e7e5e4']),
  makePreset('cyanotype_mono', 'Cyanotype Blue', 'bw', { grayscale: 1, sepia: 0.28, hueRotate: 175, contrast: 1.18, brightness: 0.96 }, ['#1e3a8a', '#93c5fd']),
  makePreset('split_sepia_bw', 'Split Sepia', 'bw', { grayscale: 1, sepia: 0.34, contrast: 1.24, brightness: 0.95 }, ['#44403c', '#d6d3d1']),
  makePreset('slate_mono', 'Slate Mono', 'bw', { grayscale: 1, sepia: 0.16, hueRotate: 195, contrast: 1.27, brightness: 0.94 }, ['#334155', '#cbd5e1']),
  makePreset('silver_olive', 'Silver Olive', 'bw', { grayscale: 1, sepia: 0.24, hueRotate: 48, contrast: 1.12, brightness: 0.99 }, ['#3f6212', '#d4d4d8']),
  makePreset('faded_chalk', 'Faded Chalk', 'bw', { grayscale: 1, contrast: 0.81, brightness: 1.14 }, ['#a1a1aa', '#ffffff']),
  makePreset('bleach_bw', 'Bleach Bypass', 'bw', { grayscale: 0.92, contrast: 1.44, brightness: 0.95, saturate: 0.85 }, ['#18181b', '#94a3b8']),
  makePreset('crisp_bw_hd', 'Crisp B&W HD', 'bw', { grayscale: 1, contrast: 1.45, brightness: 1.07 }, ['#09090b', '#f8fafc']),

  // ============================================================================
  // 8. SOCIAL MEDIA (25)
  // ============================================================================
  makePreset('vivid', 'Vivid Pop', 'social', { saturate: 1.38, contrast: 1.12, brightness: 1.03 }, ['#3b82f6', '#ec4899']),
  makePreset('crisp_hd', 'Crisp HD', 'social', { contrast: 1.18, saturate: 1.18, brightness: 1.04 }, ['#0ea5e9', '#38bdf8']),
  makePreset('cyber_glow', 'Cyber Glow', 'social', { saturate: 1.65, contrast: 1.25, hueRotate: -18 }, ['#8b5cf6', '#06b6d4']),
  makePreset('viral_pop', 'Viral Pop', 'social', { saturate: 1.48, contrast: 1.16, brightness: 1.05 }, ['#ef4444', '#f59e0b']),
  makePreset('clean_reel', 'Clean Reel', 'social', { contrast: 1.08, brightness: 1.05, saturate: 1.1 }, ['#60a5fa', '#cbd5e1']),
  makePreset('daily_clean', 'Daily Clean', 'social', { brightness: 1.04, contrast: 1.06, saturate: 1.08 }, ['#94a3b8', '#e2e8f0']),
  makePreset('urban_walk', 'Urban Street', 'social', { contrast: 1.15, saturate: 0.9, brightness: 1.0 }, ['#475569', '#94a3b8']),
  makePreset('bright_vlog', 'Bright Vlog', 'social', { brightness: 1.12, contrast: 1.05, saturate: 1.15 }, ['#f8fafc', '#93c5fd']),
  makePreset('sunset', 'Sunset Reels', 'social', { sepia: 0.28, saturate: 1.52, hueRotate: -10, brightness: 1.02 }, ['#ef4444', '#f59e0b']),
  makePreset('sahara', 'Sahara Feed', 'social', { sepia: 0.45, saturate: 1.28, brightness: 1.06, contrast: 1.05 }, ['#a16207', '#fbbf24']),
  makePreset('cool', 'Cool Story', 'social', { hueRotate: 12, saturate: 0.92, contrast: 1.06, brightness: 1.02 }, ['#3b82f6', '#a5f3fc']),
  makePreset('cyberpunk', 'Cyberpunk', 'social', { saturate: 1.8, contrast: 1.28, hueRotate: -28 }, ['#ec4899', '#06b6d4']),
  makePreset('neon_tokyo', 'Neon Tokyo', 'social', { saturate: 1.7, contrast: 1.24, hueRotate: 24, brightness: 0.98 }, ['#8b5cf6', '#38bdf8']),
  makePreset('electric_blue', 'Electric Blue', 'social', { hueRotate: 20, saturate: 1.42, contrast: 1.16 }, ['#2563eb', '#22d3ee']),
  makePreset('synthwave', 'Synthwave', 'social', { hueRotate: -32, saturate: 1.65, contrast: 1.22 }, ['#d946ef', '#4f46e5']),
  makePreset('tiktok_boost', 'TikTok Boost', 'social', { brightness: 1.07, contrast: 1.2, saturate: 1.44, hueRotate: -5 }, ['#fe2c55', '#25f4ee']),
  makePreset('shorts_punch', 'Shorts Punch', 'social', { brightness: 1.06, contrast: 1.23, saturate: 1.36 }, ['#ef4444', '#f8fafc']),
  makePreset('insta_aesthetic', 'Aesthetic Feed', 'social', { sepia: 0.14, brightness: 1.06, contrast: 0.97, saturate: 1.12, hueRotate: -4 }, ['#f472b6', '#fde68a']),
  makePreset('creator_hdr', 'Creator HDR', 'social', { contrast: 1.27, brightness: 1.03, saturate: 1.32 }, ['#2563eb', '#f59e0b']),
  makePreset('hyper_color', 'Hyper Color', 'social', { brightness: 1.04, contrast: 1.14, saturate: 1.72, hueRotate: 7 }, ['#ec4899', '#22c55e']),
  makePreset('vapor_chill', 'Vapor Chill', 'social', { brightness: 1.05, contrast: 1.09, saturate: 1.34, hueRotate: -42 }, ['#c084fc', '#67e8f9']),
  makePreset('lifestyle_pro', 'Lifestyle Pro', 'social', { sepia: 0.08, brightness: 1.08, contrast: 1.09, saturate: 1.16 }, ['#38bdf8', '#fde047']),
  makePreset('travel_snap', 'Travel Snap', 'social', { brightness: 1.05, contrast: 1.15, saturate: 1.39, hueRotate: 5 }, ['#0ea5e9', '#10b981']),
  makePreset('minimal_slate', 'Minimal Slate', 'social', { brightness: 1.03, contrast: 1.11, saturate: 0.78, hueRotate: 6 }, ['#64748b', '#e2e8f0']),
  makePreset('party_flash', 'Party Flash', 'social', { brightness: 1.09, contrast: 1.21, saturate: 1.56, hueRotate: -16 }, ['#f43f5e', '#8b5cf6']),
];

export const TOTAL_FILTER_COUNT = FILTER_PRESETS.filter((p) => p.id !== 'none').length;

export function getFilterCategoryCount(category: FilterCategory): number {
  if (category === 'all') return TOTAL_FILTER_COUNT;
  return FILTER_PRESETS.filter((p) => p.id !== 'none' && p.category === category).length;
}

export const DEFAULT_ADJUSTMENTS: VideoAdjustments = {
  filterPreset: 'none',
  filterIntensity: 100,
  brightness: 100,
  contrast: 100,
  saturation: 100,
};

export function findFilterPreset(id: string): FilterPresetDefinition {
  return FILTER_PRESETS.find((p) => p.id === id) ?? FILTER_PRESETS[0];
}

/**
 * Scales individual CSS filter functions by an intensity ratio (0..1) so 0%..100%
 * filter strength sliders work identically in both live preview and Canvas export.
 */
export function scaleCssFilterByIntensity(cssFilter: string, intensityPct: number): string {
  if (!cssFilter || intensityPct <= 0) return '';
  if (intensityPct >= 100) return cssFilter;

  const ratio = Math.max(0, Math.min(1, intensityPct / 100));
  return cssFilter.replace(/([a-z-]+)\(([^)]+)\)/gi, (_match, fn: string, rawVal: string) => {
    const name = fn.toLowerCase();
    if (name === 'hue-rotate') {
      const deg = parseFloat(rawVal);
      if (Number.isFinite(deg)) {
        return `hue-rotate(${(deg * ratio).toFixed(1)}deg)`;
      }
      return _match;
    }
    const num = parseFloat(rawVal);
    if (!Number.isFinite(num)) return _match;

    const baseline = name === 'sepia' || name === 'grayscale' ? 0 : 1;
    const scaled = baseline + (num - baseline) * ratio;
    return `${name}(${scaled.toFixed(2)})`;
  });
}

export function buildCssFilter(adj: VideoAdjustments): string {
  const parts: string[] = [];
  const preset = FILTER_PRESETS.find((p) => p.id === adj.filterPreset);
  const intensity = adj.filterIntensity ?? 100;
  if (preset && preset.cssFilter && intensity > 0) {
    const scaled = scaleCssFilterByIntensity(preset.cssFilter, intensity);
    if (scaled) parts.push(scaled);
  }
  if (adj.brightness !== 100) {
    parts.push(`brightness(${(adj.brightness / 100).toFixed(2)})`);
  }
  if (adj.contrast !== 100) {
    parts.push(`contrast(${(adj.contrast / 100).toFixed(2)})`);
  }
  if (adj.saturation !== 100) {
    parts.push(`saturate(${(adj.saturation / 100).toFixed(2)})`);
  }
  return parts.length > 0 ? parts.join(' ') : 'none';
}

export function hasCustomAdjustments(adj: VideoAdjustments): boolean {
  return (
    adj.filterPreset !== 'none' ||
    adj.brightness !== 100 ||
    adj.contrast !== 100 ||
    adj.saturation !== 100
  );
}

export const SPEED_OPTIONS: number[] = [
  0.1, 0.2, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0,
];

export const ASPECT_RATIO_OPTIONS: Array<{
  id: AspectRatioPreset;
  label: string;
  ratio: number | null;
}> = [
  { id: 'original', label: 'Original', ratio: null },
  { id: '9:16', label: '9:16', ratio: 9 / 16 },
  { id: '16:9', label: '16:9', ratio: 16 / 9 },
  { id: '1:1', label: '1:1', ratio: 1 },
  { id: '4:5', label: '4:5', ratio: 4 / 5 },
];

export function getTargetAspectNumber(
  preset: AspectRatioPreset,
  srcW: number,
  srcH: number
): number {
  const found = ASPECT_RATIO_OPTIONS.find((o) => o.id === preset);
  if (found && found.ratio !== null) {
    return found.ratio;
  }
  return srcW > 0 && srcH > 0 ? srcW / srcH : 16 / 9;
}
