import { MotionTrack, MotionTrackPoint } from '../types/editor';

/**
 * Pure block-matching tracker step operating on RGBA image buffers.
 * Compares a template patch around (prevPxX, prevPxY) against candidate offsets within searchRadius
 * using Sum of Absolute Differences (SAD) weighted toward luminance & chroma edges.
 */
export function matchTemplatePatch(
  templatePixels: Uint8ClampedArray,
  frameW: number,
  frameH: number,
  tplCenterX: number,
  tplCenterY: number,
  targetPixels: Uint8ClampedArray,
  guessCenterX: number,
  guessCenterY: number,
  patchRadius = 10,
  searchRadius = 22
): { x: number; y: number; confidence: number } {
  const minX = Math.max(patchRadius, Math.round(guessCenterX) - searchRadius);
  const maxX = Math.min(frameW - 1 - patchRadius, Math.round(guessCenterX) + searchRadius);
  const minY = Math.max(patchRadius, Math.round(guessCenterY) - searchRadius);
  const maxY = Math.min(frameH - 1 - patchRadius, Math.round(guessCenterY) + searchRadius);

  const clampedTplX = Math.max(patchRadius, Math.min(frameW - 1 - patchRadius, Math.round(tplCenterX)));
  const clampedTplY = Math.max(patchRadius, Math.min(frameH - 1 - patchRadius, Math.round(tplCenterY)));

  if (minX > maxX || minY > maxY) {
    return { x: guessCenterX, y: guessCenterY, confidence: 0.4 };
  }

  let bestX = Math.round(guessCenterX);
  let bestY = Math.round(guessCenterY);
  let bestSad = Infinity;
  const sampleStep = 2;
  let sampleCount = 0;

  for (let py = -patchRadius; py <= patchRadius; py += sampleStep) {
    for (let px = -patchRadius; px <= patchRadius; px += sampleStep) {
      sampleCount += 1;
    }
  }

  for (let cy = minY; cy <= maxY; cy += 2) {
    for (let cx = minX; cx <= maxX; cx += 2) {
      let sad = 0;
      for (let py = -patchRadius; py <= patchRadius; py += sampleStep) {
        const ty = clampedTplY + py;
        const fy = cy + py;
        for (let px = -patchRadius; px <= patchRadius; px += sampleStep) {
          const tIdx = (ty * frameW + (clampedTplX + px)) * 4;
          const fIdx = (fy * frameW + (cx + px)) * 4;
          const dr = Math.abs(templatePixels[tIdx] - targetPixels[fIdx]);
          const dg = Math.abs(templatePixels[tIdx + 1] - targetPixels[fIdx + 1]);
          const db = Math.abs(templatePixels[tIdx + 2] - targetPixels[fIdx + 2]);
          sad += dr * 0.3 + dg * 0.59 + db * 0.11;
          if (sad >= bestSad) break;
        }
        if (sad >= bestSad) break;
      }
      if (sad < bestSad) {
        bestSad = sad;
        bestX = cx;
        bestY = cy;
      }
    }
  }

  // Sub-pixel 1px refinement around best coarse match
  const fineMinX = Math.max(patchRadius, bestX - 2);
  const fineMaxX = Math.min(frameW - 1 - patchRadius, bestX + 2);
  const fineMinY = Math.max(patchRadius, bestY - 2);
  const fineMaxY = Math.min(frameH - 1 - patchRadius, bestY + 2);

  for (let cy = fineMinY; cy <= fineMaxY; cy++) {
    for (let cx = fineMinX; cx <= fineMaxX; cx++) {
      let sad = 0;
      for (let py = -patchRadius; py <= patchRadius; py += sampleStep) {
        const ty = clampedTplY + py;
        const fy = cy + py;
        for (let px = -patchRadius; px <= patchRadius; px += sampleStep) {
          const tIdx = (ty * frameW + (clampedTplX + px)) * 4;
          const fIdx = (fy * frameW + (cx + px)) * 4;
          const dr = Math.abs(templatePixels[tIdx] - targetPixels[fIdx]);
          const dg = Math.abs(templatePixels[tIdx + 1] - targetPixels[fIdx + 1]);
          const db = Math.abs(templatePixels[tIdx + 2] - targetPixels[fIdx + 2]);
          sad += dr * 0.3 + dg * 0.59 + db * 0.11;
          if (sad >= bestSad) break;
        }
        if (sad >= bestSad) break;
      }
      if (sad < bestSad) {
        bestSad = sad;
        bestX = cx;
        bestY = cy;
      }
    }
  }

  const avgSad = bestSad / Math.max(1, sampleCount);
  const confidence = Math.max(0, Math.min(1, 1 - avgSad / 70));
  return { x: bestX, y: bestY, confidence };
}

/**
 * Tracks a chosen normalized stage coordinate (anchorX, anchorY in -50..50) across a video clip window.
 */
export async function trackObjectInVideo(params: {
  videoUrl: string;
  anchorX: number; // -50..50 (% from stage center)
  anchorY: number; // -50..50 (% from stage center)
  startTime: number;
  endTime: number;
  label: string;
  trackId: string;
  onProgress?: (pct: number) => void;
}): Promise<MotionTrack> {
  const {
    videoUrl,
    anchorX,
    anchorY,
    startTime,
    endTime,
    label,
    trackId,
    onProgress,
  } = params;

  const span = Math.max(0.2, endTime - startTime);
  const sampleRate = span > 12 ? 8 : 12; // 8-12 Hz gives fast, smooth tracking on mobile
  const totalSteps = Math.max(3, Math.min(160, Math.round(span * sampleRate)));

  const video = document.createElement('video');
  video.src = videoUrl;
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error('Video load timed out')), 8000);
      video.onloadeddata = () => {
        window.clearTimeout(timer);
        resolve();
      };
      video.onerror = () => {
        window.clearTimeout(timer);
        reject(new Error('Could not decode video for motion tracking.'));
      };
    });

    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 360;
    const scale = Math.min(1, 220 / Math.max(vw, vh));
    const fw = Math.max(96, Math.round(vw * scale));
    const fh = Math.max(72, Math.round(vh * scale));

    const canvas = document.createElement('canvas');
    canvas.width = fw;
    canvas.height = fh;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) throw new Error('Canvas unavailable for motion tracking.');

    let curPxX = ((anchorX + 50) / 100) * fw;
    let curPxY = ((anchorY + 50) / 100) * fh;

    const points: MotionTrackPoint[] = [];
    let anchorTemplate: Uint8ClampedArray | null = null;
    let anchorTplX = curPxX;
    let anchorTplY = curPxY;
    let prevFramePixels: Uint8ClampedArray | null = null;
    let prevPxX = curPxX;
    let prevPxY = curPxY;

    const seekToFrame = (t: number) =>
      new Promise<void>((resolve) => {
        const clampedT = Math.max(0, Math.min(Math.max(0, video.duration - 0.02), t));
        if (Math.abs(video.currentTime - clampedT) < 0.008) {
          resolve();
          return;
        }
        const onSeeked = () => resolve();
        video.addEventListener('seeked', onSeeked, { once: true });
        video.currentTime = clampedT;
      });

    for (let i = 0; i <= totalSteps; i++) {
      const ratio = i / totalSteps;
      const t = startTime + ratio * (endTime - startTime);
      await seekToFrame(t);

      ctx.drawImage(video, 0, 0, fw, fh);
      const frameData = ctx.getImageData(0, 0, fw, fh).data;

      if (i === 0) {
        anchorTemplate = new Uint8ClampedArray(frameData);
        prevFramePixels = new Uint8ClampedArray(frameData);
        anchorTplX = curPxX;
        anchorTplY = curPxY;
        prevPxX = curPxX;
        prevPxY = curPxY;
        points.push({
          time: Number(t.toFixed(3)),
          x: Number(anchorX.toFixed(2)),
          y: Number(anchorY.toFixed(2)),
          confidence: 1,
        });
      } else if (prevFramePixels && anchorTemplate) {
        // Track frame-to-frame delta, then refine slightly against initial anchor template to prevent drift
        const frameMatch = matchTemplatePatch(
          prevFramePixels,
          fw,
          fh,
          prevPxX,
          prevPxY,
          frameData,
          curPxX,
          curPxY,
          Math.max(6, Math.round(Math.min(fw, fh) * 0.06)),
          Math.max(12, Math.round(Math.min(fw, fh) * 0.14))
        );

        curPxX = frameMatch.x;
        curPxY = frameMatch.y;

        // Re-anchor check if match quality stays high against original appearance
        const anchorMatch = matchTemplatePatch(
          anchorTemplate,
          fw,
          fh,
          anchorTplX,
          anchorTplY,
          frameData,
          curPxX,
          curPxY,
          Math.max(6, Math.round(Math.min(fw, fh) * 0.06)),
          8
        );
        if (anchorMatch.confidence > 0.72) {
          curPxX = curPxX * 0.55 + anchorMatch.x * 0.45;
          curPxY = curPxY * 0.55 + anchorMatch.y * 0.45;
        }

        prevFramePixels = new Uint8ClampedArray(frameData);
        prevPxX = curPxX;
        prevPxY = curPxY;

        const normX = Math.max(-48, Math.min(48, (curPxX / fw) * 100 - 50));
        const normY = Math.max(-48, Math.min(48, (curPxY / fh) * 100 - 50));
        points.push({
          time: Number(t.toFixed(3)),
          x: Number(normX.toFixed(2)),
          y: Number(normY.toFixed(2)),
          confidence: Number(frameMatch.confidence.toFixed(2)),
        });
      }

      onProgress?.(Math.round((i / totalSteps) * 100));
    }

    return {
      id: trackId,
      label,
      anchorX,
      anchorY,
      startTime,
      endTime,
      points,
    };
  } finally {
    video.removeAttribute('src');
    video.load();
  }
}

/**
 * Evaluates a tracked target's normalized position (x, y in -50..50 %) at source timeline `time`.
 */
export function evaluateMotionTrack(
  track: MotionTrack | undefined,
  time: number
): { x: number; y: number } | null {
  if (!track || track.points.length === 0) return null;
  const pts = track.points;
  if (time <= pts[0].time) return { x: pts[0].x, y: pts[0].y };
  const last = pts[pts.length - 1];
  if (time >= last.time) return { x: last.x, y: last.y };

  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    if (time >= a.time && time <= b.time) {
      const span = b.time - a.time;
      const t = span > 1e-6 ? (time - a.time) / span : 0;
      return {
        x: a.x + (b.x - a.x) * t,
        y: a.y + (b.y - a.y) * t,
      };
    }
  }
  return { x: last.x, y: last.y };
}
