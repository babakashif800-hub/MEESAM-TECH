import { KeyframeEasing, TransformKeyframe } from '../types/editor';

export interface EvaluatedTransform {
  x: number;
  y: number;
  scale: number;
  rotation: number;
  opacity: number;
}

export const DEFAULT_TRANSFORM: EvaluatedTransform = {
  x: 0,
  y: 0,
  scale: 1,
  rotation: 0,
  opacity: 1,
};

function applyEasing(t: number, easing: KeyframeEasing): number {
  const c = Math.max(0, Math.min(1, t));
  switch (easing) {
    case 'ease-in':
      return c * c;
    case 'ease-out':
      return 1 - (1 - c) * (1 - c);
    case 'ease-in-out':
      return c < 0.5 ? 2 * c * c : 1 - Math.pow(-2 * c + 2, 2) / 2;
    case 'linear':
    default:
      return c;
  }
}

export function evaluateKeyframes(
  keyframes: TransformKeyframe[] | undefined,
  time: number,
  fallback: EvaluatedTransform = DEFAULT_TRANSFORM
): EvaluatedTransform {
  if (!keyframes || keyframes.length === 0) {
    return fallback;
  }

  const sorted = [...keyframes].sort((a, b) => a.time - b.time);
  if (time <= sorted[0].time) {
    const k = sorted[0];
    return { x: k.x, y: k.y, scale: k.scale, rotation: k.rotation, opacity: k.opacity };
  }
  const last = sorted[sorted.length - 1];
  if (time >= last.time) {
    return {
      x: last.x,
      y: last.y,
      scale: last.scale,
      rotation: last.rotation,
      opacity: last.opacity,
    };
  }

  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (time >= a.time && time <= b.time) {
      const span = Math.max(0.0001, b.time - a.time);
      const rawT = (time - a.time) / span;
      const t = applyEasing(rawT, b.easing || a.easing || 'ease-in-out');
      return {
        x: a.x + (b.x - a.x) * t,
        y: a.y + (b.y - a.y) * t,
        scale: a.scale + (b.scale - a.scale) * t,
        rotation: a.rotation + (b.rotation - a.rotation) * t,
        opacity: a.opacity + (b.opacity - a.opacity) * t,
      };
    }
  }

  return fallback;
}

export function createMotionPresetKeyframes(
  preset: 'zoom_in' | 'zoom_out' | 'pan_lr' | 'fade_pop',
  startTime: number,
  endTime: number,
  makeId: () => string
): TransformKeyframe[] {
  const s = Number(startTime.toFixed(2));
  const e = Number(Math.max(startTime + 0.4, endTime).toFixed(2));
  const mid = Number(((s + e) / 2).toFixed(2));

  switch (preset) {
    case 'zoom_in':
      return [
        { id: makeId(), time: s, x: 0, y: 0, scale: 1.0, rotation: 0, opacity: 1, easing: 'ease-in-out' },
        { id: makeId(), time: e, x: 0, y: 0, scale: 1.35, rotation: 0, opacity: 1, easing: 'ease-in-out' },
      ];
    case 'zoom_out':
      return [
        { id: makeId(), time: s, x: 0, y: 0, scale: 1.35, rotation: 0, opacity: 1, easing: 'ease-out' },
        { id: makeId(), time: e, x: 0, y: 0, scale: 1.0, rotation: 0, opacity: 1, easing: 'ease-out' },
      ];
    case 'pan_lr':
      return [
        { id: makeId(), time: s, x: -12, y: 0, scale: 1.25, rotation: 0, opacity: 1, easing: 'ease-in-out' },
        { id: makeId(), time: e, x: 12, y: 0, scale: 1.25, rotation: 0, opacity: 1, easing: 'ease-in-out' },
      ];
    case 'fade_pop':
    default:
      return [
        { id: makeId(), time: s, x: 0, y: 8, scale: 0.85, rotation: -3, opacity: 0.25, easing: 'ease-out' },
        { id: makeId(), time: mid, x: 0, y: 0, scale: 1.08, rotation: 0, opacity: 1, easing: 'ease-in-out' },
        { id: makeId(), time: e, x: 0, y: 0, scale: 1.0, rotation: 0, opacity: 1, easing: 'linear' },
      ];
  }
}
