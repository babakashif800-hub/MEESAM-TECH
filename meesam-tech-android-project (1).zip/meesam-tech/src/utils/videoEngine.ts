import type { ImageSegmenter } from '@mediapipe/tasks-vision';
import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import {
  AspectRatioPreset,
  AudioLayer,
  BgRemovalSettings,
  ChromaKeySettings,
  ExportResolution,
  FrameFitMode,
  MaskSettings,
  MotionTrack,
  OverlayLayer,
  StabilizationSettings,
  TextOverlay,
  TimelineSegment,
  TransformKeyframe,
  VideoAdjustments,
  VideoEffectLayer,
} from '../types/editor';
import { getBgSegmenter, renderSegmentedFrame } from './bgRemover';
import { renderChromaKeyFrame } from './chromaKey';
import { EffectsRenderPool, applyVideoEffectsToCanvas } from './effectsEngine';
import {
  buildCssFilter,
  DEFAULT_ADJUSTMENTS,
  getTargetAspectNumber,
} from './filters';
import { DEFAULT_TRANSFORM, evaluateKeyframes } from './keyframes';
import { resolveScriptRenderConfig } from './languages';
import { applyMaskToCanvas } from './maskRenderer';
import { evaluateMotionTrack } from './motionTracker';
import { DemuxedMp4VideoTrack, parseMp4VideoTrack } from './mp4Demuxer';
import {
  editedTimeToSegmentSourceOffset,
  evaluateCurveAtProgress,
  hasCustomSpeedCurve,
  integrateSegmentSourceToEdited,
} from './speedCurve';
import { evaluateStabilization } from './stabilizer';
import {
  getActiveSegments,
  getEditedDuration,
  getSegmentDisplaySpeed,
  getSegmentEditedDuration,
  getSegmentSpeed,
} from './time';
import {
  applyExportCanvasTransition,
  computeAudioFadeMultiplier,
  getTransitionProgress,
} from './transitions';

/**
 * Extracts evenly spaced frame thumbnails from a video URL for the filmstrip timeline.
 */
export async function generateThumbnails(
  videoUrl: string,
  duration: number,
  count = 10
): Promise<string[]> {
  if (!Number.isFinite(duration) || duration <= 0) return [];

  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.src = videoUrl;
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const thumbnails: string[] = [];
    let currentIndex = 0;
    let settled = false;

    const cleanup = () => {
      video.removeAttribute('src');
      video.load();
    };

    const finish = () => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(thumbnails);
    };

    const safetyTimer = window.setTimeout(finish, 8000);

    video.addEventListener('error', () => {
      window.clearTimeout(safetyTimer);
      finish();
    });

    video.addEventListener('loadeddata', () => {
      const aspect =
        video.videoWidth && video.videoHeight ? video.videoWidth / video.videoHeight : 16 / 9;
      canvas.height = 72;
      canvas.width = Math.max(48, Math.round(72 * aspect));

      const seekNext = () => {
        if (currentIndex >= count) {
          window.clearTimeout(safetyTimer);
          finish();
          return;
        }
        const targetTime = Math.min(
          Math.max(0.05, ((currentIndex + 0.5) / count) * duration),
          Math.max(0.05, duration - 0.05)
        );
        video.currentTime = targetTime;
      };

      video.addEventListener('seeked', () => {
        try {
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            thumbnails.push(canvas.toDataURL('image/jpeg', 0.6));
          }
        } catch {
          // Ignore frame capture errors on restricted frames
        }
        currentIndex += 1;
        seekNext();
      });

      seekNext();
    });
  });
}

/**
 * Picks a reliable WebM MIME type for MediaRecorder fallback (avoiding Chromium's buggy MediaRecorder MP4 muxer).
 */
export function selectSupportedWebmMime(): { mimeType: string; extension: string } {
  const candidates = [
    { mimeType: 'video/webm;codecs=vp9,opus', extension: 'webm' },
    { mimeType: 'video/webm;codecs=vp8,opus', extension: 'webm' },
    { mimeType: 'video/webm;codecs=vp9', extension: 'webm' },
    { mimeType: 'video/webm;codecs=vp8', extension: 'webm' },
    { mimeType: 'video/webm', extension: 'webm' },
  ];

  if (typeof MediaRecorder === 'undefined') {
    return { mimeType: '', extension: 'webm' };
  }

  for (const candidate of candidates) {
    if (MediaRecorder.isTypeSupported(candidate.mimeType)) {
      return candidate;
    }
  }
  return { mimeType: '', extension: 'webm' };
}

/**
 * Generates a real playable & editable 7.5-second sample video clip locally at an exact 30.000fps cadence.
 * Uses deterministic WebCodecs + mp4-muxer when available, falling back to 30fps MediaRecorder WebM.
 */
export async function createSampleVideoFile(): Promise<File> {
  const width = 960;
  const height = 540;
  const durationSec = 7.5;
  const fps = 30;
  const totalFrames = Math.round(durationSec * fps);
  const frameDurationUs = Math.round(1_000_000 / fps);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context is unavailable in this browser.');
  }

  const drawSampleFrame = (t: number, sec: number) => {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(0.55, '#1e293b');
    grad.addColorStop(1, '#1d4ed8');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    for (let i = 0; i < 4; i++) {
      const phase = t * Math.PI * 2 + i * 0.9;
      const yBase = height * (0.42 + i * 0.11);
      ctx.beginPath();
      ctx.moveTo(0, yBase);
      for (let x = 0; x <= width; x += 24) {
        const y = yBase + Math.sin(x * 0.008 + phase) * (28 - i * 4);
        ctx.lineTo(x, y);
      }
      ctx.strokeStyle = `rgba(147, 197, 253, ${0.28 - i * 0.05})`;
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
    ctx.restore();

    const cx = width * 0.5 + Math.cos(t * Math.PI * 2) * 180;
    const cy = height * 0.44 + Math.sin(t * Math.PI * 4) * 45;
    ctx.beginPath();
    ctx.arc(cx, cy, 22, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(59, 130, 246, 0.85)';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx, cy, 34, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(191, 219, 254, 0.4)';
    ctx.lineWidth = 2;
    ctx.stroke();

    const sceneLabel =
      sec < 2.5 ? 'Scene 01 · Intro' : sec < 5.0 ? 'Scene 02 · Motion' : 'Scene 03 · Outro';

    ctx.fillStyle = '#f8fafc';
    ctx.font = '600 36px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('MEESAM TECH Sample Clip', 56, 84);

    ctx.fillStyle = '#93c5fd';
    ctx.font = '500 22px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText(sceneLabel, 56, 124);

    ctx.fillStyle = 'rgba(248, 250, 252, 0.9)';
    ctx.font = '600 28px "JetBrains Mono", monospace';
    ctx.fillText(`00:0${sec.toFixed(1)}s`, 56, height - 54);

    ctx.fillStyle = 'rgba(255,255,255,0.16)';
    ctx.fillRect(56, height - 34, width - 112, 6);
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(56, height - 34, (width - 112) * t, 6);
  };

  // Prefer deterministic WebCodecs H.264 MP4 generation so sample clip has exact 30fps timestamps
  const videoCodecSelection = await pickWebCodecsVideoConfig(width, height, 2_500_000, fps);
  if (videoCodecSelection) {
    try {
      const sampleRate = 48000;
      const audioSelection = await pickWebCodecsAudioConfig(1, sampleRate);
      const target = new ArrayBufferTarget();
      const muxer = new Muxer({
        target,
        fastStart: 'in-memory',
        firstTimestampBehavior: 'offset',
        video: {
          codec: videoCodecSelection.muxerCodec,
          width,
          height,
        },
        audio: audioSelection
          ? {
              codec: audioSelection.muxerCodec,
              numberOfChannels: 1,
              sampleRate: audioSelection.targetSampleRate,
            }
          : undefined,
      });

      let audioShiftUs: number | null = null;
      let lastAudioMuxUs = -1;
      let lastVideoMuxUs = -1;
      const submittedFrames: Array<{ timestampUs: number; durationUs: number }> = [];

      const videoEncoder = new VideoEncoder({
        output: (chunk, meta) => {
          const entry = submittedFrames.shift();
          const data = new Uint8Array(chunk.byteLength);
          chunk.copyTo(data);
          let ts = Math.max(
            0,
            videoCodecSelection.isBaseline && entry ? entry.timestampUs : chunk.timestamp
          );
          if (ts <= lastVideoMuxUs) ts = lastVideoMuxUs + 1;
          lastVideoMuxUs = ts;
          const dur =
            chunk.duration !== null &&
            chunk.duration !== undefined &&
            Number.isFinite(chunk.duration) &&
            chunk.duration > 0
              ? chunk.duration
              : entry?.durationUs ?? frameDurationUs;
          muxer.addVideoChunkRaw(data, chunk.type, ts, dur, meta);
        },
        error: () => {},
      });
      videoEncoder.configure(videoCodecSelection.encoderConfig);

      let audioEncoder: AudioEncoder | null = null;
      if (audioSelection) {
        audioEncoder = new AudioEncoder({
          output: (chunk, meta) => {
            const data = new Uint8Array(chunk.byteLength);
            chunk.copyTo(data);
            if (audioShiftUs === null) {
              audioShiftUs = chunk.timestamp < 0 ? -chunk.timestamp : 0;
            }
            let ts = Math.max(0, chunk.timestamp + audioShiftUs);
            if (ts <= lastAudioMuxUs) ts = lastAudioMuxUs + 1;
            lastAudioMuxUs = ts;
            const fallbackAudioDur = Math.round(
              (1024 / audioSelection.targetSampleRate) * 1_000_000
            );
            const dur =
              chunk.duration !== null &&
              chunk.duration !== undefined &&
              Number.isFinite(chunk.duration) &&
              chunk.duration > 0
                ? chunk.duration
                : fallbackAudioDur;
            muxer.addAudioChunkRaw(data, chunk.type, ts, dur, meta);
          },
          error: () => {},
        });
        audioEncoder.configure(audioSelection.encoderConfig);
      }

      if (audioEncoder && audioSelection) {
        const sr = audioSelection.targetSampleRate;
        const totalSamples = Math.round(durationSec * sr);
        const chunkSize = 1024;
        for (let offset = 0; offset < totalSamples; offset += chunkSize) {
          const count = Math.min(chunkSize, totalSamples - offset);
          const pcm = new Float32Array(count);
          for (let j = 0; j < count; j++) {
            const tSec = (offset + j) / sr;
            // Gentle 220Hz harmonic pulse
            pcm[j] = Math.sin(2 * Math.PI * 220 * tSec) * 0.03;
          }
          const audioData = new AudioData({
            format: 'f32-planar',
            sampleRate: sr,
            numberOfFrames: count,
            numberOfChannels: 1,
            timestamp: Math.round((offset / sr) * 1_000_000),
            data: pcm,
          });
          audioEncoder.encode(audioData);
          audioData.close();
          if (audioEncoder.encodeQueueSize > 20) {
            await new Promise((r) => window.setTimeout(r, 5));
          }
        }
      }

      for (let i = 0; i < totalFrames; i++) {
        const sec = i / fps;
        const t = sec / durationSec;
        drawSampleFrame(t, sec);
        const timestampUs = Math.round(sec * 1_000_000);
        const nextTimestampUs = Math.round(((i + 1) / fps) * 1_000_000);
        const durUs = Math.max(1000, nextTimestampUs - timestampUs);
        submittedFrames.push({ timestampUs, durationUs: durUs });
        const frame = new VideoFrame(canvas, {
          timestamp: timestampUs,
          duration: durUs,
        });
        videoEncoder.encode(frame, { keyFrame: i % 30 === 0 });
        frame.close();
        if (videoEncoder.encodeQueueSize > 6) {
          await new Promise((r) => window.setTimeout(r, 8));
        }
      }

      await videoEncoder.flush();
      if (audioEncoder) {
        await audioEncoder.flush();
        audioEncoder.close();
      }
      videoEncoder.close();
      muxer.finalize();

      const blob = new Blob([target.buffer], { type: 'video/mp4' });
      return new File([blob], 'meesam-sample-clip.mp4', { type: 'video/mp4' });
    } catch {
      // Fall through to WebM MediaRecorder if WebCodecs sample creation fails
    }
  }

  // Fallback 30fps MediaRecorder WebM sample clip
  const durationMs = durationSec * 1000;
  const frameIntervalMs = 1000 / fps;
  const stream = canvas.captureStream(0);
  const videoTrack = stream.getVideoTracks()[0] as
    | (MediaStreamTrack & { requestFrame?: () => void })
    | undefined;

  let audioCtx: AudioContext | null = null;
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
      const dest = audioCtx.createMediaStreamDestination();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 220;
      gain.gain.value = 0.03;
      osc.connect(gain);
      gain.connect(dest);
      osc.start();
      dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
    }
  } catch {
    // Proceed video-only
  }

  const { mimeType, extension } = selectSupportedWebmMime();
  const options: MediaRecorderOptions = mimeType
    ? { mimeType, videoBitsPerSecond: 2_500_000 }
    : { videoBitsPerSecond: 2_500_000 };
  const recorder = new MediaRecorder(stream, options);
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (ev) => {
    if (ev.data && ev.data.size > 0) chunks.push(ev.data);
  };

  return new Promise((resolve, reject) => {
    const startTime = performance.now();
    let lastDrawTime = -frameIntervalMs;
    let rafId = 0;

    const loop = (now: number) => {
      const elapsed = now - startTime;
      if (elapsed - lastDrawTime >= frameIntervalMs - 1) {
        lastDrawTime = elapsed;
        const sec = Math.min(elapsed / 1000, durationSec);
        drawSampleFrame(Math.min(sec / durationSec, 1), sec);
        videoTrack?.requestFrame?.();
      }
      if (elapsed < durationMs) {
        rafId = requestAnimationFrame(loop);
      } else if (recorder.state === 'recording') {
        recorder.stop();
      }
    };

    recorder.onstop = () => {
      cancelAnimationFrame(rafId);
      stream.getTracks().forEach((tr) => tr.stop());
      if (audioCtx) audioCtx.close().catch(() => {});
      const blob = new Blob(chunks, { type: recorder.mimeType || mimeType || 'video/webm' });
      resolve(new File([blob], `meesam-sample-clip.${extension}`, { type: blob.type }));
    };

    recorder.onerror = () => {
      cancelAnimationFrame(rafId);
      stream.getTracks().forEach((tr) => tr.stop());
      if (audioCtx) audioCtx.close().catch(() => {});
      reject(new Error('Could not generate sample video in this browser.'));
    };

    drawSampleFrame(0, 0);
    videoTrack?.requestFrame?.();
    recorder.start(250);
    rafId = requestAnimationFrame(loop);
  });
}

export interface ExportVideoParams {
  sourceUrl: string;
  sourceWidth: number;
  sourceHeight: number;
  sourceMediaKind?: 'video' | 'image';
  segments: TimelineSegment[];
  resolution: ExportResolution;
  adjustments?: VideoAdjustments;
  videoEffects?: VideoEffectLayer[];
  textOverlays?: TextOverlay[];
  aspectRatio?: AspectRatioPreset;
  frameFit?: FrameFitMode;
  mainKeyframes?: TransformKeyframe[];
  motionTracks?: MotionTrack[];
  overlayLayers?: OverlayLayer[];
  audioLayers?: AudioLayer[];
  bgRemoval?: BgRemovalSettings;
  chromaKey?: ChromaKeySettings;
  stabilization?: StabilizationSettings;
  mask?: MaskSettings;
  signal?: AbortSignal;
  onProgress: (progress: number, detail: string) => void;
}

export interface ExportPhotoParams {
  sourceUrl: string;
  sourceWidth: number;
  sourceHeight: number;
  resolution: ExportResolution;
  adjustments?: VideoAdjustments;
  videoEffects?: VideoEffectLayer[];
  textOverlays?: TextOverlay[];
  aspectRatio?: AspectRatioPreset;
  frameFit?: FrameFitMode;
  mainKeyframes?: TransformKeyframe[];
  motionTracks?: MotionTrack[];
  overlayLayers?: OverlayLayer[];
  bgRemoval?: BgRemovalSettings;
  chromaKey?: ChromaKeySettings;
  stabilization?: StabilizationSettings;
  mask?: MaskSettings;
  previewTime?: number;
}

export interface ExportVideoResult {
  blob: Blob;
  blobUrl: string;
  mimeType: string;
  extension: string;
}

export function getScaledDimensions(
  srcW: number,
  srcH: number,
  resolution: ExportResolution,
  aspectRatio: AspectRatioPreset = 'original'
): { width: number; height: number } {
  const safeW = srcW > 0 ? srcW : 1280;
  const safeH = srcH > 0 ? srcH : 720;
  const targetRatio = getTargetAspectNumber(aspectRatio, safeW, safeH);

  let targetShortEdge = Math.min(safeW, safeH);
  if (resolution === '4k') {
    targetShortEdge = 2160;
  } else if (resolution === '1080p') {
    targetShortEdge = 1080;
  } else if (resolution === '720p') {
    targetShortEdge = 720;
  } else if (resolution === '480p') {
    targetShortEdge = 480;
  } else {
    // Original resolution capped at 4K UHD (3840) for browser encoder stability
    const maxEdge = 3840;
    const scale = Math.min(1, maxEdge / Math.max(safeW, safeH));
    targetShortEdge = Math.round(Math.min(safeW, safeH) * scale);
  }

  let outW: number;
  let outH: number;
  if (targetRatio >= 1) {
    outH = Math.max(240, targetShortEdge);
    outW = Math.round(outH * targetRatio);
  } else {
    outW = Math.max(240, targetShortEdge);
    outH = Math.round(outW / targetRatio);
  }

  // Clamp long edge to 3840 for ultra-wide aspect ratios at 4K so codecs remain happy
  const maxLongEdge = resolution === '4k' || resolution === 'original' ? 3840 : 2560;
  if (Math.max(outW, outH) > maxLongEdge) {
    const down = maxLongEdge / Math.max(outW, outH);
    outW = Math.round(outW * down);
    outH = Math.round(outH * down);
  }

  return {
    width: Math.max(2, Math.round(outW / 2) * 2),
    height: Math.max(2, Math.round(outH / 2) * 2),
  };
}

interface PreparedOverlayVisual {
  layer: OverlayLayer;
  imageEl?: HTMLImageElement;
  videoEl?: HTMLVideoElement;
  detach?: () => void;
}

interface DrawFrameExtras {
  mainKeyframes?: TransformKeyframe[];
  motionTracks?: MotionTrack[];
  overlays?: PreparedOverlayVisual[];
  bgRemoval?: BgRemovalSettings;
  bgSegmenter?: ImageSegmenter | null;
  bgScratchCanvas?: HTMLCanvasElement | null;
  bgCustomImage?: HTMLImageElement | null;
  chromaKey?: ChromaKeySettings;
  chromaCustomImage?: HTMLImageElement | null;
  chromaCustomVideo?: HTMLVideoElement | null;
  stabilization?: StabilizationSettings;
  mask?: MaskSettings;
  maskWorkCanvas?: HTMLCanvasElement | null;
  maskAlphaCanvas?: HTMLCanvasElement | null;
  videoEffects?: VideoEffectLayer[];
  effectsPool?: EffectsRenderPool;
}

function loadImageElement(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

/**
 * Draws the video frame with optional AI background removal, keyframe transforms, aspect framing,
 * CSS color filters, V2 overlay layers, and styled captions/text overlays.
 */
function drawExportFrame(
  ctx: CanvasRenderingContext2D,
  source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | VideoFrame,
  canvasW: number,
  canvasH: number,
  cssFilter: string,
  frameFit: FrameFitMode,
  textOverlays: TextOverlay[],
  sourceTime: number,
  extras?: DrawFrameExtras
): void {
  ctx.save();
  ctx.filter = 'none';
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, canvasW, canvasH);

  const vw =
    source instanceof HTMLVideoElement
      ? source.videoWidth || canvasW
      : source instanceof HTMLImageElement
      ? source.naturalWidth || source.width || canvasW
      : source instanceof HTMLCanvasElement
      ? source.width || canvasW
      : source.displayWidth || source.codedWidth || canvasW;
  const vh =
    source instanceof HTMLVideoElement
      ? source.videoHeight || canvasH
      : source instanceof HTMLImageElement
      ? source.naturalHeight || source.height || canvasH
      : source instanceof HTMLCanvasElement
      ? source.height || canvasH
      : source.displayHeight || source.codedHeight || canvasH;
  const videoRatio = vw / Math.max(1, vh);
  const canvasRatio = canvasW / Math.max(1, canvasH);

  let drawW = canvasW;
  let drawH = canvasH;
  let drawX = 0;
  let drawY = 0;

  if (frameFit === 'cover') {
    if (videoRatio > canvasRatio) {
      drawH = canvasH;
      drawW = canvasH * videoRatio;
      drawX = (canvasW - drawW) / 2;
    } else {
      drawW = canvasW;
      drawH = canvasW / videoRatio;
      drawY = (canvasH - drawH) / 2;
    }
  } else {
    if (videoRatio > canvasRatio) {
      drawW = canvasW;
      drawH = canvasW / videoRatio;
      drawY = (canvasH - drawH) / 2;
    } else {
      drawH = canvasH;
      drawW = canvasH * videoRatio;
      drawX = (canvasW - drawW) / 2;
    }
  }

  let drawSource: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | VideoFrame = source;
  if (extras?.chromaKey?.enabled && extras.bgScratchCanvas) {
    renderChromaKeyFrame(
      source,
      extras.bgScratchCanvas,
      extras.chromaKey,
      extras.chromaCustomImage,
      extras.chromaCustomVideo
    );
    drawSource = extras.bgScratchCanvas;
  } else if (
    extras?.bgSegmenter &&
    extras.bgRemoval &&
    extras.bgRemoval.mode !== 'off' &&
    extras.bgScratchCanvas
  ) {
    renderSegmentedFrame(
      extras.bgSegmenter,
      source,
      extras.bgScratchCanvas,
      extras.bgRemoval,
      extras.bgCustomImage,
      448
    );
    drawSource = extras.bgScratchCanvas;
  }

  const mainTf = evaluateKeyframes(extras?.mainKeyframes, sourceTime, DEFAULT_TRANSFORM);
  const stabTf = evaluateStabilization(extras?.stabilization, sourceTime);
  const combinedX = mainTf.x + stabTf.x;
  const combinedY = mainTf.y + stabTf.y;
  const combinedScale = mainTf.scale * stabTf.scale;

  const drawMainTo = (target: CanvasRenderingContext2D) => {
    target.save();
    target.globalAlpha = Math.max(0, Math.min(1, mainTf.opacity));
    target.translate(
      canvasW / 2 + (combinedX / 100) * canvasW,
      canvasH / 2 + (combinedY / 100) * canvasH
    );
    if (mainTf.rotation !== 0) {
      target.rotate((mainTf.rotation * Math.PI) / 180);
    }
    if (combinedScale !== 1) {
      target.scale(combinedScale, combinedScale);
    }
    target.filter = cssFilter || 'none';
    target.drawImage(
      drawSource,
      drawX - canvasW / 2,
      drawY - canvasH / 2,
      drawW,
      drawH
    );
    target.filter = 'none';
    target.restore();
  };

  const activeEffects = (extras?.videoEffects ?? []).filter(
    (fx) =>
      fx.enabled &&
      fx.intensity > 0 &&
      sourceTime >= fx.startTime - 0.02 &&
      sourceTime <= fx.endTime + 0.02
  );
  const effectsPool = extras?.effectsPool;

  if (activeEffects.length > 0 && effectsPool) {
    const effectCanvas = effectsPool.getWorkA(canvasW, canvasH);
    const effectCtx = effectCanvas.getContext('2d');
    if (effectCtx) {
      effectCtx.clearRect(0, 0, canvasW, canvasH);
      drawMainTo(effectCtx);
      applyVideoEffectsToCanvas(effectCanvas, activeEffects, sourceTime, effectsPool, 960);

      if (
        extras?.mask &&
        extras.mask.shape !== 'none' &&
        extras.maskAlphaCanvas
      ) {
        applyMaskToCanvas(
          ctx,
          effectCanvas,
          extras.maskAlphaCanvas,
          canvasW,
          canvasH,
          extras.mask
        );
      } else {
        ctx.drawImage(effectCanvas, 0, 0, canvasW, canvasH);
      }
    } else {
      drawMainTo(ctx);
    }
  } else if (
    extras?.mask &&
    extras.mask.shape !== 'none' &&
    extras.maskWorkCanvas &&
    extras.maskAlphaCanvas
  ) {
    if (extras.maskWorkCanvas.width !== canvasW) extras.maskWorkCanvas.width = canvasW;
    if (extras.maskWorkCanvas.height !== canvasH) extras.maskWorkCanvas.height = canvasH;
    const workCtx = extras.maskWorkCanvas.getContext('2d');
    if (workCtx) {
      workCtx.clearRect(0, 0, canvasW, canvasH);
      drawMainTo(workCtx);
      applyMaskToCanvas(
        ctx,
        extras.maskWorkCanvas,
        extras.maskAlphaCanvas,
        canvasW,
        canvasH,
        extras.mask
      );
    } else {
      drawMainTo(ctx);
    }
  } else {
    drawMainTo(ctx);
  }

  // Render V2 Overlay / Picture-in-Picture layers (with Motion Tracking)
  if (extras?.overlays && extras.overlays.length > 0) {
    for (const ov of extras.overlays) {
      const { layer, imageEl, videoEl } = ov;
      if (sourceTime < layer.startTime - 0.02 || sourceTime > layer.endTime + 0.02) {
        continue;
      }
      const media: CanvasImageSource | null =
        layer.kind === 'image'
          ? imageEl && imageEl.complete
            ? imageEl
            : null
          : videoEl && videoEl.readyState >= 2
          ? videoEl
          : null;
      if (!media) continue;

      const mediaW =
        layer.kind === 'image'
          ? imageEl?.naturalWidth || layer.width || 640
          : videoEl?.videoWidth || layer.width || 640;
      const mediaH =
        layer.kind === 'image'
          ? imageEl?.naturalHeight || layer.height || 360
          : videoEl?.videoHeight || layer.height || 360;

      const tf = evaluateKeyframes(layer.keyframes, sourceTime, {
        x: layer.x,
        y: layer.y,
        scale: layer.scale,
        rotation: layer.rotation,
        opacity: layer.opacity,
      });

      const track = layer.trackId
        ? extras.motionTracks?.find((m) => m.id === layer.trackId)
        : undefined;
      const tracked = evaluateMotionTrack(track, sourceTime);
      const posX = tracked && track ? tf.x + (tracked.x - track.anchorX) : tf.x;
      const posY = tracked && track ? tf.y + (tracked.y - track.anchorY) : tf.y;

      const mediaRatio = mediaW / Math.max(1, mediaH);
      const baseH = canvasH * 0.48;
      const baseW = baseH * mediaRatio;

      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, tf.opacity));
      ctx.translate(canvasW * (0.5 + posX / 100), canvasH * (0.5 + posY / 100));
      if (tf.rotation !== 0) {
        ctx.rotate((tf.rotation * Math.PI) / 180);
      }
      ctx.scale(tf.scale, tf.scale);
      ctx.drawImage(media, -baseW / 2, -baseH / 2, baseW, baseH);
      ctx.restore();
    }
  }

  // Render active text overlays, stickers & AI captions cleanly at matching proportions
  const activeTexts = textOverlays.filter(
    (item) =>
      item.text.trim().length > 0 &&
      sourceTime >= item.startTime - 0.02 &&
      sourceTime <= item.endTime + 0.02
  );

  for (const item of activeTexts) {
    const baseScale = Math.min(canvasW, canvasH);
    const sizeMultiplier = Math.min(3.0, Math.max(0.4, item.scale ?? 1));
    const fontSize = item.isSticker
      ? Math.max(
          20,
          Math.round(
            baseScale *
              (item.size === 'sm' ? 0.09 : item.size === 'lg' ? 0.16 : 0.12) *
              sizeMultiplier
          )
        )
      : Math.max(
          14,
          Math.round(
            baseScale *
              (item.size === 'sm' ? 0.042 : item.size === 'lg' ? 0.072 : 0.055) *
              sizeMultiplier
          )
        );
    const scriptCfg = resolveScriptRenderConfig(
      item.text,
      item.lang,
      item.dir ?? 'auto'
    );
    ctx.save();
    ctx.globalAlpha = Math.min(1, Math.max(0.1, item.opacity ?? 1));
    ctx.font = `${item.isSticker ? '400' : '700'} ${fontSize}px ${scriptCfg.fontFamily}`;
    ctx.direction = scriptCfg.dir;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const track = item.trackId
      ? extras?.motionTracks?.find((m) => m.id === item.trackId)
      : undefined;
    const tracked = evaluateMotionTrack(track, sourceTime);
    const hasFreeCoords =
      typeof item.x === 'number' || typeof item.y === 'number' || Boolean(tracked);

    const lines = item.text.split('\n');
    const lineHeight = fontSize * (scriptCfg.langAttr === 'ur' ? 1.5 : 1.3);
    const totalTextH = lines.length * lineHeight;

    let centerX = canvasW * 0.5;
    let centerY = canvasH * 0.5;

    if (hasFreeCoords) {
      const baseX = typeof item.x === 'number' ? item.x : track ? track.anchorX : 0;
      const baseY =
        typeof item.y === 'number'
          ? item.y
          : track
          ? track.anchorY
          : item.position === 'top'
          ? -34
          : item.position === 'bottom'
          ? 34
          : 0;
      const posX = tracked && track ? baseX + (tracked.x - track.anchorX) : baseX;
      const posY = tracked && track ? baseY + (tracked.y - track.anchorY) : baseY;
      centerX = canvasW * (0.5 + posX / 100);
      centerY = canvasH * (0.5 + posY / 100);
    } else if (item.position === 'top') {
      centerY = Math.max(totalTextH * 0.6 + 24, canvasH * 0.14);
    } else if (item.position === 'bottom') {
      centerY = Math.min(canvasH - totalTextH * 0.6 - 24, canvasH * 0.86);
    }

    const maxLineW = Math.max(...lines.map((l) => ctx.measureText(l).width));
    if (!item.isSticker && item.style === 'boxed') {
      const padX = fontSize * 0.55;
      const padY = fontSize * 0.35;
      const boxW = Math.min(canvasW - 32, maxLineW + padX * 2);
      const boxH = totalTextH + padY * 2;
      const boxX = centerX - boxW / 2;
      const boxY = centerY - boxH / 2;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.72)';
      ctx.beginPath();
      ctx.roundRect(boxX, boxY, boxW, boxH, Math.round(fontSize * 0.3));
      ctx.fill();
    } else if (!item.isSticker && item.style === 'subtitle-bar' && !hasFreeCoords) {
      const padY = fontSize * 0.42;
      const barH = totalTextH + padY * 2;
      ctx.fillStyle = 'rgba(8, 10, 16, 0.82)';
      ctx.fillRect(0, centerY - barH / 2, canvasW, barH);
    }

    lines.forEach((line, idx) => {
      const y = centerY - totalTextH / 2 + lineHeight * (idx + 0.5);
      if (!item.isSticker && (item.style === 'outline' || item.style === 'pop')) {
        ctx.lineWidth = Math.max(3, Math.round(fontSize * (item.style === 'pop' ? 0.18 : 0.14)));
        ctx.strokeStyle = '#000000';
        ctx.lineJoin = 'round';
        ctx.miterLimit = 2;
        ctx.strokeText(line, centerX, y, canvasW - 40);
      } else if (item.style === 'clean' || item.isSticker) {
        ctx.shadowColor = 'rgba(0,0,0,0.75)';
        ctx.shadowBlur = Math.round(fontSize * 0.22);
        ctx.shadowOffsetY = 2;
      }
      ctx.fillStyle = item.color || (item.style === 'pop' ? '#facc15' : '#ffffff');
      ctx.fillText(line, centerX, y, canvasW - 40);
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetY = 0;
    });
    ctx.restore();
  }

  ctx.restore();
}

function createAttachedExportVideo(sourceUrl: string): {
  video: HTMLVideoElement;
  detach: () => void;
} {
  // Attach to DOM with tiny visible box so Chrome/Android never throttles hardware video decoding or requestVideoFrameCallback
  const wrapper = document.createElement('div');
  wrapper.style.position = 'fixed';
  wrapper.style.left = '0';
  wrapper.style.top = '0';
  wrapper.style.width = '2px';
  wrapper.style.height = '2px';
  wrapper.style.opacity = '0.01';
  wrapper.style.pointerEvents = 'none';
  wrapper.style.overflow = 'hidden';
  wrapper.style.zIndex = '-9999';
  wrapper.setAttribute('aria-hidden', 'true');

  const video = document.createElement('video');
  video.src = sourceUrl;
  video.playsInline = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';
  video.muted = true;
  video.defaultPlaybackRate = 1.0;
  video.playbackRate = 1.0;
  video.style.width = '2px';
  video.style.height = '2px';

  wrapper.appendChild(video);
  document.body.appendChild(wrapper);

  const detach = () => {
    video.pause();
    video.removeAttribute('src');
    video.load();
    wrapper.remove();
  };

  return { video, detach };
}

async function waitForVideoReady(video: HTMLVideoElement): Promise<void> {
  if (video.readyState >= 2) return;
  await new Promise<void>((resolve, reject) => {
    const onLoaded = () => resolve();
    const onErr = () => reject(new Error('Unable to load source video for export.'));
    video.addEventListener('loadeddata', onLoaded, { once: true });
    video.addEventListener('error', onErr, { once: true });
  });
}

async function seekVideoPrecisely(video: HTMLVideoElement, timeSec: number): Promise<void> {
  const maxTime =
    Number.isFinite(video.duration) && video.duration > 0.01
      ? Math.max(0, video.duration - 0.002)
      : Infinity;
  const target = Math.min(maxTime, Math.max(0, timeSec));
  if (Math.abs(video.currentTime - target) < 0.0005 && video.readyState >= 2) {
    return;
  }
  await new Promise<void>((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      video.removeEventListener('seeked', finish);
      video.removeEventListener('error', finish);
      resolve();
    };
    const timer = window.setTimeout(finish, 2500);
    video.addEventListener('seeked', finish, { once: true });
    video.addEventListener('error', finish, { once: true });
    video.currentTime = target;
  });
}

async function probeVideoFps(video: HTMLVideoElement): Promise<number> {
  const supportsVfc = typeof video.requestVideoFrameCallback === 'function';
  if (!supportsVfc) return 30;

  const prevTime = video.currentTime;
  const prevMuted = video.muted;
  const prevRate = video.playbackRate;

  try {
    video.muted = true;
    video.playbackRate = 1.0;
    await seekVideoPrecisely(video, 0);

    const deltas: number[] = [];
    await new Promise<void>((resolve) => {
      let lastMt: number | null = null;
      let count = 0;
      let handle = 0;
      let done = false;

      const finish = () => {
        if (done) return;
        done = true;
        window.clearTimeout(timer);
        if (handle && typeof video.cancelVideoFrameCallback === 'function') {
          video.cancelVideoFrameCallback(handle);
        }
        video.pause();
        resolve();
      };

      const timer = window.setTimeout(finish, 350);

      const onFrame = (_now: number, meta: { mediaTime: number }) => {
        if (done) return;
        if (lastMt !== null) {
          const d = meta.mediaTime - lastMt;
          if (d > 0.004 && d < 0.12) {
            deltas.push(d);
          }
        }
        lastMt = meta.mediaTime;
        count += 1;
        if (count >= 6 || deltas.length >= 4) {
          finish();
        } else {
          handle = video.requestVideoFrameCallback(onFrame);
        }
      };

      handle = video.requestVideoFrameCallback(onFrame);
      video.play().catch(finish);
    });

    if (deltas.length > 0) {
      deltas.sort((a, b) => a - b);
      const median = deltas[Math.floor(deltas.length / 2)];
      const raw = 1 / median;
      const standard = [24, 25, 30, 50, 60];
      for (const s of standard) {
        if (Math.abs(raw - s) / s < 0.06) return s;
      }
      return Math.max(15, Math.min(60, Math.round(raw)));
    }
  } catch {
    // Fallback cleanly
  } finally {
    video.pause();
    video.muted = prevMuted;
    video.playbackRate = prevRate;
    await seekVideoPrecisely(video, prevTime);
  }
  return 30;
}

async function pickWebCodecsVideoConfig(
  width: number,
  height: number,
  bitrate: number,
  targetFps = 30
): Promise<{
  encoderConfig: VideoEncoderConfig;
  muxerCodec: 'avc';
  isBaseline: boolean;
} | null> {
  if (typeof VideoEncoder === 'undefined') return null;

  const needs4kLevel = Math.max(width, height) > 2048 || width * height > 2_300_000;
  const clampedFps = Math.max(1, Math.min(120, Math.round(targetFps)));

  // Strictly enforce H.264 (avc1) for standard MP4 output; prefer Constrained Baseline (zero B-frames) first
  const candidates: Array<{ codec: string; isBaseline: boolean }> = needs4kLevel
    ? [
        { codec: 'avc1.42e033', isBaseline: true }, // Constrained Baseline L5.1 (4K)
        { codec: 'avc1.420033', isBaseline: true }, // Baseline L5.1 (4K)
        { codec: 'avc1.42e034', isBaseline: true }, // Constrained Baseline L5.2
        { codec: 'avc1.420034', isBaseline: true },
        { codec: 'avc1.4d0033', isBaseline: false }, // Main L5.1 (4K)
        { codec: 'avc1.640033', isBaseline: false }, // High L5.1 (4K)
        { codec: 'avc1.640034', isBaseline: false }, // High L5.2 (4K60)
        { codec: 'avc1.640032', isBaseline: false }, // High L5.0
      ]
    : [
        { codec: 'avc1.42e02a', isBaseline: true }, // Constrained Baseline L4.2 (1080p60)
        { codec: 'avc1.42002a', isBaseline: true }, // Baseline L4.2
        { codec: 'avc1.42e028', isBaseline: true }, // Constrained Baseline L4.0 (1080p30)
        { codec: 'avc1.420028', isBaseline: true },
        { codec: 'avc1.42e01f', isBaseline: true }, // Constrained Baseline L3.1 (720p30)
        { codec: 'avc1.42001f', isBaseline: true },
        { codec: 'avc1.42e01e', isBaseline: true }, // Baseline L3.0
        { codec: 'avc1.4d002a', isBaseline: false }, // Main L4.2
        { codec: 'avc1.4d0028', isBaseline: false }, // Main L4.0
        { codec: 'avc1.64002a', isBaseline: false }, // High L4.2
        { codec: 'avc1.640028', isBaseline: false }, // High L4.0
      ];

  const hwModes: HardwareAcceleration[] = [
    'no-preference',
    'prefer-hardware',
    'prefer-software',
  ];
  const latencyModes: LatencyMode[] = ['quality', 'realtime'];

  for (const latencyMode of latencyModes) {
    for (const hw of hwModes) {
      for (const candidate of candidates) {
        const config: VideoEncoderConfig = {
          codec: candidate.codec,
          width,
          height,
          bitrate,
          framerate: clampedFps,
          latencyMode,
          hardwareAcceleration: hw,
          avc: { format: 'avc' },
        };
        try {
          const support = await VideoEncoder.isConfigSupported(config);
          if (support.supported) {
            return {
              encoderConfig: {
                ...(support.config ?? config),
                framerate: clampedFps,
                latencyMode,
                avc: { format: 'avc' },
              },
              muxerCodec: 'avc',
              isBaseline: candidate.isBaseline,
            };
          }
        } catch {
          // Try next codec
        }
      }
    }
  }
  return null;
}

async function fetchSourceBuffer(sourceUrl: string): Promise<ArrayBuffer | null> {
  try {
    const response = await fetch(sourceUrl);
    if (!response.ok) return null;
    return await response.arrayBuffer();
  } catch {
    return null;
  }
}

async function decodeAudioBufferFromBytes(
  buffer: ArrayBuffer | null
): Promise<AudioBuffer | null> {
  if (!buffer || buffer.byteLength === 0) return null;
  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;

  let audioCtx: AudioContext | null = null;
  try {
    audioCtx = new AudioContextClass();
    // Slice a copy because decodeAudioData detaches the passed ArrayBuffer
    return await audioCtx.decodeAudioData(buffer.slice(0));
  } catch {
    return null;
  } finally {
    if (audioCtx) {
      audioCtx.close().catch(() => {});
    }
  }
}

async function decodeSourceAudioBuffer(sourceUrl: string): Promise<AudioBuffer | null> {
  const bytes = await fetchSourceBuffer(sourceUrl);
  return decodeAudioBufferFromBytes(bytes);
}

async function pickWebCodecsAudioConfig(
  numberOfChannels: number,
  sampleRate: number
): Promise<{
  encoderConfig: AudioEncoderConfig;
  muxerCodec: 'aac' | 'opus';
  targetSampleRate: number;
} | null> {
  if (typeof AudioEncoder === 'undefined') return null;

  const channels = Math.max(1, Math.min(2, numberOfChannels));
  const candidates: Array<{
    codec: string;
    muxerCodec: 'aac' | 'opus';
    rate: number;
  }> = [
    { codec: 'mp4a.40.2', muxerCodec: 'aac', rate: sampleRate },
    { codec: 'mp4a.40.2', muxerCodec: 'aac', rate: 48000 },
    { codec: 'mp4a.40.2', muxerCodec: 'aac', rate: 44100 },
    { codec: 'opus', muxerCodec: 'opus', rate: 48000 },
  ];

  for (const cand of candidates) {
    const config: AudioEncoderConfig = {
      codec: cand.codec,
      numberOfChannels: channels,
      sampleRate: cand.rate,
      bitrate: 192_000,
    };
    try {
      const support = await AudioEncoder.isConfigSupported(config);
      if (support.supported) {
        return {
          encoderConfig: support.config ?? config,
          muxerCodec: cand.muxerCodec,
          targetSampleRate: cand.rate,
        };
      }
    } catch {
      // Try next audio codec
    }
  }
  return null;
}

/**
 * Resamples an AudioBuffer cleanly using OfflineAudioContext when sample rate differs from encoder requirement.
 */
async function resampleAudioBuffer(
  buffer: AudioBuffer,
  targetChannels: number,
  targetSampleRate: number
): Promise<AudioBuffer> {
  if (
    buffer.sampleRate === targetSampleRate &&
    buffer.numberOfChannels === targetChannels
  ) {
    return buffer;
  }

  const targetLength = Math.max(1, Math.ceil(buffer.duration * targetSampleRate));
  const offline = new OfflineAudioContext(targetChannels, targetLength, targetSampleRate);
  const source = offline.createBufferSource();
  source.buffer = buffer;
  source.connect(offline.destination);
  source.start(0);
  return offline.startRendering();
}

/**
 * Deterministic WebCodecs + mp4-muxer export pipeline:
 * - Parses MP4/MOV source sample tables to extract native FPS and decode linearly via VideoDecoder (zero dropped frames).
 * - Falls back to deterministic frame-by-frame seeking for WebM/non-MP4 sources (zero real-time video.play() drift).
 * - Encodes strictly with H.264 (avc1) + AAC/Opus with matched 0-origin microsecond timestamps for locked A/V sync.
 */
async function exportWithWebCodecs(
  params: ExportVideoParams,
  width: number,
  height: number,
  bitrate: number
): Promise<ExportVideoResult> {
  const activeSegments = getActiveSegments(params.segments);
  const isPhotoSource = params.sourceMediaKind === 'image';

  params.onProgress(2, 'Analyzing source media and audio tracks...');
  const sourceBuffer = isPhotoSource ? null : await fetchSourceBuffer(params.sourceUrl);
  const sourceBytes = sourceBuffer ? new Uint8Array(sourceBuffer) : null;
  const demuxedMp4: DemuxedMp4VideoTrack | null = sourceBuffer
    ? parseMp4VideoTrack(sourceBuffer)
    : null;

  let canUseMp4Decoder = false;
  if (demuxedMp4 && typeof VideoDecoder !== 'undefined') {
    try {
      const decSupport = await VideoDecoder.isConfigSupported({
        codec: demuxedMp4.codec,
        codedWidth: demuxedMp4.codedWidth,
        codedHeight: demuxedMp4.codedHeight,
        description: demuxedMp4.description,
      });
      canUseMp4Decoder = Boolean(decSupport.supported);
    } catch {
      canUseMp4Decoder = false;
    }
  }

  const attachedSource =
    isPhotoSource || canUseMp4Decoder ? null : createAttachedExportVideo(params.sourceUrl);
  const video = attachedSource?.video ?? null;
  const detach = attachedSource?.detach ?? (() => {});

  if (video) {
    try {
      await waitForVideoReady(video);
    } catch (err) {
      detach();
      throw err;
    }
  }

  const detectedSourceFps = isPhotoSource
    ? 30
    : demuxedMp4
    ? demuxedMp4.fps
    : video
    ? await probeVideoFps(video)
    : 30;
  const defaultFrameDurationUs = Math.max(
    1000,
    Math.round(1_000_000 / Math.max(1, detectedSourceFps))
  );

  const videoCodecSelection = await pickWebCodecsVideoConfig(
    width,
    height,
    bitrate,
    detectedSourceFps
  );
  if (!videoCodecSelection) {
    detach();
    throw new Error('WEBCODECS_UNSUPPORTED');
  }

  // Decode source audio (when video) + any unmuted A1 audio layers or V2 video overlay audio
  const rawAudioBuffer = isPhotoSource
    ? null
    : sourceBuffer
    ? await decodeAudioBufferFromBytes(sourceBuffer)
    : await decodeSourceAudioBuffer(params.sourceUrl);
  const activeAudioLayers = (params.audioLayers ?? []).filter(
    (a) => !a.muted && a.volume > 0
  );
  const activeOverlayAudioLayers = (params.overlayLayers ?? []).filter(
    (l) => l.kind === 'video' && !l.muted && l.volume > 0
  );

  const hasAnyAudio =
    Boolean(rawAudioBuffer && rawAudioBuffer.numberOfChannels > 0) ||
    activeAudioLayers.length > 0 ||
    activeOverlayAudioLayers.length > 0;

  let audioSelection: Awaited<ReturnType<typeof pickWebCodecsAudioConfig>> = null;
  let preparedAudioBuffer: AudioBuffer | null = null;
  const decodedExtraAudio: Array<{
    startTime: number;
    endTime: number;
    sourceOffsetSec?: number;
    volume: number;
    fadeInSec?: number;
    fadeOutSec?: number;
    buffer: AudioBuffer;
  }> = [];

  if (hasAnyAudio) {
    const baseChannels = rawAudioBuffer?.numberOfChannels || 2;
    const baseRate = rawAudioBuffer?.sampleRate || 48000;
    audioSelection = await pickWebCodecsAudioConfig(baseChannels, baseRate);

    if (audioSelection) {
      const targetCh = audioSelection.encoderConfig.numberOfChannels;
      const targetSr = audioSelection.targetSampleRate;
      if (rawAudioBuffer && rawAudioBuffer.numberOfChannels > 0) {
        preparedAudioBuffer = await resampleAudioBuffer(
          rawAudioBuffer,
          targetCh,
          targetSr
        );
      }

      for (const aLayer of activeAudioLayers) {
        const buf = await decodeSourceAudioBuffer(aLayer.url);
        if (buf && buf.numberOfChannels > 0) {
          decodedExtraAudio.push({
            startTime: aLayer.startTime,
            endTime: aLayer.endTime,
            sourceOffsetSec: aLayer.sourceOffsetSec ?? 0,
            volume: aLayer.volume,
            fadeInSec: aLayer.fadeInSec,
            fadeOutSec: aLayer.fadeOutSec,
            buffer: await resampleAudioBuffer(buf, targetCh, targetSr),
          });
        }
      }

      for (const vLayer of activeOverlayAudioLayers) {
        const buf = await decodeSourceAudioBuffer(vLayer.url);
        if (buf && buf.numberOfChannels > 0) {
          decodedExtraAudio.push({
            startTime: vLayer.startTime,
            endTime: vLayer.endTime,
            volume: vLayer.volume,
            buffer: await resampleAudioBuffer(buf, targetCh, targetSr),
          });
        }
      }
    }
  }

  // Load Chroma Key or AI background remover assets + backdrops
  let bgSegmenter: ImageSegmenter | null = null;
  let bgCustomImage: HTMLImageElement | null = null;
  let chromaCustomImage: HTMLImageElement | null = null;
  let chromaCustomVideo: { video: HTMLVideoElement; detach: () => void } | null = null;
  let bgScratchCanvas: HTMLCanvasElement | null = null;

  if (params.chromaKey?.enabled) {
    bgScratchCanvas = document.createElement('canvas');
    bgScratchCanvas.width = width;
    bgScratchCanvas.height = height;
    if (params.chromaKey.bgMode === 'image' && params.chromaKey.bgImageUrl) {
      chromaCustomImage = await loadImageElement(params.chromaKey.bgImageUrl);
    } else if (params.chromaKey.bgMode === 'video' && params.chromaKey.bgVideoUrl) {
      const attachedBg = createAttachedExportVideo(params.chromaKey.bgVideoUrl);
      try {
        await waitForVideoReady(attachedBg.video);
        chromaCustomVideo = attachedBg;
      } catch {
        attachedBg.detach();
      }
    }
  } else if (params.bgRemoval && params.bgRemoval.mode !== 'off') {
    params.onProgress(4, 'Loading AI background remover model...');
    bgSegmenter = await getBgSegmenter();
    if (params.bgRemoval.mode === 'image' && params.bgRemoval.bgImageUrl) {
      bgCustomImage = await loadImageElement(params.bgRemoval.bgImageUrl);
    }
    bgScratchCanvas = document.createElement('canvas');
    bgScratchCanvas.width = width;
    bgScratchCanvas.height = height;
  }

  const maskWorkCanvas =
    params.mask && params.mask.shape !== 'none' ? document.createElement('canvas') : null;
  const maskAlphaCanvas =
    params.mask && params.mask.shape !== 'none' ? document.createElement('canvas') : null;

  // Preload V2 overlay visuals
  const preparedOverlays: PreparedOverlayVisual[] = [];
  for (const layer of params.overlayLayers ?? []) {
    if (layer.kind === 'image') {
      const imageEl = await loadImageElement(layer.url);
      if (imageEl) {
        preparedOverlays.push({ layer, imageEl });
      }
    } else {
      const attached = createAttachedExportVideo(layer.url);
      try {
        await waitForVideoReady(attached.video);
        preparedOverlays.push({
          layer,
          videoEl: attached.video,
          detach: attached.detach,
        });
      } catch {
        attached.detach();
      }
    }
  }

  if (params.signal?.aborted) {
    detach();
    chromaCustomVideo?.detach();
    preparedOverlays.forEach((o) => o.detach?.());
    throw new DOMException('Export cancelled', 'AbortError');
  }

  const sourceImage = isPhotoSource ? await loadImageElement(params.sourceUrl) : null;
  if (isPhotoSource && !sourceImage) {
    detach();
    chromaCustomVideo?.detach();
    preparedOverlays.forEach((o) => o.detach?.());
    throw new Error('Unable to load source photo for export.');
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    detach();
    chromaCustomVideo?.detach();
    preparedOverlays.forEach((o) => o.detach?.());
    throw new Error('Export canvas unavailable.');
  }

  let videoEncoder: VideoEncoder | null = null;
  let audioEncoder: AudioEncoder | null = null;
  let encoderError: Error | null = null;

  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    fastStart: 'in-memory',
    firstTimestampBehavior: 'offset',
    video: {
      codec: videoCodecSelection.muxerCodec,
      width,
      height,
      // Omit integer frameRate so mp4-muxer uses 57600 timescale, supporting both integer (24/25/30/60) & fractional (23.976/29.97/VFR) rates accurately
    },
    audio: audioSelection
      ? {
          codec: audioSelection.muxerCodec,
          numberOfChannels: audioSelection.encoderConfig.numberOfChannels,
          sampleRate: audioSelection.targetSampleRate,
        }
      : undefined,
  });

  try {
    let lastVideoMuxUs = -1;
    let lastObservedChunkPtsUs = -1;
    const submittedVideoFrames: Array<{ timestampUs: number; durationUs: number }> = [];
    let audioShiftUs: number | null = null;
    let lastAudioMuxUs = -1;

    videoEncoder = new VideoEncoder({
      output: (chunk, meta) => {
        try {
          const entry = submittedVideoFrames.shift();
          const data = new Uint8Array(chunk.byteLength);
          chunk.copyTo(data);

          const rawPts = chunk.timestamp;
          const isMonotonicStream =
            videoCodecSelection.isBaseline || rawPts >= lastObservedChunkPtsUs;
          lastObservedChunkPtsUs = rawPts;

          let ts: number;
          let cto = 0;
          if (videoCodecSelection.isBaseline && entry) {
            ts = Math.max(0, entry.timestampUs);
          } else if (!isMonotonicStream && entry) {
            // Handle rare B-frame reordering while keeping DTS monotonic
            ts = Math.max(0, rawPts);
            cto = rawPts - entry.timestampUs;
          } else {
            ts = Math.max(0, entry ? entry.timestampUs : rawPts);
          }

          if (cto === 0) {
            if (ts <= lastVideoMuxUs) ts = lastVideoMuxUs + 1;
            lastVideoMuxUs = ts;
          } else {
            const dts = ts - cto;
            if (dts <= lastVideoMuxUs) {
              ts += lastVideoMuxUs + 1 - dts;
            }
            lastVideoMuxUs = ts - cto;
          }

          const dur =
            chunk.duration !== null &&
            chunk.duration !== undefined &&
            Number.isFinite(chunk.duration) &&
            chunk.duration > 0
              ? chunk.duration
              : entry?.durationUs ?? defaultFrameDurationUs;
          muxer.addVideoChunkRaw(data, chunk.type, ts, dur, meta, cto);
        } catch (err) {
          encoderError = err instanceof Error ? err : new Error(String(err));
        }
      },
      error: (err) => {
        encoderError = err instanceof Error ? err : new Error(String(err));
      },
    });
    videoEncoder.configure(videoCodecSelection.encoderConfig);

    if (audioSelection) {
      audioEncoder = new AudioEncoder({
        output: (chunk, meta) => {
          try {
            const data = new Uint8Array(chunk.byteLength);
            chunk.copyTo(data);
            // Normalize negative AAC/Opus encoder priming delay so timestamps remain >= 0 and monotonic
            if (audioShiftUs === null) {
              audioShiftUs = chunk.timestamp < 0 ? -chunk.timestamp : 0;
            }
            let ts = Math.max(0, chunk.timestamp + audioShiftUs);
            if (ts <= lastAudioMuxUs) ts = lastAudioMuxUs + 1;
            lastAudioMuxUs = ts;
            const fallbackAudioDur = Math.round(
              (1024 / audioSelection.targetSampleRate) * 1_000_000
            );
            const dur =
              chunk.duration !== null &&
              chunk.duration !== undefined &&
              Number.isFinite(chunk.duration) &&
              chunk.duration > 0
                ? chunk.duration
                : fallbackAudioDur;
            muxer.addAudioChunkRaw(data, chunk.type, ts, dur, meta);
          } catch (err) {
            encoderError = err instanceof Error ? err : new Error(String(err));
          }
        },
        error: (err) => {
          encoderError = err instanceof Error ? err : new Error(String(err));
        },
      });
      audioEncoder.configure(audioSelection.encoderConfig);
    }

    // 1. Encode sample-accurate mixed audio segments (Main track + A1 Audio Layers + V2 Overlay Audio)
    if (audioEncoder && audioSelection) {
      const sr = audioSelection.targetSampleRate;
      const chCount = audioSelection.encoderConfig.numberOfChannels;
      const chunkFrames = 1024;
      let totalSamplesEncoded = 0;

      for (const seg of activeSegments) {
        if (params.signal?.aborted) {
          throw new DOMException('Export cancelled', 'AbortError');
        }
        const segSpeed = getSegmentSpeed(seg);
        const segHasCurve = hasCustomSpeedCurve(seg);
        const segVolume = seg.meta?.muted ? 0 : seg.meta?.volume ?? 1;
        const segOutDur = Math.max(0.02, getSegmentEditedDuration(seg));
        const segOutSamples = Math.max(1, Math.round(segOutDur * sr));

        const mixedChannels: Float32Array[] = Array.from(
          { length: chCount },
          () => new Float32Array(segOutSamples)
        );

        // Mix main video audio (with Speed Curve playbackRate automation when active!)
        if (preparedAudioBuffer && segVolume > 0) {
          const startSample = Math.max(0, Math.round(seg.start * sr));
          const endSample = Math.min(preparedAudioBuffer.length, Math.round(seg.end * sr));
          const segSampleLen = Math.max(0, endSample - startSample);

          if (segSampleLen > 0) {
            let mainBuf: AudioBuffer = preparedAudioBuffer;
            let mainOffset = startSample;
            let mainLen = segSampleLen;

            if (segHasCurve || Math.abs(segSpeed - 1.0) > 0.01) {
              const tempCtx = new OfflineAudioContext(chCount, segSampleLen, sr);
              const sliceBuf = tempCtx.createBuffer(chCount, segSampleLen, sr);
              for (let ch = 0; ch < chCount; ch++) {
                sliceBuf.copyToChannel(
                  preparedAudioBuffer.getChannelData(ch).subarray(startSample, endSample),
                  ch
                );
              }
              const renderCtx = new OfflineAudioContext(chCount, segOutSamples, sr);
              const srcNode = renderCtx.createBufferSource();
              srcNode.buffer = sliceBuf;
              if (segHasCurve && seg.meta?.speedCurve) {
                const steps = 64;
                const srcLen = seg.end - seg.start;
                const srcDt = srcLen / steps;
                let outCursor = 0;
                for (let k = 0; k < steps; k++) {
                  const midU = (k + 0.5) / steps;
                  const spd = Math.max(
                    0.25,
                    evaluateCurveAtProgress(seg.meta.speedCurve, midU, segSpeed)
                  );
                  srcNode.playbackRate.setValueAtTime(spd, outCursor);
                  outCursor += srcDt / spd;
                }
              } else {
                srcNode.playbackRate.value = segSpeed;
              }
              srcNode.connect(renderCtx.destination);
              srcNode.start(0);
              mainBuf = await renderCtx.startRendering();
              mainOffset = 0;
              mainLen = mainBuf.length;
            }

            const copyLen = Math.min(segOutSamples, mainLen);
            const segFadeIn = seg.meta?.fadeInSec ?? 0;
            const segFadeOut = seg.meta?.fadeOutSec ?? 0;
            for (let ch = 0; ch < chCount; ch++) {
              const srcArr = mainBuf.getChannelData(ch);
              const dstArr = mixedChannels[ch];
              for (let s = 0; s < copyLen; s++) {
                const env =
                  segFadeIn > 0 || segFadeOut > 0
                    ? computeAudioFadeMultiplier(s / sr, segOutDur, segFadeIn, segFadeOut)
                    : 1;
                dstArr[s] += srcArr[mainOffset + s] * segVolume * env;
              }
            }
          }
        }

        // Mix extra A1 audio layers & V2 overlay video audio overlapping this segment
        const avgSpeed = getSegmentDisplaySpeed(seg);
        for (const extra of decodedExtraAudio) {
          const overlapStart = Math.max(seg.start, extra.startTime);
          const overlapEnd = Math.min(seg.end, extra.endTime);
          if (overlapEnd <= overlapStart) continue;

          const outOffset = Math.max(
            0,
            Math.round(integrateSegmentSourceToEdited(seg, overlapStart - seg.start) * sr)
          );
          const mixLen = Math.min(
            segOutSamples - outOffset,
            Math.round(
              (integrateSegmentSourceToEdited(seg, overlapEnd - seg.start) -
                integrateSegmentSourceToEdited(seg, overlapStart - seg.start)) *
                sr
            )
          );
          const extraLen = extra.buffer.length;
          if (mixLen <= 0 || extraLen <= 0) continue;

          const layerSpan = Math.max(0.1, extra.endTime - extra.startTime);
          const layerFadeIn = extra.fadeInSec ?? 0;
          const layerFadeOut = extra.fadeOutSec ?? 0;
          const sourceOffset = Math.max(0, extra.sourceOffsetSec ?? 0);

          for (let ch = 0; ch < chCount; ch++) {
            const srcCh = extra.buffer.getChannelData(
              ch % extra.buffer.numberOfChannels
            );
            const dstCh = mixedChannels[ch];
            for (let k = 0; k < mixLen; k++) {
              const layerElapsedSec = overlapStart - extra.startTime + (k / sr) * avgSpeed;
              const srcSec = sourceOffset + layerElapsedSec;
              const srcIdx = Math.floor(srcSec * sr) % extraLen;
              if (srcIdx >= 0 && srcIdx < extraLen) {
                const env =
                  layerFadeIn > 0 || layerFadeOut > 0
                    ? computeAudioFadeMultiplier(
                        layerElapsedSec,
                        layerSpan,
                        layerFadeIn,
                        layerFadeOut
                      )
                    : 1;
                dstCh[outOffset + k] += srcCh[srcIdx] * extra.volume * env;
              }
            }
          }
        }

        // Clamp and encode mixed audio chunks
        for (let pos = 0; pos < segOutSamples; pos += chunkFrames) {
          if (encoderError) throw encoderError;
          const count = Math.min(chunkFrames, segOutSamples - pos);
          const planarData = new Float32Array(count * chCount);
          for (let ch = 0; ch < chCount; ch++) {
            const srcArr = mixedChannels[ch];
            const offset = ch * count;
            for (let s = 0; s < count; s++) {
              const sample = srcArr[pos + s];
              planarData[offset + s] =
                sample > 1 ? 1 : sample < -1 ? -1 : sample;
            }
          }

          const timestampUs = Math.round((totalSamplesEncoded / sr) * 1_000_000);
          const audioData = new AudioData({
            format: 'f32-planar',
            sampleRate: sr,
            numberOfFrames: count,
            numberOfChannels: chCount,
            timestamp: timestampUs,
            data: planarData,
          });
          audioEncoder.encode(audioData);
          audioData.close();
          totalSamplesEncoded += count;

          if (audioEncoder.encodeQueueSize > 24) {
            await new Promise((r) => window.setTimeout(r, 5));
          }
        }
      }
    }

    const totalEditedDuration = Math.max(0.1, getEditedDuration(activeSegments));
    const cssFilter = buildCssFilter(params.adjustments ?? DEFAULT_ADJUSTMENTS);
    const frameFit: FrameFitMode = params.frameFit ?? 'contain';
    const textOverlays = params.textOverlays ?? [];
    const drawExtras: DrawFrameExtras = {
      mainKeyframes: params.mainKeyframes,
      motionTracks: params.motionTracks,
      overlays: preparedOverlays,
      bgRemoval: params.bgRemoval,
      bgSegmenter,
      bgScratchCanvas,
      bgCustomImage,
      chromaKey: params.chromaKey,
      chromaCustomImage,
      chromaCustomVideo: chromaCustomVideo?.video ?? null,
      stabilization: params.stabilization,
      mask: params.mask,
      maskWorkCanvas,
      maskAlphaCanvas,
      videoEffects: params.videoEffects,
      effectsPool: new EffectsRenderPool(),
    };

    // Scratch canvases for optional smooth slow-motion frame blending, rotation & clip transitions
    const prevCanvas = document.createElement('canvas');
    prevCanvas.width = width;
    prevCanvas.height = height;
    const prevCtx = prevCanvas.getContext('2d');

    const blendCanvas = document.createElement('canvas');
    blendCanvas.width = width;
    blendCanvas.height = height;
    const blendCtx = blendCanvas.getContext('2d');

    const transInCanvas = document.createElement('canvas');
    transInCanvas.width = width;
    transInCanvas.height = height;
    const transInCtx = transInCanvas.getContext('2d');

    const transOutCanvas = document.createElement('canvas');
    transOutCanvas.width = width;
    transOutCanvas.height = height;
    const transOutCtx = transOutCanvas.getContext('2d');
    let hasOutgoingSegFrame = false;

    const rotatedCanvas =
      demuxedMp4 && demuxedMp4.displayRotation !== 0
        ? document.createElement('canvas')
        : null;
    const rotatedCtx = rotatedCanvas ? rotatedCanvas.getContext('2d') : null;

    const normalizeVideoFrame = (
      raw: VideoFrame,
      rotation: 0 | 90 | 180 | 270
    ): VideoFrame | HTMLCanvasElement => {
      if (rotation === 0 || !rotatedCanvas || !rotatedCtx) return raw;
      const cw = raw.displayWidth || raw.codedWidth;
      const ch = raw.displayHeight || raw.codedHeight;
      const outW = rotation === 90 || rotation === 270 ? ch : cw;
      const outH = rotation === 90 || rotation === 270 ? cw : ch;
      if (rotatedCanvas.width !== outW) rotatedCanvas.width = outW;
      if (rotatedCanvas.height !== outH) rotatedCanvas.height = outH;
      rotatedCtx.save();
      rotatedCtx.clearRect(0, 0, outW, outH);
      rotatedCtx.translate(outW / 2, outH / 2);
      rotatedCtx.rotate((rotation * Math.PI) / 180);
      rotatedCtx.drawImage(raw, -cw / 2, -ch / 2, cw, ch);
      rotatedCtx.restore();
      return rotatedCanvas;
    };

    let accumulatedSec = 0;
    let lastEncodedTimestampUs = -1;
    let frameCounter = 0;

    const renderAndEncodeCanvasFrame = async (
      frameSource: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement | VideoFrame,
      mediaTime: number,
      seg: TimelineSegment,
      timestampUs: number,
      durationUs: number,
      isLastFrameOfSeg: boolean,
      allowSmoothSlowMo: boolean,
      hasPrevSnapshotRef: { value: boolean; lastTsUs: number }
    ) => {
      if (!videoEncoder) return;
      if (encoderError) throw encoderError;

      if (chromaCustomVideo) {
        const bgTarget = mediaTime % Math.max(0.2, chromaCustomVideo.video.duration || 5);
        await seekVideoPrecisely(chromaCustomVideo.video, bgTarget);
      }

      for (const ov of preparedOverlays) {
        if (
          ov.videoEl &&
          mediaTime >= ov.layer.startTime - 0.05 &&
          mediaTime <= ov.layer.endTime + 0.05
        ) {
          const targetOvTime =
            (mediaTime - ov.layer.startTime) % Math.max(0.1, ov.layer.duration);
          await seekVideoPrecisely(ov.videoEl, targetOvTime);
        }
      }

      drawExportFrame(
        ctx,
        frameSource,
        width,
        height,
        cssFilter,
        frameFit,
        textOverlays,
        mediaTime,
        drawExtras
      );

      const activeTrans = getTransitionProgress(seg, mediaTime);
      if (activeTrans && transInCtx) {
        transInCtx.drawImage(canvas, 0, 0);
        applyExportCanvasTransition(
          ctx,
          transInCanvas,
          transOutCanvas,
          hasOutgoingSegFrame,
          width,
          height,
          activeTrans.type,
          activeTrans.progress
        );
      }

      const safeTs =
        lastEncodedTimestampUs >= 0 && timestampUs <= lastEncodedTimestampUs
          ? lastEncodedTimestampUs + 1000
          : Math.max(0, timestampUs);
      const safeDur = Math.max(1000, durationUs);

      // Optional smooth slow-motion frame interpolation when user slows clip down
      if (
        allowSmoothSlowMo &&
        hasPrevSnapshotRef.value &&
        prevCtx &&
        blendCtx &&
        safeTs - hasPrevSnapshotRef.lastTsUs > 45_000
      ) {
        const gapUs = safeTs - hasPrevSnapshotRef.lastTsUs;
        const steps = Math.min(8, Math.round(gapUs / 33_333));
        if (steps >= 2) {
          const subDur = Math.max(1000, Math.floor(safeDur / steps));
          for (let k = 0; k < steps; k++) {
            const subTs = safeTs + k * subDur;
            const alpha = (k + 1) / steps;
            blendCtx.save();
            blendCtx.globalAlpha = 1;
            blendCtx.drawImage(prevCanvas, 0, 0);
            blendCtx.globalAlpha = alpha;
            blendCtx.drawImage(canvas, 0, 0);
            blendCtx.restore();

            const effDur =
              k === steps - 1 ? Math.max(1000, safeTs + safeDur - subTs) : subDur;
            submittedVideoFrames.push({ timestampUs: subTs, durationUs: effDur });
            const subFrame = new VideoFrame(blendCanvas, {
              timestamp: subTs,
              duration: effDur,
            });
            videoEncoder.encode(subFrame, { keyFrame: frameCounter % 60 === 0 });
            subFrame.close();
            frameCounter += 1;
            lastEncodedTimestampUs = subTs;
          }
          prevCtx.drawImage(canvas, 0, 0);
          hasPrevSnapshotRef.lastTsUs = safeTs;
          if (isLastFrameOfSeg && transOutCtx) {
            transOutCtx.drawImage(canvas, 0, 0);
            hasOutgoingSegFrame = true;
          }
          if (videoEncoder.encodeQueueSize > 8) {
            await new Promise((r) => window.setTimeout(r, 6));
          }
          return;
        }
      }

      if (allowSmoothSlowMo && prevCtx) {
        prevCtx.drawImage(canvas, 0, 0);
        hasPrevSnapshotRef.value = true;
        hasPrevSnapshotRef.lastTsUs = safeTs;
      }

      if (isLastFrameOfSeg && transOutCtx) {
        transOutCtx.drawImage(canvas, 0, 0);
        hasOutgoingSegFrame = true;
      }

      submittedVideoFrames.push({ timestampUs: safeTs, durationUs: safeDur });
      const vf = new VideoFrame(canvas, {
        timestamp: safeTs,
        duration: safeDur,
      });
      videoEncoder.encode(vf, { keyFrame: frameCounter % 60 === 0 });
      vf.close();
      frameCounter += 1;
      lastEncodedTimestampUs = safeTs;

      if (videoEncoder.encodeQueueSize > 8) {
        await new Promise((r) => window.setTimeout(r, 6));
      }
    };

    // 2. Encode video frames deterministically
    if (sourceImage && !canUseMp4Decoder && !video) {
      // Deterministic 30fps photo-to-MP4 encode loop (preserves keyframes, filters, transitions, V2 overlays & A1 audio)
      const fps = 30;
      for (let i = 0; i < activeSegments.length; i++) {
        if (params.signal?.aborted) {
          throw new DOMException('Export cancelled', 'AbortError');
        }
        const seg = activeSegments[i];
        const segDuration = getSegmentEditedDuration(seg);
        const totalSegFrames = Math.max(1, Math.round(segDuration * fps));
        const hasPrevRef = { value: false, lastTsUs: 0 };

        for (let f = 0; f < totalSegFrames; f++) {
          if (params.signal?.aborted) {
            throw new DOMException('Export cancelled', 'AbortError');
          }
          const localSec = f / fps;
          const mediaTime = Math.min(
            seg.end,
            seg.start + editedTimeToSegmentSourceOffset(seg, localSec)
          );
          const timestampUs = Math.round((accumulatedSec + localSec) * 1_000_000);
          const nextTimestampUs =
            f === totalSegFrames - 1
              ? Math.round((accumulatedSec + segDuration) * 1_000_000)
              : Math.round((accumulatedSec + (f + 1) / fps) * 1_000_000);

          await renderAndEncodeCanvasFrame(
            sourceImage,
            mediaTime,
            seg,
            timestampUs,
            Math.max(1000, nextTimestampUs - timestampUs),
            f === totalSegFrames - 1,
            false,
            hasPrevRef
          );

          const overallProgress = Math.min(
            95,
            Math.max(
              3,
              Math.round(((accumulatedSec + localSec) / totalEditedDuration) * 95)
            )
          );
          params.onProgress(overallProgress, `Rendering frame ${f + 1} of ${totalSegFrames}`);
        }

        accumulatedSec += segDuration;
      }
    } else if (canUseMp4Decoder && demuxedMp4 && sourceBytes) {
      // Primary deterministic MP4/MOV pipeline via WebCodecs VideoDecoder (zero real-time drops, exact native FPS & timestamps)
      for (let i = 0; i < activeSegments.length; i++) {
        if (params.signal?.aborted) {
          throw new DOMException('Export cancelled', 'AbortError');
        }
        if (encoderError) throw encoderError;

        const seg = activeSegments[i];
        const segSpeed = getSegmentSpeed(seg);
        const segHasCurve = hasCustomSpeedCurve(seg);
        const isNativeSpeed = !segHasCurve && Math.abs(segSpeed - 1.0) < 0.005;
        const useSmoothSlowMo = Boolean(
          seg.meta?.smoothSlowMo && (segSpeed < 0.99 || segHasCurve)
        );
        const segDuration = getSegmentEditedDuration(seg);
        const segStartOutUs = Math.round(accumulatedSec * 1_000_000);
        const segEndOutUs = Math.round((accumulatedSec + segDuration) * 1_000_000);

        const samples = demuxedMp4.samples;
        let firstTargetIdx = samples.findIndex((s) => s.ptsSec >= seg.start - 0.002);
        if (firstTargetIdx < 0) firstTargetIdx = Math.max(0, samples.length - 1);

        let keyIdx = firstTargetIdx;
        while (keyIdx > 0 && !samples[keyIdx].isKey) {
          keyIdx -= 1;
        }

        let endSampleIdx = samples.length - 1;
        for (let s = firstTargetIdx; s < samples.length; s++) {
          if (samples[s].ptsSec > seg.end + 0.15) {
            endSampleIdx = s;
            break;
          }
        }

        const decodedQueue: VideoFrame[] = [];
        let decoderDone = false;
        let decoderErr: Error | null = null;
        let notifyPuller: (() => void) | null = null;
        const wakePuller = () => {
          const fn = notifyPuller;
          notifyPuller = null;
          fn?.();
        };

        const decoder = new VideoDecoder({
          output: (frame) => {
            decodedQueue.push(frame);
            wakePuller();
          },
          error: (err) => {
            decoderErr = err instanceof Error ? err : new Error(String(err));
            wakePuller();
          },
        });
        decoder.configure({
          codec: demuxedMp4.codec,
          codedWidth: demuxedMp4.codedWidth,
          codedHeight: demuxedMp4.codedHeight,
          description: demuxedMp4.description,
        });

        let sampleCursor = keyIdx;
        let flushStarted = false;

        const feedMore = () => {
          if (decoderErr || decoderDone || decoder.state !== 'configured') return;
          while (
            sampleCursor <= endSampleIdx &&
            decodedQueue.length + decoder.decodeQueueSize < 8
          ) {
            const sample = samples[sampleCursor++];
            const chunk = new EncodedVideoChunk({
              type: sample.isKey ? 'key' : 'delta',
              timestamp: Math.round(sample.ptsSec * 1_000_000),
              duration: Math.max(1, Math.round(sample.durationSec * 1_000_000)),
              data: sourceBytes.subarray(sample.offset, sample.offset + sample.size),
            });
            decoder.decode(chunk);
          }
          if (sampleCursor > endSampleIdx && !flushStarted) {
            flushStarted = true;
            decoder
              .flush()
              .then(() => {
                decoderDone = true;
                wakePuller();
              })
              .catch((err) => {
                decoderErr = err instanceof Error ? err : new Error(String(err));
                decoderDone = true;
                wakePuller();
              });
          }
        };

        const onAbortWake = () => wakePuller();
        params.signal?.addEventListener('abort', onAbortWake, { once: true });

        const pullNextDecodedFrame = async (): Promise<VideoFrame | null> => {
          while (true) {
            if (params.signal?.aborted) {
              throw new DOMException('Export cancelled', 'AbortError');
            }
            if (decoderErr) throw decoderErr;
            if (decodedQueue.length > 0) {
              const f = decodedQueue.shift()!;
              feedMore();
              return f;
            }
            if (decoderDone) return null;
            feedMore();
            await new Promise<void>((res) => {
              notifyPuller = res;
            });
          }
        };

        const hasPrevRef = { value: false, lastTsUs: 0 };

        try {
          if (isNativeSpeed) {
            // Preserve exact original source frame cadence & relative timestamps (24/25/29.97/30/50/60/VFR)
            let lastPreStart: { frame: VideoFrame; ptsSec: number } | null = null;
            let pending: { frame: VideoFrame; ptsSec: number; outUs: number } | null = null;
            let emittedFirst = false;

            while (true) {
              const df = await pullNextDecodedFrame();
              if (!df) break;
              const ptsSec = df.timestamp / 1_000_000;

              if (ptsSec < seg.start - 0.002) {
                lastPreStart?.frame.close();
                lastPreStart = { frame: df, ptsSec };
                continue;
              }

              if (ptsSec >= seg.end - 0.002) {
                df.close();
                break;
              }

              if (!emittedFirst) {
                emittedFirst = true;
                if (lastPreStart && ptsSec - seg.start > 0.015) {
                  pending = {
                    frame: lastPreStart.frame,
                    ptsSec: seg.start,
                    outUs: segStartOutUs,
                  };
                  lastPreStart = null;
                } else {
                  lastPreStart?.frame.close();
                  lastPreStart = null;
                  const firstOutUs =
                    ptsSec - seg.start < defaultFrameDurationUs / 1_000_000
                      ? segStartOutUs
                      : segStartOutUs + Math.round((ptsSec - seg.start) * 1_000_000);
                  pending = { frame: df, ptsSec, outUs: firstOutUs };
                  continue;
                }
              }

              const nextOutUs = Math.max(
                (pending?.outUs ?? segStartOutUs) + 1000,
                segStartOutUs + Math.round((ptsSec - seg.start) * 1_000_000)
              );

              if (pending) {
                const durUs = Math.max(1000, nextOutUs - pending.outUs);
                const srcView = normalizeVideoFrame(
                  pending.frame,
                  demuxedMp4.displayRotation
                );
                await renderAndEncodeCanvasFrame(
                  srcView,
                  pending.ptsSec,
                  seg,
                  pending.outUs,
                  durUs,
                  false,
                  false,
                  hasPrevRef
                );
                pending.frame.close();

                const overallProgress = Math.min(
                  95,
                  Math.max(
                    3,
                    Math.round(
                      ((accumulatedSec + (pending.ptsSec - seg.start)) /
                        totalEditedDuration) *
                        95
                    )
                  )
                );
                params.onProgress(
                  overallProgress,
                  `Rendering clip ${i + 1} of ${activeSegments.length}`
                );
              }

              pending = { frame: df, ptsSec, outUs: nextOutUs };
            }

            if (!emittedFirst && lastPreStart) {
              pending = {
                frame: lastPreStart.frame,
                ptsSec: seg.start,
                outUs: segStartOutUs,
              };
              lastPreStart = null;
            } else {
              lastPreStart?.frame.close();
              lastPreStart = null;
            }

            if (pending) {
              const finalDurUs = Math.max(
                defaultFrameDurationUs,
                segEndOutUs - pending.outUs
              );
              const srcView = normalizeVideoFrame(
                pending.frame,
                demuxedMp4.displayRotation
              );
              await renderAndEncodeCanvasFrame(
                srcView,
                pending.ptsSec,
                seg,
                pending.outUs,
                finalDurUs,
                true,
                false,
                hasPrevRef
              );
              pending.frame.close();
              pending = null;
            }
          } else {
            // Speed-modified or Speed Curve segment: deterministic output FPS stepping mapped via curve integral
            const targetFps = Math.min(60, Math.max(24, Math.round(detectedSourceFps)));
            const totalSegFrames = Math.max(1, Math.round(segDuration * targetFps));

            let currentDec: { frame: VideoFrame; ptsSec: number } | null = null;
            let nextDec: { frame: VideoFrame; ptsSec: number } | null = null;

            const primeFirst = await pullNextDecodedFrame();
            if (primeFirst) {
              currentDec = { frame: primeFirst, ptsSec: primeFirst.timestamp / 1_000_000 };
              const primeSecond = await pullNextDecodedFrame();
              if (primeSecond) {
                nextDec = { frame: primeSecond, ptsSec: primeSecond.timestamp / 1_000_000 };
              }
            }

            try {
              for (let f = 0; f < totalSegFrames; f++) {
                if (params.signal?.aborted) {
                  throw new DOMException('Export cancelled', 'AbortError');
                }
                const localOutSec = f / targetFps;
                const targetSrcTime = Math.min(
                  seg.end,
                  seg.start + editedTimeToSegmentSourceOffset(seg, localOutSec)
                );

                while (nextDec && nextDec.ptsSec <= targetSrcTime + 0.001) {
                  currentDec?.frame.close();
                  currentDec = nextDec;
                  const pulled = await pullNextDecodedFrame();
                  nextDec = pulled
                    ? { frame: pulled, ptsSec: pulled.timestamp / 1_000_000 }
                    : null;
                }

                if (!currentDec) break;

                const timestampUs = Math.round((accumulatedSec + localOutSec) * 1_000_000);
                const nextTimestampUs =
                  f === totalSegFrames - 1
                    ? segEndOutUs
                    : Math.round((accumulatedSec + (f + 1) / targetFps) * 1_000_000);
                const durUs = Math.max(1000, nextTimestampUs - timestampUs);

                const srcView = normalizeVideoFrame(
                  currentDec.frame,
                  demuxedMp4.displayRotation
                );
                await renderAndEncodeCanvasFrame(
                  srcView,
                  targetSrcTime,
                  seg,
                  timestampUs,
                  durUs,
                  f === totalSegFrames - 1,
                  useSmoothSlowMo,
                  hasPrevRef
                );

                const overallProgress = Math.min(
                  95,
                  Math.max(
                    3,
                    Math.round(((accumulatedSec + localOutSec) / totalEditedDuration) * 95)
                  )
                );
                params.onProgress(
                  overallProgress,
                  `Rendering clip ${i + 1} of ${activeSegments.length}`
                );
              }
            } finally {
              currentDec?.frame.close();
              nextDec?.frame.close();
            }
          }
        } finally {
          params.signal?.removeEventListener('abort', onAbortWake);
          while (decodedQueue.length > 0) {
            decodedQueue.shift()?.close();
          }
          try {
            if (decoder.state !== 'closed') decoder.close();
          } catch {
            // Ignore close error
          }
        }

        accumulatedSec += segDuration;
      }
    } else if (video) {
      // Deterministic frame-by-frame seek stepper for non-MP4 (e.g. WebM) or codecs unsupported by VideoDecoder
      const targetFps = Math.min(60, Math.max(15, Math.round(detectedSourceFps)));
      for (let i = 0; i < activeSegments.length; i++) {
        if (params.signal?.aborted) {
          throw new DOMException('Export cancelled', 'AbortError');
        }
        if (encoderError) throw encoderError;

        const seg = activeSegments[i];
        const segSpeed = getSegmentSpeed(seg);
        const useSmoothSlowMo = Boolean(
          seg.meta?.smoothSlowMo && (segSpeed < 0.99 || hasCustomSpeedCurve(seg))
        );
        const segDuration = getSegmentEditedDuration(seg);
        const segEndOutUs = Math.round((accumulatedSec + segDuration) * 1_000_000);
        const totalSegFrames = Math.max(1, Math.round(segDuration * targetFps));
        const hasPrevRef = { value: false, lastTsUs: 0 };

        for (let f = 0; f < totalSegFrames; f++) {
          if (params.signal?.aborted) {
            throw new DOMException('Export cancelled', 'AbortError');
          }
          const localOutSec = f / targetFps;
          const mediaTime = Math.min(
            seg.end,
            seg.start + editedTimeToSegmentSourceOffset(seg, localOutSec)
          );

          await seekVideoPrecisely(video, mediaTime);

          const timestampUs = Math.round((accumulatedSec + localOutSec) * 1_000_000);
          const nextTimestampUs =
            f === totalSegFrames - 1
              ? segEndOutUs
              : Math.round((accumulatedSec + (f + 1) / targetFps) * 1_000_000);
          const durUs = Math.max(1000, nextTimestampUs - timestampUs);

          await renderAndEncodeCanvasFrame(
            video,
            mediaTime,
            seg,
            timestampUs,
            durUs,
            f === totalSegFrames - 1,
            useSmoothSlowMo,
            hasPrevRef
          );

          const overallProgress = Math.min(
            95,
            Math.max(
              3,
              Math.round(((accumulatedSec + localOutSec) / totalEditedDuration) * 95)
            )
          );
          params.onProgress(
            overallProgress,
            `Rendering clip ${i + 1} of ${activeSegments.length}`
          );
        }

        accumulatedSec += segDuration;
      }
    }

    params.onProgress(96, 'Finalizing MP4 file...');
    await videoEncoder.flush();
    if (audioEncoder) {
      await audioEncoder.flush();
    }
    if (encoderError) throw encoderError;

    muxer.finalize();
    const mp4Blob = new Blob([target.buffer], { type: 'video/mp4' });
    const blobUrl = URL.createObjectURL(mp4Blob);
    params.onProgress(100, 'Export complete');

    return {
      blob: mp4Blob,
      blobUrl,
      mimeType: 'video/mp4',
      extension: 'mp4',
    };
  } finally {
    detach();
    chromaCustomVideo?.detach();
    preparedOverlays.forEach((o) => o.detach?.());
    try {
      if (videoEncoder && videoEncoder.state !== 'closed') {
        videoEncoder.close();
      }
    } catch {
      // Ignore close error
    }
    try {
      if (audioEncoder && audioEncoder.state !== 'closed') {
        audioEncoder.close();
      }
    } catch {
      // Ignore close error
    }
  }
}

/**
 * Fallback WebM MediaRecorder exporter (used only on browsers without WebCodecs).
 * Uses `captureStream(0)` + `requestFrame()` gated strictly by source `mediaTime` changes so
 * high-refresh displays (60Hz/120Hz) cannot create slow-motion frame duplication.
 */
async function exportWithWebmFallback(
  params: ExportVideoParams,
  width: number,
  height: number,
  bitrate: number
): Promise<ExportVideoResult> {
  const activeSegments = getActiveSegments(params.segments);

  const { video, detach } = createAttachedExportVideo(params.sourceUrl);
  video.muted = false;

  await waitForVideoReady(video);
  if (params.signal?.aborted) {
    detach();
    throw new DOMException('Export cancelled', 'AbortError');
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    detach();
    throw new Error('Export canvas unavailable.');
  }

  const outputStream = canvas.captureStream(0);
  const videoTrack = outputStream.getVideoTracks()[0] as
    | (MediaStreamTrack & { requestFrame?: () => void })
    | undefined;

  let audioCtx: AudioContext | null = null;
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
      if (audioCtx.state === 'suspended') {
        await audioCtx.resume();
      }
      const sourceNode = audioCtx.createMediaElementSource(video);
      const destNode = audioCtx.createMediaStreamDestination();
      sourceNode.connect(destNode);
      destNode.stream.getAudioTracks().forEach((t) => outputStream.addTrack(t));
    }
  } catch {
    video.muted = true;
  }

  const { mimeType, extension } = selectSupportedWebmMime();
  const recorderOptions: MediaRecorderOptions = mimeType
    ? { mimeType, videoBitsPerSecond: bitrate }
    : { videoBitsPerSecond: bitrate };

  const recorder = new MediaRecorder(outputStream, recorderOptions);
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) chunks.push(e.data);
  };

  let cancelled = false;
  const cleanupAll = () => {
    detach();
    outputStream.getTracks().forEach((tr) => tr.stop());
    if (audioCtx) {
      audioCtx.close().catch(() => {});
    }
  };

  const stopPromise = new Promise<ExportVideoResult>((resolve, reject) => {
    recorder.onstop = () => {
      cleanupAll();
      if (cancelled) {
        reject(new DOMException('Export cancelled', 'AbortError'));
        return;
      }
      const finalMime = recorder.mimeType || mimeType || 'video/webm';
      const blob = new Blob(chunks, { type: finalMime });
      const blobUrl = URL.createObjectURL(blob);
      resolve({
        blob,
        blobUrl,
        mimeType: finalMime,
        extension,
      });
    };
    recorder.onerror = () => {
      cleanupAll();
      reject(new Error('Video encoder failed during export.'));
    };
  });

  if (params.signal) {
    params.signal.addEventListener(
      'abort',
      () => {
        cancelled = true;
        if (recorder.state !== 'inactive') {
          recorder.stop();
        } else {
          cleanupAll();
        }
      },
      { once: true }
    );
  }

  try {
    const cssFilter = buildCssFilter(params.adjustments ?? DEFAULT_ADJUSTMENTS);
    const frameFit: FrameFitMode = params.frameFit ?? 'contain';
    const textOverlays = params.textOverlays ?? [];
    const webmExtras: DrawFrameExtras = {
      mainKeyframes: params.mainKeyframes,
      motionTracks: params.motionTracks,
      bgRemoval: params.bgRemoval,
      chromaKey: params.chromaKey,
      stabilization: params.stabilization,
      mask: params.mask,
      videoEffects: params.videoEffects,
      effectsPool: new EffectsRenderPool(),
    };
    const totalOutDuration = Math.max(0.1, getEditedDuration(activeSegments));
    let accumulatedElapsed = 0;

    for (let i = 0; i < activeSegments.length; i++) {
      if (cancelled || params.signal?.aborted) {
        throw new DOMException('Export cancelled', 'AbortError');
      }

      const seg = activeSegments[i];
      const segSpeed = getSegmentSpeed(seg);
      const segOutDur = (seg.end - seg.start) / segSpeed;

      await seekVideoPrecisely(video, seg.start);
      video.playbackRate = segSpeed;
      video.muted = Boolean(seg.meta?.muted);
      video.volume = seg.meta?.muted ? 0 : seg.meta?.volume ?? 1;

      if (cancelled || params.signal?.aborted) {
        throw new DOMException('Export cancelled', 'AbortError');
      }

      drawExportFrame(
        ctx,
        video,
        width,
        height,
        cssFilter,
        frameFit,
        textOverlays,
        seg.start,
        webmExtras
      );
      videoTrack?.requestFrame?.();

      await video.play();

      if (recorder.state === 'inactive') {
        recorder.start(250);
      }

      await new Promise<void>((resolve) => {
        let lastMediaTime = -1;
        let done = false;
        let vfcId = 0;
        let timerId = 0;

        const supportsVfc = typeof video.requestVideoFrameCallback === 'function';

        const finishSeg = () => {
          if (done) return;
          done = true;
          window.clearInterval(timerId);
          if (typeof video.cancelVideoFrameCallback === 'function' && vfcId) {
            video.cancelVideoFrameCallback(vfcId);
          }
          video.pause();
          resolve();
        };

        const pushFrame = (mediaTime: number) => {
          if (done || cancelled || params.signal?.aborted) {
            finishSeg();
            return;
          }
          if (Math.abs(mediaTime - lastMediaTime) >= 0.001) {
            lastMediaTime = mediaTime;
            drawExportFrame(
              ctx,
              video,
              width,
              height,
              cssFilter,
              frameFit,
              textOverlays,
              mediaTime,
              webmExtras
            );
            videoTrack?.requestFrame?.();
          }

          const segProgress = Math.max(
            0,
            Math.min(segOutDur, (mediaTime - seg.start) / segSpeed)
          );
          const pct = Math.min(
            99,
            Math.round(((accumulatedElapsed + segProgress) / totalOutDuration) * 100)
          );
          params.onProgress(pct, `Rendering clip ${i + 1} of ${activeSegments.length}`);

          if (mediaTime >= seg.end - 0.02 || video.ended) {
            finishSeg();
          }
        };

        if (supportsVfc) {
          const cb = (_now: number, meta: { mediaTime: number }) => {
            pushFrame(meta.mediaTime);
            if (!done) {
              vfcId = video.requestVideoFrameCallback(cb);
            }
          };
          vfcId = video.requestVideoFrameCallback(cb);
        }

        timerId = window.setInterval(() => {
          pushFrame(video.currentTime);
        }, 25);
      });

      accumulatedElapsed += segOutDur;
    }

    params.onProgress(100, 'Finalizing video file...');
    if (recorder.state !== 'inactive') {
      recorder.stop();
    }
  } catch (err) {
    if (recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      cleanupAll();
    }
    throw err;
  }

  return stopPromise;
}

/**
 * Exports active trimmed/cut segments preserving original 1.0x playback speed, frame rate, timestamps, audio, and edited duration.
 */
export async function exportEditedVideo(params: ExportVideoParams): Promise<ExportVideoResult> {
  const activeSegments = getActiveSegments(params.segments);
  if (activeSegments.length === 0) {
    throw new Error('No active video clips to export.');
  }

  const { width, height } = getScaledDimensions(
    params.sourceWidth,
    params.sourceHeight,
    params.resolution,
    params.aspectRatio ?? 'original'
  );

  const maxEdge = Math.max(width, height);
  const bitrate =
    params.resolution === '4k' || maxEdge >= 2800
      ? 24_000_000
      : params.resolution === '1080p' || maxEdge >= 1600
      ? 10_000_000
      : params.resolution === '720p'
      ? 5_000_000
      : params.resolution === '480p'
      ? 2_500_000
      : maxEdge >= 1080
      ? 10_000_000
      : 6_000_000;

  try {
    return await exportWithWebCodecs(params, width, height, bitrate);
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw err;
    }
    if (params.sourceMediaKind === 'image') {
      throw err;
    }
    // Only fall back to WebM if the browser genuinely lacks WebCodecs H.264 MP4 support
    if (
      err instanceof Error &&
      err.message === 'WEBCODECS_UNSUPPORTED' &&
      typeof MediaRecorder !== 'undefined'
    ) {
      return await exportWithWebmFallback(params, width, height, bitrate);
    }
    throw err;
  }
}

/**
 * Exports an edited/filtered photo cleanly at chosen resolution as a lossless PNG image.
 */
export async function exportEditedPhoto(params: ExportPhotoParams): Promise<ExportVideoResult> {
  const sourceImage = await loadImageElement(params.sourceUrl);
  if (!sourceImage) {
    throw new Error('Unable to load photo for export.');
  }

  const natW = sourceImage.naturalWidth || params.sourceWidth || 1280;
  const natH = sourceImage.naturalHeight || params.sourceHeight || 720;
  const { width, height } = getScaledDimensions(
    natW,
    natH,
    params.resolution,
    params.aspectRatio ?? 'original'
  );

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Export canvas unavailable.');
  }

  let bgSegmenter: ImageSegmenter | null = null;
  let bgCustomImage: HTMLImageElement | null = null;
  let chromaCustomImage: HTMLImageElement | null = null;
  let bgScratchCanvas: HTMLCanvasElement | null = null;

  if (params.chromaKey?.enabled) {
    bgScratchCanvas = document.createElement('canvas');
    bgScratchCanvas.width = width;
    bgScratchCanvas.height = height;
    if (params.chromaKey.bgMode === 'image' && params.chromaKey.bgImageUrl) {
      chromaCustomImage = await loadImageElement(params.chromaKey.bgImageUrl);
    }
  } else if (params.bgRemoval && params.bgRemoval.mode !== 'off') {
    bgSegmenter = await getBgSegmenter();
    if (params.bgRemoval.mode === 'image' && params.bgRemoval.bgImageUrl) {
      bgCustomImage = await loadImageElement(params.bgRemoval.bgImageUrl);
    }
    bgScratchCanvas = document.createElement('canvas');
    bgScratchCanvas.width = width;
    bgScratchCanvas.height = height;
  }

  const maskWorkCanvas =
    params.mask && params.mask.shape !== 'none' ? document.createElement('canvas') : null;
  const maskAlphaCanvas =
    params.mask && params.mask.shape !== 'none' ? document.createElement('canvas') : null;

  const preparedOverlays: PreparedOverlayVisual[] = [];
  for (const layer of params.overlayLayers ?? []) {
    if (layer.kind === 'image') {
      const imageEl = await loadImageElement(layer.url);
      if (imageEl) {
        preparedOverlays.push({ layer, imageEl });
      }
    }
  }

  const cssFilter = buildCssFilter(params.adjustments ?? DEFAULT_ADJUSTMENTS);
  drawExportFrame(
    ctx,
    sourceImage,
    width,
    height,
    cssFilter,
    params.frameFit ?? 'contain',
    params.textOverlays ?? [],
    params.previewTime ?? 0,
    {
      mainKeyframes: params.mainKeyframes,
      motionTracks: params.motionTracks,
      overlays: preparedOverlays,
      bgRemoval: params.bgRemoval,
      bgSegmenter,
      bgScratchCanvas,
      bgCustomImage,
      chromaKey: params.chromaKey,
      chromaCustomImage,
      stabilization: params.stabilization,
      mask: params.mask,
      maskWorkCanvas,
      maskAlphaCanvas,
      videoEffects: params.videoEffects,
      effectsPool: new EffectsRenderPool(),
    }
  );

  const pngBlob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => {
      if (b) resolve(b);
      else reject(new Error('Could not encode PNG image.'));
    }, 'image/png');
  });

  const blobUrl = URL.createObjectURL(pngBlob);
  return {
    blob: pngBlob,
    blobUrl,
    mimeType: 'image/png',
    extension: 'png',
  };
}

