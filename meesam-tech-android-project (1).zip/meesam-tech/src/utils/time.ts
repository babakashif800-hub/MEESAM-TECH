import { TimelineSegment } from '../types/editor';
import {
  getCurveSegmentEditedDuration,
  getSegmentAverageSpeed,
  integrateSegmentSourceToEdited,
} from './speedCurve';

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/**
 * Formats seconds into MM:SS.d (e.g. 01:04.2) with fixed width for tabular-nums.
 */
export function formatTimecode(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00.0';
  const totalTenths = Math.floor(seconds * 10 + 0.0001);
  const tenths = totalTenths % 10;
  const totalSeconds = Math.floor(totalTenths / 10);
  const secs = totalSeconds % 60;
  const mins = Math.floor(totalSeconds / 60);

  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  return `${mm}:${ss}.${tenths}`;
}

export function formatDurationShort(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '0.0s';
  if (seconds < 60) {
    return `${seconds.toFixed(1)}s`;
  }
  const mins = Math.floor(seconds / 60);
  const secs = (seconds % 60).toFixed(0).padStart(2, '0');
  return `${mins}m ${secs}s`;
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes < 1024 * 1024) {
    return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function getSegmentSpeed(seg: TimelineSegment): number {
  const s = seg.meta?.speed ?? 1;
  return Number.isFinite(s) && s > 0 ? s : 1;
}

export function getSegmentEditedDuration(seg: TimelineSegment): number {
  if (seg.meta?.speedCurve && seg.meta.speedCurve.length >= 2) {
    return getCurveSegmentEditedDuration(seg);
  }
  return (seg.end - seg.start) / getSegmentSpeed(seg);
}

export function getSegmentDisplaySpeed(seg: TimelineSegment): number {
  if (seg.meta?.speedCurve && seg.meta.speedCurve.length >= 2) {
    return getSegmentAverageSpeed(seg);
  }
  return getSegmentSpeed(seg);
}

export function getActiveSegments(segments: TimelineSegment[]): TimelineSegment[] {
  return segments.filter((seg) => !seg.deleted && seg.end - seg.start > 0.05);
}

export function getEditedDuration(segments: TimelineSegment[]): number {
  return getActiveSegments(segments).reduce(
    (acc, seg) => acc + getSegmentEditedDuration(seg),
    0
  );
}

export function sourceTimeToEditedTime(sourceTime: number, segments: TimelineSegment[]): number {
  const active = getActiveSegments(segments);
  let elapsed = 0;
  for (const seg of active) {
    if (sourceTime <= seg.start) {
      return elapsed;
    }
    if (sourceTime >= seg.start && sourceTime <= seg.end) {
      return elapsed + integrateSegmentSourceToEdited(seg, sourceTime - seg.start);
    }
    elapsed += getSegmentEditedDuration(seg);
  }
  return elapsed;
}

export function findSegmentAtTime(
  time: number,
  segments: TimelineSegment[]
): TimelineSegment | undefined {
  return segments.find((seg) => time >= seg.start - 0.001 && time <= seg.end + 0.001);
}
