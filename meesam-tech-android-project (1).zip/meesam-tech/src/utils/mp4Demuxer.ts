export interface DemuxedVideoSample {
  offset: number;
  size: number;
  isKey: boolean;
  dtsSec: number;
  ptsSec: number;
  durationSec: number;
}

export interface DemuxedMp4VideoTrack {
  codec: string;
  codedWidth: number;
  codedHeight: number;
  displayRotation: 0 | 90 | 180 | 270;
  timescale: number;
  durationSec: number;
  fps: number;
  description?: Uint8Array;
  samples: DemuxedVideoSample[];
}

interface Mp4Box {
  type: string;
  start: number;
  headerSize: number;
  end: number;
}

function readAscii(view: DataView, offset: number, length: number): string {
  let out = '';
  for (let i = 0; i < length; i++) {
    out += String.fromCharCode(view.getUint8(offset + i));
  }
  return out;
}

function readU64(view: DataView, offset: number): number {
  const hi = view.getUint32(offset, false);
  const lo = view.getUint32(offset + 4, false);
  return hi * 4294967296 + lo;
}

function readI64(view: DataView, offset: number): number {
  const hi = view.getInt32(offset, false);
  const lo = view.getUint32(offset + 4, false);
  return hi * 4294967296 + lo;
}

function iterBoxes(view: DataView, start: number, end: number): Mp4Box[] {
  const boxes: Mp4Box[] = [];
  let pos = start;
  while (pos + 8 <= end) {
    const rawSize = view.getUint32(pos, false);
    const type = readAscii(view, pos + 4, 4);
    let headerSize = 8;
    let boxSize = rawSize;
    if (rawSize === 1) {
      if (pos + 16 > end) break;
      boxSize = readU64(view, pos + 8);
      headerSize = 16;
    } else if (rawSize === 0) {
      boxSize = end - pos;
    }
    if (!Number.isFinite(boxSize) || boxSize < headerSize) break;
    const boxEnd = Math.min(end, pos + boxSize);
    boxes.push({ type, start: pos, headerSize, end: boxEnd });
    if (boxEnd <= pos) break;
    pos = boxEnd;
  }
  return boxes;
}

function findChildBox(
  view: DataView,
  parent: Mp4Box,
  type: string
): Mp4Box | null {
  const children = iterBoxes(view, parent.start + parent.headerSize, parent.end);
  return children.find((b) => b.type === type) ?? null;
}

function findChildBoxes(
  view: DataView,
  parent: Mp4Box,
  type: string
): Mp4Box[] {
  const children = iterBoxes(view, parent.start + parent.headerSize, parent.end);
  return children.filter((b) => b.type === type);
}

function toHex2(n: number): string {
  return n.toString(16).padStart(2, '0');
}

function snapStandardFps(rawFps: number): number {
  if (!Number.isFinite(rawFps) || rawFps <= 0) return 30;
  const standardRates = [
    24000 / 1001,
    24,
    25,
    30000 / 1001,
    30,
    48,
    50,
    60000 / 1001,
    60,
    120,
  ];
  let bestRate: number | null = null;
  let bestDiff = 0.00035;
  for (const rate of standardRates) {
    const relDiff = Math.abs(rawFps - rate) / rate;
    if (relDiff < bestDiff) {
      bestDiff = relDiff;
      bestRate = rate;
    }
  }
  if (bestRate !== null) return bestRate;
  return Math.max(1, Math.min(240, Math.round(rawFps * 1000) / 1000));
}

function parseTkhdRotation(view: DataView, tkhdBox: Mp4Box): 0 | 90 | 180 | 270 {
  const payload = tkhdBox.start + tkhdBox.headerSize;
  if (payload + 4 > tkhdBox.end) return 0;
  const version = view.getUint8(payload);
  const matrixOffset = payload + (version === 1 ? 52 : 40);
  if (matrixOffset + 20 > tkhdBox.end) return 0;

  const a = view.getInt32(matrixOffset, false) / 65536;
  const b = view.getInt32(matrixOffset + 4, false) / 65536;
  const deg = ((Math.round((Math.atan2(b, a) * 180) / Math.PI) % 360) + 360) % 360;
  if (deg === 90) return 90;
  if (deg === 180) return 180;
  if (deg === 270) return 270;
  return 0;
}

function reverseBits32(v: number): number {
  let r = 0;
  for (let i = 0; i < 32; i++) {
    r = (r << 1) | ((v >>> i) & 1);
  }
  return r >>> 0;
}

function buildHevcCodecString(
  boxType: string,
  hvcC: Uint8Array
): string {
  if (hvcC.byteLength < 13) return `${boxType}.1.6.L93.B0`;
  const b1 = hvcC[1];
  const space = (b1 >> 6) & 0x03;
  const spaceStr = space === 1 ? 'A' : space === 2 ? 'B' : space === 3 ? 'C' : '';
  const tier = (b1 >> 5) & 0x01 ? 'H' : 'L';
  const profileIdc = b1 & 0x1f;
  const compatRaw =
    ((hvcC[2] << 24) | (hvcC[3] << 16) | (hvcC[4] << 8) | hvcC[5]) >>> 0;
  const compatHex = reverseBits32(compatRaw).toString(16);
  const levelIdc = hvcC[12];
  const constraints: number[] = [];
  for (let i = 6; i < 12; i++) constraints.push(hvcC[i]);
  while (constraints.length > 1 && constraints[constraints.length - 1] === 0) {
    constraints.pop();
  }
  const constraintPart = constraints.map((c) => c.toString(16)).join('.');
  return `${boxType}.${spaceStr}${profileIdc}.${compatHex}.${tier}${levelIdc}.${constraintPart}`;
}

function parseStsdVideo(
  bytes: Uint8Array,
  view: DataView,
  stsdBox: Mp4Box
): {
  codec: string;
  codedWidth: number;
  codedHeight: number;
  description?: Uint8Array;
} | null {
  const payload = stsdBox.start + stsdBox.headerSize;
  if (payload + 8 > stsdBox.end) return null;
  const entryCount = view.getUint32(payload + 4, false);
  if (entryCount < 1) return null;

  const entries = iterBoxes(view, payload + 8, stsdBox.end);
  const entry = entries[0];
  if (!entry) return null;

  const entryPayload = entry.start + entry.headerSize;
  // VideoSampleEntry fixed body after 8-byte header is 78 bytes
  if (entryPayload + 78 > entry.end) return null;
  const codedWidth = view.getUint16(entryPayload + 24, false);
  const codedHeight = view.getUint16(entryPayload + 26, false);
  if (codedWidth <= 0 || codedHeight <= 0) return null;

  const childBoxes = iterBoxes(view, entryPayload + 78, entry.end);
  const findConfig = (name: string) => {
    const b = childBoxes.find((c) => c.type === name);
    if (!b) return undefined;
    return bytes.slice(b.start + b.headerSize, b.end);
  };

  if (entry.type === 'avc1' || entry.type === 'avc3') {
    const avcC = findConfig('avcC');
    if (!avcC || avcC.byteLength < 4) return null;
    const codec = `${entry.type}.${toHex2(avcC[1])}${toHex2(avcC[2])}${toHex2(avcC[3])}`;
    return { codec, codedWidth, codedHeight, description: avcC };
  }

  if (entry.type === 'hvc1' || entry.type === 'hev1') {
    const hvcC = findConfig('hvcC');
    if (!hvcC || hvcC.byteLength < 13) return null;
    const codec = buildHevcCodecString(entry.type, hvcC);
    return { codec, codedWidth, codedHeight, description: hvcC };
  }

  if (entry.type === 'vp09') {
    const vpcC = findConfig('vpcC');
    if (!vpcC || vpcC.byteLength < 8) {
      return { codec: 'vp09.00.41.08', codedWidth, codedHeight };
    }
    // vpcC is a FullBox (4-byte version/flags + profile, level, bitDepth/chroma/fullRange)
    const profile = toHex2(vpcC[4] ?? 0);
    const level = toHex2(vpcC[5] ?? 41);
    const bitDepth = toHex2(((vpcC[6] ?? 0x80) >> 4) & 0x0f || 8);
    return { codec: `vp09.${profile}.${level}.${bitDepth}`, codedWidth, codedHeight };
  }

  if (entry.type === 'av01') {
    const av1C = findConfig('av1C');
    if (!av1C || av1C.byteLength < 4) {
      return { codec: 'av01.0.08M.08', codedWidth, codedHeight };
    }
    const seqProfile = (av1C[1] >> 5) & 0x07;
    const seqLevelIdx0 = av1C[1] & 0x1f;
    const seqTier0 = (av1C[2] >> 7) & 0x01 ? 'H' : 'M';
    const highBitDepth = (av1C[2] >> 6) & 0x01;
    const twelveBit = (av1C[2] >> 5) & 0x01;
    const bitDepth = highBitDepth ? (twelveBit ? '12' : '10') : '08';
    return {
      codec: `av01.${seqProfile}.${String(seqLevelIdx0).padStart(2, '0')}${seqTier0}.${bitDepth}`,
      codedWidth,
      codedHeight,
    };
  }

  return null;
}

/**
 * Parses an ISO-BMFF MP4/MOV buffer in pure TypeScript to extract the video track's
 * exact sample table, native FPS, display rotation, and WebCodecs DecoderConfig metadata.
 * Returns null for non-MP4 files, fragmented MP4s without stsz samples, or unsupported layouts.
 */
export function parseMp4VideoTrack(buffer: ArrayBuffer): DemuxedMp4VideoTrack | null {
  if (!buffer || buffer.byteLength < 16) return null;
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);

  const rootBoxes = iterBoxes(view, 0, buffer.byteLength);
  const hasIsoBrand = rootBoxes.some(
    (b) => b.type === 'ftyp' || b.type === 'moov'
  );
  if (!hasIsoBrand) return null;

  const moovBox = rootBoxes.find((b) => b.type === 'moov');
  if (!moovBox) return null;

  const traks = findChildBoxes(view, moovBox, 'trak');
  for (const trakBox of traks) {
    const mdiaBox = findChildBox(view, trakBox, 'mdia');
    if (!mdiaBox) continue;

    const hdlrBox = findChildBox(view, mdiaBox, 'hdlr');
    if (!hdlrBox) continue;
    const hdlrPayload = hdlrBox.start + hdlrBox.headerSize;
    if (hdlrPayload + 12 > hdlrBox.end) continue;
    const handlerSubtype = readAscii(view, hdlrPayload + 8, 4);
    if (handlerSubtype !== 'vide') continue;

    const mdhdBox = findChildBox(view, mdiaBox, 'mdhd');
    if (!mdhdBox) continue;
    const mdhdPayload = mdhdBox.start + mdhdBox.headerSize;
    if (mdhdPayload + 20 > mdhdBox.end) continue;
    const mdhdVersion = view.getUint8(mdhdPayload);
    const timescale =
      mdhdVersion === 1
        ? view.getUint32(mdhdPayload + 20, false)
        : view.getUint32(mdhdPayload + 12, false);
    if (!timescale || timescale <= 0) continue;

    const tkhdBox = findChildBox(view, trakBox, 'tkhd');
    const displayRotation = tkhdBox ? parseTkhdRotation(view, tkhdBox) : 0;

    // Inspect optional edit list (elst) for simple start offset vs complex multi-edit clips
    let elstMediaTimeTicks: number | null = null;
    const edtsBox = findChildBox(view, trakBox, 'edts');
    if (edtsBox) {
      const elstBox = findChildBox(view, edtsBox, 'elst');
      if (elstBox) {
        const elstPayload = elstBox.start + elstBox.headerSize;
        if (elstPayload + 8 <= elstBox.end) {
          const elstVer = view.getUint8(elstPayload);
          const elstCount = view.getUint32(elstPayload + 4, false);
          if (elstCount > 1) {
            // Complex multi-segment edit list: defer to HTMLVideoElement stepper
            return null;
          }
          if (elstCount === 1) {
            const entryOff = elstPayload + 8;
            if (elstVer === 1 && entryOff + 20 <= elstBox.end) {
              const mt = readI64(view, entryOff + 8);
              if (mt < 0) return null;
              elstMediaTimeTicks = mt;
            } else if (elstVer === 0 && entryOff + 12 <= elstBox.end) {
              const mt = view.getInt32(entryOff + 4, false);
              if (mt < 0) return null;
              elstMediaTimeTicks = mt;
            }
          }
        }
      }
    }

    const minfBox = findChildBox(view, mdiaBox, 'minf');
    const stblBox = minfBox ? findChildBox(view, minfBox, 'stbl') : null;
    if (!stblBox) continue;

    const stsdBox = findChildBox(view, stblBox, 'stsd');
    const sttsBox = findChildBox(view, stblBox, 'stts');
    const stszBox = findChildBox(view, stblBox, 'stsz');
    const stscBox = findChildBox(view, stblBox, 'stsc');
    const stcoBox = findChildBox(view, stblBox, 'stco');
    const co64Box = findChildBox(view, stblBox, 'co64');
    if (!stsdBox || !sttsBox || !stszBox || !stscBox || (!stcoBox && !co64Box)) {
      continue;
    }

    const videoInfo = parseStsdVideo(bytes, view, stsdBox);
    if (!videoInfo) return null;

    // Parse stsz (sample sizes)
    const stszPayload = stszBox.start + stszBox.headerSize;
    if (stszPayload + 12 > stszBox.end) return null;
    const constantSampleSize = view.getUint32(stszPayload + 4, false);
    const sampleCount = view.getUint32(stszPayload + 8, false);
    if (sampleCount === 0) return null;

    const sampleSizes = new Uint32Array(sampleCount);
    if (constantSampleSize > 0) {
      sampleSizes.fill(constantSampleSize);
    } else {
      if (stszPayload + 12 + sampleCount * 4 > stszBox.end) return null;
      for (let i = 0; i < sampleCount; i++) {
        sampleSizes[i] = view.getUint32(stszPayload + 12 + i * 4, false);
      }
    }

    // Parse stco / co64 (chunk offsets)
    const chunkOffsets: number[] = [];
    if (stcoBox) {
      const p = stcoBox.start + stcoBox.headerSize;
      const count = view.getUint32(p + 4, false);
      for (let i = 0; i < count && p + 8 + i * 4 + 4 <= stcoBox.end; i++) {
        chunkOffsets.push(view.getUint32(p + 8 + i * 4, false));
      }
    } else if (co64Box) {
      const p = co64Box.start + co64Box.headerSize;
      const count = view.getUint32(p + 4, false);
      for (let i = 0; i < count && p + 8 + i * 8 + 8 <= co64Box.end; i++) {
        chunkOffsets.push(readU64(view, p + 8 + i * 8));
      }
    }
    if (chunkOffsets.length === 0) return null;

    // Parse stsc (sample-to-chunk)
    const stscPayload = stscBox.start + stscBox.headerSize;
    const stscCount = view.getUint32(stscPayload + 4, false);
    const stscEntries: Array<{ firstChunk: number; samplesPerChunk: number }> = [];
    for (
      let i = 0;
      i < stscCount && stscPayload + 8 + i * 12 + 12 <= stscBox.end;
      i++
    ) {
      stscEntries.push({
        firstChunk: view.getUint32(stscPayload + 8 + i * 12, false),
        samplesPerChunk: view.getUint32(stscPayload + 8 + i * 12 + 4, false),
      });
    }
    if (stscEntries.length === 0) return null;

    // Parse stts (decoding time-to-sample)
    const sttsPayload = sttsBox.start + sttsBox.headerSize;
    const sttsCount = view.getUint32(sttsPayload + 4, false);
    const sttsDurations = new Uint32Array(sampleCount);
    const dtsTicksArr = new Float64Array(sampleCount);
    let sampleCursor = 0;
    let dtsCursor = 0;
    for (
      let i = 0;
      i < sttsCount && sttsPayload + 8 + i * 8 + 8 <= sttsBox.end;
      i++
    ) {
      const count = view.getUint32(sttsPayload + 8 + i * 8, false);
      const delta = view.getUint32(sttsPayload + 8 + i * 8 + 4, false);
      for (let k = 0; k < count && sampleCursor < sampleCount; k++) {
        sttsDurations[sampleCursor] = delta;
        dtsTicksArr[sampleCursor] = dtsCursor;
        dtsCursor += delta;
        sampleCursor += 1;
      }
    }
    if (sampleCursor === 0) return null;

    // Parse optional ctts (composition time offset)
    const cttsOffsets = new Int32Array(sampleCount);
    const cttsBox = findChildBox(view, stblBox, 'ctts');
    if (cttsBox) {
      const p = cttsBox.start + cttsBox.headerSize;
      const cttsVer = view.getUint8(p);
      const count = view.getUint32(p + 4, false);
      let idx = 0;
      for (let i = 0; i < count && p + 8 + i * 8 + 8 <= cttsBox.end; i++) {
        const sc = view.getUint32(p + 8 + i * 8, false);
        const offsetVal =
          cttsVer === 1
            ? view.getInt32(p + 8 + i * 8 + 4, false)
            : view.getUint32(p + 8 + i * 8 + 4, false);
        for (let k = 0; k < sc && idx < sampleCount; k++) {
          cttsOffsets[idx] = offsetVal;
          idx += 1;
        }
      }
    }

    // Parse optional stss (sync/keyframe samples; if missing, all samples are keyframes)
    let keySampleSet: Set<number> | null = null;
    const stssBox = findChildBox(view, stblBox, 'stss');
    if (stssBox) {
      const p = stssBox.start + stssBox.headerSize;
      const count = view.getUint32(p + 4, false);
      keySampleSet = new Set<number>();
      for (let i = 0; i < count && p + 8 + i * 4 + 4 <= stssBox.end; i++) {
        keySampleSet.add(view.getUint32(p + 8 + i * 4, false) - 1);
      }
    }

    // Compute per-sample byte offsets from stsc + chunkOffsets + sampleSizes
    const sampleOffsets = new Float64Array(sampleCount);
    let sIdx = 0;
    let stscIdx = 0;
    for (let chunkIdx = 0; chunkIdx < chunkOffsets.length && sIdx < sampleCount; chunkIdx++) {
      const oneBasedChunk = chunkIdx + 1;
      while (
        stscIdx + 1 < stscEntries.length &&
        oneBasedChunk >= stscEntries[stscIdx + 1].firstChunk
      ) {
        stscIdx += 1;
      }
      const spc = stscEntries[stscIdx].samplesPerChunk;
      let bytePos = chunkOffsets[chunkIdx];
      for (let k = 0; k < spc && sIdx < sampleCount; k++) {
        sampleOffsets[sIdx] = bytePos;
        bytePos += sampleSizes[sIdx];
        sIdx += 1;
      }
    }
    if (sIdx < sampleCount) return null;

    // Normalize PTS baseline so presentation timestamps start cleanly at 0.000s
    let minPtsTicks = Infinity;
    for (let i = 0; i < sampleCount; i++) {
      const pts = dtsTicksArr[i] + cttsOffsets[i];
      if (pts < minPtsTicks) minPtsTicks = pts;
    }
    const basePtsTicks =
      elstMediaTimeTicks !== null && elstMediaTimeTicks >= minPtsTicks
        ? elstMediaTimeTicks
        : Number.isFinite(minPtsTicks)
        ? minPtsTicks
        : 0;

    const samples: DemuxedVideoSample[] = new Array(sampleCount);
    for (let i = 0; i < sampleCount; i++) {
      const ptsTicks = dtsTicksArr[i] + cttsOffsets[i] - basePtsTicks;
      const durTicks = Math.max(1, sttsDurations[i]);
      if (sampleOffsets[i] + sampleSizes[i] > buffer.byteLength) {
        return null;
      }
      samples[i] = {
        offset: sampleOffsets[i],
        size: sampleSizes[i],
        isKey: keySampleSet ? keySampleSet.has(i) : true,
        dtsSec: dtsTicksArr[i] / timescale,
        ptsSec: Math.max(0, ptsTicks / timescale),
        durationSec: durTicks / timescale,
      };
    }

    const totalDurSec = dtsCursor > 0 ? dtsCursor / timescale : sampleCount / 30;
    const fps = snapStandardFps(sampleCount / Math.max(0.001, totalDurSec));

    return {
      codec: videoInfo.codec,
      codedWidth: videoInfo.codedWidth,
      codedHeight: videoInfo.codedHeight,
      displayRotation,
      timescale,
      durationSec: totalDurSec,
      fps,
      description: videoInfo.description,
      samples,
    };
  }

  return null;
}
