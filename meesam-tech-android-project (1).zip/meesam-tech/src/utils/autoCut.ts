import { AiAutoCutRange, TimelineSegment } from '../types/editor';

export interface ActivityWindow {
  startTime: number;
  endTime: number;
  score: number; // 0..1 combined visual motion + audio RMS energy
}

/**
 * Computes per-second visual change + audio energy scores locally in the browser
 * so AI Auto Cut can identify silent gaps vs high-action highlights accurately.
 */
export async function analyzeClipActivityWindows(
  videoUrl: string,
  duration: number
): Promise<ActivityWindow[]> {
  if (!Number.isFinite(duration) || duration <= 0.4) return [];

  const stepSec = duration > 25 ? 1.0 : 0.5;
  const windowCount = Math.max(2, Math.min(80, Math.floor(duration / stepSec)));
  const visualDiffs = new Float32Array(windowCount);
  const audioRms = new Float32Array(windowCount);

  // 1. Sample compact video frames for visual motion/scene change
  const video = document.createElement('video');
  video.src = videoUrl;
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error('timeout')), 7000);
      video.onloadeddata = () => {
        window.clearTimeout(timer);
        resolve();
      };
      video.onerror = () => {
        window.clearTimeout(timer);
        reject(new Error('error'));
      };
    });

    const fw = 64;
    const fh = 36;
    const canvas = document.createElement('canvas');
    canvas.width = fw;
    canvas.height = fh;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    let prevData: Uint8ClampedArray | null = null;
    for (let i = 0; i < windowCount; i++) {
      const t = Math.min(Math.max(0, duration - 0.03), (i + 0.5) * stepSec);
      await new Promise<void>((resolve) => {
        if (Math.abs(video.currentTime - t) < 0.01) {
          resolve();
          return;
        }
        video.addEventListener('seeked', () => resolve(), { once: true });
        video.currentTime = t;
      });
      if (ctx) {
        ctx.drawImage(video, 0, 0, fw, fh);
        const cur = ctx.getImageData(0, 0, fw, fh).data;
        if (prevData) {
          let sum = 0;
          for (let p = 0; p < cur.length; p += 16) {
            sum +=
              Math.abs(cur[p] - prevData[p]) +
              Math.abs(cur[p + 1] - prevData[p + 1]) +
              Math.abs(cur[p + 2] - prevData[p + 2]);
          }
          visualDiffs[i] = sum / (cur.length / 16) / 255;
        }
        prevData = new Uint8ClampedArray(cur);
      }
    }
  } catch {
    // Visual scan optional
  } finally {
    video.removeAttribute('src');
    video.load();
  }

  // 2. Sample audio RMS energy per window if audio track exists
  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (AudioContextClass) {
    const audioCtx = new AudioContextClass();
    try {
      const resp = await fetch(videoUrl);
      const buf = await resp.arrayBuffer();
      const decoded = await audioCtx.decodeAudioData(buf);
      const ch = decoded.getChannelData(0);
      const sr = decoded.sampleRate;
      for (let i = 0; i < windowCount; i++) {
        const s0 = Math.floor(i * stepSec * sr);
        const s1 = Math.min(ch.length, Math.floor((i + 1) * stepSec * sr));
        if (s1 > s0) {
          let sq = 0;
          for (let k = s0; k < s1; k += 4) {
            sq += ch[k] * ch[k];
          }
          audioRms[i] = Math.sqrt(sq / Math.max(1, (s1 - s0) / 4));
        }
      }
    } catch {
      // Video may have no audio track
    } finally {
      audioCtx.close().catch(() => {});
    }
  }

  // Normalize & combine signals
  let maxVis = 0.001;
  let maxAud = 0.001;
  for (let i = 0; i < windowCount; i++) {
    if (visualDiffs[i] > maxVis) maxVis = visualDiffs[i];
    if (audioRms[i] > maxAud) maxAud = audioRms[i];
  }

  const out: ActivityWindow[] = [];
  for (let i = 0; i < windowCount; i++) {
    const vNorm = visualDiffs[i] / maxVis;
    const aNorm = maxAud > 0.005 ? audioRms[i] / maxAud : vNorm;
    const score = Number((vNorm * 0.55 + aNorm * 0.45).toFixed(3));
    out.push({
      startTime: Number((i * stepSec).toFixed(2)),
      endTime: Number(Math.min(duration, (i + 1) * stepSec).toFixed(2)),
      score,
    });
  }
  return out;
}

/**
 * Pure algorithm that selects high-activity highlight keepRanges locally when instant Smart Trim is requested.
 */
export function selectKeepRangesFromWindows(
  windows: ActivityWindow[],
  duration: number,
  targetRatio = 0.55
): AiAutoCutRange[] {
  if (windows.length === 0 || duration <= 0.6) {
    return [{ startTime: 0, endTime: Math.max(0.5, duration), reason: 'Full clip', score: 1 }];
  }

  const sortedScores = [...windows].map((w) => w.score).sort((a, b) => a - b);
  const cutoffIdx = Math.min(
    sortedScores.length - 1,
    Math.max(0, Math.floor(sortedScores.length * (1 - targetRatio)))
  );
  const threshold = Math.max(0.18, sortedScores[cutoffIdx] * 0.92);

  const ranges: AiAutoCutRange[] = [];
  let activeStart: number | null = null;
  let scoreSum = 0;
  let scoreCnt = 0;

  for (const win of windows) {
    if (win.score >= threshold) {
      if (activeStart === null) {
        activeStart = win.startTime;
        scoreSum = win.score;
        scoreCnt = 1;
      } else {
        scoreSum += win.score;
        scoreCnt += 1;
      }
    } else if (activeStart !== null) {
      const prevEnd = win.startTime;
      if (prevEnd - activeStart >= 0.45) {
        ranges.push({
          startTime: activeStart,
          endTime: prevEnd,
          reason: 'High action / clear audio',
          score: Number((scoreSum / scoreCnt).toFixed(2)),
        });
      }
      activeStart = null;
      scoreSum = 0;
      scoreCnt = 0;
    }
  }

  if (activeStart !== null && duration - activeStart >= 0.45) {
    ranges.push({
      startTime: activeStart,
      endTime: Number(duration.toFixed(2)),
      reason: 'Closing highlight',
      score: Number((scoreSum / Math.max(1, scoreCnt)).toFixed(2)),
    });
  }

  // Merge ranges that are very close together (< 0.4s gap)
  const merged: AiAutoCutRange[] = [];
  for (const r of ranges) {
    const prev = merged[merged.length - 1];
    if (prev && r.startTime - prev.endTime <= 0.4) {
      prev.endTime = r.endTime;
    } else {
      merged.push({ ...r });
    }
  }

  if (merged.length === 0) {
    const best = [...windows].sort((a, b) => b.score - a.score)[0];
    return [
      {
        startTime: Math.max(0, best.startTime - 0.5),
        endTime: Math.min(duration, best.endTime + 1.5),
        reason: 'Peak activity highlight',
        score: best.score,
      },
    ];
  }

  return merged;
}

/**
 * Builds non-destructive timeline segments across [0 .. duration] where kept ranges remain active and filler spans are marked `deleted: true`.
 */
export function buildSegmentsFromKeepRanges(
  duration: number,
  keepRanges: AiAutoCutRange[],
  makeId: () => string
): TimelineSegment[] {
  const safeDur = Math.max(0.5, duration);
  const valid = [...keepRanges]
    .map((r) => ({
      start: Math.max(0, Math.min(safeDur - 0.3, r.startTime)),
      end: Math.max(0.3, Math.min(safeDur, r.endTime)),
    }))
    .filter((r) => r.end - r.start >= 0.3)
    .sort((a, b) => a.start - b.start);

  if (valid.length === 0) {
    return [{ id: makeId(), start: 0, end: safeDur, deleted: false }];
  }

  // Merge overlaps
  const normalized: Array<{ start: number; end: number }> = [];
  for (const r of valid) {
    const prev = normalized[normalized.length - 1];
    if (prev && r.start <= prev.end + 0.1) {
      prev.end = Math.max(prev.end, r.end);
    } else {
      normalized.push({ ...r });
    }
  }

  const out: TimelineSegment[] = [];
  let cursor = 0;

  for (const keep of normalized) {
    if (keep.start - cursor >= 0.25) {
      out.push({
        id: makeId(),
        start: Number(cursor.toFixed(3)),
        end: Number(keep.start.toFixed(3)),
        deleted: true,
      });
    }
    const segStart = out.length === 0 ? Math.min(cursor, keep.start) : keep.start;
    out.push({
      id: makeId(),
      start: Number(segStart.toFixed(3)),
      end: Number(keep.end.toFixed(3)),
      deleted: false,
    });
    cursor = keep.end;
  }

  if (safeDur - cursor >= 0.25) {
    out.push({
      id: makeId(),
      start: Number(cursor.toFixed(3)),
      end: Number(safeDur.toFixed(3)),
      deleted: true,
    });
  } else if (out.length > 0 && safeDur - cursor > 0) {
    out[out.length - 1].end = Number(safeDur.toFixed(3));
  }

  return out;
}
