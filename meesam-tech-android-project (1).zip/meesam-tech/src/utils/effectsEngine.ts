import { VideoEffectId, VideoEffectLayer } from '../types/editor';

export class EffectsRenderPool {
  private a: HTMLCanvasElement | null = null;
  private b: HTMLCanvasElement | null = null;
  private c: HTMLCanvasElement | null = null;
  private px: HTMLCanvasElement | null = null;

  private ensure(
    slot: 'a' | 'b' | 'c' | 'px',
    w: number,
    h: number
  ): HTMLCanvasElement {
    const safeW = Math.max(1, Math.round(w));
    const safeH = Math.max(1, Math.round(h));
    let canvas = this[slot];
    if (!canvas) {
      canvas = document.createElement('canvas');
      this[slot] = canvas;
    }
    if (canvas.width !== safeW) canvas.width = safeW;
    if (canvas.height !== safeH) canvas.height = safeH;
    return canvas;
  }

  getWorkA(w: number, h: number): HTMLCanvasElement {
    return this.ensure('a', w, h);
  }

  getWorkB(w: number, h: number): HTMLCanvasElement {
    return this.ensure('b', w, h);
  }

  getWorkC(w: number, h: number): HTMLCanvasElement {
    return this.ensure('c', w, h);
  }

  getPixelWork(w: number, h: number): HTMLCanvasElement {
    return this.ensure('px', w, h);
  }
}

function clampByte(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function prng(seed: number): number {
  const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
}

/**
 * Snapshot canvas into workB so effects can safely draw/blend over target canvas.
 */
function snapshotTo(
  src: HTMLCanvasElement,
  dst: HTMLCanvasElement
): CanvasRenderingContext2D | null {
  const dctx = dst.getContext('2d');
  if (!dctx) return null;
  dctx.clearRect(0, 0, dst.width, dst.height);
  dctx.drawImage(src, 0, 0, dst.width, dst.height);
  return dctx;
}

/**
 * Draws a processed pixel canvas onto target canvas with smooth intensity alpha blending.
 */
function runPixelTransform(
  targetCanvas: HTMLCanvasElement,
  targetCtx: CanvasRenderingContext2D,
  pool: EffectsRenderPool,
  intensityRatio: number,
  maxDim: number,
  transformFn: (
    srcData: Uint8ClampedArray,
    dstData: Uint8ClampedArray,
    pw: number,
    ph: number
  ) => void
): void {
  const w = targetCanvas.width;
  const h = targetCanvas.height;
  const scale = Math.min(1, maxDim / Math.max(1, Math.max(w, h)));
  const pw = Math.max(8, Math.round(w * scale));
  const ph = Math.max(8, Math.round(h * scale));

  const pxCanvas = pool.getPixelWork(pw, ph);
  const pxCtx = pxCanvas.getContext('2d', { willReadFrequently: true });
  if (!pxCtx) return;

  pxCtx.clearRect(0, 0, pw, ph);
  pxCtx.drawImage(targetCanvas, 0, 0, pw, ph);
  const imgData = pxCtx.getImageData(0, 0, pw, ph);
  const srcData = new Uint8ClampedArray(imgData.data);
  transformFn(srcData, imgData.data, pw, ph);
  pxCtx.putImageData(imgData, 0, 0);

  targetCtx.save();
  targetCtx.globalAlpha = clamp01(intensityRatio);
  targetCtx.imageSmoothingEnabled = true;
  targetCtx.drawImage(pxCanvas, 0, 0, w, h);
  targetCtx.restore();
}

/**
 * Draws a centered vignette overlay on top of targetCtx.
 */
function drawVignette(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  innerRatio: number,
  outerAlpha: number,
  tintHex = '0,0,0',
  blend: GlobalCompositeOperation = 'source-over'
): void {
  const cx = w / 2;
  const cy = h / 2;
  const maxR = Math.hypot(cx, cy);
  const grad = ctx.createRadialGradient(
    cx,
    cy,
    maxR * clamp01(innerRatio),
    cx,
    cy,
    maxR
  );
  grad.addColorStop(0, `rgba(${tintHex},0)`);
  grad.addColorStop(1, `rgba(${tintHex},${clamp01(outerAlpha)})`);
  ctx.save();
  ctx.globalCompositeOperation = blend;
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

/**
 * Draws RGB channel split horizontal/vertical offset cleanly using screen-composited color buffers.
 */
function drawChannelSplit(
  targetCanvas: HTMLCanvasElement,
  targetCtx: CanvasRenderingContext2D,
  pool: EffectsRenderPool,
  dxR: number,
  dyR: number,
  dxB: number,
  dyB: number,
  alpha: number
): void {
  const w = targetCanvas.width;
  const h = targetCanvas.height;
  const scale = Math.min(1, 560 / Math.max(1, Math.max(w, h)));
  const pw = Math.max(8, Math.round(w * scale));
  const ph = Math.max(8, Math.round(h * scale));

  const pxCanvas = pool.getPixelWork(pw, ph);
  const pxCtx = pxCanvas.getContext('2d', { willReadFrequently: true });
  const snap = pool.getWorkB(w, h);
  if (!pxCtx || !snapshotTo(targetCanvas, snap)) return;

  pxCtx.clearRect(0, 0, pw, ph);
  pxCtx.drawImage(snap, 0, 0, pw, ph);
  const base = pxCtx.getImageData(0, 0, pw, ph);
  const src = base.data;
  const out = new Uint8ClampedArray(src.length);

  const sDxR = Math.round(dxR * scale);
  const sDyR = Math.round(dyR * scale);
  const sDxB = Math.round(dxB * scale);
  const sDyB = Math.round(dyB * scale);

  for (let y = 0; y < ph; y++) {
    const ry = y + sDyR < 0 ? 0 : y + sDyR >= ph ? ph - 1 : y + sDyR;
    const by = y + sDyB < 0 ? 0 : y + sDyB >= ph ? ph - 1 : y + sDyB;
    for (let x = 0; x < pw; x++) {
      const rx = x + sDxR < 0 ? 0 : x + sDxR >= pw ? pw - 1 : x + sDxR;
      const bx = x + sDxB < 0 ? 0 : x + sDxB >= pw ? pw - 1 : x + sDxB;
      const idx = (y * pw + x) * 4;
      const rIdx = (ry * pw + rx) * 4;
      const bIdx = (by * pw + bx) * 4;
      out[idx] = src[rIdx];
      out[idx + 1] = src[idx + 1];
      out[idx + 2] = src[bIdx + 2];
      out[idx + 3] = src[idx + 3];
    }
  }
  base.data.set(out);
  pxCtx.putImageData(base, 0, 0);

  targetCtx.save();
  targetCtx.globalAlpha = clamp01(alpha);
  targetCtx.imageSmoothingEnabled = true;
  targetCtx.drawImage(pxCanvas, 0, 0, w, h);
  targetCtx.restore();
}

/**
 * Draws trapezoidal 3D perspective slant by slicing horizontally or vertically via drawImage.
 */
function draw3DPerspective(
  targetCanvas: HTMLCanvasElement,
  targetCtx: CanvasRenderingContext2D,
  pool: EffectsRenderPool,
  tiltX: number, // -0.35..0.35 (left/right closer)
  tiltY: number, // -0.25..0.25 (top/bottom pitch)
  scaleFactor: number,
  bgFill = '#05070c',
  withShadow = true
): void {
  const w = targetCanvas.width;
  const h = targetCanvas.height;
  const snap = pool.getWorkB(w, h);
  if (!snapshotTo(targetCanvas, snap)) return;

  targetCtx.save();
  targetCtx.fillStyle = bgFill;
  targetCtx.fillRect(0, 0, w, h);

  const strips = Math.min(96, Math.max(36, Math.round(w / 10)));
  const sw = w / strips;
  const cw = (w * scaleFactor) / strips;
  const startX = (w - w * scaleFactor) / 2;

  if (withShadow) {
    targetCtx.fillStyle = 'rgba(0,0,0,0.48)';
    targetCtx.fillRect(
      startX + w * 0.02,
      h * (1 - scaleFactor) * 0.5 + h * 0.03,
      w * scaleFactor,
      h * scaleFactor
    );
  }

  for (let i = 0; i < strips; i++) {
    const u = strips > 1 ? i / (strips - 1) - 0.5 : 0; // -0.5..0.5
    const persp = 1 + u * tiltX * 1.4;
    const stripH = Math.max(4, h * scaleFactor * persp);
    const dy = (h - stripH) / 2 + u * h * tiltY * 0.4;
    const dx = startX + i * cw;

    targetCtx.drawImage(snap, i * sw, 0, sw + 0.6, h, dx, dy, cw + 0.8, stripH);

    // Subtle 3D shading across angled surface
    if (Math.abs(tiltX) > 0.02) {
      const shade = u * tiltX * 0.65;
      if (shade < 0) {
        targetCtx.fillStyle = `rgba(0,0,0,${Math.min(0.42, -shade)})`;
        targetCtx.fillRect(dx, dy, cw + 0.8, stripH);
      } else if (shade > 0) {
        targetCtx.fillStyle = `rgba(255,255,255,${Math.min(0.16, shade * 0.4)})`;
        targetCtx.fillRect(dx, dy, cw + 0.8, stripH);
      }
    }
  }
  targetCtx.restore();
}

/**
 * Smooth bilinear pixel sampler for distortion-free 3D lenses, waves, and shockwaves.
 */
function sampleBilinearRGB(
  src: Uint8ClampedArray,
  pw: number,
  ph: number,
  fx: number,
  fy: number,
  dst: Uint8ClampedArray,
  dIdx: number
): void {
  const cx = fx < 0 ? 0 : fx > pw - 1 ? pw - 1 : fx;
  const cy = fy < 0 ? 0 : fy > ph - 1 ? ph - 1 : fy;
  const x0 = Math.floor(cx);
  const y0 = Math.floor(cy);
  const x1 = x0 + 1 < pw ? x0 + 1 : pw - 1;
  const y1 = y0 + 1 < ph ? y0 + 1 : ph - 1;
  const wx = cx - x0;
  const wy = cy - y0;
  const w00 = (1 - wx) * (1 - wy);
  const w10 = wx * (1 - wy);
  const w01 = (1 - wx) * wy;
  const w11 = wx * wy;
  const i00 = (y0 * pw + x0) * 4;
  const i10 = (y0 * pw + x1) * 4;
  const i01 = (y1 * pw + x0) * 4;
  const i11 = (y1 * pw + x1) * 4;
  dst[dIdx] = clampByte(src[i00] * w00 + src[i10] * w10 + src[i01] * w01 + src[i11] * w11);
  dst[dIdx + 1] = clampByte(
    src[i00 + 1] * w00 + src[i10 + 1] * w10 + src[i01 + 1] * w01 + src[i11 + 1] * w11
  );
  dst[dIdx + 2] = clampByte(
    src[i00 + 2] * w00 + src[i10 + 2] * w10 + src[i01 + 2] * w01 + src[i11 + 2] * w11
  );
}

/**
 * Extracts bright specular highlights above `threshold` (0..255) into a blurred glow canvas
 * for authentic cinema halation, optical bloom, and cyber neon glow without muddying shadows.
 */
function renderHighlightGlowCanvas(
  snapCanvas: HTMLCanvasElement,
  pool: EffectsRenderPool,
  blurPx: number,
  threshold: number,
  tint: [number, number, number] = [1, 1, 1]
): HTMLCanvasElement | null {
  const w = snapCanvas.width;
  const h = snapCanvas.height;
  const scale = Math.min(1, 320 / Math.max(1, Math.max(w, h)));
  const pw = Math.max(8, Math.round(w * scale));
  const ph = Math.max(8, Math.round(h * scale));

  const pxCanvas = pool.getPixelWork(pw, ph);
  const pctx = pxCanvas.getContext('2d', { willReadFrequently: true });
  if (!pctx) return null;

  pctx.clearRect(0, 0, pw, ph);
  pctx.drawImage(snapCanvas, 0, 0, pw, ph);
  const imgData = pctx.getImageData(0, 0, pw, ph);
  const d = imgData.data;
  const invSpan = 1 / Math.max(12, 255 - threshold);

  for (let i = 0; i < d.length; i += 4) {
    const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    if (lum <= threshold) {
      d[i] = 0;
      d[i + 1] = 0;
      d[i + 2] = 0;
    } else {
      const k = clamp01((lum - threshold) * invSpan);
      const gain = k * (1 + k * 0.45);
      d[i] = clampByte(d[i] * gain * tint[0]);
      d[i + 1] = clampByte(d[i + 1] * gain * tint[1]);
      d[i + 2] = clampByte(d[i + 2] * gain * tint[2]);
    }
  }
  pctx.putImageData(imgData, 0, 0);

  const glowCanvas = pool.getWorkC(w, h);
  const gctx = glowCanvas.getContext('2d');
  if (!gctx) return null;
  gctx.clearRect(0, 0, w, h);
  gctx.filter = `blur(${Math.max(1, blurPx).toFixed(1)}px)`;
  gctx.drawImage(pxCanvas, 0, 0, w, h);
  gctx.filter = 'none';
  return glowCanvas;
}

/**
 * Edge-preserving skin-tone surface smoothing so beauty mode smooths skin texture
 * while keeping eyes, hair, eyelashes, and sharp details intact.
 */
function applySelectiveSkinSmooth(
  targetCanvas: HTMLCanvasElement,
  targetCtx: CanvasRenderingContext2D,
  pool: EffectsRenderPool,
  ratio: number,
  spNorm: number,
  maxPixelDim: number,
  softBrightness = 1.04,
  matteMix = 0
): void {
  const w = targetCanvas.width;
  const h = targetCanvas.height;
  const snap = pool.getWorkB(w, h);
  if (!snapshotTo(targetCanvas, snap)) return;

  const blurPx = Math.max(2, Math.min(w, h) * (0.01 + spNorm * 0.015));
  const softCanvas = pool.getWorkC(w, h);
  const sctx = softCanvas.getContext('2d');
  if (!sctx) return;
  sctx.clearRect(0, 0, w, h);
  sctx.filter = `blur(${blurPx.toFixed(1)}px) brightness(${softBrightness.toFixed(2)})`;
  sctx.drawImage(snap, -blurPx, -blurPx, w + blurPx * 2, h + blurPx * 2);
  sctx.filter = 'none';

  const scale = Math.min(1, maxPixelDim / Math.max(1, Math.max(w, h)));
  const pw = Math.max(8, Math.round(w * scale));
  const ph = Math.max(8, Math.round(h * scale));

  const pxSharp = pool.getPixelWork(pw, ph);
  const pctx = pxSharp.getContext('2d', { willReadFrequently: true });
  if (!pctx) return;

  pctx.clearRect(0, 0, pw, ph);
  pctx.drawImage(softCanvas, 0, 0, pw, ph);
  const softData = new Uint8ClampedArray(pctx.getImageData(0, 0, pw, ph).data);

  pctx.clearRect(0, 0, pw, ph);
  pctx.drawImage(snap, 0, 0, pw, ph);
  const sharpImg = pctx.getImageData(0, 0, pw, ph);
  const d = sharpImg.data;

  const strength = clamp01(ratio * (0.55 + spNorm * 0.45));
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i];
    const g = d[i + 1];
    const b = d[i + 2];
    const sr = softData[i];
    const sg = softData[i + 1];
    const sb = softData[i + 2];

    const lumDiff = Math.abs(r + g + b - (sr + sg + sb)) / 3;
    // Edge preservation: strong high-contrast boundaries (eyes/hair) resist smoothing
    const edgePreserve = Math.max(0.15, 1 - lumDiff / 44);
    // Warm skin-hue emphasis boosts smoothing naturally on skin tones
    const skinSignal = r > g && r > b && r - b > 12 ? 1.15 : 0.78;
    const wBlend = clamp01(strength * edgePreserve * skinSignal);

    let nr = r + (sr - r) * wBlend;
    let ng = g + (sg - g) * wBlend;
    let nb = b + (sb - b) * wBlend;
    if (matteMix > 0) {
      const m = matteMix * wBlend;
      nr = nr * (1 - m * 0.1) + 18 * m;
      ng = ng * (1 - m * 0.1) + 14 * m;
      nb = nb * (1 - m * 0.1) + 14 * m;
    }
    d[i] = clampByte(nr);
    d[i + 1] = clampByte(ng);
    d[i + 2] = clampByte(nb);
  }
  pctx.putImageData(sharpImg, 0, 0);

  targetCtx.save();
  targetCtx.imageSmoothingEnabled = true;
  targetCtx.drawImage(pxSharp, 0, 0, w, h);
  targetCtx.restore();
}

function formatCamcorderTC(timeSec: number): string {
  const safe = Math.max(0, timeSec);
  const mins = Math.floor(safe / 60);
  const secs = Math.floor(safe % 60);
  const frames = Math.floor((safe % 1) * 30);
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  const ff = String(frames).padStart(2, '0');
  return `${mm}:${ss}:${ff}`;
}

/**
 * Applies ONE video effect layer onto targetCanvas in-place.
 * Works identically for live preview, export MP4/WebM, PNG photos, and thumbnail previews.
 */
export function applySingleVideoEffect(
  targetCanvas: HTMLCanvasElement,
  effectId: VideoEffectId,
  intensityPct: number,
  speedPct: number,
  timeSec: number,
  pool: EffectsRenderPool,
  maxPixelDim = 760,
  layerProgress = 0.5
): void {
  const ratio = clamp01(intensityPct / 100);
  if (ratio <= 0.005) return;

  const ctx = targetCanvas.getContext('2d');
  if (!ctx) return;

  const w = targetCanvas.width;
  const h = targetCanvas.height;
  const minEdge = Math.max(1, Math.min(w, h));
  const spd = 0.25 + clamp01(speedPct / 100) * 2.0; // 0.25..2.25
  const spNorm = clamp01(speedPct / 100);
  const t = timeSec * spd;
  const prog = clamp01(layerProgress);

  switch (effectId) {
    // =========================================================================
    // 1. CINEMATIC (12)
    // =========================================================================
    case 'cin_letterbox_239': {
      const barFrac = (0.08 + spNorm * 0.1) * ratio;
      const barH = Math.round(h * barFrac);
      ctx.save();
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, w, barH);
      ctx.fillRect(0, h - barH, w, barH);
      ctx.restore();
      return;
    }

    case 'cin_anamorphic_flare': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const drift = Math.sin(t * 1.4) * h * 0.08;
      const cy = h * 0.36 + drift;
      const fx = w * (0.5 + 0.16 * Math.cos(t * 0.9));
      const streakH = Math.max(4, h * (0.032 + spNorm * 0.055));

      const glowCanvas = renderHighlightGlowCanvas(
        snap,
        pool,
        Math.max(3, minEdge * 0.025),
        175,
        [0.55, 0.9, 1.3]
      );

      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      if (glowCanvas) {
        ctx.globalAlpha = 0.45 * ratio;
        ctx.drawImage(glowCanvas, 0, 0, w, h);
      }
      ctx.globalAlpha = 0.88 * ratio;
      // Wide cyan anamorphic streak
      const grad = ctx.createLinearGradient(0, cy - streakH, 0, cy + streakH);
      grad.addColorStop(0, 'rgba(14,165,233,0)');
      grad.addColorStop(0.36, 'rgba(56,189,248,0.42)');
      grad.addColorStop(0.5, 'rgba(240,249,255,0.96)');
      grad.addColorStop(0.64, 'rgba(56,189,248,0.42)');
      grad.addColorStop(1, 'rgba(14,165,233,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, cy - streakH, w, streakH * 2);

      // Core intense flare + oval iris bokeh ghosts along axis
      const core = ctx.createRadialGradient(fx, cy, 0, fx, cy, w * 0.34);
      core.addColorStop(0, 'rgba(255,255,255,0.75)');
      core.addColorStop(0.22, 'rgba(125,211,252,0.45)');
      core.addColorStop(0.55, 'rgba(37,99,235,0.18)');
      core.addColorStop(1, 'rgba(37,99,235,0)');
      ctx.fillStyle = core;
      ctx.fillRect(0, 0, w, h);

      for (let g = 1; g <= 4; g++) {
        const gx = w - fx + (fx - w / 2) * (g * 0.42);
        const gy = h - cy + (cy - h / 2) * (g * 0.32);
        const rx = minEdge * (0.025 + g * 0.012);
        ctx.fillStyle = `rgba(${g % 2 === 0 ? '96,165,250' : '192,132,252'},${0.2 * ratio})`;
        ctx.beginPath();
        ctx.ellipse(gx, gy, rx * 0.68, rx * 1.35, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'cin_teal_orange': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const warmShift = 0.6 + spNorm * 0.8;
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          const shadowW = (1 - lum) * (1 - lum);
          const highW = lum * lum;
          dst[i] = clampByte(r - shadowW * 28 + highW * 42 * warmShift);
          dst[i + 1] = clampByte(g + shadowW * 12 + highW * 10);
          dst[i + 2] = clampByte(b + shadowW * 38 - highW * 36 * warmShift);
        }
      });
      return;
    }

    case 'cin_noir_spotlight': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = 0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2];
          const c = clampByte((lum - 128) * 1.45 + 122);
          dst[i] = c;
          dst[i + 1] = c;
          dst[i + 2] = c;
        }
      });
      drawVignette(ctx, w, h, 0.2 + spNorm * 0.25, 0.86 * ratio);
      return;
    }

    case 'cin_halation_film': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blurPx = Math.max(2, Math.round(minEdge * (0.016 + spNorm * 0.032)));
      const glow = renderHighlightGlowCanvas(snap, pool, blurPx, 155, [1.35, 0.42, 0.16]);
      if (!glow) return;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.85 * ratio;
      ctx.drawImage(glow, 0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'cin_bleach_bypass': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const gain = 1.25 + spNorm * 0.45;
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const mr = lum * 0.68 + r * 0.32;
          const mg = lum * 0.68 + g * 0.32;
          const mb = lum * 0.68 + b * 0.32;
          dst[i] = clampByte((mr - 128) * gain + 128);
          dst[i + 1] = clampByte((mg - 128) * gain + 128);
          dst[i + 2] = clampByte((mb - 128) * gain + 128);
        }
      });
      return;
    }

    case 'cin_dramatic_vignette': {
      drawVignette(ctx, w, h, 0.28 + (1 - spNorm) * 0.25, 0.88 * ratio);
      return;
    }

    case 'cin_zoom_breathe': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const zoom = 1 + (0.08 + 0.16 * ratio) * (0.5 + 0.5 * Math.sin(t * 2.1));
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case 'cin_sunset_grad': {
      const depth = 0.45 + spNorm * 0.4;
      const grad = ctx.createLinearGradient(0, 0, 0, h * depth);
      grad.addColorStop(0, `rgba(245, 158, 11, ${0.58 * ratio})`);
      grad.addColorStop(0.5, `rgba(234, 88, 12, ${0.26 * ratio})`);
      grad.addColorStop(1, 'rgba(234, 88, 12, 0)');
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'cin_action_shake': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const amp = minEdge * 0.032 * ratio;
      const dx = (Math.sin(t * 17.3) + Math.cos(t * 9.7) * 0.6) * amp;
      const dy = (Math.cos(t * 15.1) + Math.sin(t * 11.2) * 0.6) * amp;
      const rot = Math.sin(t * 13.0) * 0.035 * ratio;
      const zoom = 1.08 + 0.04 * ratio;
      ctx.save();
      ctx.translate(w / 2 + dx, h / 2 + dy);
      ctx.rotate(rot);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case 'cin_widescreen_soft': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blurPx = Math.max(2, Math.round(minEdge * 0.025));
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.38 * ratio * (0.6 + spNorm * 0.5);
      ctx.filter = `blur(${blurPx}px) brightness(1.1)`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();

      const barH = Math.round(h * 0.08 * ratio);
      ctx.save();
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, w, barH);
      ctx.fillRect(0, h - barH, w, barH);
      ctx.restore();
      return;
    }

    case 'cin_cold_thriller': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 0.84);
          dst[i + 1] = clampByte(src[i + 1] * 0.96 + 4);
          dst[i + 2] = clampByte(src[i + 2] * 1.12 + 16);
        }
      });
      drawVignette(ctx, w, h, 0.35, (0.55 + spNorm * 0.3) * ratio, '2,6,23');
      return;
    }

    case 'cin_imax_teal': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const punch = 1.12 + spNorm * 0.25;
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          const sh = (1 - lum) * (1 - lum);
          const hi = lum * lum;
          const cr = clampByte(((r - 128) * punch + 128) - sh * 26 + hi * 38);
          const cg = clampByte(((g - 128) * punch + 128) + sh * 10 + hi * 8);
          const cb = clampByte(((b - 128) * punch + 128) + sh * 34 - hi * 28);
          dst[i] = cr;
          dst[i + 1] = cg;
          dst[i + 2] = cb;
        }
      });
      const barH = Math.round(h * 0.065 * ratio);
      ctx.save();
      drawVignette(ctx, w, h, 0.34, 0.45 * ratio);
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, w, barH);
      ctx.fillRect(0, h - barH, w, barH);
      ctx.restore();
      return;
    }

    case 'cin_blockbuster_gold': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const warm = 0.8 + spNorm * 0.55;
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          dst[i] = clampByte(r * (1.04 + lum * 0.12 * warm) + 14);
          dst[i + 1] = clampByte(g * (0.98 + lum * 0.06 * warm) + 6);
          dst[i + 2] = clampByte(b * (0.82 - lum * 0.08 * warm));
        }
      });
      const glow = renderHighlightGlowCanvas(snap, pool, Math.max(3, minEdge * 0.025), 170, [1.3, 0.9, 0.35]);
      if (glow) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.42 * ratio;
        ctx.drawImage(glow, 0, 0, w, h);
        ctx.restore();
      }
      drawVignette(ctx, w, h, 0.3, 0.48 * ratio, '24,10,0');
      return;
    }

    case 'cin_blade_neon': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          const sh = 1 - lum;
          dst[i] = clampByte(r * 0.92 + lum * lum * 55 + sh * 14);
          dst[i + 1] = clampByte(g * 0.84 + sh * 24);
          dst[i + 2] = clampByte(b * 1.15 + sh * 42 + lum * 24);
        }
      });
      const glow = renderHighlightGlowCanvas(snap, pool, Math.max(3, minEdge * (0.02 + spNorm * 0.025)), 165, [1.25, 0.45, 1.3]);
      if (glow) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.55 * ratio;
        ctx.drawImage(glow, 0, 0, w, h);
        ctx.restore();
      }
      drawVignette(ctx, w, h, 0.3, 0.6 * ratio, '15,5,32');
      return;
    }

    case 'cin_scope_reveal': {
      const openCurve = clamp01(prog * (1.1 + spNorm * 1.4));
      const ease = 1 - Math.pow(1 - openCurve, 3);
      const barH = Math.round(h * 0.5 * (1 - ease * 0.84) * ratio);
      if (barH > 0) {
        ctx.save();
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, w, barH);
        ctx.fillRect(0, h - barH, w, barH);
        ctx.restore();
      }
      return;
    }

    // =========================================================================
    // 2. BLUR (14)
    // =========================================================================
    case 'blur_gaussian': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(1, minEdge * (0.012 + spNorm * 0.04) * ratio);
      ctx.save();
      ctx.filter = `blur(${px.toFixed(1)}px)`;
      ctx.drawImage(snap, -px, -px, w + px * 2, h + px * 2);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'blur_frosted': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(2, minEdge * (0.025 + spNorm * 0.05) * ratio);
      ctx.save();
      ctx.filter = `blur(${px.toFixed(1)}px) brightness(1.08)`;
      ctx.drawImage(snap, -px, -px, w + px * 2, h + px * 2);
      ctx.filter = 'none';
      ctx.fillStyle = `rgba(226, 232, 240, ${0.18 * ratio})`;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'blur_motion_h': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const span = w * (0.03 + spNorm * 0.065) * ratio;
      const taps = 11;
      ctx.save();
      for (let i = 0; i < taps; i++) {
        const off = ((i / (taps - 1)) - 0.5) * span;
        ctx.globalAlpha = 1 / (i + 1);
        ctx.drawImage(snap, off, 0, w, h);
      }
      ctx.restore();
      return;
    }

    case 'blur_motion_v': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const span = h * (0.035 + spNorm * 0.07) * ratio;
      const taps = 11;
      ctx.save();
      for (let i = 0; i < taps; i++) {
        const off = ((i / (taps - 1)) - 0.5) * span;
        ctx.globalAlpha = 1 / (i + 1);
        ctx.drawImage(snap, 0, off, w, h);
      }
      ctx.restore();
      return;
    }

    case 'blur_radial_spin': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const maxAng = (0.045 + spNorm * 0.095) * ratio;
      const taps = 12;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      for (let i = 1; i <= taps; i++) {
        const ang = ((i / taps) - 0.5) * maxAng * 2;
        ctx.save();
        ctx.rotate(ang);
        ctx.scale(1.05, 1.05);
        ctx.globalAlpha = 0.2;
        ctx.drawImage(snap, -w / 2, -h / 2, w, h);
        ctx.restore();
      }
      ctx.restore();
      return;
    }

    case 'blur_zoom_burst': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const maxZoom = (0.14 + spNorm * 0.32) * ratio;
      const taps = 11;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      for (let i = 1; i <= taps; i++) {
        const sc = 1 + (i / taps) * maxZoom;
        ctx.save();
        ctx.scale(sc, sc);
        ctx.globalAlpha = 0.22 * (1 - i / (taps + 2));
        ctx.drawImage(snap, -w / 2, -h / 2, w, h);
        ctx.restore();
      }
      ctx.restore();
      return;
    }

    case 'blur_tilt_shift': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blurred = pool.getWorkC(w, h);
      const bctx = blurred.getContext('2d');
      if (!bctx) return;
      const px = Math.max(2, minEdge * 0.026 * ratio);
      bctx.clearRect(0, 0, w, h);
      bctx.filter = `blur(${px.toFixed(1)}px) saturate(1.22)`;
      bctx.drawImage(snap, -px, -px, w + px * 2, h + px * 2);
      bctx.filter = 'none';

      const halfBand = (0.12 + (1 - spNorm) * 0.14);
      bctx.save();
      bctx.globalCompositeOperation = 'destination-out';
      const feather = bctx.createLinearGradient(0, 0, 0, h);
      feather.addColorStop(0, 'rgba(0,0,0,0)');
      feather.addColorStop(Math.max(0.05, 0.5 - halfBand - 0.14), 'rgba(0,0,0,0.45)');
      feather.addColorStop(Math.max(0.1, 0.5 - halfBand), 'rgba(0,0,0,1)');
      feather.addColorStop(Math.min(0.9, 0.5 + halfBand), 'rgba(0,0,0,1)');
      feather.addColorStop(Math.min(0.95, 0.5 + halfBand + 0.14), 'rgba(0,0,0,0.45)');
      feather.addColorStop(1, 'rgba(0,0,0,0)');
      bctx.fillStyle = feather;
      bctx.fillRect(0, 0, w, h);
      bctx.restore();

      ctx.drawImage(blurred, 0, 0, w, h);
      return;
    }

    case 'blur_halo_focus': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blurred = pool.getWorkC(w, h);
      const bctx = blurred.getContext('2d');
      if (!bctx) return;
      const px = Math.max(2, minEdge * 0.025 * ratio);
      bctx.clearRect(0, 0, w, h);
      bctx.filter = `blur(${px.toFixed(1)}px)`;
      bctx.drawImage(snap, -px, -px, w + px * 2, h + px * 2);
      bctx.filter = 'none';

      // Cut transparent radial center out of blurred canvas
      const rInner = minEdge * (0.2 + (1 - spNorm) * 0.16);
      const rOuter = minEdge * 0.54;
      bctx.save();
      bctx.globalCompositeOperation = 'destination-out';
      const grad = bctx.createRadialGradient(w / 2, h / 2, rInner, w / 2, h / 2, rOuter);
      grad.addColorStop(0, 'rgba(0,0,0,1)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      bctx.fillStyle = grad;
      bctx.fillRect(0, 0, w, h);
      bctx.restore();

      ctx.drawImage(blurred, 0, 0, w, h);
      return;
    }

    case 'blur_bokeh_dream': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(2, minEdge * (0.02 + spNorm * 0.03) * ratio);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.55 * ratio;
      ctx.filter = `blur(${px.toFixed(1)}px) saturate(1.35) contrast(1.25)`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'blur_pixelate': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blocks = Math.max(8, Math.round((72 - spNorm * 52) / Math.max(0.25, ratio)));
      const pw = Math.max(6, blocks);
      const ph = Math.max(6, Math.round((blocks * h) / Math.max(1, w)));
      const small = pool.getPixelWork(pw, ph);
      const sctx = small.getContext('2d');
      if (!sctx) return;
      sctx.imageSmoothingEnabled = true;
      sctx.clearRect(0, 0, pw, ph);
      sctx.drawImage(snap, 0, 0, pw, ph);

      ctx.save();
      ctx.imageSmoothingEnabled = false;
      ctx.globalAlpha = ratio;
      ctx.drawImage(small, 0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'blur_soft_mist': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(2, minEdge * (0.015 + spNorm * 0.025));
      ctx.save();
      ctx.globalCompositeOperation = 'lighten';
      ctx.globalAlpha = 0.48 * ratio;
      ctx.filter = `blur(${px.toFixed(1)}px) brightness(1.06)`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'blur_motion_trail': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const offX = Math.sin(t * 2.5) * w * (0.025 + spNorm * 0.04) * ratio;
      const offY = Math.cos(t * 2.1) * h * 0.015 * ratio;
      ctx.save();
      ctx.globalAlpha = 0.35 * ratio;
      ctx.drawImage(snap, offX, offY, w, h);
      ctx.globalAlpha = 0.22 * ratio;
      ctx.drawImage(snap, offX * 2, offY * 2, w, h);
      ctx.restore();
      return;
    }

    case 'blur_whip_diagonal': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const span = minEdge * (0.04 + spNorm * 0.08) * ratio;
      const taps = 11;
      ctx.save();
      for (let i = 0; i < taps; i++) {
        const u = i / (taps - 1) - 0.5;
        ctx.globalAlpha = 1 / (i + 1);
        ctx.drawImage(snap, u * span, -u * span * 0.72, w, h);
      }
      ctx.restore();
      return;
    }

    case 'blur_speed_lines': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const maxZoom = (0.18 + spNorm * 0.28) * ratio;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      for (let i = 1; i <= 8; i++) {
        const sc = 1 + (i / 8) * maxZoom;
        ctx.save();
        ctx.scale(sc, sc);
        ctx.globalAlpha = 0.18 * (1 - i / 10);
        ctx.drawImage(snap, -w / 2, -h / 2, w, h);
        ctx.restore();
      }
      ctx.restore();
      // Dynamic anime / sports radial speed streaks around outer edges
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const lineCount = 34;
      for (let i = 0; i < lineCount; i++) {
        const ang = (i / lineCount) * Math.PI * 2 + Math.sin(t * 3 + i) * 0.04;
        const rIn = minEdge * (0.28 + prng(i * 11 + Math.floor(t * 16)) * 0.14);
        const rOut = Math.hypot(w, h) * 0.65;
        ctx.strokeStyle = `rgba(224,242,254,${(0.24 + prng(i) * 0.35) * ratio})`;
        ctx.lineWidth = Math.max(1, minEdge * (0.003 + prng(i + 9) * 0.004));
        ctx.beginPath();
        ctx.moveTo(w / 2 + Math.cos(ang) * rIn, h / 2 + Math.sin(ang) * rIn);
        ctx.lineTo(w / 2 + Math.cos(ang) * rOut, h / 2 + Math.sin(ang) * rOut);
        ctx.stroke();
      }
      ctx.restore();
      return;
    }

    // =========================================================================
    // 3. 3D (12)
    // =========================================================================
    case '3d_anaglyph': {
      const shift = Math.max(2, w * (0.01 + spNorm * 0.025) * ratio);
      drawChannelSplit(targetCanvas, ctx, pool, -shift, 0, shift, 0, 0.92 * ratio);
      return;
    }

    case '3d_card_float': {
      const tiltX = Math.sin(t * 1.4) * (0.14 + spNorm * 0.14) * ratio;
      const tiltY = Math.cos(t * 1.1) * 0.12 * ratio;
      draw3DPerspective(targetCanvas, ctx, pool, tiltX, tiltY, 0.84, '#070a12', true);
      return;
    }

    case '3d_tilt_left': {
      draw3DPerspective(
        targetCanvas,
        ctx,
        pool,
        -(0.14 + spNorm * 0.2) * ratio,
        0.04 * ratio,
        0.88,
        '#05070c',
        true
      );
      return;
    }

    case '3d_tilt_right': {
      draw3DPerspective(
        targetCanvas,
        ctx,
        pool,
        (0.14 + spNorm * 0.2) * ratio,
        -0.04 * ratio,
        0.88,
        '#05070c',
        true
      );
      return;
    }

    case '3d_flip_mirror': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      ctx.save();
      ctx.translate(w, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.restore();
      if (spNorm > 0.15) {
        drawVignette(ctx, w, h, 0.45, 0.35 * spNorm * ratio);
      }
      return;
    }

    case '3d_swing_pendulum': {
      const tiltX = Math.sin(t * 2.2) * 0.24 * ratio;
      const tiltY = Math.sin(t * 2.2 + 1.2) * 0.08 * ratio;
      draw3DPerspective(targetCanvas, ctx, pool, tiltX, tiltY, 0.9, '#030508', true);
      return;
    }

    case '3d_fisheye_barrel': {
      const strength = (0.35 + spNorm * 0.65) * ratio;
      runPixelTransform(targetCanvas, ctx, pool, 1, maxPixelDim, (src, dst, pw, ph) => {
        const cx = pw / 2;
        const cy = ph / 2;
        const maxR = Math.hypot(cx, cy);
        for (let y = 0; y < ph; y++) {
          const ny = (y - cy) / maxR;
          for (let x = 0; x < pw; x++) {
            const nx = (x - cx) / maxR;
            const r = Math.hypot(nx, ny);
            const factor = r > 0 ? Math.pow(r, 1 - strength * 0.55) / r : 1;
            const sx = cx + nx * factor * maxR * 0.85;
            const sy = cy + ny * factor * maxR * 0.85;
            sampleBilinearRGB(src, pw, ph, sx, sy, dst, (y * pw + x) * 4);
          }
        }
      });
      return;
    }

    case '3d_pincushion_warp': {
      const strength = (0.35 + spNorm * 0.7) * ratio;
      runPixelTransform(targetCanvas, ctx, pool, 1, maxPixelDim, (src, dst, pw, ph) => {
        const cx = pw / 2;
        const cy = ph / 2;
        const maxR = Math.hypot(cx, cy);
        for (let y = 0; y < ph; y++) {
          const ny = (y - cy) / maxR;
          for (let x = 0; x < pw; x++) {
            const nx = (x - cx) / maxR;
            const r2 = nx * nx + ny * ny;
            const scaleBack = 1 / (1 + strength * 0.8 * r2);
            const sx = cx + nx * scaleBack * maxR;
            const sy = cy + ny * scaleBack * maxR;
            sampleBilinearRGB(src, pw, ph, sx, sy, dst, (y * pw + x) * 4);
          }
        }
      });
      return;
    }

    case '3d_parallax_depth': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const scBg = 1.06 + Math.sin(t * 1.8) * 0.04 * ratio;
      const scFg = 1.12 + Math.cos(t * 1.8) * 0.06 * ratio;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(scBg, scBg);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();

      ctx.save();
      ctx.beginPath();
      ctx.ellipse(w / 2, h / 2, w * 0.34, h * 0.38, 0, 0, Math.PI * 2);
      ctx.clip();
      ctx.translate(w / 2, h / 2);
      ctx.scale(scFg, scFg);
      ctx.globalAlpha = 0.72 * ratio;
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case '3d_ripple_wave': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const strips = 48;
      const sh = h / strips;
      const amp = w * 0.022 * ratio;
      ctx.save();
      for (let i = 0; i < strips; i++) {
        const offX = Math.sin(i * 0.38 + t * 5.0) * amp;
        ctx.drawImage(snap, 0, i * sh, w, sh + 1, offX, i * sh, w, sh + 1);
      }
      ctx.restore();
      return;
    }

    case '3d_horizon_roll': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const angle = Math.sin(t * 1.5) * 0.16 * ratio;
      const zoom = 1.18;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate(angle);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case '3d_split_prism': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const shift = w * (0.04 + spNorm * 0.08) * ratio;
      ctx.save();
      // Left third
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, w / 3, h);
      ctx.clip();
      ctx.drawImage(snap, -shift, 0, w, h);
      ctx.restore();
      // Right third
      ctx.save();
      ctx.beginPath();
      ctx.rect((w * 2) / 3, 0, w / 3, h);
      ctx.clip();
      ctx.drawImage(snap, shift, 0, w, h);
      ctx.restore();
      // Subtle glass bevel lines
      ctx.strokeStyle = `rgba(255,255,255,${0.25 * ratio})`;
      ctx.lineWidth = Math.max(1, w * 0.003);
      ctx.beginPath();
      ctx.moveTo(w / 3, 0);
      ctx.lineTo(w / 3, h);
      ctx.moveTo((w * 2) / 3, 0);
      ctx.lineTo((w * 2) / 3, h);
      ctx.stroke();
      ctx.restore();
      return;
    }

    case '3d_zoom_bounce': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const bounce = Math.abs(Math.sin(t * 2.8));
      const sc = 1.04 + bounce * bounce * (0.14 + spNorm * 0.14) * ratio;
      const tilt = Math.sin(t * 2.8) * 0.04 * ratio;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate(tilt);
      ctx.scale(sc, sc);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case '3d_cube_rotate': {
      const phase = (t * 0.55) % (Math.PI * 2);
      const tiltX = Math.sin(phase) * (0.28 + spNorm * 0.08) * ratio;
      const tiltY = Math.cos(phase * 0.7) * 0.1 * ratio;
      draw3DPerspective(targetCanvas, ctx, pool, tiltX, tiltY, 0.84, '#05070e', true);
      return;
    }

    case '3d_shockwave': {
      const ringR = ((t * 0.65) % 1) * 0.88 + 0.08;
      const waveAmp = (0.04 + spNorm * 0.06) * ratio;
      runPixelTransform(targetCanvas, ctx, pool, 1, maxPixelDim, (src, dst, pw, ph) => {
        const cx = pw / 2;
        const cy = ph / 2;
        const maxR = Math.hypot(cx, cy);
        for (let y = 0; y < ph; y++) {
          const ny = (y - cy) / maxR;
          for (let x = 0; x < pw; x++) {
            const nx = (x - cx) / maxR;
            const r = Math.hypot(nx, ny);
            const dist = Math.abs(r - ringR);
            if (dist < 0.14 && r > 0.001) {
              const push = Math.cos((dist / 0.14) * Math.PI * 0.5) * waveAmp;
              const sx = cx + ((nx / r) * (r - push)) * maxR;
              const sy = cy + ((ny / r) * (r - push)) * maxR;
              sampleBilinearRGB(src, pw, ph, sx, sy, dst, (y * pw + x) * 4);
            } else {
              const idx = (y * pw + x) * 4;
              dst[idx] = src[idx];
              dst[idx + 1] = src[idx + 1];
              dst[idx + 2] = src[idx + 2];
            }
          }
        }
      });
      return;
    }

    // =========================================================================
    // 4. GLITCH (12)
    // =========================================================================
    case 'gl_rgb_split': {
      const jitter = 0.65 + 0.55 * Math.abs(Math.sin(t * 9.0));
      const shift = w * 0.022 * ratio * jitter;
      drawChannelSplit(targetCanvas, ctx, pool, -shift, 0, shift, 0, 0.95);
      return;
    }

    case 'gl_vhs_tear': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const tearY = ((t * 0.35) % 1) * h;
      const bandH = h * 0.16;
      const strips = 18;
      const sh = bandH / strips;
      ctx.save();
      for (let i = 0; i < strips; i++) {
        const y = (tearY + i * sh) % h;
        const off = (prng(Math.floor(t * 24) + i) - 0.5) * w * 0.14 * ratio;
        ctx.drawImage(snap, 0, y, w, sh + 1, off, y, w, sh + 1);
      }
      ctx.fillStyle = `rgba(255,255,255,${0.18 * ratio})`;
      ctx.fillRect(0, tearY, w, Math.max(2, h * 0.008));
      ctx.restore();
      return;
    }

    case 'gl_block_corrupt': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const tick = Math.floor(t * 14);
      const count = Math.round(8 + 14 * ratio);
      ctx.save();
      for (let i = 0; i < count; i++) {
        const r1 = prng(tick * 31 + i * 7);
        const r2 = prng(tick * 17 + i * 13);
        const r3 = prng(tick * 23 + i * 19);
        const bw = w * (0.08 + r1 * 0.24);
        const bh = h * (0.03 + r2 * 0.08);
        const sx = r2 * (w - bw);
        const sy = r1 * (h - bh);
        const dx = clampByteLike(Math.round(sx + (r3 - 0.5) * w * 0.16 * ratio), Math.max(0, w - bw));
        const dy = clampByteLike(Math.round(sy + (r1 - 0.5) * h * 0.06 * ratio), Math.max(0, h - bh));
        ctx.drawImage(snap, sx, sy, bw, bh, dx, dy, bw, bh);
        if (i % 3 === 0) {
          ctx.fillStyle = i % 2 === 0 ? `rgba(6,182,212,${0.25 * ratio})` : `rgba(236,72,153,${0.25 * ratio})`;
          ctx.fillRect(dx, dy, bw, bh * 0.35);
        }
      }
      ctx.restore();
      return;
    }

    case 'gl_scanline_slice': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const tick = Math.floor(t * 16);
      const slices = 22;
      const sh = h / slices;
      ctx.save();
      for (let i = 0; i < slices; i++) {
        const rnd = prng(tick * 19 + i);
        const off = rnd > 0.68 ? (rnd - 0.84) * w * 0.18 * ratio : 0;
        if (off !== 0) {
          ctx.drawImage(snap, 0, i * sh, w, sh + 1, off, i * sh, w, sh + 1);
        }
      }
      ctx.fillStyle = `rgba(0,0,0,${0.28 * ratio})`;
      const step = Math.max(3, Math.round(h / 120));
      for (let y = 0; y < h; y += step * 2) {
        ctx.fillRect(0, y, w, step * 0.5);
      }
      ctx.restore();
      return;
    }

    case 'gl_static_snow': {
      const seed = Math.floor(t * 24);
      runPixelTransform(targetCanvas, ctx, pool, ratio, 420, (src, dst, pw, ph) => {
        const strength = (45 + spNorm * 85) * ratio;
        for (let y = 0; y < ph; y++) {
          for (let x = 0; x < pw; x++) {
            const idx = (y * pw + x) * 4;
            const n = (prng((x * 13 + y * 57 + seed) % 9973) - 0.5) * strength;
            dst[idx] = clampByte(src[idx] + n);
            dst[idx + 1] = clampByte(src[idx + 1] + n);
            dst[idx + 2] = clampByte(src[idx + 2] + n);
          }
        }
      });
      return;
    }

    case 'gl_chromatic_jitter': {
      const pulse = Math.abs(Math.sin(t * 12));
      const zoom = 1 + pulse * 0.08 * ratio;
      const snap = pool.getWorkB(w, h);
      if (snapshotTo(targetCanvas, snap)) {
        ctx.save();
        ctx.translate(w / 2, h / 2);
        ctx.scale(zoom, zoom);
        ctx.drawImage(snap, -w / 2, -h / 2, w, h);
        ctx.restore();
      }
      const shift = w * 0.025 * pulse * ratio;
      drawChannelSplit(targetCanvas, ctx, pool, -shift, shift * 0.3, shift, -shift * 0.3, 0.9);
      return;
    }

    case 'gl_crt_monitor': {
      ctx.save();
      const lineStep = Math.max(3, Math.round((h / 110) * (0.7 + spNorm * 0.6)));
      ctx.fillStyle = `rgba(0,0,0,${0.34 * ratio})`;
      for (let y = 0; y < h; y += lineStep * 2) {
        ctx.fillRect(0, y, w, lineStep);
      }
      ctx.fillStyle = `rgba(16,185,129,${0.08 * ratio})`;
      ctx.fillRect(0, 0, w, h);
      drawVignette(ctx, w, h, 0.42, 0.72 * ratio);
      ctx.restore();
      return;
    }

    case 'gl_bad_reception': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const strips = 30;
      const sh = h / strips;
      const tick = Math.floor(t * 18);
      ctx.save();
      for (let i = 0; i < strips; i++) {
        const wave = Math.sin(i * 0.7 + t * 14) * w * 0.028 * ratio;
        const burst = prng(tick + i * 5) > 0.86 ? (prng(i + tick) - 0.5) * w * 0.14 * ratio : 0;
        ctx.drawImage(snap, 0, i * sh, w, sh + 1, wave + burst, i * sh, w, sh + 1);
      }
      const flicker = 0.08 + 0.18 * prng(tick * 3);
      ctx.fillStyle = `rgba(255,255,255,${flicker * ratio})`;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'gl_neon_glitch': {
      const tick = Math.floor(t * 12);
      const flash = prng(tick) > 0.55;
      const shift = w * 0.018 * ratio;
      drawChannelSplit(targetCanvas, ctx, pool, -shift, 0, shift, 0, 0.85);
      if (flash) {
        ctx.save();
        ctx.globalCompositeOperation = 'difference';
        ctx.fillStyle = `rgba(217,70,239,${0.35 * ratio})`;
        const bandY = prng(tick + 9) * h * 0.7;
        ctx.fillRect(0, bandY, w, h * 0.18);
        ctx.restore();
      }
      return;
    }

    case 'gl_pixel_melt': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const cols = 32;
      const cw = w / cols;
      ctx.save();
      for (let i = 0; i < cols; i++) {
        const drop = prng(i * 17 + 3) * h * (0.12 + spNorm * 0.25) * ratio;
        ctx.drawImage(snap, i * cw, 0, cw + 1, h, i * cw, drop, cw + 1, h);
      }
      ctx.restore();
      return;
    }

    case 'gl_cyber_scramble': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      ctx.save();
      ctx.fillStyle = `rgba(16, 185, 129, ${0.22 * ratio})`;
      ctx.globalCompositeOperation = 'color';
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'source-over';
      const tick = Math.floor(t * 14);
      for (let i = 0; i < 6; i++) {
        const y = prng(tick + i * 11) * h * 0.85;
        const bh = h * 0.05;
        const off = (prng(tick + i * 29) - 0.5) * w * 0.16 * ratio;
        ctx.drawImage(snap, 0, y, w, bh, off, y, w, bh);
      }
      ctx.restore();
      return;
    }

    case 'gl_vhs_double': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const offset = w * (0.02 + spNorm * 0.04) * ratio;
      ctx.save();
      ctx.globalAlpha = 0.45 * ratio;
      ctx.filter = 'saturate(0.4) hue-rotate(-30deg)';
      ctx.drawImage(snap, -offset, 0, w, h);
      ctx.drawImage(snap, offset, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'gl_rgb_wave': {
      const shift = Math.max(2, w * 0.022 * ratio);
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const strips = 42;
      const sh = h / strips;
      ctx.save();
      for (let i = 0; i < strips; i++) {
        const dx = Math.sin(i * 0.45 + t * 9) * w * (0.014 + spNorm * 0.02) * ratio;
        ctx.drawImage(snap, 0, i * sh, w, sh + 1, dx, i * sh, w, sh + 1);
      }
      ctx.restore();
      drawChannelSplit(targetCanvas, ctx, pool, -shift, 0, shift, 0, 0.82 * ratio);
      return;
    }

    case 'gl_flash_cut': {
      const beat = Math.pow(Math.max(0, Math.sin(t * 7.5)), 4);
      const zoom = 1 + beat * 0.09 * ratio;
      const snap = pool.getWorkB(w, h);
      if (snapshotTo(targetCanvas, snap)) {
        ctx.save();
        ctx.translate(w / 2, h / 2);
        ctx.scale(zoom, zoom);
        ctx.drawImage(snap, -w / 2, -h / 2, w, h);
        ctx.restore();
      }
      const shift = w * (0.012 + beat * 0.032) * ratio;
      drawChannelSplit(targetCanvas, ctx, pool, -shift, 0, shift, 0, 0.9);
      if (beat > 0.45) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = `rgba(224,242,254,${beat * 0.48 * ratio})`;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
      }
      return;
    }

    // =========================================================================
    // 5. VINTAGE (12)
    // =========================================================================
    case 'vin_8mm_gate': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          dst[i] = clampByte(r * 0.52 + g * 0.48 + 20);
          dst[i + 1] = clampByte(r * 0.32 + g * 0.52 + 12);
          dst[i + 2] = clampByte(r * 0.18 + g * 0.34 + b * 0.25);
        }
      });
      drawVignette(ctx, w, h, 0.34, 0.82 * ratio, '15,8,0');
      const gate = Math.max(4, minEdge * 0.035 * ratio);
      ctx.save();
      ctx.strokeStyle = '#050403';
      ctx.lineWidth = gate * 2;
      ctx.strokeRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'vin_16mm_grain': {
      const seed = Math.floor(t * 20);
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        const grainAmp = 34 + spNorm * 45;
        for (let y = 0; y < ph; y++) {
          for (let x = 0; x < pw; x++) {
            const idx = (y * pw + x) * 4;
            const n = (prng((x * 19 + y * 43 + seed) % 8191) - 0.5) * grainAmp;
            dst[idx] = clampByte(src[idx] * 0.96 + 14 + n);
            dst[idx + 1] = clampByte(src[idx + 1] * 0.95 + 10 + n);
            dst[idx + 2] = clampByte(src[idx + 2] * 0.84 + 4 + n);
          }
        }
      });
      return;
    }

    case 'vin_sepia_dust': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          dst[i] = clampByte(r * 0.393 + g * 0.769 + b * 0.189);
          dst[i + 1] = clampByte(r * 0.349 + g * 0.686 + b * 0.168);
          dst[i + 2] = clampByte(r * 0.272 + g * 0.534 + b * 0.131);
        }
      });
      const tick = Math.floor(t * 14);
      ctx.save();
      ctx.strokeStyle = `rgba(254, 243, 199, ${0.38 * ratio})`;
      ctx.lineWidth = Math.max(1, w * 0.002);
      for (let i = 0; i < 4; i++) {
        const sx = prng(tick * 13 + i * 17) * w;
        ctx.beginPath();
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx + (prng(i) - 0.5) * 6, h);
        ctx.stroke();
      }
      ctx.fillStyle = `rgba(255,250,235,${0.45 * ratio})`;
      for (let i = 0; i < 10; i++) {
        ctx.beginPath();
        ctx.arc(
          prng(tick + i * 31) * w,
          prng(tick + i * 47) * h,
          Math.max(1, minEdge * 0.004),
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'vin_burned_edges': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const burnW = w * (0.28 + spNorm * 0.2);
      const leftG = ctx.createLinearGradient(0, 0, burnW, 0);
      leftG.addColorStop(0, `rgba(234, 88, 12, ${0.78 * ratio})`);
      leftG.addColorStop(0.5, `rgba(245, 158, 11, ${0.32 * ratio})`);
      leftG.addColorStop(1, 'rgba(245, 158, 11, 0)');
      ctx.fillStyle = leftG;
      ctx.fillRect(0, 0, burnW, h);

      const rightG = ctx.createLinearGradient(w, 0, w - burnW * 0.85, 0);
      rightG.addColorStop(0, `rgba(220, 38, 38, ${0.62 * ratio})`);
      rightG.addColorStop(1, 'rgba(220, 38, 38, 0)');
      ctx.fillStyle = rightG;
      ctx.fillRect(w - burnW, 0, burnW, h);
      ctx.restore();
      return;
    }

    case 'vin_polaroid_frame': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const pad = Math.round(minEdge * (0.04 + spNorm * 0.05) * ratio);
      const bottomPad = Math.round(pad * 2.4);
      ctx.save();
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, w, h);
      ctx.filter = 'contrast(0.92) sepia(0.22) brightness(1.04)';
      ctx.drawImage(
        snap,
        pad,
        pad,
        Math.max(4, w - pad * 2),
        Math.max(4, h - pad - bottomPad)
      );
      ctx.filter = 'none';
      ctx.strokeStyle = 'rgba(0,0,0,0.12)';
      ctx.lineWidth = 1;
      ctx.strokeRect(pad, pad, Math.max(4, w - pad * 2), Math.max(4, h - pad - bottomPad));
      ctx.restore();
      return;
    }

    case 'vin_camcorder_98': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      ctx.save();
      ctx.filter = `saturate(${1 - 0.15 * ratio}) contrast(${1 + 0.1 * ratio})`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      // Viewfinder corners & REC indicator
      const m = Math.round(minEdge * 0.06);
      const arm = Math.round(minEdge * 0.08);
      ctx.strokeStyle = `rgba(255,255,255,${0.8 * ratio})`;
      ctx.lineWidth = Math.max(2, minEdge * 0.005);
      ctx.beginPath();
      ctx.moveTo(m, m + arm);
      ctx.lineTo(m, m);
      ctx.lineTo(m + arm, m);
      ctx.moveTo(w - m - arm, m);
      ctx.lineTo(w - m, m);
      ctx.lineTo(w - m, m + arm);
      ctx.moveTo(m, h - m - arm);
      ctx.lineTo(m, h - m);
      ctx.lineTo(m + arm, h - m);
      ctx.moveTo(w - m - arm, h - m);
      ctx.lineTo(w - m, h - m);
      ctx.lineTo(w - m, h - m - arm);
      ctx.stroke();

      const blink = Math.floor(t * 2) % 2 === 0;
      const fs = Math.max(11, Math.round(minEdge * 0.04));
      ctx.font = `700 ${fs}px monospace`;
      if (blink) {
        ctx.fillStyle = `rgba(239,68,68,${0.95 * ratio})`;
        ctx.beginPath();
        ctx.arc(m + fs * 0.9, m + fs * 1.1, fs * 0.34, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = `rgba(255,255,255,${0.9 * ratio})`;
      ctx.fillText(`REC ${formatCamcorderTC(timeSec)}`, m + fs * 1.6, m + fs * 1.45);
      ctx.fillText('SP · 1998-08-14', m + fs * 0.5, h - m - fs * 0.65);
      ctx.restore();
      return;
    }

    case 'vin_silent_movie': {
      const flicker = 0.88 + 0.22 * prng(Math.floor(t * 16));
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = (0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]) * flicker;
          const v = clampByte((lum - 128) * 1.35 + 122);
          dst[i] = v;
          dst[i + 1] = clampByte(v * 0.97);
          dst[i + 2] = clampByte(v * 0.88);
        }
      });
      drawVignette(ctx, w, h, 0.25, 0.85 * ratio);
      return;
    }

    case 'vin_kodak_warm': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.08 + 16);
          dst[i + 1] = clampByte(src[i + 1] * 1.03 + 12);
          dst[i + 2] = clampByte(src[i + 2] * 0.88 + 8);
        }
      });
      drawVignette(ctx, w, h, 0.4, 0.42 * ratio, '35,18,0');
      return;
    }

    case 'vin_retro_tv': {
      ctx.save();
      const step = Math.max(3, Math.round(h / 95));
      ctx.fillStyle = `rgba(15, 23, 42, ${0.32 * ratio})`;
      for (let y = 0; y < h; y += step * 2) {
        ctx.fillRect(0, y, w, step * 0.8);
      }
      ctx.fillStyle = `rgba(251, 191, 36, ${0.09 * ratio})`;
      ctx.fillRect(0, 0, w, h);
      drawVignette(ctx, w, h, 0.38, 0.72 * ratio);
      ctx.restore();
      return;
    }

    case 'vin_faded_print': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const lift = 28 + spNorm * 26;
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 0.82 + lift + 8);
          dst[i + 1] = clampByte(src[i + 1] * 0.82 + lift + 5);
          dst[i + 2] = clampByte(src[i + 2] * 0.78 + lift);
        }
      });
      return;
    }

    case 'vin_projector_flicker': {
      const pulse = 0.74 + 0.26 * Math.sin(t * 28);
      ctx.save();
      ctx.fillStyle = `rgba(0,0,0,${(1 - pulse) * 0.75 * ratio})`;
      ctx.fillRect(0, 0, w, h);
      drawVignette(ctx, w, h, 0.35, 0.55 * ratio, '24,14,2');
      ctx.restore();
      return;
    }

    case 'vin_sun_bleached': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.12 + 26);
          dst[i + 1] = clampByte(src[i + 1] * 1.12 + 24);
          dst[i + 2] = clampByte(src[i + 2] * 1.02 + 22);
        }
      });
      return;
    }

    case 'vin_kodak_2383': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const c = 1.18 + spNorm * 0.22;
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
          const cr = (r - 128) * c + 128;
          const cg = (g - 128) * c + 128;
          const cb = (b - 128) * c + 128;
          dst[i] = clampByte(cr + lum * 16 - (1 - lum) * 8);
          dst[i + 1] = clampByte(cg + lum * 6);
          dst[i + 2] = clampByte(cb - lum * 18 + (1 - lum) * 14);
        }
      });
      drawVignette(ctx, w, h, 0.38, 0.45 * ratio, '10,12,18');
      return;
    }

    case 'vin_cine_reel': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const borderW = Math.max(10, Math.round(w * 0.08 * ratio));
      ctx.save();
      ctx.filter = `sepia(${0.28 * ratio}) contrast(${1.08 + 0.12 * ratio})`;
      ctx.drawImage(snap, borderW, 0, w - borderW * 2, h);
      ctx.filter = 'none';
      ctx.fillStyle = '#09090b';
      ctx.fillRect(0, 0, borderW, h);
      ctx.fillRect(w - borderW, 0, borderW, h);

      // Animated film sprockets
      const holeH = Math.max(8, h * 0.06);
      const step = holeH * 1.85;
      const scroll = (t * h * 0.45) % step;
      const holeW = Math.max(4, borderW * 0.52);
      const padX = (borderW - holeW) / 2;
      ctx.fillStyle = 'rgba(226,232,240,0.82)';
      for (let y = -step + scroll; y < h + step; y += step) {
        ctx.fillRect(padX, y, holeW, holeH);
        ctx.fillRect(w - borderW + padX, y, holeW, holeH);
      }
      ctx.restore();
      return;
    }

    // =========================================================================
    // 6. COLOR (12)
    // =========================================================================
    case 'col_duotone_cyber': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = clamp01((0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]) / 255);
          dst[i] = clampByte(35 + lum * (6 - 35) + (1 - lum) * 200);
          dst[i + 1] = clampByte(24 + lum * 195);
          dst[i + 2] = clampByte(115 + lum * 140);
        }
      });
      return;
    }

    case 'col_infrared': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const r = src[i];
          const g = src[i + 1];
          const b = src[i + 2];
          dst[i] = clampByte(g * 1.35 + 30);
          dst[i + 1] = clampByte(b * 0.85 + r * 0.18);
          dst[i + 2] = clampByte(r * 0.72 + b * 0.45);
        }
      });
      return;
    }

    case 'col_thermal': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const gain = 0.85 + spNorm * 0.5;
        for (let i = 0; i < src.length; i += 4) {
          const lum = clamp01(((0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]) / 255) * gain);
          let r = 0;
          let g = 0;
          let b = 0;
          if (lum < 0.33) {
            const k = lum / 0.33;
            r = k * 140;
            g = 0;
            b = 60 + k * 160;
          } else if (lum < 0.66) {
            const k = (lum - 0.33) / 0.33;
            r = 140 + k * 115;
            g = k * 120;
            b = 220 * (1 - k);
          } else {
            const k = (lum - 0.66) / 0.34;
            r = 255;
            g = 120 + k * 135;
            b = k * 230;
          }
          dst[i] = clampByte(r);
          dst[i + 1] = clampByte(g);
          dst[i + 2] = clampByte(b);
        }
      });
      return;
    }

    case 'col_solarize': {
      const thresh = 100 + spNorm * 70;
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = src[i] > thresh ? 255 - src[i] : src[i];
          dst[i + 1] = src[i + 1] > thresh ? 255 - src[i + 1] : src[i + 1];
          dst[i + 2] = src[i + 2] > thresh ? 255 - src[i + 2] : src[i + 2];
        }
      });
      return;
    }

    case 'col_electric_invert': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = 255 - src[i];
          dst[i + 1] = 255 - src[i + 1];
          dst[i + 2] = 255 - src[i + 2];
        }
      });
      return;
    }

    case 'col_posterize': {
      const levels = Math.max(2, Math.round(7 - spNorm * 4));
      const step = 255 / (levels - 1);
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = Math.round(src[i] / step) * step;
          dst[i + 1] = Math.round(src[i + 1] / step) * step;
          dst[i + 2] = Math.round(src[i + 2] / step) * step;
        }
      });
      return;
    }

    case 'col_cyanotype': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = clamp01((0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]) / 255);
          dst[i] = clampByte(12 + lum * 225);
          dst[i + 1] = clampByte(35 + lum * 208);
          dst[i + 2] = clampByte(95 + lum * 160);
        }
      });
      return;
    }

    case 'col_matrix_tint': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = 0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2];
          dst[i] = clampByte(lum * 0.24);
          dst[i + 1] = clampByte(lum * (1.15 + spNorm * 0.25));
          dst[i + 2] = clampByte(lum * 0.36);
        }
      });
      return;
    }

    case 'col_sunset_duotone': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          const lum = clamp01((0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2]) / 255);
          dst[i] = clampByte(78 + lum * 177);
          dst[i + 1] = clampByte(18 + lum * 192);
          dst[i + 2] = clampByte(132 - lum * 92);
        }
      });
      return;
    }

    case 'col_vibrant_hdr': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      ctx.save();
      ctx.filter = `contrast(${(1 + 0.35 * ratio).toFixed(2)}) saturate(${(1 + 0.65 * ratio).toFixed(2)})`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'col_pastel_wash': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 0.78 + 64);
          dst[i + 1] = clampByte(src[i + 1] * 0.78 + 56);
          dst[i + 2] = clampByte(src[i + 2] * 0.8 + 68);
        }
      });
      return;
    }

    case 'col_color_cycle': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const deg = (t * 140) % 360;
      ctx.save();
      ctx.globalAlpha = ratio;
      ctx.filter = `hue-rotate(${deg.toFixed(1)}deg) saturate(1.25)`;
      ctx.drawImage(snap, 0, 0, w, h);
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    // =========================================================================
    // 7. LIGHT (12)
    // =========================================================================
    case 'lgt_sun_flare': {
      const fx = w * (0.2 + 0.15 * Math.sin(t * 0.9));
      const fy = h * 0.22;
      const r = minEdge * (0.55 + spNorm * 0.3);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createRadialGradient(fx, fy, 0, fx, fy, r);
      grad.addColorStop(0, `rgba(255, 251, 235, ${0.9 * ratio})`);
      grad.addColorStop(0.25, `rgba(251, 191, 36, ${0.65 * ratio})`);
      grad.addColorStop(0.65, `rgba(234, 88, 12, ${0.24 * ratio})`);
      grad.addColorStop(1, 'rgba(234, 88, 12, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Subtle lens ring
      ctx.strokeStyle = `rgba(253, 224, 71, ${0.22 * ratio})`;
      ctx.lineWidth = Math.max(2, minEdge * 0.01);
      ctx.beginPath();
      ctx.arc(w * 0.65, h * 0.68, minEdge * 0.12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      return;
    }

    case 'lgt_rainbow_prism': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createLinearGradient(0, 0, w, h * (0.6 + spNorm * 0.4));
      grad.addColorStop(0, `rgba(244,63,94,${0.48 * ratio})`);
      grad.addColorStop(0.25, `rgba(245,158,11,${0.36 * ratio})`);
      grad.addColorStop(0.5, `rgba(34,197,94,${0.28 * ratio})`);
      grad.addColorStop(0.75, `rgba(56,189,248,${0.42 * ratio})`);
      grad.addColorStop(1, `rgba(168,85,247,${0.48 * ratio})`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_light_sweep': {
      const pos = ((t * 0.55) % 1.6) - 0.3;
      const cx = w * pos;
      const bw = w * 0.28;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createLinearGradient(cx - bw, 0, cx + bw, h);
      grad.addColorStop(0, 'rgba(255,255,255,0)');
      grad.addColorStop(0.5, `rgba(248, 250, 252, ${0.75 * ratio})`);
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_bokeh_orbs': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      for (let i = 0; i < 14; i++) {
        const px = ((prng(i * 11 + 1) + t * 0.04 * (i % 2 === 0 ? 1 : -1) + 2) % 1) * w;
        const py = ((prng(i * 23 + 3) + Math.sin(t + i) * 0.04 + 2) % 1) * h;
        const r = minEdge * (0.04 + prng(i * 7) * 0.07);
        const grad = ctx.createRadialGradient(px, py, 0, px, py, r);
        const warm = i % 3 === 0 ? '251,191,36' : i % 3 === 1 ? '251,146,60' : '254,240,138';
        grad.addColorStop(0, `rgba(${warm}, ${0.42 * ratio})`);
        grad.addColorStop(0.75, `rgba(${warm}, ${0.28 * ratio})`);
        grad.addColorStop(1, `rgba(${warm}, 0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'lgt_disco_strobe': {
      const idx = Math.floor(t * 4) % 4;
      const palette = [
        'rgba(236,72,153,',
        'rgba(59,130,246,',
        'rgba(168,85,247,',
        'rgba(34,211,238,',
      ];
      const col = palette[idx];
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const pulse = 0.35 + 0.35 * Math.abs(Math.sin(t * 8));
      const grad = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, minEdge * 0.75);
      grad.addColorStop(0, `${col}${pulse * ratio})`);
      grad.addColorStop(1, `${col}0)`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_spotlight': {
      drawVignette(ctx, w, h, 0.14 + spNorm * 0.24, 0.88 * ratio);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const beam = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, minEdge * 0.42);
      beam.addColorStop(0, `rgba(255, 250, 220, ${0.26 * ratio})`);
      beam.addColorStop(1, 'rgba(255, 250, 220, 0)');
      ctx.fillStyle = beam;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_halo_bloom': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(3, minEdge * (0.025 + spNorm * 0.035));
      const glow = renderHighlightGlowCanvas(snap, pool, px, 165, [1.2, 1.14, 0.96]);
      if (!glow) return;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.88 * ratio;
      ctx.drawImage(glow, 0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_sunset_leak': {
      const pulse = 0.75 + 0.25 * Math.sin(t * 1.8);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createRadialGradient(w * 0.92, h * 0.45, 0, w * 0.92, h * 0.45, w * 0.55);
      grad.addColorStop(0, `rgba(251, 146, 60, ${0.92 * ratio * pulse})`);
      grad.addColorStop(0.45, `rgba(239, 68, 68, ${0.46 * ratio * pulse})`);
      grad.addColorStop(1, 'rgba(239, 68, 68, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_moonlight': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const grad = ctx.createRadialGradient(w * 0.5, 0, 0, w * 0.5, 0, h * 0.85);
      grad.addColorStop(0, `rgba(186, 230, 253, ${0.52 * ratio})`);
      grad.addColorStop(0.6, `rgba(56, 189, 248, ${0.22 * ratio})`);
      grad.addColorStop(1, 'rgba(30, 58, 138, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_starburst': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      for (let i = 0; i < 6; i++) {
        const sx = prng(i * 19 + 5) * w * 0.8 + w * 0.1;
        const sy = prng(i * 29 + 7) * h * 0.75 + h * 0.12;
        const size = minEdge * (0.08 + 0.04 * Math.sin(t * 3 + i)) * ratio;
        ctx.strokeStyle = `rgba(255, 253, 224, ${0.72 * ratio})`;
        ctx.lineWidth = Math.max(1.5, minEdge * 0.005);
        ctx.beginPath();
        ctx.moveTo(sx - size, sy);
        ctx.lineTo(sx + size, sy);
        ctx.moveTo(sx, sy - size);
        ctx.lineTo(sx, sy + size);
        ctx.stroke();

        const dot = ctx.createRadialGradient(sx, sy, 0, sx, sy, size * 0.45);
        dot.addColorStop(0, `rgba(255,255,255,${0.8 * ratio})`);
        dot.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = dot;
        ctx.beginPath();
        ctx.arc(sx, sy, size * 0.45, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'lgt_neon_rim': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const border = Math.max(8, minEdge * (0.06 + spNorm * 0.08));
      const gL = ctx.createLinearGradient(0, 0, border, 0);
      gL.addColorStop(0, `rgba(6, 182, 212, ${0.82 * ratio})`);
      gL.addColorStop(1, 'rgba(6, 182, 212, 0)');
      ctx.fillStyle = gL;
      ctx.fillRect(0, 0, border, h);

      const gR = ctx.createLinearGradient(w, 0, w - border, 0);
      gR.addColorStop(0, `rgba(236, 72, 153, ${0.82 * ratio})`);
      gR.addColorStop(1, 'rgba(236, 72, 153, 0)');
      ctx.fillStyle = gR;
      ctx.fillRect(w - border, 0, border, h);
      ctx.restore();
      return;
    }

    case 'lgt_studio_ring': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const ring = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, minEdge * 0.6);
      ring.addColorStop(0, `rgba(255, 255, 255, ${0.32 * ratio})`);
      ring.addColorStop(0.7, `rgba(226, 232, 240, ${0.14 * ratio})`);
      ring.addColorStop(1, 'rgba(226, 232, 240, 0)');
      ctx.fillStyle = ring;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_neon_tunnel': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const rings = 5;
      for (let i = 0; i < rings; i++) {
        const phase = ((t * 0.55 + i / rings) % 1);
        const r = phase * minEdge * 0.72;
        const alpha = Math.sin(phase * Math.PI) * 0.65 * ratio;
        const col = i % 2 === 0 ? `rgba(217,70,239,${alpha})` : `rgba(34,211,238,${alpha})`;
        ctx.strokeStyle = col;
        ctx.lineWidth = Math.max(2, minEdge * (0.012 + phase * 0.015));
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, r, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
      return;
    }

    case 'lgt_lens_flare_pro': {
      const fx = w * (0.24 + 0.52 * (0.5 + 0.5 * Math.sin(t * 0.75)));
      const fy = h * (0.28 + 0.16 * Math.cos(t * 0.55));
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const sun = ctx.createRadialGradient(fx, fy, 0, fx, fy, minEdge * 0.45);
      sun.addColorStop(0, `rgba(255,255,255,${0.9 * ratio})`);
      sun.addColorStop(0.18, `rgba(253,224,71,${0.55 * ratio})`);
      sun.addColorStop(0.55, `rgba(249,115,22,${0.22 * ratio})`);
      sun.addColorStop(1, 'rgba(249,115,22,0)');
      ctx.fillStyle = sun;
      ctx.fillRect(0, 0, w, h);

      // Multi-blade optical streak
      const bar = ctx.createLinearGradient(0, fy - minEdge * 0.03, 0, fy + minEdge * 0.03);
      bar.addColorStop(0, 'rgba(56,189,248,0)');
      bar.addColorStop(0.5, `rgba(186,230,253,${0.65 * ratio})`);
      bar.addColorStop(1, 'rgba(56,189,248,0)');
      ctx.fillStyle = bar;
      ctx.fillRect(0, fy - minEdge * 0.03, w, minEdge * 0.06);

      // Hexagonal / circular aperture ghosts along diagonal through center
      const dx = w / 2 - fx;
      const dy = h / 2 - fy;
      const ghosts = [0.55, 0.95, 1.4, 1.85];
      ghosts.forEach((m, idx) => {
        const gx = fx + dx * m;
        const gy = fy + dy * m;
        const gr = minEdge * (0.045 + idx * 0.02);
        const col = idx % 2 === 0 ? '56,189,248' : '251,191,36';
        ctx.fillStyle = `rgba(${col},${0.22 * ratio})`;
        ctx.beginPath();
        ctx.arc(gx, gy, gr, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();
      return;
    }

    case 'lgt_prism_leak_pro': {
      const shift = Math.sin(t * 1.1) * w * 0.08;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const g1 = ctx.createRadialGradient(w * 0.1 + shift, h * 0.25, 0, w * 0.1 + shift, h * 0.25, w * 0.6);
      g1.addColorStop(0, `rgba(251,113,133,${0.78 * ratio})`);
      g1.addColorStop(0.45, `rgba(245,158,11,${0.36 * ratio})`);
      g1.addColorStop(1, 'rgba(245,158,11,0)');
      ctx.fillStyle = g1;
      ctx.fillRect(0, 0, w, h);

      const g2 = ctx.createRadialGradient(w * 0.88 - shift, h * 0.78, 0, w * 0.88 - shift, h * 0.78, w * 0.55);
      g2.addColorStop(0, `rgba(56,189,248,${0.55 * ratio})`);
      g2.addColorStop(0.5, `rgba(168,85,247,${0.28 * ratio})`);
      g2.addColorStop(1, 'rgba(168,85,247,0)');
      ctx.fillStyle = g2;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'lgt_cyber_bloom': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(3, minEdge * (0.022 + spNorm * 0.032));
      const thresh = 190 - spNorm * 45;
      const glow = renderHighlightGlowCanvas(snap, pool, px, thresh, [0.95, 0.75, 1.4]);
      if (!glow) return;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.92 * ratio;
      ctx.drawImage(glow, 0, 0, w, h);
      ctx.restore();
      return;
    }

    // =========================================================================
    // 8. BEAUTY (13)
    // =========================================================================
    case 'bty_skin_smooth': {
      applySelectiveSkinSmooth(targetCanvas, ctx, pool, ratio, spNorm, maxPixelDim, 1.04, 0);
      return;
    }

    case 'bty_glamour_glow': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(2, minEdge * 0.02);
      const glow = renderHighlightGlowCanvas(snap, pool, px, 150, [1.15, 1.05, 1.08]);
      if (glow) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.55 * ratio;
        ctx.drawImage(glow, 0, 0, w, h);
        ctx.restore();
      }
      return;
    }

    case 'bty_peach_warm': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.07 + 16);
          dst[i + 1] = clampByte(src[i + 1] * 1.03 + 9);
          dst[i + 2] = clampByte(src[i + 2] * 0.96 + 4);
        }
      });
      return;
    }

    case 'bty_rose_radiance': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.08 + 14);
          dst[i + 1] = clampByte(src[i + 1] * 1.0 + 4);
          dst[i + 2] = clampByte(src[i + 2] * 1.04 + 12);
        }
      });
      return;
    }

    case 'bty_studio_bright': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        const boost = 14 + spNorm * 22;
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.06 + boost);
          dst[i + 1] = clampByte(src[i + 1] * 1.06 + boost);
          dst[i + 2] = clampByte(src[i + 2] * 1.06 + boost);
        }
      });
      return;
    }

    case 'bty_airbrush': {
      applySelectiveSkinSmooth(targetCanvas, ctx, pool, ratio, spNorm, maxPixelDim, 1.06, 0.45);
      return;
    }

    case 'bty_pearl_glow': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.08 + 18);
          dst[i + 1] = clampByte(src[i + 1] * 1.08 + 19);
          dst[i + 2] = clampByte(src[i + 2] * 1.1 + 22);
        }
      });
      return;
    }

    case 'bty_golden_tan': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 1.1 + 14);
          dst[i + 1] = clampByte(src[i + 1] * 1.0 + 4);
          dst[i + 2] = clampByte(src[i + 2] * 0.82);
        }
      });
      return;
    }

    case 'bty_angel_halo': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const px = Math.max(3, minEdge * 0.024);
      const glow = renderHighlightGlowCanvas(snap, pool, px, 145, [1.2, 1.12, 1.15]);
      if (glow) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.65 * ratio;
        ctx.drawImage(glow, 0, 0, w, h);
        ctx.restore();
      }
      return;
    }

    case 'bty_crisp_detail': {
      const strength = (0.45 + spNorm * 0.85) * ratio;
      runPixelTransform(targetCanvas, ctx, pool, 1, 520, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const up = ((y - 1) * pw + x) * 4;
            const dn = ((y + 1) * pw + x) * 4;
            const lf = (y * pw + (x - 1)) * 4;
            const rt = (y * pw + (x + 1)) * 4;
            for (let c = 0; c < 3; c++) {
              const lap = 4 * src[idx + c] - src[up + c] - src[dn + c] - src[lf + c] - src[rt + c];
              dst[idx + c] = clampByte(src[idx + c] + lap * strength * 0.45);
            }
          }
        }
      });
      return;
    }

    case 'bty_velvet_matte': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, maxPixelDim, (src, dst) => {
        for (let i = 0; i < src.length; i += 4) {
          dst[i] = clampByte(src[i] * 0.88 + 20);
          dst[i + 1] = clampByte(src[i + 1] * 0.88 + 17);
          dst[i + 2] = clampByte(src[i + 2] * 0.88 + 18);
        }
      });
      return;
    }

    case 'bty_satin_diffuse': {
      applySelectiveSkinSmooth(targetCanvas, ctx, pool, ratio * 0.72, spNorm, maxPixelDim, 1.05, 0.2);
      return;
    }

    case 'bty_hollywood_glam': {
      applySelectiveSkinSmooth(targetCanvas, ctx, pool, ratio * 0.75, spNorm, maxPixelDim, 1.05, 0.15);
      const snap = pool.getWorkB(w, h);
      if (snapshotTo(targetCanvas, snap)) {
        const glow = renderHighlightGlowCanvas(snap, pool, Math.max(2, minEdge * 0.022), 160, [1.22, 1.06, 0.92]);
        if (glow) {
          ctx.save();
          ctx.globalCompositeOperation = 'screen';
          ctx.globalAlpha = 0.55 * ratio;
          ctx.drawImage(glow, 0, 0, w, h);
          ctx.restore();
        }
      }
      drawVignette(ctx, w, h, 0.35, 0.32 * ratio, '24,14,18');
      return;
    }

    // =========================================================================
    // 9. AI (12)
    // =========================================================================
    case 'ai_neon_edges': {
      const edgeGain = 1.2 + spNorm * 1.4;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const rIdx = (y * pw + x + 1) * 4;
            const bIdx = ((y + 1) * pw + x) * 4;
            const l0 = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
            const lr = 0.299 * src[rIdx] + 0.587 * src[rIdx + 1] + 0.114 * src[rIdx + 2];
            const lb = 0.299 * src[bIdx] + 0.587 * src[bIdx + 1] + 0.114 * src[bIdx + 2];
            const mag = Math.min(255, (Math.abs(l0 - lr) + Math.abs(l0 - lb)) * 2.2 * edgeGain);
            const u = x / pw;
            dst[idx] = clampByte(mag * (0.2 + 0.8 * u));
            dst[idx + 1] = clampByte(mag * (0.9 - 0.55 * u));
            dst[idx + 2] = clampByte(mag);
          }
        }
      });
      return;
    }

    case 'ai_comic_ink': {
      const inkThresh = 65 - spNorm * 25;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const rIdx = (y * pw + x + 1) * 4;
            const bIdx = ((y + 1) * pw + x) * 4;
            const l0 = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
            const lr = 0.299 * src[rIdx] + 0.587 * src[rIdx + 1] + 0.114 * src[rIdx + 2];
            const lb = 0.299 * src[bIdx] + 0.587 * src[bIdx + 1] + 0.114 * src[bIdx + 2];
            const edge = Math.abs(l0 - lr) + Math.abs(l0 - lb);
            if (edge > inkThresh) {
              dst[idx] = 14;
              dst[idx + 1] = 14;
              dst[idx + 2] = 18;
            } else {
              dst[idx] = Math.round(src[idx] / 64) * 64;
              dst[idx + 1] = Math.round(src[idx + 1] / 64) * 64;
              dst[idx + 2] = Math.round(src[idx + 2] / 64) * 64;
            }
          }
        }
      });
      return;
    }

    case 'ai_pencil_sketch': {
      const gain = 2.0 + spNorm * 2.2;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const rIdx = (y * pw + x + 1) * 4;
            const bIdx = ((y + 1) * pw + x) * 4;
            const l0 = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
            const lr = 0.299 * src[rIdx] + 0.587 * src[rIdx + 1] + 0.114 * src[rIdx + 2];
            const lb = 0.299 * src[bIdx] + 0.587 * src[bIdx + 1] + 0.114 * src[bIdx + 2];
            const edge = (Math.abs(l0 - lr) + Math.abs(l0 - lb)) * gain;
            const tone = clampByte(246 - edge - (255 - l0) * 0.18);
            dst[idx] = tone;
            dst[idx + 1] = clampByte(tone - 3);
            dst[idx + 2] = clampByte(tone - 8);
          }
        }
      });
      return;
    }

    case 'ai_charcoal_draw': {
      const gain = 2.2 + spNorm * 2.5;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const rIdx = (y * pw + x + 1) * 4;
            const bIdx = ((y + 1) * pw + x) * 4;
            const l0 = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
            const lr = 0.299 * src[rIdx] + 0.587 * src[rIdx + 1] + 0.114 * src[rIdx + 2];
            const lb = 0.299 * src[bIdx] + 0.587 * src[bIdx + 1] + 0.114 * src[bIdx + 2];
            const edge = Math.min(255, (Math.abs(l0 - lr) + Math.abs(l0 - lb)) * gain);
            const v = clampByte(20 + edge * 0.9 + l0 * 0.15);
            dst[idx] = v;
            dst[idx + 1] = v;
            dst[idx + 2] = clampByte(v + 4);
          }
        }
      });
      return;
    }

    case 'ai_oil_paint': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const quant = 32 + Math.round(spNorm * 32);
      runPixelTransform(targetCanvas, ctx, pool, ratio, 420, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const nb = (y * pw + Math.max(0, x - 2)) * 4;
            const r = (src[idx] * 2 + src[nb]) / 3;
            const g = (src[idx + 1] * 2 + src[nb + 1]) / 3;
            const b = (src[idx + 2] * 2 + src[nb + 2]) / 3;
            dst[idx] = clampByte(Math.round(r / quant) * quant);
            dst[idx + 1] = clampByte(Math.round(g / quant) * quant);
            dst[idx + 2] = clampByte(Math.round(b / quant) * quant);
          }
        }
      });
      return;
    }

    case 'ai_night_vision': {
      const gain = 1.25 + spNorm * 0.8;
      const seed = Math.floor(t * 20);
      runPixelTransform(targetCanvas, ctx, pool, ratio, 460, (src, dst, pw, ph) => {
        for (let y = 0; y < ph; y++) {
          const scan = y % 3 === 0 ? 0.85 : 1.0;
          for (let x = 0; x < pw; x++) {
            const idx = (y * pw + x) * 4;
            const lum = (0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2]) * gain;
            const noise = (prng((x * 11 + y * 37 + seed) % 7919) - 0.5) * 28;
            const gVal = clampByte((lum + noise) * scan);
            dst[idx] = clampByte(gVal * 0.18);
            dst[idx + 1] = gVal;
            dst[idx + 2] = clampByte(gVal * 0.25);
          }
        }
      });
      drawVignette(ctx, w, h, 0.35, 0.82 * ratio, '0,15,5');
      return;
    }

    case 'ai_xray_scan': {
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const rIdx = (y * pw + x + 1) * 4;
            const lum = 0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2];
            const lr = 0.299 * src[rIdx] + 0.587 * src[rIdx + 1] + 0.114 * src[rIdx + 2];
            const inv = 255 - lum;
            const edge = Math.abs(lum - lr) * (1.2 + spNorm * 1.4);
            dst[idx] = clampByte(inv * 0.35 + edge * 0.4);
            dst[idx + 1] = clampByte(inv * 0.82 + edge);
            dst[idx + 2] = clampByte(inv + edge);
          }
        }
      });
      return;
    }

    case 'ai_emboss_3d': {
      const depth = 1.2 + spNorm * 2.0;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 480, (src, dst, pw, ph) => {
        for (let y = 1; y < ph - 1; y++) {
          for (let x = 1; x < pw - 1; x++) {
            const idx = (y * pw + x) * 4;
            const tl = ((y - 1) * pw + (x - 1)) * 4;
            const br = ((y + 1) * pw + (x + 1)) * 4;
            const dr = (src[tl] - src[br]) * depth + 128;
            const dg = (src[tl + 1] - src[br + 1]) * depth + 128;
            const db = (src[tl + 2] - src[br + 2]) * depth + 128;
            const l = 0.299 * dr + 0.587 * dg + 0.114 * db;
            dst[idx] = clampByte(l);
            dst[idx + 1] = clampByte(l);
            dst[idx + 2] = clampByte(l);
          }
        }
      });
      return;
    }

    case 'ai_hologram': {
      const drift = Math.sin(t * 7) * w * 0.008 * ratio;
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      runPixelTransform(targetCanvas, ctx, pool, ratio, 460, (src, dst, pw, ph) => {
        for (let y = 0; y < ph; y++) {
          const line = y % 3 === 0 ? 0.65 : 1.08;
          for (let x = 0; x < pw; x++) {
            const idx = (y * pw + x) * 4;
            const lum = (0.299 * src[idx] + 0.587 * src[idx + 1] + 0.114 * src[idx + 2]) * line;
            dst[idx] = clampByte(lum * 0.22);
            dst[idx + 1] = clampByte(lum * 0.92 + 18);
            dst[idx + 2] = clampByte(lum * 1.15 + 32);
          }
        }
      });
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.25 * ratio;
      ctx.drawImage(snap, drift, 0, w, h);
      ctx.restore();
      return;
    }

    case 'ai_pop_art': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const hw = w / 2;
      const hh = h / 2;
      const quads: Array<{ x: number; y: number; filter: string }> = [
        { x: 0, y: 0, filter: 'contrast(1.6) saturate(2.2) hue-rotate(-25deg)' },
        { x: hw, y: 0, filter: 'contrast(1.6) saturate(2.2) hue-rotate(85deg)' },
        { x: 0, y: hh, filter: 'contrast(1.6) saturate(2.2) hue-rotate(190deg)' },
        { x: hw, y: hh, filter: 'contrast(1.6) saturate(2.2) hue-rotate(285deg)' },
      ];
      ctx.save();
      ctx.globalAlpha = ratio;
      for (const q of quads) {
        ctx.filter = q.filter;
        ctx.drawImage(snap, q.x, q.y, hw, hh);
      }
      ctx.filter = 'none';
      ctx.restore();
      return;
    }

    case 'ai_kaleidoscope': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const hw = w / 2;
      const hh = h / 2;
      const shiftX = Math.sin(t * 1.2) * w * 0.08 * spNorm;
      const srcW = Math.max(8, hw);
      const srcH = Math.max(8, hh);

      const tile = pool.getWorkC(hw, hh);
      const tctx = tile.getContext('2d');
      if (!tctx) return;
      tctx.clearRect(0, 0, hw, hh);
      tctx.drawImage(snap, clampByteLike(Math.round(shiftX), Math.max(0, w - srcW)), 0, srcW, srcH, 0, 0, hw, hh);

      ctx.save();
      ctx.globalAlpha = ratio;
      // Top-left
      ctx.drawImage(tile, 0, 0, hw, hh);
      // Top-right mirrored X
      ctx.save();
      ctx.translate(w, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(tile, 0, 0, hw, hh);
      ctx.restore();
      // Bottom-left mirrored Y
      ctx.save();
      ctx.translate(0, h);
      ctx.scale(1, -1);
      ctx.drawImage(tile, 0, 0, hw, hh);
      ctx.restore();
      // Bottom-right mirrored X & Y
      ctx.save();
      ctx.translate(w, h);
      ctx.scale(-1, -1);
      ctx.drawImage(tile, 0, 0, hw, hh);
      ctx.restore();
      ctx.restore();
      return;
    }

    case 'ai_depth_portrait': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const blurred = pool.getWorkC(w, h);
      const bctx = blurred.getContext('2d');
      if (!bctx) return;
      const px = Math.max(3, minEdge * (0.02 + spNorm * 0.03) * ratio);
      bctx.clearRect(0, 0, w, h);
      bctx.filter = `blur(${px.toFixed(1)}px)`;
      bctx.drawImage(snap, -px, -px, w + px * 2, h + px * 2);
      bctx.filter = 'none';

      // Keep foreground portrait ellipse crisp
      bctx.save();
      bctx.globalCompositeOperation = 'destination-out';
      const grad = bctx.createRadialGradient(
        w * 0.5,
        h * 0.45,
        minEdge * 0.2,
        w * 0.5,
        h * 0.45,
        minEdge * 0.5
      );
      grad.addColorStop(0, 'rgba(0,0,0,1)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      bctx.fillStyle = grad;
      bctx.fillRect(0, 0, w, h);
      bctx.restore();

      ctx.drawImage(blurred, 0, 0, w, h);
      return;
    }

    // =========================================================================
    // 10. MAGIC (9)
    // =========================================================================
    case 'mag_fireflies': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 22;
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 13 + 2) + Math.sin(t * 0.7 + i * 1.9) * 0.08 + 2) % 1) * w;
        const py = ((prng(i * 29 + 5) - t * 0.045 * (0.5 + prng(i)) + 10) % 1) * h;
        const flicker = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * 4.2 + i * 2.1));
        const r = minEdge * (0.014 + prng(i * 7) * 0.028);
        const grad = ctx.createRadialGradient(px, py, 0, px, py, r);
        grad.addColorStop(0, `rgba(255,251,235,${0.95 * flicker * ratio})`);
        grad.addColorStop(0.3, `rgba(251,191,36,${0.7 * flicker * ratio})`);
        grad.addColorStop(1, 'rgba(245,158,11,0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'mag_stardust': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 28;
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 17 + 9) + t * 0.03 * (i % 2 === 0 ? 1 : -1) + 5) % 1) * w;
        const py = ((prng(i * 31 + 11) + t * 0.02 + 5) % 1) * h;
        const twinkle = Math.pow(0.5 + 0.5 * Math.sin(t * 6.5 + i * 1.7), 2);
        const size = minEdge * (0.015 + prng(i * 11) * 0.025) * (0.6 + 0.6 * twinkle);
        const hue = i % 3 === 0 ? '254,240,138' : i % 3 === 1 ? '240,171,252' : '125,211,252';
        ctx.strokeStyle = `rgba(${hue},${0.88 * twinkle * ratio})`;
        ctx.lineWidth = Math.max(1, minEdge * 0.003);
        ctx.beginPath();
        ctx.moveTo(px - size, py);
        ctx.lineTo(px + size, py);
        ctx.moveTo(px, py - size);
        ctx.lineTo(px, py + size);
        ctx.stroke();

        const g = ctx.createRadialGradient(px, py, 0, px, py, size * 0.7);
        g.addColorStop(0, `rgba(255,255,255,${0.9 * twinkle * ratio})`);
        g.addColorStop(1, `rgba(${hue},0)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(px, py, size * 0.7, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'mag_galaxy_nebula': {
      const shift = Math.sin(t * 0.85) * w * 0.14;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const g1 = ctx.createRadialGradient(w * 0.3 + shift, h * 0.28, 0, w * 0.3 + shift, h * 0.28, w * 0.65);
      g1.addColorStop(0, `rgba(168,85,247,${0.56 * ratio})`);
      g1.addColorStop(0.5, `rgba(59,130,246,${0.32 * ratio})`);
      g1.addColorStop(1, 'rgba(59,130,246,0)');
      ctx.fillStyle = g1;
      ctx.fillRect(0, 0, w, h);

      const g2 = ctx.createRadialGradient(w * 0.72 - shift, h * 0.7, 0, w * 0.72 - shift, h * 0.7, w * 0.6);
      g2.addColorStop(0, `rgba(34,211,238,${0.48 * ratio})`);
      g2.addColorStop(0.5, `rgba(236,72,153,${0.26 * ratio})`);
      g2.addColorStop(1, 'rgba(236,72,153,0)');
      ctx.fillStyle = g2;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'mag_snowfall': {
      ctx.save();
      const count = 42;
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 19 + 3) + Math.sin(t * 1.4 + i) * 0.03 + 4) % 1) * w;
        const py = ((prng(i * 23 + 7) + t * (0.14 + prng(i) * 0.14)) % 1) * h;
        const r = minEdge * (0.004 + prng(i * 5) * 0.009);
        const alpha = (0.45 + prng(i * 13) * 0.45) * ratio;
        const g = ctx.createRadialGradient(px, py, 0, px, py, r * 1.6);
        g.addColorStop(0, `rgba(255,255,255,${alpha})`);
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(px, py, r * 1.6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'mag_rain_streak': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 48;
      const slant = w * 0.025;
      const len = h * (0.08 + spNorm * 0.08);
      ctx.lineCap = 'round';
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 29 + 1) + t * 0.06) % 1) * w;
        const py = ((prng(i * 37 + 4) + t * (0.65 + prng(i) * 0.55)) % 1.15 - 0.1) * h;
        ctx.strokeStyle = `rgba(186,230,253,${(0.25 + prng(i * 3) * 0.35) * ratio})`;
        ctx.lineWidth = Math.max(1, minEdge * 0.0022);
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px - slant, py + len);
        ctx.stroke();
      }
      ctx.restore();
      return;
    }

    case 'mag_ember_sparks': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 30;
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 41 + 2) + Math.sin(t * 2.4 + i) * 0.05 + 6) % 1) * w;
        const py = ((prng(i * 17 + 8) - t * (0.28 + prng(i) * 0.25) + 12) % 1) * h;
        const r = minEdge * (0.007 + prng(i * 7) * 0.015);
        const g = ctx.createRadialGradient(px, py, 0, px, py, r * 1.7);
        g.addColorStop(0, `rgba(254,240,138,${0.95 * ratio})`);
        g.addColorStop(0.45, `rgba(249,115,22,${0.7 * ratio})`);
        g.addColorStop(1, 'rgba(220,38,38,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(px, py, r * 1.7, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    case 'mag_lightning_arc': {
      const cycle = (t * 0.9) % 1;
      const flash = cycle < 0.25 ? Math.sin((cycle / 0.25) * Math.PI) : 0;
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      if (flash > 0.05) {
        ctx.fillStyle = `rgba(224,242,254,${0.32 * flash * ratio})`;
        ctx.fillRect(0, 0, w, h);
      }
      const tick = Math.floor(t * 6);
      const startX = w * (0.22 + prng(tick) * 0.56);
      ctx.strokeStyle = `rgba(224,242,254,${(0.45 + 0.55 * flash) * ratio})`;
      ctx.lineWidth = Math.max(1.5, minEdge * 0.005);
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = Math.max(6, minEdge * 0.03);
      ctx.beginPath();
      let cx = startX;
      let cy = 0;
      ctx.moveTo(cx, cy);
      for (let s = 1; s <= 7; s++) {
        cx += (prng(tick * 13 + s * 7) - 0.5) * w * 0.14;
        cy = (s / 7) * h * 0.85;
        ctx.lineTo(cx, cy);
      }
      ctx.stroke();
      ctx.restore();
      return;
    }

    case 'mag_prism_shimmer': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 16;
      for (let i = 0; i < count; i++) {
        const px = prng(i * 19 + 5) * w;
        const py = prng(i * 23 + 11) * h;
        const s = minEdge * (0.04 + 0.03 * Math.sin(t * 3 + i));
        const a = (0.3 + 0.35 * Math.sin(t * 4 + i * 2)) * ratio;
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(t * 0.6 + i);
        ctx.fillStyle = i % 2 === 0 ? `rgba(34,211,238,${a})` : `rgba(244,114,182,${a})`;
        ctx.beginPath();
        ctx.moveTo(0, -s);
        ctx.lineTo(s * 0.55, 0);
        ctx.lineTo(0, s);
        ctx.lineTo(-s * 0.55, 0);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();
      return;
    }

    case 'mag_heart_float': {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const count = 16;
      for (let i = 0; i < count; i++) {
        const px = ((prng(i * 17 + 3) + Math.sin(t * 1.4 + i) * 0.05 + 4) % 1) * w;
        const py = ((prng(i * 29 + 9) - t * (0.14 + prng(i) * 0.1) + 10) % 1) * h;
        const s = minEdge * (0.022 + prng(i * 7) * 0.022);
        const alpha = (0.45 + 0.35 * Math.sin(t * 2.5 + i)) * ratio;
        ctx.fillStyle = `rgba(251,113,133,${alpha})`;
        ctx.beginPath();
        ctx.moveTo(px, py + s * 0.35);
        ctx.bezierCurveTo(px - s, py - s * 0.45, px - s * 1.15, py + s * 0.65, px, py + s * 1.25);
        ctx.bezierCurveTo(px + s * 1.15, py + s * 0.65, px + s, py - s * 0.45, px, py + s * 0.35);
        ctx.fill();
      }
      ctx.restore();
      return;
    }

    // =========================================================================
    // 11. TRANSITION FX (9)
    // =========================================================================
    case 'trn_flash_white': {
      const curveRate = 1 + spNorm * 2.5;
      const p = clamp01(prog * curveRate);
      const flash = Math.pow(1 - Math.abs(p * 2 - 1), 1.6);
      const alpha = clamp01(flash * 0.95 * ratio);
      ctx.save();
      ctx.fillStyle = `rgba(255,255,255,${alpha})`;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'trn_black_fade': {
      const curveRate = 1 + spNorm * 2.5;
      const p = clamp01(prog * curveRate);
      const darkness = Math.pow(1 - p, 1.4) * ratio;
      ctx.save();
      ctx.fillStyle = `rgba(0,0,0,${clamp01(darkness)})`;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'trn_zoom_in_punch': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const curve = Math.sin(clamp01(prog) * Math.PI);
      const zoom = 1 + curve * (0.28 + spNorm * 0.32) * ratio;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case 'trn_zoom_out_drop': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const ease = 1 - Math.pow(1 - clamp01(prog), 3);
      const zoom = 1 + (1 - ease) * (0.45 + spNorm * 0.4) * ratio;
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      return;
    }

    case 'trn_whip_pan_left': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const curve = Math.sin(clamp01(prog) * Math.PI);
      const span = w * (0.12 + spNorm * 0.22) * curve * ratio;
      const taps = 9;
      ctx.save();
      for (let i = 0; i < taps; i++) {
        const off = -(i / (taps - 1)) * span;
        ctx.globalAlpha = 1 / (i + 1);
        ctx.drawImage(snap, off, 0, w, h);
      }
      ctx.restore();
      return;
    }

    case 'trn_iris_circle': {
      const open = clamp01(prog * (1.15 + spNorm * 1.3));
      const maxR = Math.hypot(w / 2, h / 2);
      const innerR = maxR * open;
      const outerR = innerR + minEdge * 0.14;
      ctx.save();
      const grad = ctx.createRadialGradient(w / 2, h / 2, innerR * 0.85, w / 2, h / 2, outerR);
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(1, `rgba(0,0,0,${0.98 * ratio})`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'trn_shutter_split': {
      const p = clamp01(prog * (1.2 + spNorm * 1.4));
      const closeFactor = Math.sin(p * Math.PI);
      const cover = Math.round((h * 0.48) * closeFactor * ratio);
      if (cover > 0) {
        ctx.save();
        ctx.fillStyle = '#05070a';
        ctx.fillRect(0, 0, w, cover);
        ctx.fillRect(0, h - cover, w, cover);
        ctx.restore();
      }
      return;
    }

    case 'trn_burn_flash': {
      const p = clamp01(prog * (1.2 + spNorm * 1.2));
      const pulse = Math.sin(p * Math.PI);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const g = ctx.createRadialGradient(w * 0.35, h * 0.45, 0, w * 0.35, h * 0.45, w * 0.85);
      g.addColorStop(0, `rgba(254,240,138,${0.95 * pulse * ratio})`);
      g.addColorStop(0.42, `rgba(249,115,22,${0.72 * pulse * ratio})`);
      g.addColorStop(1, 'rgba(220,38,38,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
      return;
    }

    case 'trn_shake_impact': {
      const snap = pool.getWorkB(w, h);
      if (!snapshotTo(targetCanvas, snap)) return;
      const decay = Math.pow(Math.max(0, 1 - prog * (0.85 + spNorm * 0.6)), 1.5);
      const amp = minEdge * 0.055 * decay * ratio;
      const dx = Math.sin(t * 38) * amp;
      const dy = Math.cos(t * 32) * amp;
      const zoom = 1 + 0.08 * decay * ratio;
      ctx.save();
      ctx.translate(w / 2 + dx, h / 2 + dy);
      ctx.scale(zoom, zoom);
      ctx.drawImage(snap, -w / 2, -h / 2, w, h);
      ctx.restore();
      if (decay > 0.25) {
        drawChannelSplit(targetCanvas, ctx, pool, -dx * 0.5, 0, dx * 0.5, 0, 0.7 * decay);
      }
      return;
    }

    default:
      return;
  }
}

function clampByteLike(val: number, max: number): number {
  return val < 0 ? 0 : val > max ? max : val;
}

/**
 * Renders all enabled effects active at `sourceTime` onto targetCanvas sequentially.
 */
export function applyVideoEffectsToCanvas(
  targetCanvas: HTMLCanvasElement,
  effects: VideoEffectLayer[] | undefined,
  sourceTime: number,
  pool: EffectsRenderPool,
  maxPixelDim = 760
): void {
  if (!effects || effects.length === 0) return;
  for (const fx of effects) {
    if (!fx.enabled || fx.intensity <= 0) continue;
    if (sourceTime < fx.startTime - 0.02 || sourceTime > fx.endTime + 0.02) continue;
    const span = Math.max(0.05, fx.endTime - fx.startTime);
    const layerProgress = clamp01((sourceTime - fx.startTime) / span);
    applySingleVideoEffect(
      targetCanvas,
      fx.effectId,
      fx.intensity,
      fx.speed,
      sourceTime,
      pool,
      maxPixelDim,
      layerProgress
    );
  }
}

/**
 * Generates an authentic live preview thumbnail data URL for an effect card using the user's video/photo frame.
 */
export function renderEffectThumbnailDataUrl(
  sourceImage: HTMLImageElement | null,
  effectId: VideoEffectId,
  swatch: [string, string],
  pool: EffectsRenderPool,
  thumbW = 112,
  thumbH = 64
): string {
  const c = pool.getWorkA(thumbW, thumbH);
  const ctx = c.getContext('2d');
  if (!ctx) return '';

  ctx.clearRect(0, 0, thumbW, thumbH);
  if (sourceImage && sourceImage.complete && sourceImage.naturalWidth > 0) {
    const imgRatio = sourceImage.naturalWidth / Math.max(1, sourceImage.naturalHeight);
    const boxRatio = thumbW / thumbH;
    let dw = thumbW;
    let dh = thumbH;
    let dx = 0;
    let dy = 0;
    if (imgRatio > boxRatio) {
      dh = thumbH;
      dw = thumbH * imgRatio;
      dx = (thumbW - dw) / 2;
    } else {
      dw = thumbW;
      dh = thumbW / imgRatio;
      dy = (thumbH - dh) / 2;
    }
    ctx.drawImage(sourceImage, dx, dy, dw, dh);
  } else {
    const g = ctx.createLinearGradient(0, 0, thumbW, thumbH);
    g.addColorStop(0, swatch[0]);
    g.addColorStop(1, swatch[1]);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, thumbW, thumbH);
  }

  applySingleVideoEffect(c, effectId, 90, 55, 0.85, pool, 140, 0.38);
  try {
    return c.toDataURL('image/jpeg', 0.78);
  } catch {
    return '';
  }
}
