export interface MeesamAndroidBridge {
  isAndroidApp?: () => boolean;
  saveBase64File?: (base64Data: string, fileName: string, mimeType: string) => boolean;
  showToast?: (message: string) => void;
}

declare global {
  interface Window {
    MeesamAndroid?: MeesamAndroidBridge;
    __MEESAM_API_BASE__?: string;
  }
}

export function isRunningInAndroidApp(): boolean {
  return Boolean(
    typeof window !== 'undefined' &&
      window.MeesamAndroid &&
      typeof window.MeesamAndroid.saveBase64File === 'function'
  );
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(new Error('Failed to encode file for Android storage.'));
    reader.readAsDataURL(blob);
  });
}

/**
 * Triggers a clean download on web browsers AND saves directly to
 * Downloads/MEESAM TECH/ when running inside the MEESAM TECH Android APK.
 */
export async function downloadMediaFile(params: {
  blob?: Blob;
  url: string;
  filename: string;
  mimeType: string;
}): Promise<void> {
  const { blob, url, filename, mimeType } = params;

  if (isRunningInAndroidApp() && window.MeesamAndroid?.saveBase64File) {
    try {
      const resolvedBlob = blob ?? (await (await fetch(url)).blob());
      const base64 = await blobToBase64(resolvedBlob);
      const saved = window.MeesamAndroid.saveBase64File(base64, filename, mimeType);
      if (saved) {
        return;
      }
    } catch {
      // Fall back to standard anchor click if bridge fails
    }
  }

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}
