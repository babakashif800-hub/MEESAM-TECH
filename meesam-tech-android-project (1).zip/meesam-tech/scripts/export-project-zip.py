#!/usr/bin/env python3
import os
import stat
import zipfile
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
OUT_ZIP = ROOT_DIR / "exports" / "meesam-tech-android-project.zip"

EXCLUDE_DIRS = {
    "node_modules",
    "dist",
    "exports",
    ".git",
    ".gradle",
    "build",
    "__pycache__",
    ".idea",
}

EXCLUDE_FILES = {
    ".DS_Store",
    "local.properties",
    "keystore.properties",
}

EXCLUDE_SUFFIXES = (".log", ".jks", ".keystore", ".apk", ".aab")


def should_skip_file(rel_path: Path) -> bool:
    name = rel_path.name
    if name in EXCLUDE_FILES or name.endswith(EXCLUDE_SUFFIXES):
        return True
    if name.startswith(".env") and name != ".env.example":
        return True
    parts = rel_path.parts
    if len(parts) >= 2 and parts[0] == "android" and parts[1] in {".gradle", "build"}:
        return True
    if len(parts) >= 3 and parts[0] == "android" and parts[1] == "app" and parts[2] == "build":
        return True
    return False


def main() -> None:
    OUT_ZIP.parent.mkdir(parents=True, exist_ok=True)
    tmp_zip = OUT_ZIP.with_suffix(".zip.tmp")
    count = 0

    with zipfile.ZipFile(tmp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as zf:
        for dirpath, dirnames, filenames in os.walk(ROOT_DIR):
            cur = Path(dirpath)
            rel_dir = cur.relative_to(ROOT_DIR)

            # Prune excluded directories in-place (preserving .github, .env.example, etc.)
            dirnames[:] = sorted(
                d
                for d in dirnames
                if d not in EXCLUDE_DIRS
                and not (rel_dir == Path("android") and d in {".gradle", "build"})
                and not (rel_dir == Path("android/app") and d == "build")
            )

            for fname in sorted(filenames):
                full_path = cur / fname
                rel_path = full_path.relative_to(ROOT_DIR)
                if should_skip_file(rel_path):
                    continue

                arcname = f"meesam-tech/{rel_path.as_posix()}"
                info = zipfile.ZipInfo.from_file(full_path, arcname=arcname)
                info.compress_type = zipfile.ZIP_DEFLATED
                if rel_path.as_posix() == "android/gradlew":
                    info.external_attr = (stat.S_IFREG | 0o755) << 16
                with open(full_path, "rb") as f:
                    zf.writestr(info, f.read())
                count += 1

    tmp_zip.replace(OUT_ZIP)
    size_mb = OUT_ZIP.stat().st_size / (1024 * 1024)
    print(f"Created {OUT_ZIP} ({count} files, {size_mb:.2f} MB)")


if __name__ == "__main__":
    main()
