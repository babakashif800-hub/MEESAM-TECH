import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'dist');
const androidWwwDir = path.join(rootDir, 'android', 'app', 'src', 'main', 'assets', 'www');

const shouldBuild = process.argv.includes('--build') || !fs.existsSync(distDir);

if (shouldBuild) {
  console.log('[android:sync] Building production web bundle...');
  execSync('npm run build', { cwd: rootDir, stdio: 'inherit' });
}

if (!fs.existsSync(distDir)) {
  console.error('[android:sync] Error: dist/ directory not found. Run "npm run build" first.');
  process.exit(1);
}

fs.rmSync(androidWwwDir, { recursive: true, force: true });
fs.mkdirSync(androidWwwDir, { recursive: true });
fs.cpSync(distDir, androidWwwDir, { recursive: true, force: true });

console.log(`[android:sync] Synced dist/ -> ${path.relative(rootDir, androidWwwDir)}`);
